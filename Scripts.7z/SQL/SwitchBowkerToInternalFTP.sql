/*
-- This is the sql to switch Bowker transfer endpoints to an internal ftp location.

--begin tran
--rollback
--commit
update ftp set ProtocolType = 1, HostName = 'ftp.ingrooves.com', PortNumber = '21', StartingDirectory = '/RetailersTestUploadNewDistro/Bowker/INscribe/INscribeMetadataAndCovers', UserName = 'ingroovestest', Password = 'ingrooves' from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name = 'Bowker Ftp for INscribe Digital Metadata and Cover' and c.ValidUntilUtc is null

update ftp set ProtocolType = 1, HostName = 'ftp.ingrooves.com', PortNumber = '21', StartingDirectory = '/RetailersTestUploadNewDistro/Bowker/Scholastic/', UserName = 'ingroovestest', Password = 'ingrooves' from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name = 'Bowker Ftp for Scholastic eBook' and c.ValidUntilUtc is null

update ftp set ProtocolType = 1, HostName = 'ftp.ingrooves.com', PortNumber = '21', StartingDirectory = '/RetailersTestUploadNewDistro/Bowker/Scholastic/Scholastic', UserName = 'ingroovestest', Password = 'ingrooves' from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name = 'Bowker Ftp for Scholastic Metadata and Cover' and c.ValidUntilUtc is null

update ftp set ProtocolType = 1, HostName = 'ftp.ingrooves.com', PortNumber = '21', StartingDirectory = '/RetailersTestUploadNewDistro/Bowker/INscribe/INscribeEbooks', UserName = 'ingroovestest', Password = 'ingrooves' from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name = 'Bowker Ftp for INscribe Digital eBook' and c.ValidUntilUtc is null
*/

/*
-- This is the sql to revert Bowker transfer endpoints back to the real production ftp server.

--begin tran
--rollback
--commit
update ftp set ProtocolType = 1, HostName = 'ftp.bowker.com', PortNumber = '21', StartingDirectory = '/INscribeMetadataAndCovers', UserName = 'inscribe', Password = 'insc2011' from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name = 'Bowker Ftp for INscribe Digital Metadata and Cover' and c.ValidUntilUtc is null

update ftp set ProtocolType = 1, HostName = 'ftp.bowker.com', PortNumber = '21', StartingDirectory = '/', UserName = 'ebinscribe', Password = 'ebin2011' from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name = 'Bowker Ftp for Scholastic eBook' and c.ValidUntilUtc is null

update ftp set ProtocolType = 1, HostName = 'ftp.bowker.com', PortNumber = '21', StartingDirectory = '/Scholastic', UserName = 'inscribe', Password = 'insc2011' from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name = 'Bowker Ftp for Scholastic Metadata and Cover' and c.ValidUntilUtc is null

update ftp set ProtocolType = 1, HostName = 'ftp.bowker.com', PortNumber = '21', StartingDirectory = '/INscribeEbooks', UserName = 'ebinscribe', Password = 'ebin2011' from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name = 'Bowker Ftp for INscribe Digital eBook' and c.ValidUntilUtc is null
*/