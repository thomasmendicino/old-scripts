
-- ATTENTION: don't forget to change [AthenaDistribution] and [AthenaProductCatalog] to proper DB's names

--begin tran
-- commit
-- rollback

declare @validFromUtc datetime = '2009-01-01 00:00:00.000'

declare @True bit = 1
declare @False bit = 0

DECLARE @DistributionOrderStructureGroupContracts TABLE
(
    ValidFromUtc datetime NOT NULL,
    ValidUntilUtc datetime NULL,
    Name [nvarchar](128) NOT NULL,
    SafeName [varchar](128) NOT NULL,
    [Description] [nvarchar](1024) NULL,
    PublisherName varchar(300) NOT NULL,
    RetailerName varchar(300) NOT NULL
);

INSERT INTO @DistributionOrderStructureGroupContracts
(
    ValidFromUtc,
    ValidUntilUtc,
    Name,
    SafeName,
    [Description],
    PublisherName,
    RetailerName
)
VALUES
	( @validFromUtc, NULL,  'Sony Reader Store Product History Ingestion',                        'SonyReaderStoreProductHistoryIngestion',                      'Product History Ingestion', 'INscribe Digital', 'Sony Reader Store')


INSERT INTO [dbo].[DistributionOrderStructureGroupContracts]
    ([DistributionOrderStructureGroupContractUid],
    [ContractUid],
    [CreatedAtUtc],
    [ValidFromUtc],
    [ValidUntilUtc],
    [Name],
    [SafeName],
    [Description])
SELECT 
    NEWID(),
    c.ContractUid,
    GETUTCDATE(),
    tdosgc.ValidFromUtc,
    tdosgc.ValidUntilUtc,
    tdosgc.Name,
    tdosgc.SafeName,
    tdosgc.Description
FROM @DistributionOrderStructureGroupContracts tdosgc
INNER JOIN Publishers p on p.Name = tdosgc.PublisherName
INNER JOIN Retailers r on r.Name = tdosgc.RetailerName
INNER JOIN Contracts c on c.RetailerUid = r.RetailerUid AND c.PublisherUid = p.PublisherUid

DECLARE @InformationWarning int = 3;
DECLARE @InformationWarningError int = 7;

DECLARE @DistributionContracts TABLE
(
	[Name] [nvarchar](128) NOT NULL,
	[SafeName] [varchar](128) NOT NULL,
	[Description] [nvarchar](1024) NULL,
	[RetailerName] [nvarchar](1024) NOT NULL,
	[PublisherName] [nvarchar](1024) NOT NULL,
	[BatchServiceName] [nvarchar](1024) NULL,
	[TransferServiceEndpointName] [nvarchar](1024) NULL,
	[ValidFromUtc] [datetime] NOT NULL,
	[ValidUntilUtc] [datetime] NULL,
	[Order] [int] NOT NULL,
	[TolerableEventLevels] [int] NOT NULL
)

INSERT INTO @DistributionContracts
(
	[Name],
	[SafeName],
	[Description],
	[RetailerName],
	[PublisherName],
	[BatchServiceName],
	[TransferServiceEndpointName],
	[ValidFromUtc],
	[ValidUntilUtc],
	[Order],
	[TolerableEventLevels]
)
VALUES
('Sony Reader Store Product History Ingestion Contract',  'SonyReaderProductHistoryIngestionContract',    'Product History Ingestion Contract', 'Sony Reader Store', 'INscribe Digital', 'Batch for Single Publisher', 'Product History Ingestion',  @validFromUtc, NULL, 0, @InformationWarning)


INSERT INTO [dbo].[DistributionContracts]
(
	[DistributionContractUid]
	,[Order]
	,[TolerableEventLevels]
	,[ContractUid]
	,[BatchServiceUid]
	,[TransferServiceEndpointUid]
	,[CreatedAtUtc]
	,[ValidFromUtc]
	,[ValidUntilUtc]
	,[Name]
	,[SafeName]
	,[Description]
)
SELECT 
	NEWID(),
	tdc.[Order],
	tdc.TolerableEventLevels,
	c.ContractUid,
	bs.BatchServiceUid,
	tse.TransferServiceEndpointUid,
	GETUTCDATE(),
	tdc.ValidFromUtc,
	tdc.ValidUntilUtc,
	tdc.Name,
	tdc.SafeName,
	tdc.[Description]
FROM @DistributionContracts tdc
INNER JOIN BatchServices bs on bs.Name = tdc.BatchServiceName
INNER JOIN TransferServiceEndpoints tse on tse.Name = tdc.TransferServiceEndpointName
INNER JOIN Publishers p on p.Name = tdc.PublisherName
INNER JOIN Retailers r on r.Name = tdc.RetailerName
INNER JOIN Contracts c on c.RetailerUid = r.RetailerUid AND c.PublisherUid = p.PublisherUid