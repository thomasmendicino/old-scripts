USE AthenaComposite;
;with ScholasticTitles as 
(SELECT distinct p.Ordinal 
from 
	product p
		INNER JOIN  organizations o on o.OrganizationUid = p.OrganizationUid
		INNER JOIN  AthenaSecurity..OrgHierarchy('Scholastic Inc.') oh on oh.organizationUid = o.OrganizationUid
		INNER JOIN  asset a on a.ProductUid = p.ProductUid
		INNER JOIN  AssetOverride ao on ao.AssetUid = a.AssetUid
		INNER JOIN  AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		INNER JOIN  productForms pf on pf.AssetVersionUid = av.AssetVersionUid
where av.ValidUntilUtc is NULL
	and pf.ProductFormTypeValue in (48,49,50,51,52)),
SingleMainTitle AS (
	SELECT DISTINCT
		p.Ordinal
		, replace(COALESCE(te.TitleText, te.TitlePrefix + ' ' + te.TitleWithoutPrefix),'"','''''') as Title
		, ROW_NUMBER() OVER (PARTITION BY p.Ordinal ORDER BY TitleElementLevel, isnull(te.TitleText,'z') DESC, te.TitleWithoutPrefix ASC) RowNum
	FROM
		Product p
		INNER JOIN  Asset a on a.ProductUid = p.ProductUid
		INNER JOIN  AssetOverride ao on ao.AssetUid = a.AssetUid
		INNER JOIN  AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		INNER JOIN  TitleDetails td on td.AssetVersionUid = av.AssetVersionUid
		INNER JOIN  TitleElements te ON te.TitleDetailId = td.TitleDetailId
		INNER JOIN  ScholasticTitles st ON st.Ordinal = p.Ordinal
	WHERE av.ValidUntilUtc is NULL)
select 
	p.Ordinal as ISBN, 
	o.OrganizationName as Imprint,
	mt.Title,
	pr.Amount,
	cc.CurrencyCode as Currency,
	case
		when PriceType = 14 then 'Agency'
		when PriceType = 1 then 'Wholesale'
		else cast(PriceType as nvarchar(10))
	end as PriceType, 
	--case 
		--when pr.Qualifier = 7 then 'Library'
		--when pr.Qualifier = 6 then 'Retail'
	--else cast(isnull(pr.Qualifier,'') as nvarchar(10))
	--end as PriceQualifier,
	--Omitting PriceQualifier from the report; it just needs to not be Library
	CASE
		when CHARINDEX('US',CountryList) % 2 != 0 AND CHARINDEX('CA',CountryList) % 2 != 0 THEN 'US, CA'
		when CHARINDEX('US',CountryList) % 2 != 0 AND CHARINDEX('CA',CountryList) % 2 = 0 THEN 'US'
		when CHARINDEX('US',CountryList) % 2 = 0 AND CHARINDEX('CA',CountryList) % 2 != 0 THEN 'CA'
		else 'unsure'
	end as Territory
FROM 
	AthenaProductCatalog..product p
		INNER JOIN  AthenaProductCatalog..asset a on a.ProductUid = p.ProductUid
		INNER JOIN  AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
		INNER JOIN  AthenaProductCatalog..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		INNER JOIN  AthenaSecurity..Organizations o on o.OrganizationUid = p.OrganizationUid
		INNER JOIN  AthenaProductCatalog..TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
		INNER JOIN  AthenaProductCatalog..TerritorySupplyDetails td on td.TerritorySupplyId= ts.TerritorySupplyId
		INNER JOIN  AthenaProductCatalog..prices pr on pr.TerritorySupplyDetailId = td.TerritorySupplyDetailId
		INNER JOIN  AthenaResourceStorage..resources r on r.ResourceUid = av.ResourceUid
		INNER JOIN  AthenaProductCatalog..CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
		INNER JOIN  ScholasticTitles st on st.Ordinal = p.Ordinal
		INNER JOIN  AthenaProductCatalog..refCurrencyCode cc on cc.CurrencyCodeId = pr.Currency
		INNER JOIN  SingleMainTitle mt on mt.Ordinal = p.Ordinal
WHERE pr.PriceCodeTypeName is null
	AND isnull(pr.Qualifier,6) = 6
	AND (CountryList like '%US%' or CountryList like '%CA%')
	AND ((CHARINDEX('US',CountryList) % 2 != 0) OR (CHARINDEX('CA',CountryList) % 2 != 0))
	AND av.ValidUntilUtc is NULL
	AND pr.EffectiveToUtc is NULL
	AND mt.RowNum = 1
order by p.Ordinal, av.ValidFromUtc, cs.CountryList