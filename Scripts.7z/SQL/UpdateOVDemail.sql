begin tran
select * from AthenaDistribution..TransferServiceEmailEndpoints em
join DistributionContracts dc on dc.TransferServiceEndpointUid = em.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name like '%overdri%'

update em set [To] = 'uploads@contentreserve.com, distribution@inscribedigital.com, kelly@inscribedigital.com, danny@inscribedigital.com, kbeehler@inscribedigital.com' from AthenaDistribution..TransferServiceEmailEndpoints em
join DistributionContracts dc on dc.TransferServiceEndpointUid = em.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name like '%overdri%'

/*update em set [To] = 'thomas@ingrooves.com, beau.beaver@ingrooves.com' from AthenaDistribution..TransferServiceEmailEndpoints em
join DistributionContracts dc on dc.TransferServiceEndpointUid = em.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name like '%overdri%'*/

select * from AthenaDistribution..TransferServiceEmailEndpoints em
join DistributionContracts dc on dc.TransferServiceEndpointUid = em.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name like '%overdri%'
--commit
