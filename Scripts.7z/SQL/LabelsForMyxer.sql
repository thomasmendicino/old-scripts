--begin transaction
--rollback
--commit
declare @parents table (oid int, mobile int, rownum int)
insert into @parents
select 
	organization, 
	mobile, 
	ROW_NUMBER() OVER(ORDER BY Organization) as RowNum
 from royalty where organization is not null and mobile=1


declare @children table (oid int, level int, ancestor int)
declare @counter int
declare @currentorg int

set @counter=0
while @counter < (select count(*) from @parents)
  begin
	set @counter = @counter+1
	set @currentorg = (select oid from @parents where rownum = @counter)
	insert into @children select organization, level, @currentorg from get_organization_descendants(@currentorg)
  end


declare @alreadyin table (oid int)
insert into @alreadyin
select organization from musicservicepayee where musicservice = (select id from musicservice where name = 'cricket muve music')

declare @needtoadd table (oid int)
insert into @needtoadd
select oid from @parents
union
select oid from @children
except
select oid from @alreadyin


select count(*), 'parents' from @parents
union
select count(*), 'children' from @children
union
select count(*), 'alreadyin' from @alreadyin
union
select count(*), 'need to add' from @needtoadd

select oid from @parents union select oid from @children
select * from album where gtin = '837101338790'
select * from track where album = 107253
select path, * from song where id in (select song from track where album = 107253)

--insert into MusicServicePayee (MusicService, Organization, Origin) SELECT 337, oid, 1 from @needtoadd 

--select * from musicservicepayee where musicservice = (select id from musicservice where name = 'myxer')


select top 50 * from ingrooveslog.dbo.log where machinename like '%corpo%'