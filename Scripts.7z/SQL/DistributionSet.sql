select * from distributionsetitem
select * from distributionset
select * from distributiontype

select distributionset from distributionsetitem group by distributionset, allow having (count(distributionset) = (select count(*) from distributiontype) and allow = 1)

select distributionset from distributionsetitem group by distributionset, allow having (count(distributionset) = (select count(*) from distributiontype) and allow = 1)

select distributionset, count(distributionset) occurrences from distributionsetitem where allow = 1 group by distributionset order by count(distributionset) desc
select * from distributiontype
select * from distributionsetitem

select * from musicservice
select * from distributionset where id = 208
select * from distributionsetitem where distributionset = 208

insert into distributionsetitem (distributionset, distributiontype, allow)
select 264,34,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 264,35,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 264,36,1

insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1
insert into distributionsetitem (distributionset, distributiontype, allow)
select 1,1,1