IF OBJECT_ID('tempdb..#top25') IS NOT NULL
    DROP TABLE #top25
	GO

create table #top25 (Name nvarchar(300))

;with child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName in ('Courier'
,'Bloomsbury Publishing'
,'Arcadia Publishing Inc.'
,'Ink Monster, LLC'
,'Harvest House Publishers'
,'Babelcube'
,'Bibliomotion, Inc.'
,'Charisma Media'
,'Wizard Publications, Inc.'
,'Atlantic Bridge'
,'Nancy Yost Literary Agency Inc.'
,'The Knight Agency'
,'Blackstone Audio, Inc.'
,'InterVarsity Press'
,'Accurance'
,'RosettaBooks'
,'Samuel French'
,'Island Press'
,'Harvard Education Publishing Group'
,'Wayne State University Press'
,'Shiloh Walker, Inc.'
,'David R Godine, Inc.'
,'Brown Girls Publishing'
,'Liza Dawson Associates'
,'Michelle Hoppe dba Book Boutiques'
,'Chances, Inc.'
,'Rose Publishing, Inc.'
,'JABberwocky Literary Agency, Inc.'
,'Health Professions Press, Inc.'
,'Mercury Radio Arts, Inc.'
,'Cadent Publishing'
,'Gryphon House, Inc.'
,'Publication Consultants'
,'Sylvia Day'
,'Outside the Box ebook publishing'
,'Boutique of Quality Book Publishing, Inc.'
,'Beverly Dale Mayer'
,'Soaring Phoenix Press'
,'Light Messages Publishing'
,'ACTA Publications'
,'Karin Tabke LLC'
,'Pine Tribe Ltd.'
,'Full Fathom Five, LLC'
,'James Publishing')
union all
select o.organizationName, o.OrganizationUid from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
INSERT #top25 (Name) 
SELECT o.OrganizationName from Organizations o
join child c on c.organizationName = o.OrganizationName
