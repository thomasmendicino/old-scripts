IF OBJECT_ID (N'OrgHierarchy', N'IF') IS NOT NULL
    DROP FUNCTION OrgHierarchy;
GO
CREATE FUNCTION OrgHierarchy (@orgname nvarchar(100))
RETURNS TABLE
AS
RETURN 
(
    with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @orgname
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @orgName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
select o.organizationName, organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.OrganizationName, o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select 'INscribe Digital', '00000000-0000-0000-0000-000000000001'
)
GO
