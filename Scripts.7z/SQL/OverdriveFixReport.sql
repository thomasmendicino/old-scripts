--2 sections:

--1. Titles that have come in that need fixed and reuploaded as _OVD:

--2. Titles that may have been taken down and need review for OVD:

-- These are titles that have come in in the last 24 hours that need pricing consolidated and reuploaded as _OVD.
;with #NewProductRevisions as (
select pr.ProductRevisionUid, av.ValidFromUtc from ProductRevisions pr
join contracts c on c.ContractUid = pr.ContractUid
join publishers p on p.PublisherUid = c.PublisherUid
join Retailers r on r.retailerUid = c.RetailerUid
join ProductRevisionStructures prs on prs.ProductRevisionUid = pr.ProductRevisionUid
join AssetVersion av on av.AssetVersionUid = prs.AssetVersionUid
where r.Name = 'Overdrive'
and p.Name = 'Scholastic Inc.'
and c.ValidUntilUtc is NULL
and prs.ResourceContentType = 100
and av.ValidFromUtc > getUTCdate()-1),
#ProductsWithCurrency as (
select distinct p.Ordinal as ISBN, rc.CurrencyCode as Currency from AthenaProductCatalog..product p
join AthenaProductCatalog..asset a on a.ProductUid = p.ProductUid
join AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
join AthenaProductCatalog..assetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join AthenaProductCatalog..TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join AthenaProductCatalog..TerritorySupplyDetails td on td.TerritorySupplyId = ts.TerritorySupplyId
join AthenaProductCatalog..prices pe on pe.TerritorySupplyDetailId = td.TerritorySupplyDetailId
join AthenaProductCatalog..refCurrencyCode rc on rc.CurrencyCodeId = pe.Currency
where 
pe.EffectiveFromUtc is null and pe.EffectiveToUtc is null
and av.ValidUntilUtc is NULL
and PriceType = 1
and (ao.RetailerUid is null or ao.retailerUid = (select retailerUid from AthenaDistribution..retailers where code = 'OVD'))
),
#ProductsWithMultipleCurrencies as (
select distinct p.Ordinal as ISBN, rc.CurrencyCode as Currency from AthenaProductCatalog..product p
join AthenaProductCatalog..asset a on a.ProductUid = p.ProductUid
join AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
join AthenaProductCatalog..assetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join AthenaProductCatalog..TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join AthenaProductCatalog..TerritorySupplyDetails td on td.TerritorySupplyId = ts.TerritorySupplyId
join AthenaProductCatalog..prices pe on pe.TerritorySupplyDetailId = td.TerritorySupplyDetailId
join AthenaProductCatalog..refCurrencyCode rc on rc.CurrencyCodeId = pe.Currency
join AthenaProductCatalog..CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
where p.ordinal in 
(select ISBN from #ProductsWithCurrency 
group by ISBN
having count(*)>1)
and pe.EffectiveFromUtc is null and pe.EffectiveToUtc is null
and av.ValidUntilUtc is NULL
and PriceType = 1
and (ao.RetailerUid is null or ao.retailerUid = (select retailerUid from AthenaDistribution..retailers where code = 'OVD'))),
#ScholasticParent as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = 'Scholastic Inc.'
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join #ScholasticParent p on p.parentOrganizationUId = po.organizationUid
),
#ScholasticImprints as (
select po.organizationName, po.OrganizationUid as ParentOrganizationUId from organizations po
where organizationName = 'Scholastic Inc.'
union all
select o.organizationName, o.organizationUId as ParentOrganizationUId from organizations o
join #ScholasticImprints i on i.parentorganizationUid = o.parentOrganizationUid),
#ScholasticFamily as (
select ParentOrganizationUId as orgUid from #ScholasticParent
union all
select ParentOrganizationUid as orgUId from #ScholasticImprints
except
select NULL
except
select '00000000-0000-0000-0000-000000000001'
)
select distinct Ordinal ISBN, dateadd(hh,-8,ValidFromUtc) ImportedAt, o.OrganizationName Imprint from Product p
join productRevisions pr on pr.productUid = p.productUid
join #NewProductRevisions npr on npr.productRevisionUId = pr.ProductRevisionUid
join #ProductsWithMultipleCurrencies pmc on pmc.ISBN = p.Ordinal
join #ScholasticFamily sf on sf.orgUid = p.OrganizationUid
join organizations o on o.organizationuid = p.organizationuid

-- These titles have come in for Overdrive in the last 24 hours and were batched for distribution to Overdrive. They may be removed from sale in Canada.

;with #NewBatches as (select pr.ProductRevisionUid, b.CreatedAtUtc from ProductRevisions pr
join contracts c on c.ContractUid = pr.ContractUid
join publishers p on p.PublisherUid = c.PublisherUid
join Retailers r on r.retailerUid = c.RetailerUid
join ProductRevisionStructures prs on prs.ProductRevisionUid = pr.ProductRevisionUid
join AssetVersion av on av.AssetVersionUid = prs.AssetVersionUid
join DistributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join DistributionOrderStructureGroupBatches dsgb on dsgb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join batches b on b.batchUid = dsgb.batchUid
where r.Name = 'Overdrive'
and p.Name = 'Scholastic Inc.'
and c.ValidUntilUtc is NULL
and prs.ResourceContentType = 100
and av.ValidFromUtc > getUTCdate()-1),
#ProductsWithCurrency as (
select distinct p.Ordinal as ISBN, rc.CurrencyCode as Currency from AthenaProductCatalog..product p
join AthenaProductCatalog..asset a on a.ProductUid = p.ProductUid
join AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
join AthenaProductCatalog..assetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join AthenaProductCatalog..TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join AthenaProductCatalog..TerritorySupplyDetails td on td.TerritorySupplyId = ts.TerritorySupplyId
join AthenaProductCatalog..prices pe on pe.TerritorySupplyDetailId = td.TerritorySupplyDetailId
join AthenaProductCatalog..refCurrencyCode rc on rc.CurrencyCodeId = pe.Currency
where 
pe.EffectiveFromUtc is null and pe.EffectiveToUtc is null
and av.ValidUntilUtc is NULL
and PriceType = 1
and (ao.RetailerUid is null or ao.retailerUid = (select retailerUid from AthenaDistribution..retailers where code = 'OVD'))
),
#ProductsWithMultipleCurrencies as (
select distinct p.Ordinal as ISBN, rc.CurrencyCode as Currency from AthenaProductCatalog..product p
join AthenaProductCatalog..asset a on a.ProductUid = p.ProductUid
join AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
join AthenaProductCatalog..assetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join AthenaProductCatalog..TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join AthenaProductCatalog..TerritorySupplyDetails td on td.TerritorySupplyId = ts.TerritorySupplyId
join AthenaProductCatalog..prices pe on pe.TerritorySupplyDetailId = td.TerritorySupplyDetailId
join AthenaProductCatalog..refCurrencyCode rc on rc.CurrencyCodeId = pe.Currency
join AthenaProductCatalog..CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
where p.ordinal in 
(select ISBN from #ProductsWithCurrency 
group by ISBN
having count(*)>1)
and pe.EffectiveFromUtc is null and pe.EffectiveToUtc is null
and av.ValidUntilUtc is NULL
and PriceType = 1
and (ao.RetailerUid is null or ao.retailerUid = (select retailerUid from AthenaDistribution..retailers where code = 'OVD'))),
#ScholasticParent as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = 'Scholastic Inc.'
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join #ScholasticParent p on p.parentOrganizationUId = po.organizationUid
),
#ScholasticImprints as (
select po.organizationName, po.OrganizationUid as ParentOrganizationUId from organizations po
where organizationName = 'Scholastic Inc.'
union all
select o.organizationName, o.organizationUId as ParentOrganizationUId from organizations o
join #ScholasticImprints i on i.parentorganizationUid = o.parentOrganizationUid),
#ScholasticFamily as (
select ParentOrganizationUId as orgUid from #ScholasticParent
union all
select ParentOrganizationUid as orgUId from #ScholasticImprints
except
select NULL
except
select '00000000-0000-0000-0000-000000000001'
)
select distinct Ordinal ISBN, dateadd(hh,-8,CreatedAtUtc) BatchCreatedAt, o.OrganizationName Imprint from Product p
join productRevisions pr on pr.productUid = p.productUid
join #NewBatches nb on nb.productRevisionUId = pr.ProductRevisionUid
join #ProductsWithMultipleCurrencies pmc on pmc.ISBN = p.Ordinal
join #ScholasticFamily sf on sf.orgUid = p.OrganizationUid
join organizations o on o.organizationuid = p.organizationuid
