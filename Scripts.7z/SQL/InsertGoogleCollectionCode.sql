
--begin tran
declare @publisherUid uniqueidentifier
declare @CollectionCode nvarchar(7)
declare @pubAttUid uniqueidentifier

select @publisherUid = publisherUid from AthenaDistribution.. Publishers where name = 'Rose Publishing, Inc.'
set @CollectionCode = 'YEXZRCT'
select @pubAttUid = publisherAttributeUid from athenadistribution..publisherAttributes where Name = 'Google Collection Code'

--insert athenadistribution..publisherAttributeValues (PublisherAttributeValueUid, PublisherAttributeUid, Value, PublisherUid)
select newid(), @pubAttUid, @CollectionCode, @publisherUId
--commit

/*
Checking/Finding codes

declare @pubAttUid uniqueidentifier

select @pubAttUid = publisherAttributeUid from athenadistribution..publisherAttributes where Name = 'Google Collection Code'

select p.Name [TopLevelPublisher], Value [GoogleCollectionCode] from athenadistribution..publisherAttributeValues pav
join athenadistribution..publishers p on p.publisherUId = pav.publisherUId
where pav.PublisherAttributeUid = @pubAttUid
order by p.Name

*/