use athenacomposite;
declare @Scholastic table (orgUid uniqueidentifier)

declare @organizationName nvarchar(100)
select @organizationname = 'Scholastic Inc.'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @Scholastic
select organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select '00000000-0000-0000-0000-000000000001'

select * from @Scholastic

DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @AgeRangeStart INT
DECLARE @AgeRangeEnd INT
DECLARE @GradeRangeStart INT
DECLARE @GradeRangeEnd INT
DECLARE @SeriesEscaped NVARCHAR(MAX)
DECLARE @TitleEscaped NVARCHAR(MAX)
DECLARE @SubtitleEscaped NVARCHAR(MAX)
DECLARE @ContributorsEscaped NVARCHAR(MAX)
DECLARE @DescriptionEscaped NVARCHAR(MAX)
DECLARE @PublishingStatus INT
DECLARE @OrganizationUidList NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)

SET @OrganizationUidList =  '{7127AB11-B825-4568-8115-3555E5E92CF3}' 
SET @eISBNList = NULL
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL
SET @AgeRangeStart = NULL
SET @AgeRangeEnd = NULL
SET @GradeRangeStart = NULL
SET @GradeRangeEnd = NULL
SET @SeriesEscaped = NULL
SET @TitleEscaped = NULL
SET @SubtitleEscaped = NULL
SET @ContributorsEscaped = NULL
SET @DescriptionEscaped = NULL
SET @PublishingStatus= NULL
SET @eISBNs = NULL



IF OBJECT_ID('tempdb..#CatalogReport') IS NOT NULL
    DROP TABLE #CatalogReport

IF OBJECT_ID('tempdb..#ValidMetaData') IS NOT NULL
    DROP TABLE #ValidMetaData
    
IF OBJECT_ID('tempdb..#Aggregate') IS NOT NULL
    DROP TABLE #Aggregate
  
IF OBJECT_ID('tempdb..#GradeRange') IS NOT NULL
    DROP TABLE #GradeRange 
    
IF OBJECT_ID('tempdb..#AgeRange') IS NOT NULL
    DROP TABLE #AgeRange  
     
IF OBJECT_ID('tempdb..#Contributors') IS NOT NULL
    DROP TABLE #Contributors
    
IF OBJECT_ID('tempdb..#Territories') IS NOT NULL
    DROP TABLE #Territories
    
IF OBJECT_ID('tempdb..#Prices') IS NOT NULL
    DROP TABLE #Prices
    
IF OBJECT_ID('tempdb..#Subjects') IS NOT NULL
    DROP TABLE #Subjects
    
IF OBJECT_ID('tempdb..#CollectionTitle') IS NOT NULL
    DROP TABLE #CollectionTitle
    
IF OBJECT_ID('tempdb..#ProductTitle') IS NOT NULL
	DROP TABLE #ProductTitle
	
IF OBJECT_ID('tempdb..#tempGradeRange') IS NOT NULL
    DROP TABLE #tempGradeRange 
    
IF OBJECT_ID('tempdb..#GradeRange') IS NOT NULL
    DROP TABLE #GradeRange  
    
IF OBJECT_ID('tempdb..#tempAgeRange') IS NOT NULL
    DROP TABLE #tempAgeRange 
     
IF OBJECT_ID('tempdb..#AgeRange') IS NOT NULL
    DROP TABLE #AgeRange  
    
IF OBJECT_ID('tempdb..#Descriptions') IS NOT NULL
    DROP TABLE #Descriptions
    
IF OBJECT_ID('tempdb..#Reviews') IS NOT NULL
    DROP TABLE #Reviews
    
IF OBJECT_ID('tempdb..#PublishingDate') IS NOT NULL
    DROP TABLE #PublishingDate   
    
IF OBJECT_ID('tempdb..#PublishingStatus') IS NOT NULL
    DROP TABLE #PublishingStatus      
    
IF OBJECT_ID('tempdb..#ProductFormDetails') IS NOT NULL
    DROP TABLE #ProductFormDetails    
    
IF OBJECT_ID('tempdb..#ProductLanguage') IS NOT NULL
    DROP TABLE #ProductLanguage   
    
IF OBJECT_ID('tempdb..#Audience') IS NOT NULL
    DROP TABLE #Audience    
    
IF OBJECT_ID('tempdb..#PageCount') IS NOT NULL
    DROP TABLE #PageCount   
    
IF OBJECT_ID('tempdb..#ContributorStatement') IS NOT NULL
    DROP TABLE #ContributorStatement  
    
DECLARE @MetadataResourceContentType int = 100
DECLARE @SubjectSchemeIdentifierType int = 10
DECLARE @CollectionTypeCode int = 10
DECLARE @AudienceRanges nvarchar(128) = '1, 2, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17'
DECLARE @TextContentTypeDescription int = 3
DECLARE @TextContentTypeReview int = 6
DECLARE @ProductFormDetailFixed int = 5201
DECLARE @ProductFormDetailReflowable int = 5200
DECLARE @AudienceCodeType int = 1
DECLARE @PublishingDateRole int = 1
DECLARE @ExtentType int = 1
DECLARE @TitleElementLevelProduct int = 1
DECLARE @TitleElementLevelCollection int = 2
DECLARE @TitleTypeCodeDistinctiveTitle int = 1

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
	av.AssetVersionUid,
	p.ProductUid,
	p.OrganizationUid,
	p.Ordinal
INTO
	#ValidMetadata
FROM
	AssetOverride ao
	INNER JOIN Asset a ON ao.AssetUid = a.AssetUid
	INNER JOIN AssetVersion av ON ao.AssetOverrideUid = av.AssetOverrideUid
	INNER JOIN Product p ON a.ProductUid = p.ProductUid
	INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
	a.ResourceContentType = @MetadataResourceContentType
	AND av.ValidUntilUtc IS NULL
    AND ao.Country is null
    AND ao.RetailerUid is null
	AND (@eISBNs IS NULL or p.Ordinal IN (@eISBNList))
	AND (p.OrganizationUid IN (select organizationUId from @Scholastic))    

SELECT
    m.ProductUid,
    STUFF((
        SELECT ', ' + REPLACE(REPLACE(REPLACE(PersonName, CHAR(9), ''), CHAR(10), ''), CHAR(13), '')
        FROM Contributors c
        WHERE c.AssetVersionUid = m.AssetVersionUid
        FOR XML PATH('')), 1, 2, '') Contributors
INTO #Contributors
FROM
    #ValidMetadata m

SELECT
    m.ProductUid,
    STUFF((
        SELECT REPLACE(REPLACE(REPLACE(cs.CountryList, CHAR(9), ''), CHAR(10), ''), CHAR(13), '')
        FROM TerritorySupplies ts
	        INNER JOIN TerritorySupplyDetails tsd ON ts.TerritorySupplyId = tsd.TerritorySupplyId
	        INNER JOIN CountrySets cs ON ts.CountrySetUid = cs.CountrySetUid
        WHERE ts.AssetVersionUid = m.AssetVersionUid
        FOR XML PATH('')), 1, 0, '') Territories
INTO #Territories
FROM
    #ValidMetadata m

SELECT
    m.ProductUid,
    STUFF((
		SELECT ', ' + CONVERT(nvarchar(max), p.Amount) + ' ' + rcc.CurrencyCode
		FROM TerritorySupplies ts
			INNER JOIN TerritorySupplyDetails tsd ON ts.TerritorySupplyId = tsd.TerritorySupplyId
			INNER JOIN Prices p ON tsd.TerritorySupplyDetailId = p.TerritorySupplyDetailId
			INNER JOIN refCurrencyCode rcc ON p.Currency = rcc.CurrencyCodeId
		WHERE ts.AssetVersionUid = m.AssetVersionUid
		FOR XML PATH('')), 1, 2, '') CurrencyPrices
INTO #Prices
FROM
    #ValidMetadata m

SELECT
    m.ProductUid,
    REPLACE(STUFF((
        SELECT ', ' + rs.BISACText
        FROM
            Subjects s
	        INNER JOIN refBISACCode rs ON s.SubjectCode = rs.BISACCode
        WHERE
            s.AssetVersionUid = m.AssetVersionUid
            AND s.SubjectSchemeIdentifierType = @SubjectSchemeIdentifierType
        for xml path('')), 1, 2, ''), '&amp;amp;', '&amp;') Codes
INTO #Subjects
FROM
	#ValidMetadata m

SELECT
	m.ProductUid,
	(SELECT top 1
			COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement)
		FROM
			TitleDetails td
			INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
		WHERE
			td.TitleTypeCode = @TitleTypeCodeDistinctiveTitle    -- TitleTypeCode.DistinctiveTitle
			AND te.TitleElementLevel = @TitleElementLevelProduct -- TitleElementLevelCode.Product
			AND td.CollectionId is null
			AND ((@TitleEscaped IS NOT NULL AND (te.TitleText LIKE '%' + @TitleEscaped + '%' ESCAPE '`')) OR @TitleEscaped IS NULL)
			AND ((@SubtitleEscaped IS NOT NULL AND (te.Subtitle LIKE '%' + @SubtitleEscaped + '%' ESCAPE '`')) OR @SubtitleEscaped IS NULL)
			AND m.AssetVersionUid = td.AssetVersionUid) Title
INTO #ProductTitle
FROM
	#ValidMetadata m
     
SELECT
	m.ProductUid,
	(SELECT TOP 1
		COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement)
	FROM
	    Collections c
	    INNER JOIN TitleDetails td ON c.CollectionId = td.CollectionId
        INNER JOIN TitleElements te ON td.TitleDetailId = te.TitleDetailId
    WHERE
    	c.CollectionTypeCode = @CollectionTypeCode
		AND td.TitleTypeCode = @TitleTypeCodeDistinctiveTitle   -- TitleTypeCode.DistinctiveTitle
		AND te.TitleElementLevel = @TitleElementLevelCollection -- TitleElementLevelCode.Collection
	    AND td.CollectionId IS NOT NULL
	    AND ((@SeriesEscaped IS NOT NULL AND te.TitleText LIKE '%' + @SeriesEscaped + '%' ESCAPE '`') OR (@SeriesEscaped IS NULL) OR (te.TitleText IS NULL))
	    AND m.AssetVersionUid = c.AssetVersionUid) Title
INTO #CollectionTitle
FROM
    #ValidMetadata m
 
SELECT
    r.AssetVersionUid,
	ISNULL(r.[FROM],'Unspecified') TextFROM,
	case r.[FROM]
		WHEN 'K' THEN 0 
		WHEN 'P' THEN -1
		WHEN 'Up To' THEN -1
		ELSE r.[FROM] END AS ValueFROM,
	ISNULL(r.[To],'Unspecified') AS TextTo,
	CASE r.[To] 
		WHEN 'K' THEN 0 
		WHEN 'P' THEN -1
		WHEN 'Up To' THEN -1
		ELSE r.[To] END AS ValueTo
INTO #tempGradeRange
FROM
    AudienceRanges r
WHERE
	r.AudienceRangeQualifier IN (1, 2, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17)    
    
    
SELECT
    m.ProductUid,
    (SELECT TOP 1
        CAST(GR.TextFROM AS varchar) + '-' + CAST(GR.TextTo AS varchar)
    FROM
        #tempGradeRange gr
    WHERE
        ((@GradeRangeStart >= gr.ValueFROM AND @GradeRangeEnd <= gr.ValueTo)--LOW...@GradeRangeStart...@GradeRangeEnd...HIGH
        OR ((@GradeRangeStart <= gr.ValueFROM OR @GradeRangeStart IS NULL) AND @GradeRangeEnd <= gr.ValueTo AND @GradeRangeEnd >= gr.ValueFROM)	--*@GradeRangeStart...LOW...@GradeRangeEnd...HIGH
        OR (@GradeRangeStart >= gr.ValueFROM AND @GradeRangeStart <= gr.ValueTo AND (@GradeRangeEnd >= gr.ValueTo OR @GradeRangeEnd IS NULL))	--LOW...@GradeRangeStart...HIGH...*@GradeRangeEnd
        OR ((@GradeRangeStart <= gr.ValueFROM OR @GradeRangeStart IS NULL) AND (@GradeRangeEnd >= gr.ValueTo OR @GradeRangeEnd IS NULL)))		--*@GradeRangeStart...LOW...HIGH...*@GradeRangeEnd
        AND gr.AssetVersionUid = m.AssetVersionUid
    ) GradeRange
INTO #GradeRange
FROM 
    #ValidMetadata m

SELECT
    r.AssetVersionUid,
	ISNULL(r.[From],'Unspecified') AS TextFROM,
	case r.[From]
		WHEN 'Up To' THEN -1
		ELSE r.[FROM] END AS ValueFROM,
	ISNULL(r.[To],'Unspecified') AS TextTO,
	CASE r.[To] 
		WHEN 'Up To' THEN -1
		ELSE r.[To] END AS ValueTo
INTO #tempAgeRange
FROM
    AudienceRanges r
WHERE
	r.AudienceRangeQualifier IN (4,5,6)   
    
    
SELECT
    m.ProductUid,
    (SELECT TOP 1
        CAST(ar.TextFROM AS varchar) + '-' + CAST(ar.TextTo AS varchar)
    FROM
        #tempAgeRange ar
    WHERE
        ((@AgeRangeStart >= ar.ValueFROM AND @AgeRangeEnd <= ar.ValueTo)																--LOW...@AgeRangeStart...@AgeRangeEnd...HIGH
        OR ((@AgeRangeStart <= ar.ValueFROM OR @AgeRangeStart IS NULL) AND @AgeRangeEnd <= ar.ValueTo AND @AgeRangeEnd >= ar.ValueFROM)	--*@AgeRangeStart...LOW...@AgeRangeEnd...HIGH
        OR (@AgeRangeStart >= ar.ValueFROM AND @AgeRangeStart <= ar.ValueTo AND (@AgeRangeEnd >= ar.ValueTo OR @AgeRangeEnd IS NULL))	--LOW...@AgeRangeStart...HIGH...*@AgeRangeEnd
        OR ((@AgeRangeStart <= ar.ValueFROM OR @AgeRangeStart IS NULL) AND (@AgeRangeEnd >= ar.ValueTo OR @AgeRangeEnd IS NULL)))	--*@AgeRangeStart...LOW...HIGH...*@AgeRangeEnd AND gr.AssetVersionUid = m.AssetVersionUid
        AND ar.AssetVersionUid = m.AssetVersionUid) AgeRange
INTO #AgeRange
FROM 
    #ValidMetadata m

SELECT 
    m.ProductUid, 
    (SELECT TOP 1
        t.Value
    FROM
        TextContents tc
        INNER JOIN Texts t ON t.TextContentId = tc.TextContentId
    WHERE 
        tc.TextType = @TextContentTypeDescription
        AND ((@DescriptionEscaped IS NOT NULL AND t.Value LIKE '%' + @DescriptionEscaped + '%' ESCAPE '`') OR @DescriptionEscaped IS NULL)
        AND m.AssetVersionUid = tc.AssetVersionUid) Description
INTO #Descriptions
FROM
    #ValidMetadata m


SELECT
    m.ProductUid,
    (SELECT TOP 
        1 t.Value Review
    FROM
        TextContents tc 
        INNER JOIN Texts t ON tc.TextContentId = t.TextContentId
    WHERE
        tc.TextType = @TextContentTypeReview
        AND tc.AssetVersionUid = m.AssetVersionUid) Review
INTO #Reviews
FROM
    #ValidMetadata m

SELECT
    m.ProductUid, 
    (SELECT TOP 1
        CAST(pd.Value AS DATE)
    FROM
        PublishingDates pd
    WHERE
        m.AssetVersionUid = pd.AssetVersionUid
        AND pd.PublishingDateRole = @PublishingDateRole
        AND ((@OnSaleDateRangeStart IS NOT NULL 
        AND @OnSaleDateRangeEnd IS NOT NULL 
        AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
        OR
        (@OnSaleDateRangeStart IS NULL 
        AND @OnSaleDateRangeEnd IS NOT NULL
        AND pd.Value <= @OnSaleDateRangeEnd)
        OR
        (@OnSaleDateRangeStart IS NOT NULL 
        AND @OnSaleDateRangeEnd IS NULL
        AND pd.Value >= @OnSaleDateRangeStart)
        OR
        (@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))) OnSaleDate
INTO 
    #PublishingDate
FROM
    #ValidMetadata m

 
     
SELECT
    m.ProductUid, 
    (SELECT TOP 1
        rps.Name
    FROM
        PublishingStatus ps
        INNER JOIN refPublishingStatusType rps ON rps.PublishingStatusTypeId = ps.PublishingStatusType 
    WHERE   
        (rps.PublishingStatusTypeId = @PublishingStatus OR @PublishingStatus IS NULL)
        AND AssetVersionUid = m.AssetVersionUid) PublicationStatus
INTO 
    #PublishingStatus
FROM
    #ValidMetadata m

      

SELECT
    m.productUid,
    (SELECT TOP 1
        pfd.ProductFormDetailValue 
    FROM
        ProductFormDetails pfd
    WHERE 
        pfd.AssetVersionUid = m.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (@ProductFormDetailReflowable, @ProductFormDetailFixed) ) ContentType
INTO
    #ProductFormDetails
FROM
     #ValidMetadata m 

SELECT 
    m.ProductUid,
    (SELECT TOP 1
        rlc.LanguageText
    FROM
        ProductLanguages PL
        INNER JOIN refLanguageCode rLC ON rLC.LanguageCodeId = PL.ProductLanguageCode
    WHERE
        m.AssetVersionUid = PL.AssetVersionUid) Language
INTO
    #ProductLanguage
FROM
    #ValidMetadata m

SELECT 
    m.ProductUid,
    (SELECT TOP 1
        rAC.AudienceCode
    FROM
        Audiences Aud
        INNER JOIN refAudienceCode rAC ON Aud.AudienceCodeValue = rAC.AudienceCodeId
    WHERE
        m.AssetVersionUid = Aud.AssetVersionUid
        AND (aud.AudienceCodeType IS NULL OR aud.AudienceCodeType = @AudienceCodeType)) Audience
INTO
    #Audience
FROM
    #ValidMetadata m

SELECT 
    m.ProductUid,
    (SELECT TOP 1
        Ex.Value
    FROM
        Extents Ex
    WHERE
        m.AssetVersionUid = Ex.AssetVersionUid
        AND (ex.ExtentType IS NULL OR ex.ExtentType = @ExtentType)) PageCount
INTO
    #PageCount
FROM
    #ValidMetaData m   

SELECT 
    m.ProductUid,
    (SELECT TOP 1
        CS.Text
    FROM
        ContributorStatements CS
    WHERE
        m.AssetVersionUid = CS.AssetVersionUid) ContributorStatement
INTO
    #ContributorStatement
FROM
    #ValidMetaData m   

SELECT 
    p.Name Publisher,
    m.Ordinal ISBN,
    ct.Title Series,
    pt.Title,
    CASE pfd.ContentType 
        WHEN @ProductFormDetailFixed THEN 'Fixed' 
        WHEN @ProductFormDetailReflowable  THEN 'Reflowable'
        ELSE 'Not Specified' END ContentType,
    PD.OnSaleDate,
    pdesc.Description,
    pr.Review Reviews,
    psub.Codes BISACs,
    ps.PublicationStatus PublicationStatus,
    pc.Contributors,
    ppr.CurrencyPrices Price,
    CS.ContributorStatement,     
    ar.AgeRange, 
    gr.GradeRange,
    Aud.Audience,  
    Pag.PageCount, 
    PL.Language,
    ptr.Territories
FROM
    #ValidMetadata m
    INNER JOIN Publishers p ON m.OrganizationUid = p.OrganizationUid
    INNER JOIN #Contributors pc ON pc.ProductUid = m.ProductUid
    INNER JOIN #Territories ptr ON ptr.ProductUid = m.ProductUid
    INNER JOIN #Prices ppr ON ppr.ProductUid = m.ProductUid
    INNER JOIN #Subjects psub ON psub.ProductUid = m.ProductUid
    INNER JOIN #ProductTitle pt ON pt.ProductUid = m.ProductUid
    INNER JOIN #CollectionTitle ct ON ct.ProductUid = m.ProductUid
    INNER JOIN #GradeRange gr ON gr.ProductUid = m.ProductUid
    INNER JOIN #AgeRange ar ON ar.ProductUid = m.ProductUid
    INNER JOIN #Descriptions pdesc ON pdesc.ProductUid = m.ProductUid
    INNER JOIN #Reviews pr ON pr.ProductUid = m.ProductUid
    INNER JOIN #PublishingDate pd ON m.ProductUid = pd.ProductUid
    INNER JOIN #PublishingStatus ps ON m.ProductUid = ps.ProductUid
    INNER JOIN #ProductFormDetails pfd	ON  m.ProductUid = pfd.ProductUid
    INNER JOIN #ProductLanguage PL ON m.ProductUid = PL.ProductUid
    INNER JOIN #Audience Aud ON  m.ProductUid = Aud.ProductUid
    INNER JOIN #PageCount Pag ON m.ProductUid = Pag.ProductUid
    INNER JOIN #ContributorStatement CS ON m.ProductUid = CS.ProductUid
ORDER BY
    OnSaleDate,
    Series,
    Title