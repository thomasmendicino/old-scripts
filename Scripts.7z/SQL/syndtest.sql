use INgrooves
select ts.ID TrackSyndID,
ms.Name MusicServiceName,
so.Performer PerformerName,
so.Name SongName,
a.Name AlbumName,
s.SyndicationLevel SyndLevel
from TrackSyndication ts inner join
Syndication s on s.ID = ts.Syndication inner join
MusicService ms on ms.ID = s.MusicService inner join
Track t on t.ID = ts.Track inner join
Song so on so.ID = t.Song inner join
Album a on a.SongPerformer = so.ID
where s.SyndicationLevel > 2850
order by s.SyndicationLevel
