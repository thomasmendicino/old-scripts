use AthenaUATComposite;
IF OBJECT_ID('tempdb..#versions' , 'U') IS NOT NULL
   drop TABLE #versions
GO
IF OBJECT_ID('tempdb..#pages' , 'U') IS NOT NULL
   drop TABLE #pages
GO
create table #versions (ID int identity(1,1), DistributionOrderUid uniqueidentifier, CreatedAtUtc datetime, Retailer nvarchar(3), ISBN bigint)

;with mostrecentorders as (
select Ordinal,r.Code, max(do.CreatedAtUtc) CreatedAtUtc
from AthenaUATProductCatalog..product p
join productRevisions pr on pr.ProductUid = p.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join AthenaUATSecurity..OrgHierarchy('Demo Publisher') oh on oh.organizationUId = p.OrganizationUid
where do.CreatedAtUtc > GETDATE()-3
and r.code not in ('OST','ENT','SNY','FLK')
group by Ordinal, r.code)
--select * from mostrecentorders
,
mostrecentstatus as (
select dos.distributionOrderUid, max(dos.CreatedAtUtc) MaxDistroOrderStatusAt, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join AthenaUATProductCatalog..product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostrecentorders m on m.Ordinal = p.Ordinal and m.CreatedAtUtc = do.CreatedAtUtc and r.code = m.Code
where dos.CreatedAtUtc > getdate()-3
group by dos.DistributionOrderUid, r.code)
--select * from mostrecentstatus
,
mostrecentstatusnoContract as (
select dos.distributionOrderUid from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join AthenaUATProductCatalog..product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostrecentorders m on m.Ordinal = p.Ordinal and m.CreatedAtUtc = do.CreatedAtUtc and r.code = m.Code
where dos.CreatedAtUtc > getdate()-3
AND dos.ResultingEvent = 103
group by dos.DistributionOrderUid, r.code),
mostrecentisbatch as (
select dos.DistributionOrderUid, dos.CreatedAtUtc, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join AthenaUATProductCatalog..product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join AthenaUATEventLog..refEventType et on et.EventTypeId = dos.ResultingEvent
join mostrecentstatus m on m.DistributionOrderUid = dos.DistributionOrderUid and m.MaxDistroOrderStatusAt = dos.CreatedAtUtc and r.code = m.Retailer
where 
et.EventLevelId < 4 --ERROR
AND et.EventTypeId <> 110 --Distribution Order Transfer Complete
--AND dos.CreatedAtUtc < GETUTCDATE()
) -- this is just to ignore batches in the last day that may not have had fulfillment attempted yet.


select distinct m.Retailer, p.Ordinal as ISBN, nc.* from mostrecentisbatch m
join DistributionOrders do on do.DistributionOrderUid = m.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join AthenaUATProductCatalog..product p on p.ProductUid = pr.productUid
left join mostrecentstatusnoContract nc on nc.distributionOrderUid = do.DistributionOrderUid
order by m.Retailer, p.Ordinal
