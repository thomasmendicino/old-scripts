
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE @OrganizationUidList NVARCHAR(MAX)
DECLARE @RetailerUidList NVARCHAR(MAX)
SET @RetailerUidList = '{7A11C699-1009-46FD-A4A2-205AB65DC1FA}'
SET @eISBNList = 9781448201341
SET @eISBNs = 9781448201341
SET @OrganizationUidList =  '{18370538-E24A-4DDD-A837-5E48165339FF}' 
SET @DateRangeStart = '2015-05-03 08:00:05.963' 
SET @DateRangeEnd = '2015-12-09 20:18:02.930'


DECLARE @DigitalProductFormTypes table
(
    ProductFormTypeValue int NOT NULL PRIMARY KEY,
    Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
    VALUES 
        (49, 'EA'),
        (50, 'EB'),
        (51,'EC'), 
        (52,'ED'), 
        (59,'LA'), 
        (60,'LB'), 
        (61, 'LC')

IF OBJECT_ID('tempdb..#existingMetadataDuringDateRange') IS NOT NULL
    DROP TABLE #existingMetadataDuringDateRange
 
IF OBJECT_ID('tempdb..#eBookWholesalePPT') IS NOT NULL
    DROP TABLE #eBookWholesalePPT 
    
IF OBJECT_ID('tempdb..#WholeSalePricesTemp') IS NOT NULL
    DROP TABLE #WholeSalePricesTemp 
    
IF OBJECT_ID('tempdb..#AgencySalePricesTemp') IS NOT NULL
    DROP TABLE #AgencySalePricesTemp 
    
SELECT
    av.AssetVersionUid
    ,av.ValidFromUtc ValidFrom
    ,av.ValidUntilUtc ValidTo
    ,p.ProductUid
    ,p.OrganizationUid
    ,p.Ordinal
    ,org.OrganizationName
    ,COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title
    ,ao.RetailerUid
INTO
    #existingMetadataDuringDateRange
FROM
    AssetOverride ao
    INNER JOIN Asset a ON ao.AssetUid = a.AssetUid
    INNER JOIN AssetVersion av ON ao.AssetOverrideUid = av.AssetOverrideUid
    INNER JOIN Product p ON a.ProductUid = p.ProductUid
    INNER JOIN Organizations org on p.OrganizationUid = org.OrganizationUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
    INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    a.ResourceContentType = 100                                             -- Metadata
    AND td.TitleTypeCode = 1                                                -- TitleTypeCode.DistinctiveTitle
    AND te.TitleElementLevel = 1                                            -- TitleElementLevelCode.Product
    AND td.CollectionId IS NULL
    AND (@eISBNs IS NULL or p.Ordinal IN (@eISBNList))                      -- not mandatory
    AND (p.OrganizationUid IN (select organizationUid from organizations where organizationName like '%bloomsbury%'))                       -- mandatory
    AND (ao.RetailerUid IS NULL OR (ao.RetailerUid IN (select retailerUid from Retailers where code = 'APc')))  -- mandatory, but metadata doesn't need to be retailer specific
    AND (av.ValidFromUtc >= @DateRangeStart AND av.ValidFromUtc <= @DateRangeEnd)
--The following statement will delete any non-retailer specific AND VALID 
--metadata if retailer specific metadata exists
DELETE FROM m 
FROM #existingMetadataDuringDateRange m
WHERE 
    (SELECT COUNT(*)
    From
        #existingMetadataDuringDateRange m2
    Where
        (m2.ValidTo IS NULL)
    AND (m2.Ordinal = m.Ordinal))>1
    AND m.ValidTo IS NULL
    AND m.RetailerUid IS NULL

--Table to store CountryLists blown up into rows (one row for each country to use below)
IF OBJECT_ID('tempdb..#CountrySetCountries') IS NOT NULL 
DROP TABLE #CountrySetCountries 

SELECT r.country, r.CountrySetUid, r.CountryList 
INTO #CountrySetCountries 
FROM 
( 
SELECT substring(cs.CountryList, v.number+1, 2) as country, v.number as RowNumber, cs.CountrySetUid, cs.CountryList 
FROM CountrySets cs 
join master..spt_values v on v.number < len(cs.CountryList) 
WHERE v.type = 'P' 
) r 
WHERE (RowNumber % 2) = 0 

--CTE1 - Wholesale PriceCTE
;WITH WholeSalePricesCte (AssetversionUid,ValidFrom, ValidTo, OrganizationName,Ordinal,Title,Amount,EffectiveFromUtc,EffectiveToUtc,Country,PriceType,retailerUid)
AS
(
 SELECT  
    m.AssetversionUid
    ,m.ValidFrom
    ,m.ValidTo
    ,m.OrganizationName
    ,m.Ordinal
    ,m.Title
    ,p.Amount
    ,p.EffectiveFromUtc
    ,p.EffectiveToUtc
    ,csc.Country Country
    ,p.PriceType
    ,m.RetailerUid
 FROM 
    #existingMetadataDuringDateRange m   
    INNER JOIN TerritorySupplies ts ON m.AssetVersionUid = ts.AssetVersionUid
    INNER JOIN TerritorySupplyDetails tsd ON ts.TerritorySupplyId = tsd.TerritorySupplyId
    INNER JOIN Prices p ON tsd.TerritorySupplyDetailId = p.TerritorySupplyDetailId
    INNER JOIN refCurrencyCode rcc ON p.Currency = rcc.CurrencyCodeId 
    INNER JOIN #CountrySetCountries csc ON ts.CountrySetUid = csc.CountrySetUid 
 WHERE 
    csc.Country in ('GB','US','CA','AU','NZ')
    AND p.PriceType=1 -- 1 = RecommendedRetailPrice = Wholesale
    AND P.IsTaxIncluded=0),
    
--CTE2 - Wholesale Prices CTE pivoted to get prices INTO per-territory columns
WholeSalePricesPIVOT 
(AssetversionUid, ValidFrom,ValidTo, Imprint, ISBN,Title, GBWholesalePPT,USWholesalePPT ,CAWholesalePPT,AUWholesalePPT ,NZWholesalePPT,EffectiveFromUtc,EffectiveToUtc,retailerUid) 
As(SELECT 
    AssetversionUid
    ,ValidFrom
    ,ValidTo
    ,OrganizationName Imprint
    ,ordinal ISBN
    ,Title
    ,[GB] as GBWholesalePPT
    ,[US] as USWholesalePPT
    ,[CA] as CAWholesalePPT
    ,[AU] as AUWholesalePPT
    ,[NZ] as NZWholesalePPT
    ,EffectiveFromUtc
    ,EffectiveToUtc
    ,retailerUid
FROM 
    (SELECT AssetversionUid, ValidTo,ValidFrom, OrganizationName, Ordinal, Title, Amount, EffectiveFromUtc ,EffectiveToUtc, Country, PriceType, retailerUid FROM WholeSalePricesCte) as PCte
PIVOT
(
max(PCte.amount)
FOR Country IN ([US], [GB], [AU], [CA], [NZ])
) AS Pivotable),

--CTE3 - Agency PriceCTE
AgencyPricesCte (AssetversionUid, Amount,EffectiveFromUtc,EffectiveToUtc,Country,PriceType,retailerUid)
AS
(
 SELECT  
    m.AssetversionUid
    ,p.Amount
    ,p.EffectiveFromUtc
    ,p.EffectiveToUtc
    ,csc.country Country
    ,p.PriceType
    ,m.retailerUid
 FROM 
    #existingMetadataDuringDateRange m   
    INNER JOIN TerritorySupplies ts ON m.AssetVersionUid = ts.AssetVersionUid
    INNER JOIN TerritorySupplyDetails tsd ON ts.TerritorySupplyId = tsd.TerritorySupplyId
    INNER JOIN Prices p ON tsd.TerritorySupplyDetailId = p.TerritorySupplyDetailId
    INNER JOIN refCurrencyCode rcc ON p.Currency = rcc.CurrencyCodeId 
    INNER JOIN #CountrySetCountries csc ON ts.CountrySetUid = csc.CountrySetUid 
 WHERE 
    csc.country in ('GB','US','CA','AU','NZ')  
    AND p.PriceType=14 -- 14 = Agency
    AND P.IsTaxIncluded=0),
    
--CTE4 - Agency Prices CTE pivoted to get prices INTO per-territory columns
AgencyPricesPIVOT
(AssetversionUid,GBAgency,USAgency ,CAAgency,AUAgency,NZAgency,EffectiveFromUtc,EffectiveToUtc,retailerUid) 
As(SELECT 
    AssetversionUid
    ,[GB] as GBAgency
    ,[US] as USAgency
    ,[CA] as CAAgency
    ,[AU] as AUAgency
    ,[NZ] as NZAgency
    ,EffectiveFromUtc
    ,EffectiveToUtc
    ,retailerUid
FROM 
    (SELECT AssetversionUid, Amount, EffectiveFromUtc ,EffectiveToUtc, Country, PriceType,retailerUid FROM AgencyPricesCte) as PCte
PIVOT
(
max(PCte.amount)
FOR Country IN ([US], [GB], [AU], [CA], [NZ])
) AS Pivotable),

AllAssetVersionsNoCollapsedRows 
(AssetVersionUId, ValidFrom, ValidTo, Imprint, ISBN, Title, GBWholesalePPT,GBAgency, USWholesalePPT, USAgency, CAWholesalePPT, CAAgency, AUWholesalePPT, AUAgency, NZWholesalePPT,NZAgency, EffectiveFromUtc, EffectiveToUtc)
As
(
 SELECT
    AP.AssetVersionUid, 
    WP.ValidFrom,
    WP.ValidTo,
    Imprint,
    ISBN,
    Title
    ,CASE WHEN (GBWholesalePPT = GBAgency OR GBAgency IS NULL) THEN NULL ELSE GBWholesalePPT END AS GBWholesalePPT -- don't show wholesale/agency prices if they are the same.
    ,CASE WHEN (GBAgency = GBWholesalePPT OR GBWholesalePPT IS NULL) THEN NULL ELSE GBAgency END AS GBAgency
    ,CASE WHEN (WP.USWholesalePPT = AP.USAgency OR AP.USAgency IS NULL) THEN NULL ELSE WP.USWholesalePPT END AS USWholesalePPT
	,CASE WHEN (AP.USAgency = WP.USWholesalePPT OR WP.USWholesalePPT IS NULL) THEN NULL ELSE AP.USAgency END AS USAgency
	,CASE WHEN (WP.CAWholesalePPT = AP.CAAgency OR AP.CAAgency IS NULL) THEN NULL ELSE WP.CAWholesalePPT END AS CAWholesalePPT
	,CASE WHEN (AP.CAAgency = WP.CAWholesalePPT OR WP.CAWholesalePPT IS NULL) THEN NULL ELSE AP.CAAgency END AS CAAgency
	,CASE WHEN (WP.AUWholesalePPT = AP.AUAgency OR AP.AUAgency IS NULL) THEN NULL ELSE WP.AUWholesalePPT END AS AUWholesalePPT
	,CASE WHEN (AP.AUAgency = WP.AUWholesalePPT OR WP.AUWholesalePPT IS NULL) THEN NULL ELSE AP.AUAgency END AS AUAgency
	,CASE WHEN (WP.NZWholesalePPT = AP.NZAgency OR AP.NZAgency IS NULL) THEN NULL ELSE WP.NZWholesalePPT END AS NZWholesalePPT
	,CASE WHEN (AP.NZAgency = WP.NZWholesalePPT OR WP.NZWholesalePPT IS NULL) THEN NULL ELSE AP.NZAgency END AS NZAgency
	,AP.EffectiveFromUtc
    ,AP.EffectiveToUtc
 FROM 
    AgencyPricesPivot AP 
    INNER JOIN  WholesalePricesPivot WP ON WP.assetVersionUid = AP.assetVersionUid --This group is where wholesale and agency price intervals match
        AND WP.EffectiveFromUtc = AP.EffectiveFromUtc 
        AND WP.EffectiveToUtc = AP.EffectiveToUtc
 WHERE ((WP.GBWholesalePPT <> AP.GBAgency) --Only want results WHERE each Wholesale prices is different than the  Agency price for that country
        OR (WP.USWholesalePPT <> AP.USAgency)
        OR (WP.CAWholesalePPT <> AP.CAAgency)
        OR (WP.AUWholesalePPT <> AP.AUAgency)
        OR (WP.NZWholesalePPT <> AP.NZAgency))
    AND
	 ((WP.retailerUid IS NULL AND AP.retailerUid IS NULL) --joining retailer-specific or non-retailer together
        OR (WP.retailerUid = AP.retailerUid))
UNION
SELECT
    AP.AssetVersionUid, 
    WP.ValidFrom,
    WP.ValidTo,
    Imprint,
    ISBN,
    Title
    ,CASE WHEN (GBWholesalePPT = GBAgency OR GBAgency IS NULL) THEN NULL ELSE GBWholesalePPT END AS GBWholesalePPT -- don't show wholesale/agency prices if they are the same.
    ,CASE WHEN (GBAgency = GBWholesalePPT OR GBWholesalePPT IS NULL) THEN NULL ELSE GBAgency END AS GBAgency
    ,CASE WHEN (WP.USWholesalePPT = AP.USAgency OR AP.USAgency IS NULL) THEN NULL ELSE WP.USWholesalePPT END AS USWholesalePPT
	,CASE WHEN (AP.USAgency = WP.USWholesalePPT OR WP.USWholesalePPT IS NULL) THEN NULL ELSE AP.USAgency END AS USAgency
	,CASE WHEN (WP.CAWholesalePPT = AP.CAAgency OR AP.CAAgency IS NULL) THEN NULL ELSE WP.CAWholesalePPT END AS CAWholesalePPT
	,CASE WHEN (AP.CAAgency = WP.CAWholesalePPT OR WP.CAWholesalePPT IS NULL) THEN NULL ELSE AP.CAAgency END AS CAAgency
	,CASE WHEN (WP.AUWholesalePPT = AP.AUAgency OR AP.AUAgency IS NULL) THEN NULL ELSE WP.AUWholesalePPT END AS AUWholesalePPT
	,CASE WHEN (AP.AUAgency = WP.AUWholesalePPT OR WP.AUWholesalePPT IS NULL) THEN NULL ELSE AP.AUAgency END AS AUAgency
	,CASE WHEN (WP.NZWholesalePPT = AP.NZAgency OR AP.NZAgency IS NULL) THEN NULL ELSE WP.NZWholesalePPT END AS NZWholesalePPT
	,CASE WHEN (AP.NZAgency = WP.NZWholesalePPT OR WP.NZWholesalePPT IS NULL) THEN NULL ELSE AP.NZAgency END AS NZAgency
	,AP.EffectiveFromUtc
    ,AP.EffectiveToUtc
 FROM 
    AgencyPricesPivot AP 
    INNER JOIN  WholesalePricesPivot WP ON WP.AssetVersionUid = AP.AssetVersionUid 
 WHERE NOT EXISTS (
    SELECT 1 FROM WholesalePricesPivot WP2 WHERE WP2.AssetVersionUid = AP.AssetVersionUid AND WP2.EffectiveFromUtc = AP.EffectiveFromUtc AND WP2.EffectiveToUtc = AP.EffectiveToUtc)
and (WP.EffectiveFromUtc IS NULL OR WP.EffectiveFromUtc = AP.EffectiveFromUtc)
and (WP.EffectiveToUtc IS NULL OR WP.EffectiveToUtc = AP.EffectiveToUtc)
AND ((WP.GBWholesalePPT <> AP.GBAgency) --Only want results WHERE each Wholesale prices is different than the  Agency price for that country
        OR (WP.USWholesalePPT <> AP.USAgency)
        OR (WP.CAWholesalePPT <> AP.CAAgency)
        OR (WP.AUWholesalePPT <> AP.AUAgency)
        OR (WP.NZWholesalePPT <> AP.NZAgency))
    AND
	 ((WP.retailerUid IS NULL AND AP.retailerUid IS NULL) --joining retailer-specific or non-retailer together
        OR (WP.retailerUid = AP.retailerUid)))
,
GROUPS AS(
SELECT  DENSE_RANK() OVER ( ORDER BY [ISBN], [GBWholesalePPT], [GBAgency], [USWholesalePPT], [USAgency], [CAWholesalePPT], [CAAgency], [AUWholesalePPT], [AUAgency], [NZWholesalePPT], [NZAgency], [EffectiveFromUtc], isnull([EffectiveToUtc],'2099-12-31')) AS GroupID,
        ROW_NUMBER() OVER(PARTITION BY [Imprint], [ISBN], [Title], [GBWholesalePPT], [GBAgency], [USWholesalePPT], [USAgency], [CAWholesalePPT], [CAAgency], [AUWholesalePPT], [AUAgency], [NZWholesalePPT], [NZAgency], [EffectiveFromUtc], [EffectiveToUtc] ORDER BY ValidFrom) SequenceID
		,AssetVersionUId
		,ValidFrom
		,isnull(ValidTo,'2099-12-31') AS ValidTo
		,Imprint
		,ISBN
		,Title
		,GBWholesalePPT
		,GBAgency
		,USWholesalePPT
		,USAgency
		,CAWholesalePPT
		,CAAgency
		,AUWholesalePPT
		,AUAgency
		,NZWholesalePPT
		,NZAgency
		,EffectiveFromUtc
		,EffectiveToUtc
    FROM AllAssetVersionsNoCollapsedRows
   )
,
StartingPoints AS
(
    SELECT A.*, ROW_NUMBER() OVER(ORDER BY GroupID, SequenceID) AS RowNumber
    FROM GROUPS AS A
    WHERE NOT EXISTS (
        SELECT *
        FROM GROUPS AS B
        WHERE B.GroupID = A.GroupID AND B.SequenceID = A.SequenceID - 1
        AND B.ValidTo = A.ValidFrom)
)
,
EndingPoints AS
(
    SELECT A.*, ROW_NUMBER() OVER(ORDER BY GroupID, SequenceID) AS RowNumber
    FROM GROUPS AS A
    WHERE NOT EXISTS (
        SELECT *
        FROM GROUPS AS B
        WHERE B.GroupID = A.GroupID AND B.SequenceID = A.SequenceID + 1
        AND B.ValidFrom = A.ValidTo)
)

SELECT 
     S.ValidFrom
    ,CASE WHEN COALESCE(E.ValidTo, '12/31/2099') = '12/31/2099' THEN NULL ELSE E.ValidTo END AS ValidTo
    ,S.Imprint
    ,S.ISBN
    ,S.Title
    ,S.GBWholesalePPT
    ,S.GBAgency
    ,S.USWholesalePPT
    ,S.USAgency
    ,S.CAWholesalePPT
    ,S.CAAgency
    ,S.AUWholesalePPT
    ,S.AUAgency
    ,S.NZWholesalePPT
    ,S.NZAgency
    ,S.EffectiveFromUtc
    ,S.EffectiveToUtc
FROM StartingPoints AS S
INNER JOIN EndingPoints AS E ON E.GroupID = S.GroupID AND S.RowNumber = E.RowNumber
ORDER BY S.ISBN, S.ValidFrom, S.ValidTo