--Creating austindevvm_ss as snapshot of the
--austindevvm database:
CREATE 
DATABASE thomasdev_ss_515
ON
(	NAME = INgrooves_Data, FILENAME = 
	'D:\DBs\INgrooves2\ss515\INgrooves.MDF'),
(	NAME = Primary_File2, FILENAME = 
	'D:\DBs\INgrooves2\ss515\Primary_File2.NDF'),
(	NAME = Primary_File3, FILENAME = 
	'D:\DBs\INgrooves2\ss515\Primary_File3.NDF'),
(	NAME = IndexGroup_File1, FILENAME = 
	'D:\DBs\INgrooves2\ss515\IndexGroup_File1.NDF'),
(	NAME = IndexGroup_File2, FILENAME = 
	'D:\DBs\INgrooves2\ss515\IndexGroup_File2.NDF'),
(	NAME = IndexGroup_File3, FILENAME = 
	'D:\DBs\INgrooves2\ss515\IndexGroup_File3.NDF'),
(	NAME = CacheGroup_File1, FILENAME = 
	'D:\DBs\INgrooves2\ss515\CacheGroup_File1.NDF'),	
(	NAME = CacheGroup_File2, FILENAME = 
	'D:\DBs\INgrooves2\ss515\CacheGroup_File2.NDF'),
(	NAME = CacheGroup_File3, FILENAME = 
	'D:\DBs\INgrooves2\ss515\CacheGroup_File3.NDF')
AS SNAPSHOT OF INgrooves20130227
GO
---------------------------------------------------------------

USE master;
-- Reverting austindevvm to austindevvm_ss
RESTORE 
DATABASE INgrooves20130227
from 
DATABASE_SNAPSHOT = 'thomasdev_ss_515';
GO