--select * from ActiveSubscriptions
--select * from Batch
--select * from CachePolicy
select * from Catalog 
--select * from ChunkData

select * from ConfigurationInfo where ConfigInfoID = '613337E8-DD84-4684-BE2B-C88E32F8FA05'
select * from DataSets where Linkid = '613337E8-DD84-4684-BE2B-C88E32F8FA05'
select * from DataSource where Link = '613337E8-DD84-4684-BE2B-C88E32F8FA05'
--select * from DBUpgradeHistory
--select * from Event
select top 500 * from ExecutionLogStorage where ReportId = '613337E8-DD84-4684-BE2B-C88E32F8FA05'
order by TimeStart desc
--select * from History
--select * from Keys
--select * from ModelDrill
--select * from ModelItemPolicy
--select * from ModelPerspective
--select * from Notifications
--select * from Policies
--select * from PolicyUserRole
--select * from ReportSchedule
--select * from Roles
--select * from RunningJobs
select * from Schedule where ScheduleID = '613337E8-DD84-4684-BE2B-C88E32F8FA05'
--select * from SecData
select * from Segment where segmentid = '2530076D-543E-E411-9DA1-3640B5AEEBC3'
select * from SegmentedChunk where SnapshotDataId = '613337E8-DD84-4684-BE2B-C88E32F8FA05'
select * from ChunkSegmentMapping where Chunkid = '2430076D-543E-E411-9DA1-3640B5AEEBC3'
--select * from ServerParametersInstance
--select * from ServerUpgradeHistory
--select * from SnapshotData where SnapshotDataID = 'CC9EFDEF-E62D-4068-9F77-6DE473285351'
select * from Subscriptions where Report_oId = 'CC9EFDEF-E62D-4068-9F77-6DE473285351'
--16
--select * from SubscriptionsBeingDeleted
--select * from UpgradeInfo
select * from Users where userid = 'CC9EFDEF-E62D-4068-9F77-6DE473285351'


select sc.Name [Subscription], c.Name [Report], substring(ExtensionSettings, (patindex('%<Value>%', ExtensionSettings) + len('<Value>')), (patindex('%</Value>%', ExtensionSettings) - patindex('%<Value>%', ExtensionSettings) - len('<Value>'))) EmailList 
,* from Subscriptions s
join reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join Schedule sc on sc.scheduleId = rs.ScheduleId
join Catalog c on c.ItemId = s.Report_OID
where sc.Name <> 'Automation Schedule'
order by sc.Name, c.Name

select ds.*,c2.* from Subscriptions s
join reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join Schedule sc on sc.scheduleId = rs.ScheduleId
join Catalog c on c.ItemId = s.Report_OID
join DataSets ds on ds.ItemId = c.ItemId
join Catalog c2 on c2.ItemId = ds.LinkId
where c.name = 'Failed Ingestion'
and sc.name = 'Scholastic Daily Reports'
order by c.Name, sc.Name

use ReportServer;
SELECT distinct 'select * from ' + t.name,
SCHEMA_NAME(schema_id) AS schema_name--,
--c.name AS column_name
FROM sys.tables AS t
INNER JOIN sys.columns c ON t.OBJECT_ID = c.OBJECT_ID
--WHERE c.name LIKE '%Performer%'
--ORDER BY schema_name, table_name;



SELECT t.name,
SCHEMA_NAME(schema_id) AS schema_name,
c.name AS column_name
FROM sys.tables AS t
INNER JOIN sys.columns c ON t.OBJECT_ID = c.OBJECT_ID
WHERE c.name LIKE '%segment%'
--ORDER BY schema_name, table_name;

select * from Subscriptions
select * from ExecutionLogStorage
select * from ReportSchedule
select * from History
select * from ModelDrill
select * from CachePolicy
select * from ExecutionLogStorage
select * from Notifications
select * from ReportSchedule
select * from Subscriptions
select * from Notifications

A4232CD5-F61D-4613-9275-79686977FF02
2816C125-2290-4B96-9161-C91F43F5E107
43518F8D-4A5E-49C0-B038-000CAA8D2705
select * from athenareportcatalog..reportItems
select * from athenareportcatalog..reportResources
select * from athenareportcatalog..ReportTypeConfigurations
select * from athenareportcatalog..reportTypePublishers 


use athenadistribution;
select * from PublisherAttributeValues

use athenasecurity;
select o.OrganizationName, evv.* from OrganizationEntities oe
join EavAttributeSetAttributes eas on eas.EavAttributeSetId = oe.EavAttributeSetId
join EavAttributes ea on ea.eavAttributeId = eas.eavAttributeId
join EavEntities ee on ee.EavEntityId = oe.EavEntityId
join organizations o on o.organizationUId = oe.OrganizationUid
join EavValueVarchars evv on evv.EntityId = ee.EavEntityId
where EavAttributeName = 'Email'

select case when po.OrganizationName = 'Inscribe Digital' then ' ' else po.OrganizationName end as Parent,o.OrganizationName Imprint, 
isnull(Value, '') Email from organizations o
join organizations po on po.organizationUid = o.parentOrganizationUid
left join OrganizationEntities oe on o.organizationUId = oe.OrganizationUid
left join EavEntities ee on ee.EavEntityId = oe.EavEntityId
left join EavValueVarchars evv on evv.EntityId = ee.EavEntityId
left join EavAttributeSetAttributes eas on eas.EavAttributeId = evv.AttributeId
left join EavAttributes ea on ea.eavAttributeId = eas.eavAttributeId
where (ea.EavAttributeName is null or ea.EavAttributeName = 'Email') 
order by po.Organizationname, o.OrganizationName

select * from EavValueVarchars where Value like '%@%' order by Value

select * from EavAttributes
select * from EavAttributeSetAttributes
select * from EavEntities
select * from EavAttributeSets
select * from EavValueVarchars

221
216

select c.* from DataSets ds
join catalog c on c.itemId = ds.ItemId where c.name = 'failed ingestion'


select c.* from DataSets ds
join catalog c on c.itemId = ds.LinkId where ds.ItemId = '2816C125-2290-4B96-9161-C91F43F5E107'
--select * from athenaDistribution..publishers where PublisherUid = 'CC9EFDEF-E62D-4068-9F77-6DE473285351'

select ds.* from DataSource ds
join catalog c on c.itemId = ds.ItemId where c.name = 'failed ingestion'

select * from catalog where itemid = 'CC9EFDEF-E62D-4068-9F77-6DE473285351'
select * from athenadistribution..Publishers where organizationUid = '613337E8-DD84-4684-BE2B-C88E32F8FA05'
select * from catalog where itemid = '73E2ED6C-AC74-47A3-B57A-7B98543EB21F'
6AA0F5DC-BBB2-4DB1-9172-987C063E899E
613337E8-DD84-4684-BE2B-C88E32F8FA05




select * from EavValueVarchars where EntityId in (221,
216)
select * from EavEntities where EavEntityId in (221,
216)
select * from OrganizationEntities where EavEntityId in (221,
216)
select * from UserEntities where EavEntityId in (221,
216)