
select ms.Name, ca.FolderPrefix from 
musicservice ms 
cross apply
(select top 1 ContractAuthority from musicservicecontractauthority msca
where msca.musicservice = ms.id
order by contractAuthority) msc
join contractAuthority ca on ca.id = msc.contractAuthority
