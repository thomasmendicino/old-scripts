use INgrooves
go
--

    -- WARNING: This logic is duplicated in the syndication system, so if you modify this be sure
    -- that the syndication system is also updated
	
	-- Gets an albums acceptable countires by intersecting the (1)albums countries, 
	-- (2)organizations or persons countires, (3)contracts countries, and (4)area restrictions added 
	-- countries except the albums area restrictions removed countries.
    
    -- Albums countries
(   select distinct
		  a.ID			[Album]
		, csc.Country	[Country]
    from Album a
		inner join CountrySetCountry csc on a.CountrySet = csc.CountrySet
	intersect
    -- Organizations or Persons countries
	(	select distinct 
			  a.ID			[Album]
			, csc.Country	[Country]
		from Album a
			inner join Organization o		 on a.Organization	=	o.ID
			inner join CountrySetCountry csc on o.CountrySet	=	csc.CountrySet
		union
		-- Persons countries
			select distinct 
				  a.ID			[Album]
				, csc.Country	[Country]
			from Album a
				inner join person p		 on a.Person	=	p.ID
				inner join CountrySetCountry csc on p.CountrySet	=	csc.CountrySet			
			where a.Organization is null
	)
	intersect 
	-- Contracts countries
		select distinct
			  cav.Album		[Album]
			, csc.Country	[Country]
		from ContractAlbumViewActive cav
			inner join Contract c on cav.Contract=c.ID
			inner join CountrySetCountry csc on c.CountrySet=csc.CountrySet

	union 	-- AreaRestriction added countires
		select distinct 
			  ar.Album		[Album]
			, ar.Country	[Country]
		from AreaRestriction ar	 
		where	Operator	=	'+'
)
except
	-- AreaRestriction removed countries
		select distinct 
			  ar.Album		[Album]
			, ar.Country	[Country]
		from AreaRestriction ar	 
		where	Operator	=	'-'			

