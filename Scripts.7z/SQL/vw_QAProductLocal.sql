USE [UMGNA_DAVeReplicated]
GO

/****** Object:  View [dbo].[vw_QWProductLocal]    Script Date: 04/30/2013 11:47:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* ----------------------------------------------------------------      
 * Procedure:  vw_QWProductLocal      
 * Description: View of Product Local information for the       
 *  DAVe query wizard.      
 * Maintenance History:      
 * 08/28/2006 ELTON - Created      
 * 09/11/2006 RKCUBA - Misc DAVe 6.1 mods      
 * 01/23/2007 RKCUBA - Replace some temp constants with the real fn      
 * 01/25/2007 MADNYS - Replace title_ovr with fnProductTitleOvr      
 * 03/05/2007 JCHUA  - Function call to fnProductAssociatedProduct should use "product_local_id" (Issue #: 49453)      
 * 03/21/2007 MADNYS - Fixed join to use company_cd, division_cd and label_cd  instead of company_id, division_id and label_id      
 * 03/31/2007 MADNYS - Use function to get title, version_title & recording_time      
 * 02/27/2008 FRANKLIN -  Added preorderable column. Moved from vw_QWProduct      
 * 03/05/2008 EDB    - Modified to use fnProductContributorGetExt and fnAssetContributorGetExt for user-specified delimiters      
 * 12/05/2008 MAHESH - Added new column vod_type for Video On Demand      
 * 01/09/2008 BONDJ - R2 REMEDIATION      
 * 01/09/2009 BONDJ  - R2 REMEDIATION - re-alias changed columns      
 * 01/10/2009 BONDJ  - R2 REMEDIATION - put quotes on alias       
 * 01/27/2009 JEP  - Added Video on Demand Available Date  
 * 10/12/2009 JJACOB - Added Locked and Locked Reason  
 * 05/27/2010 JJACOB - Added GDRS Release Family Column  
 * 07/23/2010 JJACOB - Added Market Date to DAVe Query Wizard  
 * 
 * 05/18/2011 - SPECIAL VERSION FOR INgrooves 
 * 05/25/2011 - RKCUBA added dbo.fnProductLocalPND to calc PND flag
 * 06/27/2011 - RKCUBA - bigIntUPC added
 * 06/28/2011 - Added gdrs_release_family_id
 * 07/06/2011 RKCUBA - Added a few more columns
 * ----------------------------------------------------------------*/      
ALTER VIEW [dbo].[vw_QWProductLocal]      
AS      
      
SELECT pl.product_local_id,      
 pl.product_id,      
 pl.country_id,      
 pl.release_company_link_id as 'unique_prod_loc_id',      
 pl.upc,      
 pl.e_release_label AS 'p_e_release_label',      
 pl.genre AS 'p_genre',      
 pl.e_marketing_tag AS 'p_e_marketing_tag',      
 dbo.fnProductTitleGet (pl.title, pl.title_override) AS 'p_title',      
 dbo.fnProductTitleOvr(pl.title,pl.title_override) AS 'p_title_ovr', --TEST RIGGED      
 dbo.fnProductVersionTitleGet (pl.version_title, pl.version_title_override) AS 'p_version_title',      
 dbo.fnProductVersionTitleOvr (pl.version_title, pl.version_title_override) AS 'p_version_title_ovr', -- test_rigged      
 pl.release_date,      
 CONVERT(VARCHAR, pl.release_date, 101) AS 'release_date_display',      
 pl.series_title AS 'p_series_title',      
 pl.dq_status AS 'p_dq_status_local',      
 pl.status_local AS 'p_status_local',      
 pl.label_id AS 'p_label_id_local',      
 CASE WHEN ISNULL(pl.catalog_no,'') = '' THEN pl.catalog_number ELSE pl.catalog_no END AS 'catalog_no',      
 pl.catalog_number,      
 dbo.fnProductPCNotice('C', pl.product_local_id) as 'c_notice',      
 dbo.fnProductPCNotice('P', pl.product_local_id) as 'p_p_notice',      
 --product_local/tv fields ---------------------------------------------------------------------------------      
 pl.video_network AS 'p_video_network',      
 pl.video_season_id AS 'p_video_season_id',      
 pl.video_original_release_year AS 'p_video_original_release_year',      
 pl.video_rating AS 'p_video_rating',      
 CAST(pl.video_short_description AS NVARCHAR(4000)) AS 'p_video_short_description',      
 CAST(pl.video_long_description AS NVARCHAR(4000)) AS 'p_video_long_description',      
 --label/company/division----------------------------------------------------------------------      
 l.label_name AS 'p_label_name_local',      
 c.company_name AS 'p_company_name_local',      
 d.division_name AS 'p_division_name_local',      
 case when (dbo.fnAssetGroupExist(p.product_id) = 1) then 'Y' else 'N' end AS 'asset_group_exists',      
 replace(dbo.fnProductAssociatedProduct(pl.product_local_id), '||', ',') AS 'p_associated_product_upc',      
 -- contributors ------------------------------------------------------------------------------      
 p_artist = dbo.fnProductContributorGetExt(p.product_id, 1367, p.music_type, pl.rms_exists, pl.country_id, ' & '),      
 p_featured_artist = dbo.fnProductContributorGetExt(p.product_id, 1371, p.music_type, pl.rms_exists, pl.country_id, ' & '),       
 p_performer = dbo.fnProductContributorGetExt(p.product_id, 1372, p.music_type, pl.rms_exists, pl.country_id, ' & '),       
 p_conductor = dbo.fnProductContributorGetExt(p.product_id, 1369, p.music_type, pl.rms_exists, pl.country_id, ' & '),        
 p_ensemble = dbo.fnProductContributorGetExt(p.product_id, 1370, p.music_type, pl.rms_exists, pl.country_id, ' & '),       
 p_composer = dbo.fnProductContributorGetExt(p.product_id, 1368, p.music_type, pl.rms_exists, pl.country_id, ' & '),      
      
 pl.venture_type,      
 pl.repertoire_owner,      
 pl.cutout_reason_code,      
 pl.product_no,      
 pl.status,      
 pl.sndtrk_code,      
 pl.orig_release_date,      
 CONVERT(VARCHAR, pl.orig_release_date, 101) AS 'orig_release_date_display',      
 pl.super_label_desc,      
 pl.label_code_desc,      
 pl.mr_rpt_co,      
 pl.mr_rpt_unit,
 p.set_count as p_set_count,      
 pl.explicit_lyrics,      
 pl.company_code,      
 pl.intl_indicator,      
 pl.config_code,      
 pl.genre_type,
 genre_type.type as 'p_genre_description',
        
 pl.product_type_ms,       
 pl.group_code,       
 pl.imprint_label,       
 pl.release_family,      
 pl.super_label,      
 pl.physical_release_date,      
 CONVERT(VARCHAR, pl.physical_release_date, 101) AS 'physical_release_date_display',      
 CASE WHEN(pl.last_dav_update > pl.last_vic_update)      
  THEN CONVERT(DATETIME, CONVERT(VARCHAR, pl.last_dav_update, 101))      
  ELSE CONVERT(DATETIME, CONVERT(VARCHAR, pl.last_vic_update, 101))      
  END AS 'last_update_date',      
 CASE WHEN (pl.last_dav_update > pl.last_vic_update)       
  THEN CONVERT(VARCHAR, pl.last_dav_update, 101)       
  ELSE CONVERT(VARCHAR, pl.last_vic_update, 101) END AS 'last_update_date_display ',      
 CASE WHEN (pl.vic_exists = 1) THEN 'Y' ELSE 'N' END AS 'vic_exists',      
 CASE WHEN (pl.rms_exists = 1) THEN 'Y' ELSE 'N' END AS 'rms_exists',      
 CASE WHEN (dbo.fnPreorderable(p.config_id) = 1) AND pl.release_date >= getdate() THEN 'Y' ELSE 'N' END as 'preorderable',      
 pl.vod_type,    
/*-- Video on Demand Available date defaults to Release date --  
 pl.release_date AS 'vod_available_date',  
 CONVERT(VARCHAR, pl.release_date, 101) AS 'vod_available_date_display',*/  
 
 -- non necessary for INgrooves since this is related to integration activities
 --CASE WHEN (lp.product_local_id is null) THEN 'N' ELSE 'Y' END AS 'locked',    
 --lp.LockType lockedreason,  
 
 pl.gdrs_release_family_id,
 rf.release_family_desc  gdrs_release_family_desc,  
 pldd.market_date,  
 CONVERT(VARCHAR, pldd.market_date, 101) AS 'market_date_display',
 dbo.fnProductLocalPND (pl.product_local_id) as 'pnd',
 pl.owning_row,
 
 prod_config.type as product_type
 
 , pl.bigintUPC
      
FROM dbo.product_local pl with (nolock)     
LEFT JOIN dbo.company c  with (nolock)     
 ON pl.company_cd = c.company_cd      
LEFT JOIN dbo.label l  with (nolock)     
 ON pl.label_cd = l.label_cd      
LEFT JOIN dbo.division d  with (nolock)     
 ON pl.division_cd = d.division_cd      
 
-- Not necessary for INGrooves (RKC) because this is related to integration activities in DAVe
-- LEFT JOIN dbo.[vw_LockedProducts] lp      
-- ON pl.product_local_id = lp.product_local_id    

inner join dbo.product p  with (nolock)     
 on p.product_id = pl.product_id      
LEFT JOIN dbo.release_family rf with (nolock)       
 ON pl.gdrs_release_family_id = rf.release_family_id    
INNER JOIN dbo.vcProductLocalDueDate pldd WITH (NOLOCK)  
ON pl.product_local_id=pldd.product_local_id 
left outer join dbo.[type] prod_config with (nolock)
	on prod_config.code = p.config_id
	and prod_config.parent_id = 321  -- parent_id of r2 configs
left outer join dbo.[type] as genre_type with (nolock)
	on genre_type.code = pl.genre
	and genre_type.parent_id = 411 -- parent_id's of genre

GO


