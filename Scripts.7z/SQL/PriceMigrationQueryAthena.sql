--drop table #CountryList
create table #CountryList (CountrySetUid uniqueIdentifier, A2 nchar(2))
declare @CountrySetUid uniqueidentifier
declare @country table (A2 nchar(2))
declare @string nvarchar(max)
select @string = ''
declare @counter int = 1
declare @Lengths table (CountrySetUid uniqueidentifier, CountryList nvarchar(max), Length int)
insert @Lengths (CountrySetUid, CountryList, Length)
select CountrySetUid, CountryList, len(CountryList) from CountrySets

declare country_cursor cursor local for
select CountrySetUid from @Lengths

open country_cursor
fetch next from country_cursor into @CountrySetuid
while @@fetch_status=0
begin

INSERT INTO #CountryList (CountrySetUid, A2)
select CountrySetUid, substring(countryList, @Counter, 2) from @Lengths l
set @Counter = @Counter + 2

--IF (@Counter >= (select Length from @Lengths)


fetch next from country_cursor into @CountrySetUid
--waitfor delay '00:00:00.020'
end


 CLOSE country_Cursor
   DEALLOCATE country_Cursor
   /*
select * from #CountryList order by CountrySetUid, A2 

where CountrySetUid = '3CA1A835-BF76-4EE2-9FD6-0BD68FE6645B' and A2> '' order by CountrySetUid, A2

select * from countrySets where countrySetUid = '3CA1A835-BF76-4EE2-9FD6-0BD68FE6645B'
*/

delete from #CountryList where A2 < 'A'


select p.Ordinal, pr.Amount, rc.CurrencyCode, /*case when len(cs.CountryList) > 100 then 'WORLD' else cs.CountryList end Countries */ cl.A2 from product p
join asset a on a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
join assetVersion av on av.assetOverrideUid = ao.assetOverrideUid
join TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join TerritorySupplyDetails tsd on tsd.TerritorySupplyId = ts.TerritorySupplyId
join Prices pr on pr.TerritorySupplyDetailId = tsd.TerritorySupplyDetailId
join CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
join refCurrencyCode rc on rc.CurrencyCodeId = pr.Currency
join #CountryList cl on cl.CountrySetUid = cs.CountrySetUId
where 
av.ValidUntilUtc is NULL
and pr.Amount is not NULL
and pr.EffectiveFromUtc is NULL
and pr.EffectiveToUtc is NULL
and pr.PriceType = 1
and CurrencyCode <> 'USD'
UNION

select distinct p.Ordinal, pr.Amount, rc.CurrencyCode, NULL as [A2]
from product p
join asset a on a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
join assetVersion av on av.assetOverrideUid = ao.assetOverrideUid
join TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join TerritorySupplyDetails tsd on tsd.TerritorySupplyId = ts.TerritorySupplyId
join Prices pr on pr.TerritorySupplyDetailId = tsd.TerritorySupplyDetailId
join CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
join refCurrencyCode rc on rc.CurrencyCodeId = pr.Currency
join #CountryList cl on cl.CountrySetUid = cs.CountrySetUId
where 
av.ValidUntilUtc is NULL
and pr.Amount is not NULL
and pr.EffectiveFromUtc is NULL
and pr.EffectiveToUtc is NULL
and pr.PriceType = 1
and CurrencyCode = 'USD'
order by Ordinal


select distinct p.Ordinal, pr.Amount, rc.CurrencyCode, cs.CountryList from product p
join asset a on a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
join assetVersion av on av.assetOverrideUid = ao.assetOverrideUid
join TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join TerritorySupplyDetails tsd on tsd.TerritorySupplyId = ts.TerritorySupplyId
join Prices pr on pr.TerritorySupplyDetailId = tsd.TerritorySupplyDetailId
join CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
join refCurrencyCode rc on rc.CurrencyCodeId = pr.Currency
where ordinal = 9780486172019
and av.ValidUntilUtc is NULL
and pr.Amount is not NULL
and pr.EffectiveFromUtc is NULL
and pr.EffectiveToUtc is NULL
and pr.PriceType = 1
and ordinal in (
9781595785688,
9781601387554,
9781597262897,
9781601387165,
9781469982472,
9781601382412,
9781601383396,
9781780784014,
9780830758289,
9781780780023,
9781780789620,
9780830753130,
9781780782010,
9780984391967,
9781780789668,
9781599799520)