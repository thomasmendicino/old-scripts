Create Database Ingrooves_20110322_1600  on 
(NAME = Ingrooves_Data, FILENAME = 'd:\databases\INgrooves\INgrooves_data_20110322_1600.ss'),
(NAME = Primary_file2, FILENAME = 'd:\databases\INgrooves\INgrooves_primary2_20110322_1600.ss'),
(NAME = Primary_file3, FILENAME = 'd:\databases\INgrooves\INgrooves_primary3_20110322_1600.ss'),
(NAME = IndexGroup_file1, FILENAME = 'd:\databases\INgrooves\INgrooves_index1_20110322_1600.ss'), 
(NAME = IndexGroup_file2, FILENAME = 'd:\databases\INgrooves\INgrooves_index2_20110322_1600.ss'), 
(NAME = IndexGroup_file3, FILENAME = 'd:\databases\INgrooves\INgrooves_index3_20110322_1600.ss'),
(NAME = CacheGRoup_file1, FILENAME = 'd:\databases\INgrooves\INgrooves_cache1_20110322_1600.ss'), 
(NAME = CacheGRoup_file2, FILENAME = 'd:\databases\INgrooves\INgrooves_cache2_20110322_1600.ss'), 
(NAME = CacheGRoup_file3, FILENAME = 'd:\databases\INgrooves\INgrooves_cache3_20110322_1600.ss') 
as snapshot of INgrooves
GO