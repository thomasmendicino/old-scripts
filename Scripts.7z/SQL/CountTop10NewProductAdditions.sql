
declare @Interval int 
set @Interval = 7
;with parents as (
select OrganizationName, OrganizationUid from Organizations
where ParentOrganizationUid = '00000000-0000-0000-0000-000000000001'),
AddedProducts as (
	select distinct p.Ordinal ISBN, p.OrganizationUid from product p
	join asset a on a.ProductUid = p.ProductUid
	join AssetOverride ao on ao.AssetUid = a.AssetUid
	join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
	where pf.ProductFormTypeValue in (49,50,51,52)
	group by p.Ordinal, p.OrganizationUid
	having min(ValidFromUtc) > getUTCdate() - @Interval),
ap as
(select 
	Parents.OrganizationName Organization,
	ISBN
from parents
join AddedProducts pp on pp.organizationUid = parents.OrganizationUId
UNION
select 
	parents.OrganizationName Organization,
	ISBN
from parents 
join organizations children on children.ParentOrganizationUid = parents.OrganizationUid
join AddedProducts ap on ap.organizationUid = children.OrganizationUId
UNION
select
	parents.OrganizationName Organization,
	ISBN
from parents 
join organizations children on children.ParentOrganizationUid = parents.OrganizationUid
join organizations grandchildren on grandchildren.ParentOrganizationUid = children.OrganizationUid
join AddedProducts ap on ap.organizationUid = grandchildren.OrganizationUId),
APcount as 
(SELECT
	Organization, count(ISBN) AddedProductCount
	from ap
	group by Organization)

select Organization, 
sum(t2.AddedProductCount) as AddedProductCount
from 
	(select case when Sequence < 10 then Organization else 'Other' end as Organization, AddedProductCount,Sequence from 
		(select Organization, AddedProductCount, ROW_NUMBER() over (order by AddedProductCount desc, Organization asc) as Sequence from APcount
		) t
	) t2
group by t2.Organization, (case when Sequence < 10 then cast(t2.AddedProductCount as nvarchar(20)) else Organization end)
UNION
select Organization, 
sum(t2.AddedProductCount) as AddedProductCount
from 
	(select Organization, AddedProductCount from 
		(select Organization, AddedProductCount from APcount WHERE Organization in (
		'Bloomsbury Publishing','Scholastic Inc.','Disney Publishing Worldwide, Inc.','Arcadia Publishing Inc.','Babelcube')
		) t
	) t2
group by t2.Organization
order by t2.Organization