use AthenaAssetProcessor;

begin tran
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySixWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentySixWest26thStreetPress' WHERE Name = 'Client Console: 26 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySixWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentySixWest26thStreetPress' WHERE Name = 'Conversion House: 26 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySixWest26thStreetPress/FTP', SafeName = 'FtpTwentySixWest26thStreetPress' WHERE Name = 'FTP: 26 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySixWest26thStreetPress/Migration', SafeName = 'MigrationTwentySixWest26thStreetPress' WHERE Name = 'Migration: 26 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySixWest26thStreetPress/Reports', SafeName = 'ReportsTwentySixWest26thStreetPress' WHERE Name = 'Reports: 26 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySevenWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentySevenWest26thStreetPress' WHERE Name = 'Client Console: 27 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySevenWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentySevenWest26thStreetPress' WHERE Name = 'Conversion House: 27 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySevenWest26thStreetPress/FTP', SafeName = 'FtpTwentySevenWest26thStreetPress' WHERE Name = 'FTP: 27 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySevenWest26thStreetPress/Migration', SafeName = 'MigrationTwentySevenWest26thStreetPress' WHERE Name = 'Migration: 27 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentySevenWest26thStreetPress/Reports', SafeName = 'ReportsTwentySevenWest26thStreetPress' WHERE Name = 'Reports: 27 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyEightWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentyEightWest26thStreetPress' WHERE Name = 'Client Console: 28 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyEightWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentyEightWest26thStreetPress' WHERE Name = 'Conversion House: 28 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyEightWest26thStreetPress/FTP', SafeName = 'FtpTwentyEightWest26thStreetPress' WHERE Name = 'FTP: 28 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyEightWest26thStreetPress/Migration', SafeName = 'MigrationTwentyEightWest26thStreetPress' WHERE Name = 'Migration: 28 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyEightWest26thStreetPress/Reports', SafeName = 'ReportsTwentyEightWest26thStreetPress' WHERE Name = 'Reports: 28 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyNineWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentyNineWest26thStreetPress' WHERE Name = 'Client Console: 29 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyNineWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentyNineWest26thStreetPress' WHERE Name = 'Conversion House: 29 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyNineWest26thStreetPress/FTP', SafeName = 'FtpTwentyNineWest26thStreetPress' WHERE Name = 'FTP: 29 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyNineWest26thStreetPress/Migration', SafeName = 'MigrationTwentyNineWest26thStreetPress' WHERE Name = 'Migration: 29 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyNineWest26thStreetPress/Reports', SafeName = 'ReportsTwentyNineWest26thStreetPress' WHERE Name = 'Reports: 29 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleThirtyWest26thStreetPress' WHERE Name = 'Client Console: 30 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseThirtyWest26thStreetPress' WHERE Name = 'Conversion House: 30 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyWest26thStreetPress/FTP', SafeName = 'FtpThirtyWest26thStreetPress' WHERE Name = 'FTP: 30 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyWest26thStreetPress/Migration', SafeName = 'MigrationThirtyWest26thStreetPress' WHERE Name = 'Migration: 30 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyWest26thStreetPress/Reports', SafeName = 'ReportsThirtyWest26thStreetPress' WHERE Name = 'Reports: 30 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyOneWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleThirtyOneWest26thStreetPress' WHERE Name = 'Client Console: 31 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyOneWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseThirtyOneWest26thStreetPress' WHERE Name = 'Conversion House: 31 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyOneWest26thStreetPress/FTP', SafeName = 'FtpThirtyOneWest26thStreetPress' WHERE Name = 'FTP: 31 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyOneWest26thStreetPress/Migration', SafeName = 'MigrationThirtyOneWest26thStreetPress' WHERE Name = 'Migration: 31 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/ThirtyOneWest26thStreetPress/Reports', SafeName = 'ReportsThirtyOneWest26thStreetPress' WHERE Name = 'Reports: 31 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentyplaceWest26thStreetPress' WHERE Name = 'Client Console: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentyplaceWest26thStreetPress' WHERE Name = 'Conversion House: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/FTP', SafeName = 'FtpTwentyplaceWest26thStreetPress' WHERE Name = 'FTP: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/Migration', SafeName = 'MigrationTwentyplaceWest26thStreetPress' WHERE Name = 'Migration: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/Reports', SafeName = 'ReportsTwentyplaceWest26thStreetPress' WHERE Name = 'Reports: 20 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentyplaceWest26thStreetPress' WHERE Name = 'Client Console: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentyplaceWest26thStreetPress' WHERE Name = 'Conversion House: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/FTP', SafeName = 'FtpTwentyplaceWest26thStreetPress' WHERE Name = 'FTP: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/Migration', SafeName = 'MigrationTwentyplaceWest26thStreetPress' WHERE Name = 'Migration: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/Reports', SafeName = 'ReportsTwentyplaceWest26thStreetPress' WHERE Name = 'Reports: 20 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentyplaceWest26thStreetPress' WHERE Name = 'Client Console: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentyplaceWest26thStreetPress' WHERE Name = 'Conversion House: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/FTP', SafeName = 'FtpTwentyplaceWest26thStreetPress' WHERE Name = 'FTP: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/Migration', SafeName = 'MigrationTwentyplaceWest26thStreetPress' WHERE Name = 'Migration: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/Reports', SafeName = 'ReportsTwentyplaceWest26thStreetPress' WHERE Name = 'Reports: 20 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentyplaceWest26thStreetPress' WHERE Name = 'Client Console: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentyplaceWest26thStreetPress' WHERE Name = 'Conversion House: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/FTP', SafeName = 'FtpTwentyplaceWest26thStreetPress' WHERE Name = 'FTP: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/Migration', SafeName = 'MigrationTwentyplaceWest26thStreetPress' WHERE Name = 'Migration: 20 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyplaceWest26thStreetPress/Reports', SafeName = 'ReportsTwentyplaceWest26thStreetPress' WHERE Name = 'Reports: 20 West 26th Street Press'


update Publishers set SafeName = 'TwentySevenWest26thStreetPress' WHERE Name = '27 West 26th Street Press'
update Publishers set SafeName = 'TwentySixWest26thStreetPress' WHERE Name = '26 West 26th Street Press'
update Publishers set SafeName = 'TwentyEightWest26thStreetPress' WHERE Name = '28 West 26th Street Press'
update Publishers set SafeName = 'TwentyNineWest26thStreetPress' WHERE Name = '29 West 26th Street Press'
update Publishers set SafeName = 'TwentyEightWest26thStreetPress' WHERE Name = '28 West 26th Street Press'
update Publishers set SafeName = 'TwentyEightWest26thStreetPress' WHERE Name = '28 West 26th Street Press'
