
create table TMFailedDistributionDataSet ([ID] [bigint] IDENTITY(1,1) NOT NULL, FailedDate datetime, Code nvarchar(10), TheReason nvarchar(1000), DistributionORderUId uniqueidentifier, [Rank] smallint, CONSTRAINT [PK_DistributionOrderUid] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
