
use AthenaDistribution;
begin tran
select * from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name like '%overdri%'
/*

update ftp set HostName = 'ftp.overdrive.com', ProtocolType = 1, PortNumber = 21, StartingDirectory = '', UserName = 'inscribedigital', Password = '4P7-MAG-ACH-8PA' from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name = 'OverDrive Ftp for All Content'

update ftp set HostName = 'ftp.overdrive.com', ProtocolType = 2, PortNumber = 22, StartingDirectory = '', UserName = 'Disney', Password = '7G4-MQA-9U2-593' from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name = 'OverDrive Disney Ftp for All Content'

update ftp set HostName = 'ftp.overdrive.com', ProtocolType = 1, PortNumber = 21, StartingDirectory = '', UserName = 'ScholasticUS', Password = 'MNB-LKP-ZZS-TRQ' from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name = 'OverDrive Scholastic Ftp for All Content'

*/

update ftp set HostName = 'ftp.ingrooves.com', ProtocolType = 1, PortNumber = 21, StartingDirectory = '/RetailersTestUploadNewDistro/Overdrive/INscribe', UserName = 'ingroovestest', Password = 'ingrooves' from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name = 'OverDrive Ftp for All Content'

update ftp set HostName = 'ftp.ingrooves.com', ProtocolType = 1, PortNumber = 21, StartingDirectory = '/RetailersTestUploadNewDistro/Overdrive/Disney', UserName = 'ingroovestest', Password = 'ingrooves' from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name = 'OverDrive Disney Ftp for All Content'

update ftp set HostName = 'ftp.ingrooves.com', ProtocolType = 1, PortNumber = 21, StartingDirectory = '/RetailersTestUploadNewDistro/Overdrive/Scholastic', UserName = 'ingroovestest', Password = 'ingrooves' from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name = 'OverDrive Scholastic Ftp for All Content'

select * from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.name like '%overdri%'