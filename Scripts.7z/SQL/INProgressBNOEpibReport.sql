/*
Barnes&Noble:
report for what has gone (epibs) to BNO where the most recent delivery file size is smaller than an archived version of the asset.

table
latest BNO distribution of epib with epib size. empty column with max epib size for that product

table 
epib sizes and valid date ranges

report
compare last distributed size with max size. If it is smaller, report both sizes.
*/

;with MaxAt as (select max(ProcessedAtUtc) [MaxProcessedAtUTC], pr.ProductUid, r.Name from AthenaComposite..distributionOrderStatus dos
join AthenaComposite..distributionOrders do on do.distributionORderUId = dos.DistributionOrderUId
join AthenaComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaComposite..contracts c on c.contractUid = pr.contractUId
join AthenaComposite..retailers r on r.retailerUId = c.retailerUid
group by pr.productUid, r.Name)
select p.Ordinal ISBN, r.Name Retailer, do.DistributionOrderUid, dos.CreatedAtUtc TransferredAt, rt.Code, rct.Name, rat.AssetTypeCode AssetType, rs.Path, rs.Length,rs.Md5 from
product p
join productrevisions pr on pr.productUid = p.ProductUid
join ProductRevisionStructures prs on prs.ProductRevisionUid = pr.ProductRevisionUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join AssetVersion av on av.AssetVersionUid = prs.AssetVersionUid
join resources rs on rs.ResourceUid = prs.ResourceUid
join AssetOverride ao on ao.AssetOverrideUid = av.AssetOverrideUid
join asset a on a.AssetUid = ao.AssetUid
join contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.retailerUid = c.RetailerUid
join refAssetType rat on rat.AssetTypeId = a.AssetType
join refEventType rt on rt.EventTypeId = dos.ResultingEvent
join maxAt m on m.MaxProcessedAtUtc = dos.ProcessedAtUtc and m.Name = r.Name and m.productUid = p.ProductUid
join TMResourceContentType rct on rct.ResourceContentType = a.ResourceContentType
where 
r.Code = 'BNO'
and dos.ResultingEvent = 110 
and dos.ResultingMessage like 'Finished transfer for%'
and rat.AssetTypeCode like '%epib%'
and do.DistributionOrderUid = '43A5280D-B7C2-4C0C-AD1B-06E5D22C7DD2'


select top 50 * from productRevisionStructures
select * from TMResourceContentType

select top 50 * from distributionorderstatus where resultingMessage like 'Finished transfer for%' order by CreatedAtUtc desc
select top 5000 * from distributionorderstatus where resultingEvent = 110 order by CreatedAtUtc desc

select top 5000 * from distributionorderstatus where distributionOrderUid = '52E84EA5-ACEB-457A-9128-A7EA20F33DC6'
select top 500 * from batchstatus where batchUid = 'c56969ba-15cf-4ca8-abe6-4adc34d0d035' order by CreatedAtUtc desc

select * from refAssetType where AssetTypeCode like '%epib%'

select distributionOrderStructureId from ProductRevisionStructures prs
join productRevisions pr on pr.ProductRevisionUid = prs.ProductRevisionUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join distributionorderstructuregroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join distributionorderstructuregroupbatches db on db.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join distributionOrderStructures dos on dos.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
where do.DistributionOrderUid = '43A5280D-B7C2-4C0C-AD1B-06E5D22C7DD2'
select * from batches where batchUid = 'AA367143-0454-446C-A537-71957E5DDC60'

select top 500 * from DistributionOrderStructureFulfillments where DistributionOrderStructureId in (select distributionOrderStructureId from ProductRevisionStructures prs
join productRevisions pr on pr.ProductRevisionUid = prs.ProductRevisionUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join distributionorderstructuregroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join distributionorderstructuregroupbatches db on db.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join distributionOrderStructures dos on dos.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
where do.DistributionOrderUid = '43A5280D-B7C2-4C0C-AD1B-06E5D22C7DD2')
--select * from distributionorderstructures

select * from resources r
join AssetVersion av on av.ResourceUid = r.ResourceUid
where r.ResourceUid in ('6A15E729-71CF-40BC-8286-900132A67981','20F369BA-108D-4F4A-A0D0-E4A4B3B7A9B1')