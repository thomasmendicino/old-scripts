begin tran
update JP set StringValue = replace(StringValue,'\\ftp','\\instor02') 
from JobParameter JP
join Job j on j.id = jp.job
where j.Name = 'AthenaImportJob'