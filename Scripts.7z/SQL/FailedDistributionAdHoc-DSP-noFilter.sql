USE AthenaComposite;
SET NOCOUNT ON 
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED	

DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @ISBNs table (ISBN bigint)
DECLARE @pacificTime int
DECLARE @DistributionTitles table (Title nvarchar(200), OrgUid uniqueidentifier, ISBN bigint, OnSaleDate datetime,    ProductUid uniqueidentifier,    RetailerUid uniqueidentifier,    Retailer nvarchar(50),    ProcessedAtUtc datetime,    distributionOrderUId uniqueidentifier)
DECLARE @DistributionDataSet table (FailedDate datetime, Code nvarchar(10), TheReason nvarchar(1000), DistributionOrderUId uniqueidentifier, [Rank] smallint)
DECLARE @Publisher nvarchar(200) = NULL
DECLARE @Retailer table (RetailerCode nvarchar(5))
DECLARE @ReasonString nvarchar(max) = NULL
/*  ------
	Set the Start and End time range to gather failed distribution from
	-------
*/
SET @DateRangeStart = getutcdate()-200
SET @DateRangeEnd = getutcdate()

/*	------
	OPTIONAL: Set the Publisher name to be searched. Using the top level publisher will include imprints. Leave NULL to search all.
	------
*/

SET @Publisher = 'Dreamspinner Press'


/*	------
	OPTIONAL: Set the Retailers to check. Use retailer CODES, not names.
	------
*/

INSERT @Retailer (RetailerCode)
SELECT Code from dbo.Retailers WHERE Code in ('APC')


/*	------
	OPTIONAL: Use a set of ISBNs to query. 
	------
*/
/*
INSERT @ISBNs (ISBN)
SELECT Ordinal from dbo.Product WHERE Ordinal in (
9781849460330,
9781849465045)
*/
/*	------
	OPTIONAL: Filter to a single failure reason string.
	Example: 'Transfer failed' or 'Physical price rules violation'
	------
*/
/*
SET @ReasonString = 'Transfer Failed'

*/

SET @pacificTime = datediff(hh,getUTCdate(),getdate())


;with MaxAt as (select max(ProcessedAtUtc) [MaxProcessedAtUTC], pr.ProductUid, r.Name from AthenaComposite..distributionOrderStatus dos
join AthenaComposite..distributionOrders do on do.distributionOrderUId = dos.DistributionOrderUId
join AthenaComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaComposite..contracts c on c.contractUid = pr.contractUId
join AthenaComposite..retailers r on r.retailerUId = c.retailerUid
join AthenaComposite..product p on p.ProductUid = pr.ProductUid
where 
	((SELECT TOP 1 1 from @ISBNs) IS NULL OR p.Ordinal in (SELECT ISBN from @ISBNs))
	AND ((@Publisher IS NULL) OR p.OrganizationUid in (select organizationUId from AthenaSecurity..OrgHierarchy(@Publisher)))
	AND ((SELECT TOP 1 1 from @Retailer) IS NULL OR r.Code in (SELECT RetailerCode from @Retailer))
group by pr.productUid, r.Name
having max(ProcessedAtUtc) > @DateRangeStart),

FailedOrders as (
select do.DistributionOrderUid from AthenaComposite..DistributionOrders do
join AthenaComposite..DistributionOrderStatus dos on dos.distributionOrderUid = do.distributionOrderUId
join AthenaComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaComposite..contracts c on c.contractUid = pr.contractUId
join AthenaComposite..retailers r on r.retailerUId = c.retailerUid
join MaxAt m on m.ProductUid = pr.productUid and m.Name = r.Name and m.MaxProcessedAtUTC = dos.ProcessedAtUTC
where dos.ResultingEventLevel = 4)

INSERT @DistributionTitles (Title, OrgUid, ISBN, OnSaleDate, ProductUid, RetailerUid, Retailer, ProcessedAtUtc, distributionOrderUId)
SELECT DISTINCT
    coalesce(td.TitleStatement, te.TitleText, TitlePrefix + ' ' + TitleWithoutPrefix) AS Title,
	pub.OrganizationUid AS OrgUid,
    p.Ordinal AS ISBN,
	pd.Value AS OnSaleDate,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    dos.ProcessedAtUtc AS ProcessedAtUtc,
    F.distributionOrderUId
FROM
	AthenaComposite..DistributionOrderStatus dos
	INNER JOIN AthenaComposite..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaComposite..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaComposite..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaComposite..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaComposite..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaComposite..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN AthenaComposite..asset a on a.productUid = p.productUid
    CROSS APPLY 
        (SELECT TOP 1 AssetOverrideUid
         FROM AthenaComposite..AssetOverride 
		 WHERE AssetUid = a.AssetUid
	     Order BY RetailerUid) ao
    INNER JOIN AthenaComposite..assetVersion av on av.assetOverrideUid = ao.assetOverrideUId
    INNER JOIN AthenaComposite..TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN AthenaComposite..TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN AthenaProductCatalog..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    INNER JOIN AthenaComposite..productForms pf on pf.assetVersionUid = av.AssetVersionUid
    INNER JOIN FailedOrders f on f.DistributionOrderUid = do.DistributionOrderUid
WHERE
	pf.ProductFormTypeValue IN (49,50,51,52)
	AND dos.ProcessedAtUtc BETWEEN @DateRangeStart AND @DateRangeEnd
	AND av.ValidUntilUtc is NULL
	AND ((SELECT TOP 1 1 from @ISBNs) IS NULL OR p.Ordinal in (SELECT ISBN from @ISBNs))
	AND ((@Publisher IS NULL) OR p.OrganizationUid in (select organizationUId from AthenaSecurity..OrgHierarchy(@Publisher)))
	AND ((SELECT TOP 1 1 from @Retailer) IS NULL OR r.Code in (SELECT RetailerCode from @Retailer))

--select * from @DistributionTitles
--1716, 1:50
--1714, 1:38
INSERT @DistributionDataSet (FailedDate, TheReason, Code, DistributionOrderUId, [Rank])
SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
    left(ret.Title,1000) AS TheReason,
	ret.Code,
	dt.DistributionOrderUId,
	1 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
	INNER JOIN AthenaComposite..DistributionOrderAcceptabilities doa on doa.distributionOrderUid = do.distributionOrderUid
    INNER JOIN AthenaComposite..refEventType ret on ret.EventTypeId = doa.ResultingEvent
WHERE
    doa.ResultingEventLevel > 2
    --AND ret.Code NOT IN ('REM','DIDC','DINA','EAVE')                          -- Not distributed based on contract
                
UNION

	SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
	left(dos.ResultingMessage,1000) AS TheReason,
	ret.Code,
    dt.DistributionOrderUId,
	2 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
    INNER JOIN AthenaComposite..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
    INNER JOIN AthenaComposite..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel > 2
    --AND ret.Code NOT IN ('DIDC','REM','DINA')                          -- Not distributed based on contract

UNION    

	SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
    left(ret.Title,1000) AS TheReason,
	ret.Code,
    dt.DistributionOrderUId,
	3 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
    INNER JOIN AthenaComposite..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
    INNER JOIN AthenaComposite..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel > 2
    --AND ret.Code NOT IN ('DIDC','REM','DINA')                          -- Not distributed based on contract
    
SELECT distinct
    ISBN,
	case 
		when po.OrganizationName = 'INscribe Digital' then o.OrganizationName
		when ppo.OrganizationName = 'INscribe Digital' then po.OrganizationName
		when pppo.OrganizationName = 'INscribe Digital' then ppo.OrganizationName
		when ppppo.OrganizationName = 'INscribe Digital' then pppo.OrganizationName
		when po.OrganizationName is NULL then o.OrganizationName
	end as [TopLevelParent],
	o.OrganizationName [Imprint],
    Title,
    OnSaleDate,
    Retailer,
    a.FailedDate,
	a.Code,
    a.TheReason as Reason
from AthenaComposite..distributionOrders do
	cross apply (
		select top 1 distributionOrderUid, TheReason, Code, FailedDate from @DistributionDataSet d
		where do.distributionOrderuid = d.distributionOrderUid
		Order by [Rank] asc, TheReason desc) a
	join @DistributionTitles dt on dt.DistributionOrderUid = do.distributionOrderUid
	join AthenaComposite..productRevisions pr on pr.productRevisionUid = do.productRevisionUid
	join AthenaProductCatalog..product p on p.productUid = pr.productUid
	join AthenaSecurity..organizations o on o.organizationUid = p.organizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations po on po.organizationUid = o.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations ppo on ppo.organizationUid = po.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations pppo on pppo.organizationUid = ppo.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations ppppo on ppppo.organizationUid = pppo.ParentOrganizationUid
where (@ReasonString is NULL OR a.TheReason like '%' + @ReasonString + '%')
	Order by TopLevelParent, Imprint, ISBN


