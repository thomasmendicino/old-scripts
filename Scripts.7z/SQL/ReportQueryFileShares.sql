/*
use reportserver
select sc.Name [Subscription], c.Name [Report]--, substring(ExtensionSettings, (patindex('%<Value>%', ExtensionSettings) + len('<Value>')), (patindex('%</Value>%', ExtensionSettings) - patindex('%<Value>%', ExtensionSettings) - len('<Value>'))) EmailList 
,s.* from Subscriptions s
join reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join Schedule sc on sc.scheduleId = rs.ScheduleId
join Catalog c on c.ItemId = s.Report_OID

*/
USE AthenaComposite;
if object_ID ('tempdb..#ReportResultsFS') is not null
drop table #ReportResultsFS
GO
if object_ID ('tempdb..#ErrFile') is not null
drop table #ErrFile
GO

declare @DeliveryExtension nvarchar(50) = 'Report Server FileShare'
declare @Schedule nvarchar(100) = 'Automation Schedule'
declare @Report nvarchar(100) = 'Failed Distribution'
create table #ReportResultsFS (SubscriptionUid uniqueidentifier, Organization uniqueidentifier, PublisherUid uniqueidentifier, Path nvarchar(1000), Filename nvarchar(200), RenderFormat nvarchar(20), WriteMode nvarchar(50), DateRangeStart datetime, DateRangeEnd datetime)
CREATE TABLE #ErrFile (ExecError INT)
declare @cmd nvarchar(max), @ExecError INT
declare @queryToRun table (SubscriptionId uniqueidentifier, Query nvarchar(max))
insert @queryToRun (SubscriptionID, Query)
select s.SubscriptionId, substring(cast(DataSettings as nvarchar(max)),(charindex('<CommandText>',cast(DataSettings as nvarchar(max))) + 13),(charindex('</CommandText>',cast(DataSettings as nvarchar(max))) - charindex('<CommandText>',cast(DataSettings as nvarchar(max))) - 13)) Query
 from ReportServer..Subscriptions s
 join ReportServer..reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join ReportServer..Schedule sc on sc.scheduleId = rs.ScheduleId
join ReportServer..Catalog c on c.ItemId = s.Report_OID
 where DeliveryExtension = @DeliveryExtension
 and sc.Name = @Schedule
 and c.Name = @Report
--select * from queryToRun
select top 1 @cmd = Query from @queryToRun
--select @cmd
insert #ReportResultsFS (Organization, PublisherUid, Path, Filename, RenderFormat, WriteMode, DateRangeStart, DateRangeEnd )
exec (@cmd)
set @ExecError = (SELECT * FROM #ErrFile)
update #ReportResultsFS set SubscriptionUid = SubscriptionId from @queryToRun where SubscriptionUid is NULL
select p.Name Publisher, po.OrganizationName Parent, c.Name Report, sc.Name Schedule, fs.Path + '/' + fs.Filename as FilePath, fs.RenderFormat, fs.DateRangeStart, fs.DateRangeEnd, s.Description, s.LastRunTime, s.LastStatus from #ReportResultsFS fs
join ReportServer..Subscriptions s on s.subscriptionId = fs.SubscriptionUid
join ReportServer..reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join ReportServer..Schedule sc on sc.scheduleId = rs.ScheduleId
join ReportServer..Catalog c on c.ItemId = s.Report_OID
join AthenaComposite..publishers p on p.publisherUid = fs.PublisherUid
join AthenaComposite..organizations o on o.organizationUid = p.OrganizationUid
left join AthenaComposite..organizations po on po.OrganizationUid = o.ParentOrganizationUid
ORDER by p.Name, fs.RenderFormat