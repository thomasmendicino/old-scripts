declare @pubname table (name nvarchar(100))
insert @pubname (name)
select '1 to 1 Publishers' union
select 'Abilene Christian University Press' union
select 'Activate Books' union
select 'Alhambra Press' union
select 'Amalion' union
select 'Amanda Cockrell' union
select 'Ambassador Family Press' union
select 'Ambrosia Sands Books' union
select 'American Society of Agricultural and Biological Engineers' union
select 'Ana Claudia Antunes' union
select 'Andre' union
select 'Art Pants Company' union
select 'Aslan Group Publishing' union
select 'Aspire Press' union
select 'Aunt Lute Books' union
select 'Autumn + Colour eBooks' union
select 'Aviva Publishing' union
select 'Babelcube Inc.' union
select 'Bad Press' union
select 'Bamboo Forest Publishing' union
select 'Bandit Books' union
select 'Barbican Press' union
select 'Bass Inc.' union
select 'Bibliomotion, Inc.' union
select 'Big Apple Publishing Co' union
select 'Big Apple Publishing Company' union
select 'Bilineata Publishing' union
select 'Bloomfield Publishing' union
select 'Bloomingdale Books' union
select 'Bolster Life Group Inc' union
select 'Bon Accord Press' union
select 'Book MatchMaker LLC' union
select 'Borre Educatief bv' union
select 'Boyds Mills Press' union
select 'BQB Publishing' union
select 'Brian D. Meeks' union
select 'Brown Girls Publishing' union
select 'Calkins Creek' union
select 'Caltrop Books' union
select 'Camino Books, Inc.' union
select 'Carson Five' union
select 'Christopher Bunn' union
select 'Cognosco Learning Publisher' union
select 'Columbia Island Press' union
select 'Concentric Order' union
select 'Conrad Jones' union
select 'Copenhagen Street Media' union
select 'Copper Bay Press, LLC' union
select 'Cosimo Books' union
select 'Cosimo Classics' union
select 'Craving Distraction Ltd' union
select 'Creative Distraction Ltd' union
select 'Creative Dynamics, LLC' union
select 'Creflo Dollar Ministries Publishing' union
select 'Crime Bytes Media' union
select 'csadler books' union
select 'D.a. Abrams' union
select 'Dan Alatorre' union
select 'Dark Fantasy Press' union
select 'DeadPixel Publications' union
select 'Defenestration Press' union
select 'Demo Publisher' union
select 'Domus Supernaturalis' union
select 'Doobie Shemer' union
select 'Douglas Valentine' union
select 'Dove''s Diner Inc.' union
select 'Dr. Rollan Roberts II' union
select 'Dunlap & Dunlap Publishing, LLC' union
select 'Dunwich Edizioni' union
select 'Ediciones Encuentro S. A.' union
select 'Edizioni Haiku' union
select 'Eileen Goudge' union
select 'Eileen Rendahl' union
select 'Elemental Editora��o' union
select 'EnemyOne' union
select 'Expansion Press' union
select 'ExtendED Notes' union
select 'Falcon Flight Press' union
select 'FAM Press' union
select 'Fire Flies Entertainment' union
select 'First Love Media' union
select 'Five MInute Books' union
select 'Float Street Press' union
select 'Freedom Rains Press' union
select 'Front Street' union
select 'Future Fiction' union
select 'Gayrotica Press' union
select 'Gimlet Eye Books' union
select 'Glenmere Press' union
select 'Granite Gate Media' union
select 'Graylin Rane' union
select 'Greater Minds Ltd' union
select 'Green Vase Publishing' union
select 'Gryphon House, Inc.' union
select 'Gryphonwood Press' union
select 'Halcyon Hall' union
select 'Harbinger Books' union
select 'Hatco Publishing' union
select 'Health Professions Press, Inc.' union
select 'Heather Trexler Remoff' union
select 'Hecate Publishing' union
select 'Hedonist Six' union
select 'Hekarose Publishing Group' union
select 'Herbert Mitgang Publications' union
select 'Hetman Publishing' union
select 'High School Voices Press' union
select 'Hinkler Books' union
select 'How To Help Children' union
select 'Iced Tea Publications' union
select 'idesire publications' union
select 'Idiom Magic Publications' union
select 'In Dreams Extreme Press' union
select 'In This Together Media' union
select 'Ink Monster' union
select 'Ink Monster, LLC' union
select 'Ink River Editions' union
select 'INscribe Digital Press' union
select 'Inverlochy House Publishers' union
select 'Island Press' union
select 'Jackie Sexton' union
select 'Janda Books' union
select 'Jason Cannon' union
select 'Jason Matthews' union
select 'Jen Minkman' union
select 'Joanne Leedom-Ackerman' union
select 'Jocelyn Han' union
select 'Jodie Esch' union
select 'John Neufeld' union
select 'JOSE RAMON MORENO BERMEJO' union
select 'Jourdan Lane' union
select 'Julie Farrell' union
select 'Karen Severson' union
select 'Karin Tabke LLC' union
select 'Katia Jordan' union
select 'Kats Kreative Ideas' union
select 'Kc Global Enterprises' union
select 'Kennerson Books' union
select 'Kettle Books' union
select 'Kevin Krajick' union
select 'Kibbe Books' union
select 'Kink and a Half Press' union
select 'Kirby Hollow Press' union
select 'KJG Publications' union
select 'Klingenberg Press' union
select 'KMWillis Books' union
select 'Koi no Otosan Books' union
select 'Kotker Books' union
select 'Kristen James' union
select 'Kyss Publishing' union
select 'Lamprey & Lee' union
select 'Laurie Lisle' union
select 'Leafwood Publishers' union
select 'Leela Books' union
select 'Let�cia Kartalian' union
select 'Lexington Avenue Press' union
select 'Lexus' union
select 'Life Changing Books' union
select 'Light Messages Publishing' union
select 'Liquid Silver Books' union
select 'Live the Dream Publishers' union
select 'Lorhainne Eckhart' union
select 'Lorhainne Eckhart Publishing' union
select 'Love Conquers All Press' union
select 'LRT Publishing' union
select 'Luey & Saperstein' union
select 'Mack C. Moore' union
select 'Macro Publishing Group' union
select 'Maialen Alonso' union
select 'Marcel Henry' union
select 'Marian Betancourt' union
select 'Marlayna Glynn Brown' union
select 'Martin Publications' union
select 'Mary and Richard Rensberry' union
select 'Mat Coward' union
select 'Maya Shepherd' union
select 'Melanie Marchande' union
select 'Melissa Martin' union
select 'Michael Foster' union
select 'Midwifery Press' union
select 'MLA Members for Scholar''s Rights' union
select 'MLC Ventures' union
select 'Molinero Books' union
select 'Monje Press' union
select 'Moon Flower Press' union
select 'Motivational Press, Inc.' union
select 'MPB Press' union
select 'MuseItUp Publishing' union
select 'MuseItYA' union
select 'MuseItYoung' union
select 'Musically Gifted Licensing Corporation' union
select 'Naughty Bytes' union
select 'Nel Mezzo della Vita Press' union
select 'Nerea Nieto' union
select 'Nero Press Edizioni' union
select 'New Vessel Press' union
select 'Nikki Pink' union
select 'North Pine Press' union
select 'Otbebookpublishing' union
select 'Our Pack Press' union
select 'P and E Press' union
select 'Pants On Fire Press' union
select 'Paper Dragon Publishing' union
select 'Paraview Press' union
select 'Patricia Mclinn' union
select 'Paul Levinson' union
select 'Perdido Pub' union
select 'Phalanx Guild Press' union
select 'Pickett Press' union
select 'Pine Tribe Ltd.' union
select 'Pixel Hall Press' union
select 'Pixel-Shifters' union
select 'Planettopia Publishing' union
select 'Polyphony H.S.' union
select 'Port Vendre Press' union
select 'Private Tutor' union
select 'Punch Buggy Studio, LLC' union
select 'Rebecca Cantrell' union
select 'Restless Books' union
select 'Richard Stooker' union
select 'Rik Isensee' union
select 'Rinnovo Press' union
select 'Rocky Pines Press' union
select 'Roos & Tegn�r AB' union
select 'Rose + Gully' union
select 'Rose Publishing, Inc.' union
select 'Rosemary Laurey' union
select 'RosettaBooks' union
select 'Rozelle Press' union
select 'Ruth Duskin Feldman Words and Pictures' union
select 'S.j. Scott' union
select 'Sage Books, LLC' union
select 'Sardis County Sentinel Press' union
select 'Saturn International' union
select 'SBD' union
select 'Scott Cramer' union
select 'Seabrooke Books' union
select 'Shawn Inmon' union
select 'Signal Press' union
select 'Simone Holloway' union
select 'Skary Ink' union
select 'SL eBooks' union
select 'Smudge Publishing' union
select 'Solo Publishing Co' union
select 'Sonic Connect Trust' union
select 'Srmasters.com' union
select 'Stone Steeple Books' union
select 'Sugarbird Publishing' union
select 'Sunrise Consulting' union
select 'Swoon Romance' union
select 'T.I.M.E. Institute, LLC' union
select 'Take Pride Learning' union
select 'Tawny Weber' union
select 'Taylor Nicole Publishing' union
select 'Ten Thousand Words Publishing Co.' union
select 'Tertia, Inc.' union
select 'The Gladys Malvern Estate' union
select 'The Lincoln Library Press, Inc.' union
select 'The Mary Lasswell Estate' union
select 'The Mermaid Literary Group' union
select 'The Vera Caspary Estate' union
select 'Theresa Nelson' union
select 'Third Bridge Press' union
select 'Three Jewels Press' union
select 'Tia With A Pen Publishing' union
select 'Tilly''s Tales' union
select 'TKA Distribution' union
select 'Tom Wells' union
select 'Torchflame Books' union
select 'Tornasol Press' union
select 'Troll River Publishing' union
select 'True 2 Life Publications' union
select 'Tule Publishing Group' union
select 'Turtleshell Press' union
select 'Ubiquitous Press' union
select 'Unitexto Editorial Digital' union
select 'Unitexto. Digital Publishing' union
select 'Urban Ideas Publishing Company' union
select 'Ursabrand Media' union
select 'USC Annenberg Press' union
select 'Valley Publishing' union
select 'Vanessa Kier' union
select 'Veronica Lane Books' union
select 'Virna DePaul' union
select 'Ward Wilson' union
select 'Wayne State University Press' union
select 'Web of Life Solutions' union
select 'Werner Stejskal' union
select 'West Creek Press' union
select 'Western Star Books' union
select 'Wilbur Cross Books' union
select 'Wordsong' union
select 'WriteLife Publishing' union
select 'YMAA Publication Center, Inc.' union
select 'Zuzalley Books'

select * from @pubname
except
select distinct p.Name from athenaassetprocessor..folderobjects fo
join importFolderConfigurations ic on ic.importFolderConfigurationUid = fo.importFolderConfigurationUId
join publishers p on p.publisherUid = ic.publisherUid
where createdAtUtc > getUTCdate()-1 
and ic.name like 'Migration%'

select * from @pubname
intersect
select distinct p.Name from athenaassetprocessor..folderobjects fo
join importFolderConfigurations ic on ic.importFolderConfigurationUid = fo.importFolderConfigurationUId
join publishers p on p.publisherUid = ic.publisherUid
where createdAtUtc > getUTCdate()-1 
and ic.name like 'Migration%'



select * from AthenaMigrator..logMessages where severity > 1 and at > getUTCdate()-1 order by at desc
select * from AthenaMigrator..jobs where jobUid in ('831B6AED-DDEF-442C-B78A-FB5093403E53',
'9FF425A1-6BCA-41C1-9528-A6A0EF799805',
'882F3DD6-5662-4BD6-B113-3A686A612471',
'5D22F653-87A3-4B9C-ABFC-2C888145A929',
'A9D74EC1-9196-46B5-8ABD-CCB0C9BEA67B',
'8E109E53-DF1B-4FE3-9B23-4F409A15204E',
'8C838560-1A3A-4181-9B36-BC62F143CDE6')
f3563345-1dc1-4247-8fe7-49a62480e176
select * from publishers where publisherUid = 'f3563345-1dc1-4247-8fe7-49a62480e176'
--Ambassador Family Press
--Babelcube Inc.
--Aslan Group Publishing
--XXXAmanda Cockrell
--Andre
--Aunt Lute Books
--XXXBass Inc.  -- Item with same key
--XXXAutumn + Colour eBooks -- Item with same key
select * from publishers pub
join organizations o on o.organizationUid = pub.organizationUid 
join product p on p.OrganizationUid = o.OrganizationUid 
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join resources r on r.ResourceUid = av.ResourceUid
left join AthenaResourceStorage..OnixResources ox on ox.ResourceUid = r.ResourceUid
where pub.name = '1 to 1 publishers' order by validfromutc

select * from publishers pub
join organizations o on o.organizationUid = pub.organizationUid 
join product p on p.OrganizationUid = o.OrganizationUid 
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join resources r on r.ResourceUid = av.ResourceUid
left join AthenaResourceStorage..OnixResources ox on ox.ResourceUid = r.ResourceUid
where pub.name like '%dunlap%' order by validfromutc

Island Press
Dunlap & Dunlap
Karin Tabke LLC



--begin tran
--delete from AthenaResourceStorage..onixResources
--commit