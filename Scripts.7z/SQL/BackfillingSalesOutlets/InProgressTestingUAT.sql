select * from publishers pub
join organizations o on o.organizationUid = pub.organizationUid 
join product p on p.OrganizationUid = o.OrganizationUid 
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join resources r on r.ResourceUid = av.ResourceUid
where pub.name = 'Amalion Publishing'

select * from organizations where organizationName = 'Amalion'

select * from organizations where 
--select * from AthenaUATResourceStorage..OnixResources 
--delete from AthenaUATResourceStorage..OnixResources
select * from publishers where name in (
'West Creek Press',
'Sugarbird Publishing',
'Freewheelin� Jones',
'The Vera Caspary Estate',
'Eileen Rendahl',
'Big Apple Publishing Company',
'YMAA Publication Center, Inc.')

select * from athenaUATdistribution..retailers

select * from AthenaUATMigrator..logMessages where at >getdate()-1 and message like '%amalion%' order by At desc



select * from product p
join organizations o on o.organizationUid = p.organizationUid 
where ordinal = 9789585784864
select * from organizations where Organizationname like '%vera%'


declare @pubname table (name nvarchar(100))
insert @pubname (name)
select '1 to 1 Publishers' union
select 'Abilene Christian University Press' union
select 'Activate Books' union
select 'Aimee Liu' union
select 'Alhambra Press' union
select 'Amalion' union
select 'Amalion Publishing' union
select 'Amanda Cockrell' union
select 'Ambassador Family Press' union
select 'Ambrosia Sands Books' union
select 'American Society of Agricultural and Biological Engineers' union
select 'Ana Claudia Antunes' union
select 'Andre' union
select 'Art Pants Company' union
select 'Aslan Group Publishing' union
select 'Aspire Press' union
select 'Aunt Lute Books' union
select 'Autumn + Colour eBooks' union
select 'Aviva Publishing' union
select 'Babelcube Inc.' union
select 'Bad Press' union
select 'Bamboo Forest Publishing' union
select 'Bandit Books' union
select 'Barbican Press' union
select 'Bass Inc.' union
select 'Bibliomotion, Inc.' union
select 'Big Apple Publishing Co' union
select 'Big Apple Publishing Company' union
select 'Bilineata Publishing' union
select 'Bloomfield Publishing' union
select 'Bloomingdale Books' union
select 'Bolster Life Group Inc' union
select 'Bon Accord Press' union
select 'Book MatchMaker LLC' union
select 'Borre Educatief bv' union
select 'Boutique of Quality Book Publishing, Inc.' union
select 'Boyds Mills Press' union
select 'BQB Publishing' union
select 'Brian D. Meeks' union
select 'Brown Girls Publishing' union
select 'Calkins Creek' union
select 'Caltrop Books' union
select 'Camino Books, Inc.' union
select 'Carson Five' union
select 'Caslon' union
select 'Christopher Bunn' union
select 'Cognosco Learning Publisher' union
select 'Columbia Island Press' union
select 'Concentric Order' 

select * from @pubname
except
select distinct p.Name from athenauatassetprocessor..folderobjects fo
join importFolderConfigurations ic on ic.importFolderConfigurationUid = fo.importFolderConfigurationUId
join publishers p on p.publisherUid = ic.publisherUid
where createdAtUtc > getUTCdate()-1 
and ic.name like 'Migration%'



