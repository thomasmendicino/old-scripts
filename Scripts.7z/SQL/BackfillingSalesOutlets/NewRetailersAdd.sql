-- variables declaration
DECLARE @RetailerCode nvarchar(3);
DECLARE @RetailerName nvarchar (100);
DECLARE @CodeType int;
DECLARE @UpdatedResources TABLE ( ResourceUid uniqueidentifier)
DECLARE @RetailerCodes TABLE ( Code nvarchar(3), Name nvarchar(100), CodeType int )

-- constants declaration
DECLARE @OnixCode int = 0; 
DECLARE @INscribeCode int = 1; 

-- Retailer Codes section
-- NOTE: Put @INscribeCode to column CodeType to use SalesOutletIDType=01 (Proprietary) and IDTypeName = "INscribe Digital Sales Outlet ID Scheme"
-- NOTE: Put @OnixCode to column CodeType to use SalesOutletIDType = 03 (ONIX sales outlet ID code. From List 139)
Insert into @RetailerCodes
values
( 'OST', 'Oyster', @INscribeCode),
( 'ENT', 'EnTitle Books',  @INscribeCode),
( 'BOW', 'Bowker',    @INscribeCode), 
( 'SRD', 'Scribd',  @INscribeCode),
( 'MIL', 'MyILibrary',  @INscribeCode) -- use @OnixCode to change generated 

-- Action
DECLARE RetailerCursor CURSOR FOR
        SELECT Code, Name, CodeType FROM @RetailerCodes

OPEN RetailerCursor
    FETCH NEXT FROM RetailerCursor INTO @RetailerCode, @RetailerName, @CodeType
    WHILE @@FETCH_STATUS = 0
    BEGIN
		------ MAIN QUERY -----
		; WITH ContentCte (Content, ResourceUid)
		AS
		(
			SELECT onr.Content,
				onr.ResourceUid
			from OnixResources onr
		)
		UPDATE cte
		set Content.modify('
			 declare default element namespace "http://ns.editeur.org/onix/3.0/reference";
				insert 
				if(sql:variable("@CodeType") =  sql:variable("@INscribeCode"))
				then
				(
					<SalesOutlet>
						<SalesOutletIdentifier>
							<SalesOutletIDType>01</SalesOutletIDType>
							<IDTypeName>INscribe Digital Sales Outlet ID Scheme</IDTypeName>
							<IDValue>{ sql:variable("@RetailerCode") }</IDValue>
						</SalesOutletIdentifier>
						<SalesOutletName>{ sql:variable("@RetailerName") }</SalesOutletName>
					</SalesOutlet> 
				)
				else 
				(
					<SalesOutlet>
						<SalesOutletIdentifier>
							<SalesOutletIDType>03</SalesOutletIDType>
							<IDValue>{ sql:variable("@RetailerCode") }</IDValue>
						</SalesOutletIdentifier>
						<SalesOutletName>{ sql:variable("@RetailerName") }</SalesOutletName>
					</SalesOutlet>
				)
				as last into 
				(/ONIXMessage/Product/PublishingDetail/SalesRestriction)[SalesRestrictionType = "01" or SalesRestrictionType = "04" or SalesRestrictionType = "05"][1]
			') 
			--(/ONIXMessage/Product/PublishingDetail/SalesRestriction)[functx:is-value-in-sequence(SalesRestrictionType,(1,2,3), ("01", "04", "05")) ][1]
			output inserted.ResourceUid into @UpdatedResources
		from ContentCte cte
		-- $ResourceUids$ must be replaced (automatically or manually)
		-- https://confluence.ingrooves.com/display/ATH/How+to+mass+update+Onix+files+stored+in+ResourceStorage
		where cte.ResourceUid in $ResourceUids$
		and cte.ResourceUid not in 
		(
			-- The retailer already exist in either opt-in or opt-out
			SELECT 
				cteInner.ResourceUid
			from ContentCte cteInner
			cross apply 
			cteInner.Content.nodes('
				declare default element namespace "http://ns.editeur.org/onix/3.0/reference"; 
				(/ONIXMessage/Product/PublishingDetail/SalesRestriction/SalesOutlet/SalesOutletIdentifier/IDValue)') t(salesOutlet)
			where salesOutlet.value('.', 'nvarchar(max)') = @RetailerCode

			UNION 
			-- Product don't contain opt-in sales restrictions
			SELECT 
				cteInner.ResourceUid
			from ContentCte cteInner
			where not cteInner.Content.exist('
			declare default element namespace "http://ns.editeur.org/onix/3.0/reference"; 
			(/ONIXMessage/Product/PublishingDetail/SalesRestriction)[SalesRestrictionType = "01" or SalesRestrictionType = "04" or SalesRestrictionType = "11"]') = 1 --true
			
			UNION 
			-- Product Contains only one Sales outlet (specific case)
			SELECT 
				cteInner.ResourceUid
			from ContentCte cteInner
			where cteInner.Content.value('
			declare default element namespace "http://ns.editeur.org/onix/3.0/reference";
			count((/ONIXMessage/Product/PublishingDetail/SalesRestriction)[SalesRestrictionType = "01" or SalesRestrictionType = "04" or SalesRestrictionType = "05"]/SalesOutlet)', 'int') = 1
		)
		--and cte.Isbn13 in (
		-- '9780545452380'
		--,'9780545361118')
		
		----- END: MAIN QUERY -------

        FETCH NEXT FROM RetailerCursor INTO @RetailerCode, @RetailerName, @CodeType
    END

CLOSE RetailerCursor
DEALLOCATE RetailerCursor

-- retrun results
SELECT DISTINCT ResourceUid
FROM @UpdatedResources