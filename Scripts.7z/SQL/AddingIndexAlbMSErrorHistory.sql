--Re-adding the index back on AlbumMusicServiceUnresolvedErrorHistoryView.
--Index was dropped inadvertently as a result of the sysupgrade script: 00085765-C_Alter_Job_Name.sql
--From JIRA INDMA-6541.
--See Sysaid ticket #16501. TM 5-19-14

IF EXISTS
(
select * from sys.objects where name = 'AlbumMusicServiceUnresolvedErrorHistoryView'
)
AND NOT EXISTS 
(
SELECT * from sys.indexes where name = 'PK_AlbumMusicServiceUnresolvedErrorHistoryView'
)

execute('CREATE UNIQUE CLUSTERED INDEX [PK_AlbumMusicServiceUnresolvedErrorHistoryView] ON [dbo].[AlbumMusicServiceUnresolvedErrorHistoryView] 
   (
   [Album] ASC,
   [MusicService] ASC,
   [ErrorHistory] ASC
   )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]')
