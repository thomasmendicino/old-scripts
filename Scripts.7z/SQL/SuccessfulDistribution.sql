DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)

SET @DateRangeStart = getutcdate()-10
SET @DateRangeEnd = getUTCdate()
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

SET @eISBNs = NULL

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

;with #DistributionTitles as (
SELECT
    pub.Name AS Publisher,
    [pi].Value AS ISBN,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
FROM
	AthenaDistribution..DistributionOrderStatus dos
	INNER JOIN AthenaDistribution..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaDistribution..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaDistribution..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaDistribution..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaDistribution..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaProductCatalog..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN AthenaProductCatalog..ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
	INNER JOIN AthenaSecurity..Organizations o on o.organizationUid = pub.organizationUid
	--INNER JOIN AthenaSecurity..OrgHierarchy('Dreamspinner Press') oh on oh.organizationUid = p.OrganizationUid
	INNER JOIN AthenaSecurity..OrgHierarchy('Disney Publishing Worldwide, Inc.') oh on oh.organizationUid = p.OrganizationUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
--    AND pub.OrganizationUid IN (@OrganizationUidList)     -- Part of the selected publisher hierarchy
--    AND (@eISBNs IS NULL OR [pi].Value IN (@eISBNList))   -- In the List of supplied ISBNs
---    AND r.retailerUid IN (@RetailerUidList)
--AND r.Code = 'APC'
AND r.Code = 'BNO'
GROUP BY
	pub.Name,
    pr.ProductUid,
    [pi].Value,
    r.Name,
    r.RetailerUid
HAVING                                                     -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)),
	#DistributionDataset as (
    
SELECT DISTINCT
    Publisher,
    ISBN,
    --coalesce(td.TitleStatement, te.TitleText) AS Title,
    --CASE pfd.ProductFormDetailValue 
        --WHEN 5201 THEN 'Fixed' 
        --WHEN 5200 THEN 'Reflowable'
        --ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS DistributionDate
FROM
	#DistributionTitles dt
    INNER JOIN AthenaDistribution..ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN AthenaDistribution..Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN AthenaDistribution..DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN AthenaDistribution..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaProductCatalog..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN asset a on a.productUid = p.productUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    LEFT JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    LEFT JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN AthenaProductCatalog..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    INNER JOIN AthenaEventLog..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel <= 2
    AND ret.Code = 'DITC'
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    --AND pd.PublishingDateRole = 1                         -- Main publishing date
    --AND td.TitleTypeCode = 1                              -- Only report on the main title
    --AND te.TitleText IS NOT NULL                          -- Only display the title elements with TitleText
    /*AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL)
	)*/)
SELECT
    ISBN,
case 
when po.OrganizationName = 'INscribe Digital' then o.OrganizationName
when ppo.OrganizationName = 'INscribe Digital' then po.OrganizationName
when pppo.OrganizationName = 'INscribe Digital' then ppo.OrganizationName
when ppppo.OrganizationName = 'INscribe Digital' then pppo.OrganizationName
when po.OrganizationName is NULL then o.OrganizationName
end as [TopLevelParent],
    Publisher [Imprint],
    --'Not Implemented' AS Series,
    --Title,
    --ContentType,
    OnSaleDate,
    Retailer,
    dateadd(hh,(datediff(hh,getUTCdate(),getdate())),DistributionDate) as DistributionDate
FROM
    #DistributionDataset dt
    join AthenaDistribution..Publishers p on p.Name = dt.Publisher
    join AthenaSecurity..Organizations o on o.organizationUId = p.organizationUId
    LEFT OUTER JOIN AthenaSecurity..Organizations po on po.organizationUid = o.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations ppo on ppo.organizationUid = po.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations pppo on pppo.organizationUid = ppo.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations ppppo on ppppo.organizationUid = pppo.ParentOrganizationUid
    
ORDER BY
    DistributionDate DESC