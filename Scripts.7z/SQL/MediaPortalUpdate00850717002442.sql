--begin tran
--commit

/*
--begin tran
--rollback
insert SongCelebrity (Song, Celebrity, Role)
select 2545639, 293462, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2545639, 293464, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2545640, 293462, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2545640, 293464, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2545641, 293462, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2545641, 293464, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2545642, 293462, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2545642, 293464, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2545643, 293462, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2545643, 293464, 2
*/
--begin tran
--rollback
--commit
--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Clean' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Clean' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Explicit = (select Explicit from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Clean' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Clean' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Clean' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Clean' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Process = 1, MediaPortalIncomplete = 0 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00850717002442')) and Name = 'Lock S**t Down - Clean')

--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Acapella' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Acapella' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Explicit = (select Explicit from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Acapella' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Acapella' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Acapella' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Acapella' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Process = 1, MediaPortalIncomplete = 0 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00850717002442')) and Name = 'Lock S**t Down - Acapella')

--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Instrumental' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Instrumental' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Explicit = (select Explicit from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Instrumental' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Instrumental' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Instrumental' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Mix = 'Instrumental' and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Process = 1, MediaPortalIncomplete = 0 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00850717002442')) and Name = 'Lock S**t Down - Instrumental')

--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442'))and Country = (select DefaultCountry from Album where gtin = '00850717002442')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Country = (select DefaultCountry from Album where gtin = '00850717002442')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Country = (select DefaultCountry from Album where gtin = '00850717002442')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Country = (select DefaultCountry from Album where gtin = '00850717002442')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where (ID = 2545639)

--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442'))and Country = (select DefaultCountry from Album where gtin = '00850717002442')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Country = (select DefaultCountry from Album where gtin = '00850717002442')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Country = (select DefaultCountry from Album where gtin = '00850717002442')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00850717002442')) and Country = (select DefaultCountry from Album where gtin = '00850717002442')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where (ID = 2545643)--(select Song from Track where Album = (select ID from album where gtin = '00850717002442')) and Name = 'Hype 2night')

--begin tran
--rollback
--commit
--update track set Fields = ((select top 1 Fields from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')))),
UMGRightTypeCore = ((select top 1 UMGRightTypeCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')))),
UMGLabelCore = ((select top 1 UMGLabelCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')))),
UMGLabelLocal = ((select top 1 UMGLabelLocal from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')))),
DistributionSet = ((select top 1 DistributionSet from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')))),
UMGOwningTerritory = 'US' where album = (select ID from album where gtin = '00850717002442')

select * from albumoverrides where album = 310749
select * from albumcelebrity where album = 310749

--begin tran
--commit
declare @gtin nvarchar (14)
declare @AlbumCelebrity int
set @gtin = '00850717002442'
set @AlbumCelebrity = (select Celebrity from AlbumCelebrity where Album = (select id from Album where gtin = '00850717002442') and country = (select defaultcountry from album where gtin = @gtin))
insert AlbumCelebrity (Album, Celebrity, Role)
select (select ID from album where gtin = @gtin), @AlbumCelebrity, (select role from AlbumCelebrity where Album = (select id from album where gtin = @gtin) and country = (select defaultcountry from album where gtin = @gtin))

--insert AlbumGenre (Album, Genre, Sequence)
select (select ID from album where gtin = '00850717002442'), 11, 1

--rollback
--begin tran
--commit
--update album set ReleaseDate = (select ReleaseDate from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Fields = (select Fields from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
--Organization = (select Organization from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Name = (select Name from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
Mix = (select Mix from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
CLine = (select CLine from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
PLine = (select PLine from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
SalesStartDate = (select SalesStartDate from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
UMGproducttype = (select umgproducttype from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
UMGlabelcore = (select umglabelcore from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
UMGlabellocal = (select umglabellocal from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
DistributionSet = (select DistributionSet from AlbumOverrides where album = (select id from album where gtin = '00850717002442') and Country = (select DefaultCountry from Album where gtin = '00850717002442')),
process = 1, UMGAccount = 4, UMGOwningTerritory = 'US' where gtin = '00850717002442'



select * from celebrity where id = 54235
select * from celebrity where id = 252210
select * from albumgenre where album = 310749
select * from albumgenre where album = (select id from album where gtin in ('00850717002442'))
select * from album where gtin = '00850717002442'
select * from albumoverrides where album = 310749
select * from process
select genre, * from song where id in (select song from track where album in (select id from album where gtin in ('00850717002442')))
select * from songoverrides where song in (select song from track where album in (select id from album where gtin in ('00850717002442')))
select * from track where album = (select id from album where gtin = '00850717002442')
select * from trackoverrides where track in (select id from track where album in (select id from album where gtin in ('00850717002442')))
select * from songcelebrity where song in (2475928,
2475929,
2475930) and (country = 248 or country is null)
--begin tran
--commit
--update track set distributionset = 100 where album = 310749

select top 100 * from ingrooveslog.dbo.log where message like '%release%'
select * from ingrooveslog.dbo.log where message like '%00850717002442%'


select defaultcountry, * from album where gtin = '00850717002442' --34
select * from albumoverrides where album = (select id from album where gtin = '00850717002442') and country = 34
select * from track where album = (select id from album where gtin = '00850717002442')
select * from trackoverrides where track in (select id from track where album = (select id from album where gtin = '00850717002442'))and country = 34
select * from song where id in (select song from track where album =(select id from album where gtin = '00850717002442'))
select * from songoverrides where song in (select song from track where album =(select id from album where gtin = '00850717002442')) and country = 34
select * from songcelebrity where song in (select song from track where album =(select id from album where gtin = '00850717002442')) and country = 34