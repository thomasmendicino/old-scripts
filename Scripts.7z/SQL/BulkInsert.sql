--drop table #PriceFix
--create table #PriceFix (product nvarchar(14), priceTier int, retailer nvarchar(30), country nvarchar(2), start datetime, [end] datetime)



bulk insert #PriceFix
from 'C:\PriceBugReport2.csv'
with (fieldterminator = ',',
rowterminator = '\n',
firstrow = 2)

