

USE [Zeus]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Failed_Rule_Orders]
AS
BEGIN
SET NOCOUNT ON
BEGIN
select rtrim(ms.Name) as 'MusicService',c.A2,a.GTIN,dr.Code,rr.EnumerationName as 'RuleResult'
from DistributionRuleResultView drrv
join DistributionRule dr on dr.ID = drrv.DistributionRule
join RuleResult rr on rr.ID = drrv.RuleResult
join Country c on c.ID = drrv.Country
join [Order] o on o.MusicService = drrv.MusicService
join OrderCountry oc on oc.[Order] = o.ID and oc.Country = drrv.Country
join OrderAlbum oa on oa.OrderCountry = oc.ID and oa.Album = drrv.Album
join Album a on a.ID = oa.Album
join MusicService ms on ms.Id = drrv.MusicService
where rr.EnumerationName in ('Suspend','Reject')
END
END
GO



