;with 
notAllowsFIXT 
as
(Select distinct o.name [label], po.name [parent label]
from musicservicepayee msp
inner join organization o on o.id = msp.organization
inner join musicservice ms on msp.musicservice = ms.id
left join organization po on po.id = o.parent 
where ms.name != 'fixt')

select * from notallowsfixt
(select o.name as [Label Name], po.name as [Parent Label (if applicable)] from organization o left join organization po on po.id = o.parent 
where o.countryset = 1074 and po.countryset = 1074)
except
(select [label], [parent label] from notAllowsFIXT)
order by [Label Name]

select o.name as [Label Name], po.name as [Parent Label (if applicable)] from organization o left join organization po on po.id = o.parent 
where o.countryset = 1074 and po.countryset = 1074
order by [Label Name]


album.organization
contractserviceview 
contractalbumviewactive

