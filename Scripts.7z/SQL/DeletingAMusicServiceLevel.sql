 -------------------------------------------------- 
 ----------------Start-Query-----------------------
 --------------------------------------------------
 --begin tran
 --rollback
 --commit
 --select * from musicservice where name like '%ATT%'
 -------------------------------------------
 --creating temp tables, set music service, and music service level     
 create table #tracksyndications (TSID int)
 create table #songsyndications (SSID int)
 declare @ms int 
 declare @lvl int 
 set @ms = (select id from musicservice where name ='ATT OTA')   --music service 
 set @lvl = 505                                               --music service level to delete
 -------------------------------------------
 
--create temporary table for Track Syndication
	insert into #tracksyndications (TSID)
   select id from tracksyndication where syndication = (select id from syndication where musicservice = @ms and syndicationlevel = @lvl)

--create temp table for Song Syndications
	
	insert into #songsyndications (SSID)
    select id from songsyndication where syndication = (select id from syndication where musicservice = @ms and syndicationlevel = @lvl)

	delete from outsourceorderdetail 
	where tracksyndication in (select TSID from #tracksyndications)

	delete from outsourceorder where id not in (select distinct outsourceorder from outsourceorderdetail)

	update changerequesttracksyndicationlog set newtracksyndication = null
	where newtracksyndication in (select TSID from #tracksyndications)
	
	delete from ChangeRequestTrackSyndicationLog
	where oldtracksyndication in (select TSID from #tracksyndications)
	
--delete distribution monitors attached to this syndication---------------------------------------------------------------------------
	delete from distributionmonitor where syndication in(
	select syndication from distributionmonitor 
	join syndication on syndication.id = distributionmonitor.syndication
	where syndication.syndicationlevel = @lvl and syndication.musicservice = @ms)
	
	update syndicationorder set syndication = null 
	where syndication = (select id from syndication where musicservice = @ms and syndicationlevel = @lvl)

	delete from tracksyndication where syndication = 
	(select id from syndication where musicservice =@ms and syndicationlevel = @lvl)
	
	update changerequestsongsyndicationlog
	set newsongsyndication = null
	where newsongsyndication in (select SSID from #songsyndications)

	delete from changerequestsongsyndicationlog
	where oldsongsyndication in (select SSID from #songsyndications)

	delete from songsyndication where id in (select id from syndication where musicservice = @ms and syndicationlevel = @lvl)

	delete from syndicationdelayedxpathresolveitem where syndicationdelayedxpathresolve in
	(select id from SyndicationDelayedXpathResolve where syndication =
	(select id from syndication where musicservice = @ms and syndicationlevel = @lvl))

	delete from SyndicationDelayedXPathResolve where syndication =
	(select id from syndication where musicservice = @ms and syndicationlevel = @lvl)

	delete from syndication where id = 
	(select id from syndication where musicservice = @ms and syndicationlevel = @lvl)

	delete from error where errorhistory in (select id from errorhistory where
	syndicationlevel = @lvl 
	and job in (select id from job where musicservice = @ms))
	
	delete from errorhistory where syndicationlevel = @lvl 
	and job in (select id from job where musicservice = @ms)

	DELETE TransferLog 
	WHERE MusicService = @ms and SyndicationLevel = @lvl


 drop table #tracksyndications
 drop table #songsyndications 
