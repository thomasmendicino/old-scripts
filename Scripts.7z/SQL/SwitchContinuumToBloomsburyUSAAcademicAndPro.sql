/*

INDMA-5705: Switch Bloomsbury Imprint 'Continuum' from an imprint of 'Bloomsbury USA' to an imprint of 'Bloomsbury USA Academic and Professional'

*/
DECLARE @Continuum int
DECLARE @OldParent int
DECLARE @NewParent int
SELECT @Continuum = ID FROM Organization WHERE Name = 'Continuum'
SELECT @OldParent = Parent FROM Organization WHERE Name = 'Continuum'
SELECT @NewParent = ID FROM Organization WHERE Name = 'Bloomsbury USA Academic and Professional'

IF @OldParent <> @NewParent
BEGIN
UPDATE Organization SET Parent = @NewParent WHERE ID = @Continuum
END