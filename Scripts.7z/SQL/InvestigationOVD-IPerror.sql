select * from organizations where organizationname like '%island%'
declare @pubUId uniqueidentifier
select @pubUid = publisherUid from publishers where name like '%island%pre%'
select @pubUid
select * from contracts where publisherUid = @pubUid


select * from product where ordinal = 9781610915700
select * from productRevisions where productuid = 'B3BB8543-8CE7-49BD-945E-E269AEE26ED5'
select * from distributionOrders where ProductRevisionUid in (select productRevisionUid from productRevisions where productuid = 'B3BB8543-8CE7-49BD-945E-E269AEE26ED5') order by createdAtUtc desc

select * from distributionOrderStatus where distributionOrderUid = '64AF9837-E5E4-4B75-B2BA-87FFD4253959'

in (
select distributionOrderuid from distributionOrders where ProductRevisionUid in (select productRevisionUid from productRevisions where productuid = 'B3BB8543-8CE7-49BD-945E-E269AEE26ED5'))

select * from distributionOrderStructureGroups where distributionorderUid = '64AF9837-E5E4-4B75-B2BA-87FFD4253959'
select * from distributionorderStructureGRoupContracts where name like '%overdrive%'
select * from distributionContracts where name like '%overdrive%' and ValidUntilUtc is null
select * from distributionContracts where name like '%kobo%new%' and ValidUntilUtc is null
select * from distributionContracts where name like '%kobo%' and ValidUntilUtc is null

select * from distributionOrderStructureGroupContracts where name like '%overdriv%preord%' order by name
select * from distributionOrderStructureGroupContracts where name like '%kobo%preord%' order by name
select * from distributionOrderStructureContracts where DistributionOrderStructureContractUid in (select DistributionOrderStructureGroupContractUid from distributionOrderStructureGroupContracts where name like '%kobo%preord%')
select * from distributionOrderStructureContracts where DistributionOrderStructureContractUid in (select DistributionOrderStructureGroupContractUid from distributionOrderStructureGroupContracts where name like '%overdriv%preord%')

select * from contracts where contractUId in (
'33107A3F-15CB-4802-A8E5-4B32285D5627',
'70B12549-D51A-42AB-8AFC-7EBE683B6FD8',
'90EF5BBD-8B37-4ADD-B9AB-05CF84FBB5D6',
'104FBB16-0B48-40B9-99A7-8FFD2A660FB1',
'8B32B325-E85D-41E0-9B11-50EE3DCBF4B0',
'E4347D9E-AB7C-4301-8B2B-F3F2ECF64598',
'9D0B1478-2886-4619-A70D-7CDC90D07CA4',
'115F3C76-9381-43D7-9D1F-C8AC49932589') and validUntilUtc is null