USE AthenaComposite;
	SET NOCOUNT ON;
	declare @Publisher nvarchar(100) = 'Dreamspinner Press'
	declare @RetailerCode nvarchar(100) = 'APC'
	declare @pubName nvarchar(1000)
	declare @actualPub table (pubName nvarchar(1000), num int identity(0,1))
	insert @actualPub (pubName)
	select Name from AthenaComposite..Publishers 
	where charindex(';' + name + ';',';' + @Publisher + ';') > 0
	OR charindex(';' + SafeName + ';',';' + @Publisher + ';') > 0
			
	if exists (select top 1 pubName from @actualPub)
	BEGIN 
		select 'Finding ebooks that need to be triggered to ''' + @RetailerCode + ' '' for ''' + STUFF((select ', ' + ap2.pubName
				FROM @actualPub ap2
				WHERE ap2.num = ap.num
				FOR XML PATH ('')),1,1,'') + '''' AS 'Summary                                                             '
		from @actualPub ap
	END
	ELSE
	BEGIN
		SELECT 'No publisher(s) matching ''' + @Publisher + ''' could be found. Try another name.'
	END


	if exists (select top 1 pubName from @actualPub)
		BEGIN 
			DECLARE @Catalog table (ISBN bigint, Imprint nvarchar(200), ParentPublisher nvarchar(200), ProductFormType nvarchar(200))
			DECLARE pub_cursor cursor local FOR
			select pubName from @actualPub
						
			open pub_cursor
			fetch next from pub_cursor into @pubName
			while @@fetch_status=0
			begin
				INSERT @Catalog (ISBN, Imprint, ParentPublisher, ProductFormType)
				select distinct
					p.Ordinal as ISBN
					, o.OrganizationName as Imprint
					, case 
						when po.OrganizationName = 'Inscribe Digital' then ''
						else po.organizationName 
					   end as ParentPublisher
					, case 
						when pf.ProductFormTypeValue = 52 then 'ED: Digital download'
						when pf.ProductFormTypeValue = 51 then 'EC: Digital online'
						when pf.ProductFormTypeValue = 50 then 'EB: Digital download and online'
						when pf.ProductFormTypeValue = 49 then 'EA: Digital (delivered electronically)'
						else cast(pf.ProductFormTypeValue as varchar(10))
					   end as ProductFormType
				from 
					AthenaProductCatalog..product p
						join AthenaProductCatalog..asset a on a.ProductUid = p.ProductUid
						join AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
						join AthenaProductCatalog..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
						join AthenaProductCatalog..productForms pf on pf.AssetVersionUid = av.AssetVersionUid
						join AthenaSecurity..OrgHierarchy(@pubName) oh on oh.organizationUId = p.OrganizationUid
						join AthenaSecurity..Organizations o on o.OrganizationUid = p.OrganizationUid
						join AthenaSecurity..Organizations po on po.OrganizationUid = o.ParentOrganizationUid
				where pf.ProductFormTypeValue in (48,49,50,51,52)
					and av.ValidUntilUtc is NULL
				order by o.OrganizationName, p.Ordinal

				fetch next from pub_cursor into @pubName
			end

			CLOSE pub_cursor
			DEALLOCATE pub_cursor
		SELECT distinct Imprint, ISBN 
		FROM @Catalog
		WHERE ISBN NOT IN (
			SELECT Ordinal from Product p
				INNER JOIN ProductRevisions pr on pr.ProductUid = p.ProductUid
				INNER JOIN DistributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
				INNER JOIN Contracts c on c.ContractUid = pr.ContractUid
				INNER JOIN Retailers r on r.RetailerUid = c.RetailerUid
				INNER JOIN @Catalog cat on cat.ISBN = p.Ordinal
			WHERE r.Code = @RetailerCode)
		ORDER BY Imprint, ISBN
END
