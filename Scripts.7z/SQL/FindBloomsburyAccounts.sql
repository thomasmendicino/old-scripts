;with XMLNAMESPACES ('http://ns.editeur.org/onix/3.0/reference' as ns)
    select 
        p.Ordinal
        , o.OrganizationName [Athena Imprint]
        , po.OrganizationName [Athena Parent]
        , content.value('(/ns:ONIXMessage/ns:Product/ns:PublishingDetail/ns:CountryOfPublication)[1]','varchar(2)') as CountryOfPublication
        , content.value('(/ns:ONIXMessage/ns:Product/ns:ProductSupply/ns:SupplyDetail/ns:Price/ns:DiscountCoded/ns:DiscountCode)[1]','varchar(3)') as DiscountCode
        , case 
            when 
            content.value('(/ns:ONIXMessage/ns:Product/ns:PublishingDetail/ns:CountryOfPublication)[1]','varchar(2)') = 'GB' AND
            content.value('(/ns:ONIXMessage/ns:Product/ns:ProductSupply/ns:SupplyDetail/ns:Price/ns:DiscountCoded/ns:DiscountCode)[1]','varchar(3)') = 'BTR'
            then 'Bloomsbury'
            when 
            content.value('(/ns:ONIXMessage/ns:Product/ns:PublishingDetail/ns:CountryOfPublication)[1]','varchar(2)') = 'US' AND
            content.value('(/ns:ONIXMessage/ns:Product/ns:ProductSupply/ns:SupplyDetail/ns:Price/ns:DiscountCoded/ns:DiscountCode)[1]','varchar(3)') = 'BTR'
            then 'Bloomsbury USA'
            when 
            content.value('(/ns:ONIXMessage/ns:Product/ns:PublishingDetail/ns:CountryOfPublication)[1]','varchar(2)') = 'GB' AND
            content.value('(/ns:ONIXMessage/ns:Product/ns:ProductSupply/ns:SupplyDetail/ns:Price/ns:DiscountCoded/ns:DiscountCode)[1]','varchar(3)') = 'BTC'
            then 'Bloomsbury Children''s Books'
            when 
            content.value('(/ns:ONIXMessage/ns:Product/ns:PublishingDetail/ns:CountryOfPublication)[1]','varchar(2)') = 'US' AND
            content.value('(/ns:ONIXMessage/ns:Product/ns:ProductSupply/ns:SupplyDetail/ns:Price/ns:DiscountCoded/ns:DiscountCode)[1]','varchar(3)') = 'BTC'
            then 'Bloomsbury USA Children''s Books'
            when
            content.value('(/ns:ONIXMessage/ns:Product/ns:PublishingDetail/ns:CountryOfPublication)[1]','varchar(2)') = 'GB' AND
            content.value('(/ns:ONIXMessage/ns:Product/ns:ProductSupply/ns:SupplyDetail/ns:Price/ns:DiscountCoded/ns:DiscountCode)[1]','varchar(3)') = 'BNT'
            then 'Bloomsbury Academic and Professional'
            when 
            content.value('(/ns:ONIXMessage/ns:Product/ns:PublishingDetail/ns:CountryOfPublication)[1]','varchar(2)') = 'US' AND
            content.value('(/ns:ONIXMessage/ns:Product/ns:ProductSupply/ns:SupplyDetail/ns:Price/ns:DiscountCoded/ns:DiscountCode)[1]','varchar(3)') = 'BNT'
            then 'Bloomsbury USA Academic and Professional'
            when 
            content.value('(/ns:ONIXMessage/ns:Product/ns:ProductSupply/ns:SupplyDetail/ns:Price/ns:DiscountCoded/ns:DiscountCode)[1]','varchar(3)') = 'BPN'
            then 'Bloomsbury Professional'
            ELSE 'Undetermined'
        END
            as [Bloomsbury Account Name]
from AthenaResourceStorage..OnixResources ox
    join AthenaProductCatalog..AssetVersion av on av.ResourceUid = ox.ResourceUid
    join AthenaProductCatalog..AssetOverride ao on ao.AssetOverrideUid = av.AssetOverrideUid
    join AthenaProductCatalog..asset a on a.AssetUid = ao.AssetUid
    join AthenaProductCatalog..product p on p.ProductUid = a.ProductUid
    join AthenaSecurity..Organizations o on o.organizationUId = p.OrganizationUid
    join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
    join AthenaSecurity..OrgHierarchy('Bloomsbury Publishing') oh on oh.organizationUId = p.OrganizationUid
where av.ValidUntilUtc is NULL
    AND content.value('(/ns:ONIXMessage/ns:Product/ns:ProductSupply/ns:SupplyDetail/ns:Price/ns:DiscountCoded/ns:DiscountCode)[1]','varchar(3)') = 'BPN'
    AND ox.IsChanged = 0