USE AthenaComposite
;with Numbers AS 
	(select 
		at.AssetTypeCode
		, p.Ordinal as ISBN
		, r.Path
		, ROW_NUMBER() OVER (PARTITION BY at.AssetTypeCode ORDER BY r.Length DESC) RowNum
		, r.Length
	from 
		product p
		join asset a on a.ProductUid = p.ProductUid
		join AssetOverride ao on ao.AssetUid = a.AssetUid
		join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		join Resources r on r.ResourceUid = av.ResourceUid
		join refAssetType at on at.AssetTypeId = a.AssetType
	where
		av.ValidUntilUtc is NULL)
select 
	AssetTypeCode
	, ISBN
	, Path as PathOnResourceStorage
	, RowNum as MaxSizeRank
	, case 
		when len(Length) > 3 then cast(cast(Length / (1024.00 * 1024) as decimal(18,2)) as nvarchar(max)) + ' MB'
		else cast(cast(Length as decimal(18,2)) as nvarchar(max)) + ' B'
	end as FileSize 
from Numbers
where RowNum < 11
order by 
	AssetTypeCode
	, RowNum ASC