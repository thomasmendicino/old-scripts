select * from syndicationorder order by submissiondate desc
select * from syndicationordereventlog where syndicationorder = 4819
select top 100 * from ingrooveslog.dbo.log

select * from pricecampaign where musicservice = (select id from musicservice where name = '24-7')

select * from pricetiermappingtype
select * from pricetiermapping where pricetiermappingtype = 10
select * from pricetier where 

select * from album a join arearestriction ar
on ar.album = a.id
where ar.country not in (select id from country where A2 in ('DE', 'AT', 'CH', 'GB', 'GR'))
and operator = '+'
select * from album where gtin in ('7340050819683 ','00619061377329','7340070423099 ','00620953359422','00619061377428','00821826002043')

select * from album where gtin like '%782388060868%'
select * from arearestriction where album = 173596
select * from country where a2 in ('DE', 'AT', 'CH', 'GB', 'GR')


select ar.* from album a
join arearestriction ar on a.id = ar.album
where a.gtin like '%782388060868%'

select * from arearestriction where album = 1216


select * from countryset
select * from countrysetcountry

select c.* from MusicService ms
inner join CountrySet cs on cs.id = ms.CountrySet
inner join CountrySetCountry csc on cs.id = csc.CountrySet
inner join Country c on c.id = csc.Country
where ms.name = 'musicload'

select ar.*, c.* from MusicService ms 
inner join AreaRestriction ar on ms.id = ar.MusicService
inner join Country c on ar.Country = c.id
where ms.name = 'MusicLoad'

select * from 

select * from musicservice where name like '%itunes%vide%'

select c.* from MusicService ms
inner join CountrySet cs on cs.id = ms.CountrySet
inner join CountrySetCountry csc on cs.id = csc.CountrySet
inner join Country c on c.id = csc.Country
where ms.name = 'MusicLoad'