select * from pricetiermapping
where pricetiermappingtype = 10
update pricetiermapping set trackprice = 1 where id = 324
update pricetiermapping set albumprice = 10 where id in (325,326,327,328)
begin tran
commit
select * from pricetier where id between 1161 and 1165
update pricetiermapping set pricestructure = null where id between 324 and 328
update pricetier set trackprice = null where id = 1161
update pricetier set albumprice = null where id = 1162
update pricetier set albumprice = null where id = 1163
update pricetier set albumprice = null where id = 1164
update pricetier set albumprice = null where id = 1165
select * from pricetiermappingtype
update pricetier set trackprice = 1, albumprice = 10 where id = 1161
update pricetier set trackprice = 1, albumprice = 10 where id in (1162,1163,1164,1165)
insert pricetiermapping (pricetiermappingtype, pricetier, pricestructure, tracktiername, albumtiername)
select 10,1161,'MixUp Track Premium','TD1', 'TD1'
insert pricetiermapping (pricetiermappingtype, pricetier, pricestructure, tracktiername, albumtiername)
select 10,1162,'MixUp Album Premium','AD1','AD1'
insert pricetiermapping (pricetiermappingtype, pricetier, pricestructure, tracktiername, albumtiername)
select 10,1163,'MixUp Standard','AD2','AD2'
insert pricetiermapping (pricetiermappingtype, pricetier, pricestructure, tracktiername, albumtiername)
select 10,1164,'MixUp Album Budget AD3','AD3','AD3'
insert pricetiermapping (pricetiermappingtype, pricetier, pricestructure, tracktiername, albumtiername)
select 10,1165,'MixUp Album Budget AD4','AD4','AD4'

select * from musicservice where name = '24-7'
update musicservice set inheritalbumpricetierfortrack = 1 where id = 243


select * from pricetier where id in (1161,1162,1163,1164,1165)


delete from pricetier where id in (1156,1157,1158,1159,1160)
begin tran
rollback
commit
select * from musicservice where name like '%24%7%'
select top 50 * from pricecampaign where track in (select id from track where album = 4482)

select * from albumsyndicationview where album = (select id from album where gtin = '729913230136') --4482
begin tran

select * from ContractAuthorityPriceTier 
where pricetier in (select id from pricetier where name like '%mixup%')

insert ContractAuthorityPriceTier (contractauthority, pricetier)
values (1, 1161)
insert ContractAuthorityPriceTier (contractauthority, pricetier)
values (1, 1162)
insert ContractAuthorityPriceTier (contractauthority, pricetier)
values (1, 1163)
insert ContractAuthorityPriceTier (contractauthority, pricetier)
values (1, 1164)
insert ContractAuthorityPriceTier (contractauthority, pricetier)
values (1, 1165)
insert ContractAuthorityPriceTier (contractauthority, pricetier)
values (1, 1164)


select * from album where id = 4482
insert pricecampaign
select * from pricetier where name like '%mixup%'
select * from pricecampaign where album = 4482
select * from pricetiermapping where pricetiermappingtype = 10
select * from musicservice where name like '%24%7%'

select * 
select * from pricecampaign where track in (select id from track where album = 4482)
--begin tran
--commit 
update pricecampaign set musicservice = 243 where startpricetier = 1161
delete from pricecampaign where track in (select id from track where album = 4482)
select album from pricecampaign group by album having count(album) > 1
select top 5 * from pricecampaign where album = 4482
update pricecampaign set country = null where startpricetier = 1162
select * from musicservice where name like '%24%7%'
update pricecampaign set startpricetier = 1162 where album = 4482
update pricecampaign set musicservice = (select id from musicservice where name = '24-7'), country= 250 where id = 3610837
delete from pricecampaign where id = 3440083
select * from song where id in (select song from track where album = 4482)
update musicservice set usetrackpricetier = 1 where id = 243
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48893, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48894, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48895, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48896, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48897, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48898, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48899, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48900, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48901, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48902, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48903, (getdate()-1)
insert pricecampaign (StartPriceTier, StartDate,IsMarketingCampaign, track, CreatedAt)
select 1161, (getdate()-1), 0, 48904, (getdate()-1)


if not exists (select 1 from PriceTier where Name='MixUp Track Premium')
insert into PriceTier(Name, Sequence, DescriptionKey, ForTrack) 
select 'MixUp Track Premium',(select MAX(sequence)+1 from PriceTier),'_24_7_mixup_track_premium',1


if not exists (select 1 from PriceTier where Name='MixUp Album Premium')
insert into PriceTier(Name, Sequence, DescriptionKey, ForAlbum) 
select 'MixUp Album Premium',(select MAX(sequence)+1 from PriceTier),'_24_7_mixup_album_premium',1

if not exists (select 1 from PriceTier where Name='MixUp Standard')
insert into PriceTier(Name, Sequence, DescriptionKey, ForAlbum) 
select 'MixUp Standard',(select MAX(sequence)+1 from PriceTier),'_24_7_mixup_album_standard',1


if not exists (select 1 from PriceTier where Name='MixUp Album Budget AD3')
insert into PriceTier(Name, Sequence, DescriptionKey, ForAlbum) 
select 'MixUp Album Budget AD3',(select MAX(sequence)+1 from PriceTier),'_24_7_mixup_album_budget_ad3',1

if not exists (select 1 from PriceTier where Name='MixUp Album Budget AD4')
insert into PriceTier(Name, Sequence, DescriptionKey, ForAlbum) 
select 'MixUp Album Budget AD4',(select MAX(sequence)+1 from PriceTier),'_24_7_mixup_album_buget_ad4',1

select top 100* from ingrooveslog.dbo.log

select * from tracksyndication where syndication in (select id from syndication where musicservice = 243)

select * from pricetiermapping
update pricetiermapping set

select * from album where gtin = '729913230136'
select * from pricecampaign where album = 4482 
insert pricecampaign (startpricetier, startdate, ismarketingcampaign, album, createdat)
select 1167,(select getdate()-1), 0, 4482, (select getdate()-1)

select * from pricetier