/*

select * from TrendFileConfiguration c
join TrendFileHeader h on h.TrendFileConfiguration = c.id
where c.name = 'Amazon eBookBase Daily GB'

*/

BEGIN TRAN
DECLARE @CSVFileType int
DECLARE @TrendFileConfigurationName NVARCHAR(200)
SELECT @CSVFileType = ID from Filetype WHERE Name = 'CSV'
SET @TrendFileConfigurationName = 'Amazon eBookBase Daily GB'

--Update header names and mappings
UPDATE [TrendFileHeader]
	SET	[Column] = 'ASIN',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 1
UPDATE [TrendFileHeader]
	SET	[Column] = 'ASIN name',
		[Map] = 'Album'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 2
UPDATE [TrendFileHeader]
	SET	[Column] = 'ID type',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 3
UPDATE [TrendFileHeader]
	SET	[Column] = 'External ID',
		[Map] = 'GTIN'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 4
UPDATE [TrendFileHeader]
	SET	[Column] = 'Product group',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 5
UPDATE [TrendFileHeader]
	SET	[Column] = 'Release date',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 6
UPDATE [TrendFileHeader]
	SET	[Column] = 'Customer Orders',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 7
UPDATE [TrendFileHeader]
	SET	[Column] = 'Units shipped',
		[Map] = 'Quantity'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 8
UPDATE [TrendFileHeader]
	SET	[Column] = 'Shipped COGS',
		[Map] = 'Revenue'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 9
UPDATE [TrendFileHeader]
	SET	[Column] = 'Units returned by customers',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 10
UPDATE [TrendFileHeader]
	SET	[Column] = 'Category',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 11
UPDATE [TrendFileHeader]
	SET	[Column] = 'Sub-category',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 12
UPDATE [TrendFileHeader]
	SET	[Column] = 'Author/Artist/Actor',
		[Map] = 'Artist'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 13

UPDATE TrendFileConfiguration SET HeaderSize = 7 WHERE Name = 'Amazon eBookBase Daily GB'

IF EXISTS (SELECT 1 FROM TrendFileHeader
	INNER JOIN TrendFileConfiguration
		ON TrendFileConfiguration.ID = TrendFileHeader.TrendFileConfiguration
	WHERE TrendFileConfiguration.Name = 'Amazon eBookBase Daily GB'
		AND Position > 13)
BEGIN
	DELETE TrendFileHeader FROM TrendFileHeader 
		INNER JOIN TrendFileConfiguration
			ON TrendFileConfiguration.ID = TrendFileHeader.TrendFileConfiguration
	WHERE TrendFileConfiguration.Name = 'Amazon eBookBase Daily GB'
		AND Position > 13
END

UPDATE TrendFileConfiguration SET FileType = @CSVFileType WHERE Name = 'Amazon eBookBase Daily GB'

--COMMIT

