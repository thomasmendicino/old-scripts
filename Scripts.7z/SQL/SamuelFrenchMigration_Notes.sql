select parent, * from organization where name like '%sam%french%'


select * from contractSongViewACtive where Song in (select s.ID from album a
join track t on t.album = a.id
join song s on t.song = s.id
where a.organization = (select id from organization where Name = 'Samuel French'))

select * from album where organization = (select id from organization where Name = 'Samuel French')
select * from album where organization = (select id from organization where Name = 'Samuel French, Inc.')
select performer, * from song where organization = (select id from organization where Name = 'Samuel French, Inc.') --and performer is not null
select * from songcelebrity where song in (select id from song where organization = (select id from organization where Name = 'Samuel French, Inc.'))
--UPDATE Album SET Organization = 34248 where Organization = (select id from organization where Name = 'Samuel French, Inc.')
--UPDATE Song SET Organization = 34248 where Organization = (select id from organization where Name = 'Samuel French, Inc.')

select * from contractalbumviewactive where album in (select id from album where organization = 37710)
select * from contractalbumviewactive where album in (select id from album where organization = 34248)

SET NOCOUNT ON
DECLARE @DesiredOrgName nvarchar(20) = 'Samuel French'
DECLARE @DeprecatedOrgName nvarchar(20) = 'Samuel French, Inc.'
DECLARE @DesiredOrg int
SELECT @DesiredOrg = ID FROM Organization WHERE Name = @DesiredOrgName
DECLARE @DeprecatedOrg int
SELECT @DeprecatedOrg = ID FROM Organization WHERE Name = @DeprecatedOrgName


UPDATE Album SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @AlbumRowCount nvarchar(10) = @@ROWCOUNT

UPDATE Song SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @SongRowCount nvarchar(10) = @@ROWCOUNT

PRINT @AlbumRowCount + ' Album rows UPDATED.'
PRINT @SongRowCount + ' Song rows UPDATED.'

UPDATE EarningTest SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @EarningTestCount nvarchar(10) = @@ROWCOUNT

UPDATE Earning SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @EarningCount nvarchar(10) = @@ROWCOUNT

PRINT @EarningTestCount + ' EarningTest rows UPDATED.'
PRINT @EarningCount + ' Earning rows UPDATED.'

/*SELECT 'SELECT * from ' + t.name + ' where ' + c.name + ' = (select id from organization where name = ''Samuel French, Inc.'')'
--SCHEMA_NAME(schema_id) AS schema_name,
--c.name AS column_name
FROM sys.tables AS t
INNER JOIN sys.columns c ON t.OBJECT_ID = c.OBJECT_ID
WHERE c.name LIKE '%organization%'
--ORDER BY schema_name, table_name;
*/

UPDATE TransferredMusicServiceCACache SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @TransferredMSCA nvarchar(10) = @@ROWCOUNT
UPDATE SyndicatedPerformerCACache SET Organization = @DesiredOrg, SongPerformer = @DesiredOrgName WHERE Organization = @DeprecatedOrg
DECLARE @SyndPerfCA nvarchar(10) = @@ROWCOUNT

PRINT @TransferredMSCA + ' TransferredMusicServiceCACache rows UPDATED.'
PRINT @SyndPerfCA + ' SyndicatedPerformerCACache rows UPDATED.'

UPDATE ImportLog SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @importLog nvarchar(10) = @@ROWCOUNT

UPDATE OwnerLabelCache SET Organization = @DesiredOrg, Label = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @OwnerLabel nvarchar(10) = @@ROWCOUNT

PRINT @importLog + ' ImportLog rows UPDATED.'
PRINT @OwnerLabel + ' OwnerLabelCache rows UPDATED.'

UPDATE PayableStatement SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @PayableStmt nvarchar(10) = @@ROWCOUNT

PRINT @PayableStmt + ' PayableStatement rows UPDATED.'

UPDATE Celebrity SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @Celebrity nvarchar(10) = @@ROWCOUNT

PRINT @Celebrity + ' Celebrity rows UPDATED.'

DELETE FROM ContactPayeeCache WHERE PayeeOrganization = @DeprecatedOrg
DECLARE @ContactPayee nvarchar(10) = @@ROWCOUNT
DELETE FROM Association WHERE FromOrganization = @DeprecatedOrg
DECLARE @Assoc nvarchar(10) = @@ROWCOUNT
DELETE FROM Organization WHERE ID = @DeprecatedOrg
DECLARE @Organization nvarchar(10) = @@ROWCOUNT

PRINT @ContactPayee + ' ContactPayee rows DELETED.'
PRINT @Assoc + ' Association rows DELETED.'
PRINT 'Organization ' + @DeprecatedOrgName + ' has been DELETED.'



--SELECT * from TransferredMusicServiceCACache where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from SyndicatedPerformerCACache where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from ImportLog where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from OwnerLabelCache where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from OwnerLabelCache where Organization = (select id from organization where name = 'Samuel French')
--SELECT * from EarningTest where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from Album where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from ContactPayeeCache where PayeeOrganization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from ContactPayeeCache where PayeeOrganization = (select id from organization where name = 'Samuel French')
--SELECT * from Song where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from PayableStatement where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from Earning where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from Celebrity where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from Association where FromOrganization = (select id from organization where name = 'Samuel French, Inc.')

