
select a.GTIN [ISBN], a.Name [Title], a.Mix [Subtitle], c.id [Contract], * from Album A
inner join contractalbumviewactive cava on cava.album = a.id
inner join contract c on c.id = cava.contract
where a.organization = (select id from organization where name = 'Island Press')

select * from Contract WHERE ID = 19144--20304
select * from ContractMusicService WHERE Contract = 20304
select * from ContractMedia where Contract = 20304
select * from AreaRestriction WHERE Contract = 20304

select * from contractServiceView where Contract = 19144
select * from contractDefaultView where Contract = 20304

create table ##ebookRetailers (ID int, Name nvarchar(30))
insert ##ebookRetailers (ID, Name)
select distinct MS.ID, MS.Name from musicservice ms
join musicserviceproducttype pt on pt.musicservice = ms.id
where pt.productType in (22,23,24)

select * from ##ebookRetailers order by id
select a.GTIN [ISBN], a.Name [Title], a.Mix [Subtitle], c.id [Contract], O.Name [Publisher], 
case when csv.musicservice = 529 then 1 else 0 end [iBookstore],
case when csv.musicservice = 534 then 1 else 0 end [Amazon eBookBase],
case when csv.musicservice = 542 then 1 else 0 end [Barnes And Noble],
case when csv.musicservice = 543 then 1 else 0 end [Kobo],
case when csv.musicservice = 544 then 1 else 0 end [Sony Reader Store],
case when csv.musicservice = 565 then 1 else 0 end [Books on Board],
case when csv.musicservice = 714 then 1 else 0 end [KDP],
case when csv.musicservice = 744 then 1 else 0 end [OverDrive],
case when csv.musicservice = 747 then 1 else 0 end [Google Books],
case when csv.musicservice = 767 then 1 else 0 end [3M],
case when csv.musicservice = 768 then 1 else 0 end [Baker And Taylor]
from Album A
inner join contractalbumviewactive cava on cava.album = a.id
inner join contract c on c.id = cava.contract
inner join organization o on o.id = a.organization
inner join contractServiceView csv on csv.Contract = cava.Contract
where o.name = 'Island Press'
and csv.Musicservice in (select id from ##ebookRetailers)

select
    Organization
  , [Atlas Op Company code]
  , [Atlas Op Unit code]
  , [Atlas Sub Label code]
  , [Atlas Super Label code]
 from 
 ( select distinct
     Organization [Organization]
   , ci.Name  [CustomID_Type]
   , Value   [CustomID_Value]
  from OrganizationAttribute oa
   left join CustomID ci on oa.CustomID=ci.ID
 ) oc
 pivot
 ( max(oc.CustomID_Value)
  for CustomID_Type in (   [Atlas Op Company code]
         , [Atlas Op Unit code]
          , [Atlas Sub Label code]
          , [Atlas Super Label code]
         )
 ) PivotedOrganizationCustomID

select * from Contract WHERE ID = 21204
select * from ContractMusicService WHERE Contract = 21204
select * from ContractMedia where Contract = 21204
select * from AreaRestriction WHERE Contract = 21204


select * from OrganizationAttribute
select * from CustomId


select * from ##ebookRetailers order by id
select a.GTIN, csv.MusicService, c.id, cava.*
from Album A
inner join contractalbumviewactive cava on cava.album = a.id
inner join contract c on c.id = cava.contract
inner join organization o on o.id = a.organization
left outer join contractServiceView csv on csv.Contract = cava.Contract
where o.name = 'Island Press'
--and csv.Musicservice in (select id from ##ebookRetailers)
and a.gtin in ('9781597263832', '9781610910286')

select * from contractmusicservice where contract in (19144,20304)
select * from contract where id in (19144,20304)
select * from contractServiceView where contract in (19144,20304)

;with pivoter (Contract, Name, Value) as
(select csv.Contract, ms.Name, case
WHEN EXISTS (select 1 from contractServiceView csv join ##ebookRetailers eb on eb.ID = csv.MusicService) 
THEN 1
ELSE 0
END
from musicservice ms 
join ##ebookRetailers eb on eb.ID = ms.ID
join contractServiceView csv on csv.musicservice = ms.id where ms.Name = 'BarnesAndNoble')
select * from pivoter




create table ##Contracts (ID int)
insert ##Contracts (ID)
select distinct C.ID from contractAlbumViewActive cava
join Contract c on c.id = cava.Contract
join Album A on A.id = Cava.Album
join Organization o on a.Organization = o.id
where o.Name = 'Island Press'

--truncate table ##includedServices
--drop table ##includedServices
create table ##includedServices (ID int, Contract int)
insert ##includedServices (ID, contract)
select distinct ms.id, csv.Contract from contractServiceView csv
inner join ##Contracts con on con.id = csv.Contract
inner join ##ebookRetailers eb on eb.id = csv.MusicService
inner join musicservice ms on ms.id = csv.musicservice

select * from ##includedServices

select distinct c.ID [contract], ms.id [musicservice], 
CASE WHEN EXISTS (select 1 from ContractServiceView csv join ##includedServices inc on inc.Contract = csv.Contract and csv.MusicService = inc.id) THEN 1
ELSE 0
END
from Contract c
join contractServiceView csv on csv.contract = c.id
left outer join musicservice ms on ms.id = csv.musicservice



select distinct c.ID [contract], ms.id [musicservice], 
CASE WHEN EXISTS (select 1 from ContractServiceView csv join ##includedServices inc on inc.Contract = csv.Contract and csv.MusicService = inc.id) THEN 1
ELSE 0
END
from Contract c
left outer join contractServiceView csv on csv.contract = c.id
left outer join musicservice ms on ms.id = csv.musicservice
where contract in (select contract from ##includedServices)
and musicservice in (select id from ##includedServices)


	select C.ID Contract, cms.MusicService
	from Contract C inner join ContractMusicService cms on cms.Contract = C.id
	where C.ExcludeServices = 0
	union
	select C.ID Contract, MS.ID
	from Contract C, MusicService MS
	where C.ExcludeServices = 1 and 
		not exists (select 1 from ContractMusicService cms where cms.Contract = C.ID and cms.MusicService = MS.ID)
		
create table ##excludedServices (MusicService int, Contract int)
insert ##excludedServices (MusicService, Contract)
select ms.ID, c.ID from 
musicservice ms
inner join ##ebookRetailers eb on eb.id = ms.id,
contract c
inner join ##Contracts con on con.ID = c.ID
EXCEPT
select ms.ID, c.ID from 
musicService ms 
join ##includedServices inc on inc.id = ms.id
join Contract c on c.ID = inc.Contract


select distinct C.ID [Contract], ms.ID [musicService], 
CASE WHEN EXISTS (select 1 from contract c join ##excludedServices exc on exc.contract = c.id inner join musicservice ms on ms.id = exc.Musicservice) then 0
WHEN EXISTS (select 1 from contract c join ##includedServices inc on inc.contract = c.id inner join musicservice ms on ms.id = inc.id) then 1
ELSE 0
END
from Contract C, musicService MS
where ms.ID in (select id from ##ebookRetailers)
and c.ID in (select id from ##contracts)
select * from ##includedServices
select * from ##excludedServices

/****************************************************/
;with pivoter (MusicService, [Contract], [Allowed]) as 
(select ID [MusicService], [Contract], 1 as Allowed
FROM ##includedServices
UNION
Select MusicService, [Contract], 0 as Allowed
FROM ##excludedServices)
--select p.*, ms.Name from pivoter p
--join musicservice ms on ms.id = p.musicservice
--ORDER by [Contract], Allowed, MusicService
/****************************************************/

select GTIN [ISBN], AlbumName [Title], Mix [Subtitle], [Contract], Name [Publisher], /*534 as [Amazon eBookBase], 529 as [iBookStore], 542 as [Barnes And Noble],
543 as [Kobo], 544 as [Sony Reader Store], 565 as [Books on Board], 714 as [KDP], 744 as [OverDrive], 747 as [Google Books], 767 as [3M], 768 as [Baker And Taylor]*/
[534],[529],[542],[543],[544],[565],[714],[744],[747],[767],[768]
from 
(
SELECT A.GTIN, a.Name [AlbumName], a.Mix, c.ID [Contract], o.Name, p.Allowed, p.MusicService FROM Album A 
inner join contractalbumviewactive cava on cava.album = a.id
inner join contract c on c.id = cava.contract
inner join organization o on o.id = a.organization
inner join contractServiceView csv on csv.Contract = cava.Contract
inner join pivoter p on p.[Contract] = c.id
where o.name = 'Island Press'
) as SourceQuery
pivot
(
Max(Allowed)
For MusicService
--IN ([0], [1])) as pvt
IN ([534],[529],[542],[543],[544],[565],[714],[744],[747],[767],[768])) as pvt
order by ISBN, [Contract]




/****************************************************/
;with pivoter2 (MusicService, [Contract], [Allowed]) as 
(select ms.Name [MusicService], [Contract], 1 as Allowed
FROM ##includedServices inc INNER JOIN MusicService MS on MS.ID = inc.ID
UNION
Select ms.Name, [Contract], 0 as Allowed
FROM ##excludedServices exc INNER JOIN MusicService MS on MS.ID = exc.MusicService)
--select p.*, ms.Name from pivoter2 p
--join musicservice ms on ms.Name = p.musicservice
--ORDER by [Contract], Allowed, MusicService
/****************************************************/

select GTIN [ISBN], AlbumName [Title], Mix [Subtitle], [Contract], Name [Publisher], [Amazon eBookBase], [iBookStore], [Barnes And Noble],
[Kobo], [Sony Reader Store], [Books on Board], [KDP], [OverDrive], [Google Books], [3M], [Baker And Taylor]
from 
(
SELECT A.GTIN, a.Name [AlbumName], a.Mix, c.ID [Contract], o.Name, p.Allowed, p.MusicService FROM Album A 
inner join contractalbumviewactive cava on cava.album = a.id
inner join contract c on c.id = cava.contract
inner join organization o on o.id = a.organization
inner join contractServiceView csv on csv.Contract = cava.Contract
inner join pivoter2 p on p.[Contract] = c.id
where o.name = 'Island Press'
) as SourceQuery
pivot
(
Max(Allowed)
For MusicService
--IN ([0], [1])) as pvt
--IN ([534],[529],[542],[543],[544],[565],[714],[744],[747],[767],[768])) as pvt
IN ([Amazon eBookBase], [iBookStore], [Barnes And Noble],[Kobo], [Sony Reader Store], [Books on Board], [KDP], [OverDrive], [Google Books], [3M], [Baker And Taylor])) as pvt
order by [Contract], ISBN
