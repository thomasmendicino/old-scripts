

;with pivoter1 (Sequence, ISBN, MGenre) as
(
select case when ag.Sequence = 1 then 'Primary Master Genre' when ag.Sequence = 2 then 'Second Master Genre' when ag.Sequence = 3 then 'Third Master Genre' when ag.Sequence = 4 then 'Fourth Master Genre' end as Sequence, a.gtin ISBN, mg.Name [MGenre] from album a 
join albumGenre ag on ag.album = a.id 
join genre g on g.id = ag.genre 
join masterGenre mg on mg.id = g.masterGenre
join albumProductType apt on apt.album = a.id 
join productType pt on pt.id = apt.productType
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)),
--select * from pivoter order by isbn
pivoter2 (Sequence2, ISBN2, BISAC) as
(
select case when ag.Sequence = 1 then 'Primary BISAC' when ag.Sequence = 2 then 'Second BISAC' when ag.Sequence = 3 then 'Third BISAC' when ag.Sequence = 4 then 'Fourth BISAC' end as Sequence2, a.gtin ISBN2, g.Code [BISAC] from album a 
join albumGenre ag on ag.album = a.id 
join genre g on g.id = ag.genre 
join albumProductType apt on apt.album = a.id 
join productType pt on pt.id = apt.productType
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)
)
--select * from pivoter2

select distinct gtin [ISBN], 
Name [Title], [Series/Book], [Author], [Imprint], [Parent], case when [AthAlbum] is NULL then coalesce(SalesStartDate, ReleaseDate) else coalesce(SalesStartDate, ReleaseDate) end as [OnSaleDate],
 case when MigratedAt is not null then 'ATHENA' when [AthAlbum] is NULL then 'INDMA' else 'ATHENA' end as [Owning System],
[Primary Master Genre], isnull([Second Master Genre],'') [Second Master Genre], isnull([Third Master Genre],'') [Third Master Genre], isnull([Fourth Master Genre],'') [Fourth Master Genre],
[Primary BISAC], isnull([Second BISAC],'') [Second BISAC], isnull([Third BISAC],'') [Third BISAC], isnull([Fourth BISAC],'') [Fourth BISAC] 
from 
(
select a.Name, isnull(a.Mix, '') [Series/Book], isnull(c.Name,'') [Author], mg.Name [MasterGenre], o.Name [Imprint], isnull(po.Name,'') [Parent], 
a.gtin, pv.MGenre, pv.Sequence, pv2.Sequence2, pv2.ISBN2, pv2.BISAC, aa.ID [AthAlbum], a.SalesStartDate, a.ReleaseDate, amo.MigratedAt
from album a
inner join organization o on o.id = a.organization
left outer join organization po on po.id = o.parent
inner join albumGenre ag on ag.album = a.id
inner join genre g on g.id = ag.genre
inner join masterGenre mg on mg.id = g.masterGenre
left outer join AthenaAlbum aa on aa.album = a.id
inner join albumProductType apt on apt.album = a.id
inner join productType pt on pt.id = apt.productType
left join pivoter1 pv on pv.ISBN = a.gtin
left join pivoter2 pv2 on pv2.ISBN2 = a.gtin
left join (select min(ac.id) minAC, ac.album from albumcelebrity ac
group by ac.album) mac on mac.album = a.id
left join albumCelebrity ac on ac.id = mac.minAC
left join Celebrity c on c.id = ac.celebrity
left join xxx_athenaMigratedOrgs amo on amo.org = o.id
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)
) as SourceQuery
pivot
(max(MGenre) for Sequence
in ([Primary Master Genre],[Second Master Genre],[Third Master Genre], [Fourth Master Genre])) as pvt1
pivot
(max(BISAC) for Sequence2
in ([Primary BISAC],[Second BISAC],[Third BISAC], [Fourth BISAC])) as pvt2
order by Imprint, ISBN