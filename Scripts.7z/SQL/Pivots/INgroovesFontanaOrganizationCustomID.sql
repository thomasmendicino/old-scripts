/*** 
	All INgrooves / Fontana labels with their CustomID's for:
	
	Atlas Op Company code
	Atlas Op Unit code
	Atlas Sub Label code
	Atlas Super Label code
	
***/
;with OrganizationCustomID
as
(	select
		  Organization
		, [Atlas Op Company code]
		, [Atlas Op Unit code]
		, [Atlas Sub Label code]
		, [Atlas Super Label code]
	from 
	(	select distinct
			  Organization	[Organization]
			, ci.Name		[CustomID_Type]
			, Value			[CustomID_Value]
		from OrganizationAttribute oa
			left join CustomID ci on oa.CustomID=ci.ID
	) oc
	pivot
	(	max(oc.CustomID_Value)
		for CustomID_Type	in	(	  [Atlas Op Company code]
									, [Atlas Op Unit code]
						 			, [Atlas Sub Label code]
						 			, [Atlas Super Label code]
								 )
	) PivotedOrganizationCustomID 				 							 
)
select distinct 
	  o.Name
	, oid.[Atlas Op Company code]
	, oid.[Atlas Op Unit code]
	, oid.[Atlas Sub Label code]
	, oid.[Atlas Super Label code]
From OrganizationCustomID oid
	inner join Organization o on oid.Organization=o.ID
	inner join	(	select 
						Organization 
					from get_organization_descendants(39486) god 
					union 
						select 
							ID [Organization]
						from Organization 
						where id= 39486
				) god on o.ID=god.Organization		
order by 
	  o.Name
	, oid.[Atlas Op Company code]
	, oid.[Atlas Op Unit code]
	, oid.[Atlas Sub Label code]
	, oid.[Atlas Super Label code]
