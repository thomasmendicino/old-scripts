/*
drop table ##ebookRetailers
drop table ##Contracts
drop table ##includedServices
drop table ##excludedServices
*/
declare @ebookRetailers table (ID int, Name nvarchar(30))
insert @ebookRetailers (ID, Name)
select distinct MS.ID, MS.Name from musicservice ms
join musicserviceproducttype pt on pt.musicservice = ms.id
where pt.productType in (22,23,24)

declare @Contracts table (ID int)
insert @Contracts (ID)
select distinct C.ID from contractAlbumViewActive cava
join Contract c on c.id = cava.Contract
join Album A on A.id = Cava.Album
join Organization o on a.Organization = o.id
where o.Name = 'Island Press'

declare @includedServices table (ID int, Contract int)
insert @includedServices (ID, contract)
select distinct ms.id, csv.Contract from contractServiceView csv
inner join @Contracts con on con.id = csv.Contract
inner join @ebookRetailers eb on eb.id = csv.MusicService
inner join musicservice ms on ms.id = csv.musicservice

declare @excludedServices table (MusicService int, Contract int)
insert @excludedServices (MusicService, Contract)
select ms.ID, c.ID from 
musicservice ms
inner join @ebookRetailers eb on eb.id = ms.id,
contract c
inner join @Contracts con on con.ID = c.ID
EXCEPT
select ms.ID, c.ID from 
musicService ms 
join @includedServices inc on inc.id = ms.id
join Contract c on c.ID = inc.Contract

/****************************************************/
;with pivoter (MusicService, [Contract], [Allowed]) as 
(select ms.Name [MusicService], [Contract], 1 as Allowed
FROM @includedServices inc INNER JOIN MusicService MS on MS.ID = inc.ID
UNION
Select ms.Name, [Contract], 0 as Allowed
FROM @excludedServices exc INNER JOIN MusicService MS on MS.ID = exc.MusicService)
--select p.*, ms.Name from pivoter p
--join musicservice ms on ms.Name = p.musicservice
--ORDER by [Contract], Allowed, MusicService
/****************************************************/


select GTIN [ISBN], AlbumName [Title], Mix [Subtitle], [Contract], Name [Publisher], [Amazon eBookBase], [iBookStore], [Barnes And Noble],
[Kobo], [Sony Reader Store], [Books on Board], [KDP], [OverDrive], [Google Books], [3M], [Baker And Taylor]
from 
(
SELECT A.GTIN, a.Name [AlbumName], a.Mix, c.ID [Contract], o.Name, p.Allowed, p.MusicService FROM Album A 
inner join contractalbumviewactive cava on cava.album = a.id
inner join contract c on c.id = cava.contract
inner join organization o on o.id = a.organization
inner join contractServiceView csv on csv.Contract = cava.Contract
inner join pivoter p on p.[Contract] = c.id
where o.name = 'Island Press'
) as SourceQuery
pivot
(
Max(Allowed)
For MusicService
IN ([Amazon eBookBase], [iBookStore], [Barnes And Noble],[Kobo], [Sony Reader Store], [Books on Board], [KDP], [OverDrive], [Google Books], [3M], [Baker And Taylor])) as pvt
order by ISBN, [Contract]