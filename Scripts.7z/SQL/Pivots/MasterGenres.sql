


;with pivoter (Sequence, ISBN, MGenre) as
(
select case when ag.Sequence = 1 then 'Primary' when ag.Sequence = 2 then 'Secondary' when ag.Sequence = 3 then 'Tertiary' end as Sequence, a.gtin ISBN, mg.Name [MGenre] from album a 
join albumGenre ag on ag.album = a.id 
join genre g on g.id = ag.genre 
join masterGenre mg on mg.id = g.masterGenre
join albumProductType apt on apt.album = a.id 
join productType pt on pt.id = apt.productType
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5))
--select * from pivoter order by isbn

select distinct gtin, [Primary], [Secondary], [Tertiary] from 
(
select mg.Name [MasterGenre], a.gtin, pv.MGenre, pv.Sequence from album a
inner join organization o on o.id = a.organization
left outer join organization po on po.id = o.parent
inner join albumGenre ag on ag.album = a.id
inner join genre g on g.id = ag.genre
inner join masterGenre mg on mg.id = g.masterGenre
left outer join AthenaAlbum aa on aa.album = a.id
inner join albumProductType apt on apt.album = a.id
inner join productType pt on pt.id = apt.productType
left join pivoter pv on pv.ISBN = a.gtin
left join (select min(ac.id) minAC, ac.album from albumcelebrity ac
group by ac.album) mac on mac.album = a.id
left join albumCelebrity ac on ac.id = mac.minAC
left join Celebrity c on c.id = ac.celebrity
left join xxx_athenaMigratedOrgs amo on amo.org = o.id
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)
) as SourceQuery
pivot
(max(MGenre) for Sequence
in ([Primary],[Secondary],[Tertiary])) as pvt
