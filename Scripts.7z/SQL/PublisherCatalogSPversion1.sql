USE [AthenaProductCatalog]
GO

/****** Object:  StoredProcedure [dbo].[PublisherCatalog]    Script Date: 4/5/2016 12:57:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







CREATE PROCEDURE [dbo].[PublisherCatalog]
	@Publisher			nvarchar(200) = ''

	AS
BEGIN
	SET NOCOUNT ON;

declare @actualPub nvarchar(300)
select top 1 @actualPub = p.Name from AthenaDistribution..Publishers p where p.Name like '%' + @Publisher + '%' OR p.SafeName like '%' + @Publisher + '%'

select TOP 1 ISNULL('Finding eBook Catalog for ''' + @actualPub + '''','No publisher matching ''' + @Publisher + ''' could be found. Try another name.' ) AS 'Summary                                                             '

select distinct
	p.Ordinal as ISBN
	, o.OrganizationName as Imprint
	, case 
		when po.OrganizationName = 'Inscribe Digital' then ''
		else po.organizationName 
	   end as ParentPublisher
	, case 
		when pf.ProductFormTypeValue = 52 then 'ED: Digital download'
		when pf.ProductFormTypeValue = 51 then 'EC: Digital online'
		when pf.ProductFormTypeValue = 50 then 'EB: Digital download and online'
		when pf.ProductFormTypeValue = 49 then 'EA: Digital (delivered electronically)'
		else cast(pf.ProductFormTypeValue as varchar(10))
	   end as ProductFormType
from 
	AthenaProductCatalog..product p
		join AthenaProductCatalog..asset a on a.ProductUid = p.ProductUid
		join AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
		join AthenaProductCatalog..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		join AthenaProductCatalog..productForms pf on pf.AssetVersionUid = av.AssetVersionUid
		join AthenaSecurity..OrgHierarchy(@actualPub) oh on oh.organizationUId = p.OrganizationUid
		join AthenaSecurity..Organizations o on o.OrganizationUid = p.OrganizationUid
		join AthenaSecurity..Organizations po on po.OrganizationUid = o.ParentOrganizationUid
where pf.ProductFormTypeValue in (48,49,50,51,52)
	and av.ValidUntilUtc is NULL
order by o.OrganizationName, p.Ordinal
	END







GO


