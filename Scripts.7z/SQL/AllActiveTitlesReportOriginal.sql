with pivoter1 (Sequence, ISBN, MGenre) as
(
select case when ag.Sequence = 1 then 'PrimaryMasterGenre' when ag.Sequence = 2 then 'SecondMasterGenre' when ag.Sequence = 3 then 'ThirdMasterGenre' when ag.Sequence = 4 then 'FourthMasterGenre' end as Sequence, a.gtin ISBN, mg.Name [MGenre] from album a 
join albumGenre ag on ag.album = a.id 
join genre g on g.id = ag.genre 
join masterGenre mg on mg.id = g.masterGenre
join albumProductType apt on apt.album = a.id 
join productType pt on pt.id = apt.productType
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)),

pivoter2 (Sequence2, ISBN2, BISAC) as
(
select case when ag.Sequence = 1 then 'PrimaryBISAC' when ag.Sequence = 2 then 'SecondBISAC' when ag.Sequence = 3 then 'ThirdBISAC' when ag.Sequence = 4 then 'FourthBISAC' end as Sequence2, a.gtin ISBN2, g.Code [BISAC] from album a 
join albumGenre ag on ag.album = a.id 
join genre g on g.id = ag.genre 
join albumProductType apt on apt.album = a.id 
join productType pt on pt.id = apt.productType
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)
)

select distinct gtin [ISBN], 
Name [Title], [Series], [Author], [Imprint], [Parent], case when [AthAlbum] is NULL then cast(datepart(yy,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(4)) + '-' +  cast(datepart(mm,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(2)) + '-' + cast(datepart(dd,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(2)) else cast(datepart(yy,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(4)) + '-' + cast(datepart(mm,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(2)) + '-' + cast(datepart(dd,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(2)) end as [OnSaleDate],
 case when MigratedAt is not null then 'ATHENA' when [AthAlbum] is NULL then 'INDMA' else 'ATHENA' end as [OwningSystem],
[PrimaryMasterGenre], isnull([SecondMasterGenre],'') [SecondMasterGenre], isnull([ThirdMasterGenre],'') [ThirdMasterGenre], isnull([FourthMasterGenre],'') [FourthMasterGenre],
[PrimaryBISAC], isnull([SecondBISAC],'') [SecondBISAC], isnull([ThirdBISAC],'') [ThirdBISAC], isnull([FourthBISAC],'') [FourthBISAC]
from 
(
select a.Name, isnull(a.Mix, '') [Series], isnull(c.Name,'') [Author], mg.Name [MasterGenre], o.Name [Imprint], isnull(po.Name,'') [Parent], 
a.gtin, pv.MGenre, pv.Sequence, pv2.Sequence2, pv2.ISBN2, pv2.BISAC, aa.ID [AthAlbum], a.SalesStartDate, a.ReleaseDate, amo.MigratedAt
from album a
inner join organization o on o.id = a.organization
left outer join organization po on po.id = o.parent
inner join albumGenre ag on ag.album = a.id
inner join genre g on g.id = ag.genre
inner join masterGenre mg on mg.id = g.masterGenre
left outer join AthenaAlbum aa on aa.album = a.id
inner join albumProductType apt on apt.album = a.id
inner join productType pt on pt.id = apt.productType
left join pivoter1 pv on pv.ISBN = a.gtin
left join pivoter2 pv2 on pv2.ISBN2 = a.gtin
left join (select min(ac.id) minAC, ac.album from albumcelebrity ac
group by ac.album) mac on mac.album = a.id
left join albumCelebrity ac on ac.id = mac.minAC
left join Celebrity c on c.id = ac.celebrity
left join xxx_athenaMigratedOrgs amo on amo.org = o.id
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)
) as SourceQuery
pivot
(max(MGenre) for Sequence
in ([PrimaryMasterGenre],[SecondMasterGenre],[ThirdMasterGenre], [FourthMasterGenre])) as pvt1
pivot
(max(BISAC) for Sequence2
in ([PrimaryBISAC],[SecondBISAC],[ThirdBISAC], [FourthBISAC])) as pvt2
order by Imprint, ISBN


/*



*/