USE [AthenaDistribution]
GO

/****** Object:  StoredProcedure [dbo].[Rosetta]    Script Date: 12/9/2014 11:02:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[Rosetta]
	@Bit			nvarchar(6) = ''

	AS
BEGIN
	SET NOCOUNT ON;

	
declare @publisherName nvarchar(100)
declare @publisherUid uniqueidentifier
declare @AllRetailers table (Name nvarchar(50))
declare @ruleSetUid uniqueidentifier

	IF @Bit = 'OPEN'

	BEGIN

set @publisherName = 'RosettaBooks'
select @publisherUid = publisherUid from AthenaDistribution..Publishers where name = @publisherName
insert @AllRetailers (Name) select Name from Retailers where Code <> 'INX'
select @ruleSetUid = RuleSetUid from AthenaDistribution..ruleSets where Name = 'Distribution Prohibited'

update c set ValidUntilUtc = getUTCdate() from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @AllRetailers)
and c.RuleSetUid = @ruleSetUid
and c.ValidUntilUtc is NULL

PRINT 'RosettaBooks Feed is now OPEN for Distribution'
	END

	IF @Bit = 'CLOSE'

	BEGIN
	
set @publisherName = 'RosettaBooks'
select @publisherUid = publisherUid from AthenaDistribution..Publishers where name = @publisherName
insert @AllRetailers (Name) select Name from Retailers where Code <> 'INX'
select @ruleSetUid = RuleSetUid from AthenaDistribution..ruleSets where Name = 'Distribution Prohibited'

;with mostRecentProhibited as
(select max(c.ValidUntilUtc) ValidUntilUtc, c.retailerUid from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @AllRetailers)
and c.RuleSetUid = @ruleSetUid
group by c.publisherUid, c.retailerUid, c.ruleSetUid
)
update c set ValidUntilUtc = NULL from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostRecentProhibited m on m.ValidUntilUtc = c.ValidUntilUtc and c.RetailerUid = m.retailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @AllRetailers)
and c.RuleSetUid = @ruleSetUid

PRINT 'RosettaBooks Feed is now CLOSED for Distribution'
	
	END

	IF @Bit not in ('OPEN','CLOSE') 
	
	BEGIN

	PRINT 'Please only use ''OPEN'' or ''CLOSE'' as the arguments for this stored procedure'
	
	END

	END


GO


