--Creating austindevvm_ss as snapshot of the
--austindevvm database:
CREATE 
DATABASE INDMAUAT_SS_20120605
ON
(	NAME = INgrooves_Data, FILENAME = 
	'E:\DataBase\INDMAUAT\Snapshot_2012-06-05\INgrooves.MDF'),
(	NAME = Primary_File2, FILENAME = 
	'E:\DataBase\INDMAUAT\Snapshot_2012-06-05\Primary_File2.NDF'),
(	NAME = Primary_File3, FILENAME = 
	'E:\DataBase\INDMAUAT\Snapshot_2012-06-05\Primary_File3.NDF'),
(	NAME = IndexGroup_File1, FILENAME = 
	'E:\DataBase\INDMAUAT\Snapshot_2012-06-05\IndexGroup_File1.NDF'),
(	NAME = IndexGroup_File2, FILENAME = 
	'E:\DataBase\INDMAUAT\Snapshot_2012-06-05\IndexGroup_File2.NDF'),
(	NAME = IndexGroup_File3, FILENAME = 
	'E:\DataBase\INDMAUAT\Snapshot_2012-06-05\IndexGroup_File3.NDF'),
(	NAME = CacheGroup_File1, FILENAME = 
	'E:\DataBase\INDMAUAT\Snapshot_2012-06-05\CacheGroup_File1.NDF'),	
(	NAME = CacheGroup_File2, FILENAME = 
	'E:\DataBase\INDMAUAT\Snapshot_2012-06-05\CacheGroup_File2.NDF'),
(	NAME = CacheGroup_File3, FILENAME = 
	'E:\DataBase\INDMAUAT\Snapshot_2012-06-05\CacheGroup_File3.NDF')
AS SNAPSHOT OF INDMAUAT
GO
---------------------------------------------------------------

USE master;
-- Reverting austindevvm to austindevvm_ss
RESTORE 
DATABASE austindevvm 
from 
DATABASE_SNAPSHOT = 'austindevvm_ss';
GO