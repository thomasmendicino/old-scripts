select r.Path, Ordinal from athenaProductCatalog..product p
join athenaProductCatalog..asset a on a.productUid = p.productUid
join athenaProductCatalog..AssetOverride ao on ao.assetUid = a.assetUid
join athenaProductCatalog..assetVersion av on av.assetOverrideUid = ao.assetOverrideUid
join athenaResourceStorage..resources r on r.resourceUid = av.resourceUid
where av.validUntilutc is null