use AthenaAssetProcessor;
/*

General query to identify the package we care about and what else was uploaded today (UTC time)

*/
select ifc.Name ImportFolder, fo.*, fos.* from ImportFolderConfigurations ifc
inner join FolderObjects fo on fo.ImportFolderConfigurationUid = ifc.ImportFolderConfigurationUid
inner join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
where 
ifc.Name like '%Disney Publishing Worldwide, Inc.%' and
fo.CreatedAtUtc > '2015-02-05' AND
fo.Path not like '%.complete%'
order by fo.CreatedAtUtc desc


/*

More specific query to identify how many items were in the upload package. Status 0 is the first step, it's like 'Processing' in the UI.

*/

select ifc.Name ImportFolder, left(fo.Path, 10) FolderName, count(*) NumberOfItems from ImportFolderConfigurations ifc
inner join FolderObjects fo on fo.ImportFolderConfigurationUid = ifc.ImportFolderConfigurationUid
inner join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
where 
ifc.Name like '%Disney Publishing Worldwide, Inc.%' and
fo.path like '%20150205.2%' AND
fo.Path not like '%.complete%'
and fos.Status = 0
group by ifc.Name, left(fo.Path, 10)

/*

Let's see how many went to the next step in ingestion process -- Status 1

*/

select ifc.Name ImportFolder, left(fo.Path, 10) FolderName, count(*) NumberOfItems from ImportFolderConfigurations ifc
inner join FolderObjects fo on fo.ImportFolderConfigurationUid = ifc.ImportFolderConfigurationUid
inner join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
where 
ifc.Name like '%Disney Publishing Worldwide, Inc.%' and
fo.path like '%20150205.2%' AND
fo.Path not like '%.complete%'
and fos.Status = 1
group by ifc.Name, left(fo.Path, 10)


/*

Let's see how many items successfully ingested (Status 2) versus had an error on import (Status 3)

*/



select ifc.Name ImportFolder, left(fo.Path, 10) FolderName, count(*) NumberOfItems, 'Successfully Ingested' as [Status] from ImportFolderConfigurations ifc
inner join FolderObjects fo on fo.ImportFolderConfigurationUid = ifc.ImportFolderConfigurationUid
inner join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
where 
ifc.Name like '%Disney Publishing Worldwide, Inc.%' and
fo.path like '%20150205.2%' AND
fo.Path not like '%.complete%'
and fos.Status = 2
group by ifc.Name, left(fo.Path, 10)
UNION
select ifc.Name ImportFolder, left(fo.Path, 10) FolderName, count(*) NumberOfItems, 'Error on Ingestion' as [Status] from ImportFolderConfigurations ifc
inner join FolderObjects fo on fo.ImportFolderConfigurationUid = ifc.ImportFolderConfigurationUid
inner join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
where 
ifc.Name like '%Disney Publishing Worldwide, Inc.%' and
fo.path like '%20150205.2%' AND
fo.Path not like '%.complete%'
and fos.Status = 3
group by ifc.Name, left(fo.Path, 10)
