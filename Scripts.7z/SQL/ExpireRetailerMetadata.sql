
use AthenaProductCatalog;
begin tran
select * from product p
join Asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join AthenaDistribution..Retailers r on r.RetailerUid = ao.RetailerUid
where p.Ordinal in (
9781625173010,
9780615741604,
9781625176394)
and av.ValidUntilUtc is NULL

update av set validUntilUtc = GETUTCDATE() from product p
join Asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join AthenaDistribution..Retailers r on r.RetailerUid = ao.RetailerUid
where p.Ordinal in (
9781625173010,
9780615741604,
9781625176394)
and av.ValidUntilUtc is NULL

select * from product p
join Asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join AthenaDistribution..Retailers r on r.RetailerUid = ao.RetailerUid
where p.Ordinal in (
9781625173010,
9780615741604,
9781625176394)
and av.ValidUntilUtc is NULL


