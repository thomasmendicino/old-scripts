
SELECT 
	p.Ordinal AS ISBN,
	max(dos.CreatedAtUtc) as LastEventAtUTC,
	case 
		when dsgms.ResultingEvent = 119 then 'APPROVED'
		when dsgms.ResultingEvent = 118 then 'QUEUED FOR APPROVAL'
		END AS [Apple Review Queue Status]
FROM
	Product p
	join productRevisions pr on pr.ProductUid = p.productUid
	join contracts c on c.ContractUid = pr.ContractUid
	join Retailers r on r.RetailerUid= c.RetailerUid
	join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
	join AthenaSecurity..OrgHierarchy('Dreamspinner Press') oh on oh.organizationUId = p.OrganizationUid
	join DistributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
	join distributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
	join DistributionOrderStructureGroupManualReviews dsgm on dsgm.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
	CROSS APPLY (
		SELECT TOP 1 ResultingEvent 
		FROM DistributionOrderStructureGroupManualReviewStatus s
		where s.DistributionOrderStructureGroupManualReviewUid = dsgm.DistributionOrderStructureGroupManualReviewUid
		ORDER BY s.CreatedAtUtc DESC) dsgms
WHERE 
	r.Code = 'APC'
GROUP BY 
	p.Ordinal, 
	case 
		when dsgms.ResultingEvent = 119 then 'APPROVED'
		when dsgms.ResultingEvent = 118 then 'QUEUED FOR APPROVAL'
	END