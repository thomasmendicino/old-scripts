begin tran
declare @pub uniqueidentifier
declare @ret1 uniqueidentifier
declare @ret2 uniqueidentifier
declare @ruleset uniqueidentifier

select @pub = publisherUid from Publishers where Name = 'Dreamspinner Press'
select @ret1 = retailerUid from Retailers where Code = 'BNO'
select @ret2 = retailerUid from Retailers where Code = 'AMZ'
select @ruleset = RuleSetUid from RuleSets where Name = 'Distribution Prohibited'

select * from contracts c
join retailers r on r.retailerUid = c.retailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where p.PublisherUid = @pub
	and r.RetailerUid in (@ret1, @ret2)
	and c.ValidUntilUtc is NULL
	and c.RuleSetUid = @ruleset

update c set ValidUntilutc = GETUTCDATE() 
from contracts c
join retailers r on r.retailerUid = c.retailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where p.PublisherUid = @pub
	and r.RetailerUid in (@ret1, @ret2)
	and c.ValidUntilUtc is NULL
	and c.RuleSetUid = @ruleset

select * from contracts c
join retailers r on r.retailerUid = c.retailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where p.PublisherUid = @pub
	and r.RetailerUid in (@ret1, @ret2)
	and c.ValidUntilUtc is NULL
	and c.RuleSetUid = @ruleset

--COMMIT