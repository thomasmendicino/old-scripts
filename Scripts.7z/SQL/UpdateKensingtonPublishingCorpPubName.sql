begin tran
select * from athenaSecurity..organizations where organizationName = 'Kensington Publishing Corp.'
update athenaSecurity..organizations
set Organizationname = 'Kensington' where organizationName = 'Kensington Publishing Corp.'
select * from athenaSecurity..organizations where organizationName = 'Kensington'

select * from athenaDistribution..Publishers where Name = 'Kensington Publishing Corp.'
update AthenaDistribution..Publishers
set Name = 'Kensington', SafeName = 'Kensington' where name = 'Kensington Publishing Corp.'
select * from athenaDistribution..Publishers where Name = 'Kensington'

select * from athenaSecurity..aspnet_users where primaryOrganizationUid = '8822C822-191F-489D-AC76-94D48E913CFD'
update athenaSecurity..aspnet_users set UserName = 'Kensington', LoweredUserName = 'kensington'
where primaryOrganizationUid = '8822C822-191F-489D-AC76-94D48E913CFD'
select * from athenaSecurity..aspnet_users where primaryOrganizationUid = '8822C822-191F-489D-AC76-94D48E913CFD'

select * from athenaAssetProcessor..importFolderConfigurations where publisherUid = '64D311E1-A62B-4FEE-835B-6133C52BA1ED'
update AthenaAssetProcessor..ImportFolderConfigurations
set Path = replace(Path,'KensingtonPublishingCorp','Kensington'),Name = replace(Name,'Kensington Publishing Corp.','Kensington'), SafeName = replace(SafeName,'KensingtonPublishingCorp','Kensington')
where PublisherUid = '64D311E1-A62B-4FEE-835B-6133C52BA1ED'
select * from athenaAssetProcessor..importFolderConfigurations where publisherUid = '64D311E1-A62B-4FEE-835B-6133C52BA1ED'

--rollback
--commit