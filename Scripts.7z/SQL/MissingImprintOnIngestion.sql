select
ISNULL(cast(p.Ordinal as char(13)),'') as ISBN,
ISNULL(o.OrganizationName,'') as TitleOwner,
pb.Name as ImportFolderPublisher,
CASE
	WHEN ResultingMessage LIKE '%is not child%' 
		THEN SUBSTRING(ResultingMessage,charindex('ERROR',ResultingMessage),charindex('not child',ResultingMessage))
	WHEN ResultingMessage LIKE '%is not found%'
		THEN SUBSTRING(ResultingMessage,charindex('ERROR.',ResultingMessage),charindex('not found.',ResultingMessage) - charindex('ERROR.',ResultingMessage) + 10)
	ELSE
		LEFT(ResultingMessage,200)
END AS [Import Error],
replace('\\' + Host + '\' + ic.Path + '\' + fo.Path,'/','\') as ImportFolder
from FolderObjectEBookProductProcessingResults fpr
	INNER JOIN FolderObjects fo 
		ON fo.FolderObjectUid = fpr.FolderObjectUid
	INNER JOIN ImportFolderConfigurations ic
		ON ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
	INNER JOIN Publishers pb
		ON pb.PublisherUid = ic.PublisherUid
	LEFT OUTER JOIN Product p
		ON p.ProductUid = fpr.ProductUid
	LEFT OUTER JOIN Organizations o
		ON o.OrganizationUid = p.OrganizationUid
where ResultingEventLevel = 4 
	AND ResultingMessage like 'Trying to find Imprint by Name%' 
	AND fpr.CreatedAtUtc > GETUTCDATE()-1