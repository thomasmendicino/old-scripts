declare @orgName nvarchar(100)
declare @orgID int
declare @ParentOrgId table (orgID int)
--set @orgName = 'Bloomsbury Publishing USA'
--set @orgName = 'Bloomsbury Publishing UK'
set @orgName = 'Nancy Yost Literary Agency Inc.'
select @orgID = ID from Organization where Name = @orgName

insert @ParentOrgId (orgID)
select ID from Organization where Parent = @orgID

select distinct o.Name Imprint, left(il.SourceData, len(o.Name)) SourceData from changeRequest cr
join ChangeRequestImportLogBatch cb on cb.ChangeRequestBatch = cr.ChangeRequestBatch
join album a on cr.album = a.id
join importLog il on il.id = cb.ImportLog
join organization o on o.id = a.organization
where a.Organization in (select @orgID
union
select orgID from @ParentOrgId)
union
select distinct o.Name Imprint, left(il.SourceData, len(rtrim(o.Name))) SourceData from importLog il
join importLogEntry ile on ile.importLog = il.ID
join album a on a.gtin = ile.SourceID
join organization o on o.id = a.organization
where a.organization in (select @orgID
union
select orgID from @ParentOrgId)

