DECLARE @User nvarchar(max)
DECLARE @Environment nvarchar(max)
SET @User = 'Charisma'
SET @Environment = 'QA'

DECLARE @Query nvarchar(max) =
    ('select u.Username, r.RoleName from AthenaSecurity' + @Environment + '.dbo.aspnet_Users u
join AthenaSecurity' + @Environment + '.dbo.aspnet_UsersInRoles ur on ur.UserId = u.UserId
join AthenaSecurity' + @Environment + '.dbo.aspnet_Roles r on r.RoleId = ur.RoleId where u.username = ''' + @User + '''')
    
exec sp_executesql @Query


*************************************

/* this doesn't quite work as I'd planned, so trashing it*/

begin tran
IF OBJECT_ID('tempdb.dbo.#Changes') IS NOT NULL DROP TABLE #Changes
CREATE TABLE #Changes (Org int, Name nvarchar(260), Celebrity int, change bit)
insert #Changes (org, name, Celebrity, change)
select 37710, 'Cusi Cram', 442226, 1
union
select 34248, 'Cusi Cram', 413927, 0 


declare @Count int = (select count(*) from albumcelebrity ac join celebrity c on c.id = ac.celebrity where c.organization = 37710)
declare @Counter int = 1
WHILE @Counter <= @Count
BEGIN
DECLARE @Query nvarchar(max) = (N'UPDATE AC SET Celebrity = ' + (SELECT cast(Celebrity as nvarchar(10)) from #Changes WHERE Change = 0) + ' FROM AlbumCelebrity AC JOIN Celebrity C on C.id = AC.Celebrity WHERE Celebrity = ' + (SELECT cast(Celebrity as nvarchar(10)) from #Changes WHERE Change = 1) + ' AND C.Organization = 37710')
exec sp_executesql @Query
set @Counter = @Counter + 1
IF (@Counter >= @Count)
	BREAK
ELSE
	CONTINUE
END