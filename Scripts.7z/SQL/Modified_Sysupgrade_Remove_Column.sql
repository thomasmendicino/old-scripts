--begin transaction

declare @Table nvarchar(max)  = 'Country'
declare @Column nvarchar(max) = 'ONIX'
declare @Query nvarchar(max)

select @Query = 'alter table ' + quotename(@Table) + ' drop constraint ' + quotename([Constraint].name)
from sys.default_constraints [Constraint]
inner join sys.objects [Object] on [Constraint].parent_object_id = [Object].object_id
inner join sys.columns [Column] on [Constraint].parent_object_id = [Column].object_id and [Constraint].parent_column_id = [Column].column_id
where [Object].name = @Table and [Column].name = @Column

exec sp_executesql @Query

GO
IF EXISTS (SELECT NULL FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Country' AND COLUMN_NAME = 'ONIX')
ALTER TABLE dbo.Country
	DROP COLUMN ONIX
GO

declare @Table2 nvarchar(max)  = 'Language'
declare @Column2 nvarchar(max) = 'ONIX'
declare @Query2 nvarchar(max)

select @Query2 = 'alter table ' + quotename(@Table2) + ' drop constraint ' + quotename([Constraint].name)
from sys.default_constraints [Constraint]
inner join sys.objects [Object] on [Constraint].parent_object_id = [Object].object_id
inner join sys.columns [Column] on [Constraint].parent_object_id = [Column].object_id and [Constraint].parent_column_id = [Column].column_id
where [Object].name = @Table2 and [Column].name = @Column2

exec sp_executesql @Query2

GO
IF EXISTS (SELECT NULL FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Language' AND COLUMN_NAME = 'ONIX')
ALTER TABLE dbo.Language
	DROP COLUMN ONIX
GO

declare @Table3 nvarchar(max)  = 'Currency'
declare @Column3 nvarchar(max) = 'ONIX'
declare @Query3 nvarchar(max)

select @Query3 = 'alter table ' + quotename(@Table3) + ' drop constraint ' + quotename([Constraint].name)
from sys.default_constraints [Constraint]
inner join sys.objects [Object] on [Constraint].parent_object_id = [Object].object_id
inner join sys.columns [Column] on [Constraint].parent_object_id = [Column].object_id and [Constraint].parent_column_id = [Column].column_id
where [Object].name = @Table3 and [Column].name = @Column3

exec sp_executesql @Query3

GO
IF EXISTS (SELECT NULL FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Currency' AND COLUMN_NAME = 'ONIX')
ALTER TABLE dbo.Currency
	DROP COLUMN ONIX
GO

--rollback transaction