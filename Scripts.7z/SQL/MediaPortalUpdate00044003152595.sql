--begin tran
--commit

/*
--begin tran
--rollback
insert SongCelebrity (Song, Celebrity, Role)
select 2475928, 54235, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2475928, 56473, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2475929, 54235, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2475929, 54238, 2
insert SongCelebrity (Song, Celebrity, Role)
select 2475929, 56473, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2475930, 54235, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2475930, 54237, 2
*/
--begin tran
--rollback
--commit
--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Process = 1, MediaPortalIncomplete = 0 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00044003152595')) and Name = 'I Love You - Remix 1')

--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Process = 1, MediaPortalIncomplete = 0 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00044003152595')) and Name = 'I Love You - (Original)')

--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Process = 1, MediaPortalIncomplete = 0 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00044003152595')) and Name = 'I Love You - (Urban AC)')

--begin tran
--rollback
--commit
--update track set Fields = ((select top 1 Fields from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')))),
UMGRightTypeCore = ((select top 1 UMGRightTypeCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')))),
UMGLabelCore = ((select top 1 UMGLabelCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')))),
UMGLabelLocal = ((select top 1 UMGLabelLocal from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')))),
UMGOwningTerritory = 'US' where album = (select ID from album where gtin = '00044003152595')

select * from albumoverrides where album = 310749
select * from albumcelebrity where album = 310749

--begin tran
--commit
declare @gtin nvarchar (14)
declare @AlbumCelebrity int
set @gtin = '00044003152595'
set @AlbumCelebrity = (select Celebrity from AlbumCelebrity where Album = (select id from Album where gtin = '00044003152595') and country = (select defaultcountry from album where gtin = @gtin))
insert AlbumCelebrity (Album, Celebrity, Role)
select (select ID from album where gtin = @gtin), @AlbumCelebrity, (select role from AlbumCelebrity where Album = (select id from album where gtin = @gtin) and country = (select defaultcountry from album where gtin = @gtin))

--insert AlbumGenre (Album, Genre, Sequence)
select (select ID from album where gtin = '00044003152595'), 132, 1


--begin tran
--commit
--update album set ReleaseDate = (select ReleaseDate from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Fields = (select Fields from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Organization = (select Organization from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
CLine = (select CLine from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
PLine = (select PLine from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
SalesStartDate = (select SalesStartDate from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
UMGproducttype = (select umgproducttype from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
UMGlabelcore = (select umglabelcore from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
UMGlabellocal = (select umglabellocal from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
process = 1, umgincomplete = 0, UMGAccount = 4, UMGOwningTerritory = 'US' where gtin = '00044003152595'
--update album set CoverArt = '/images/Covers/HAS/2011/10/10/19/CoverArt_11FONIM01743_gcSTu' where gtin = '00044003152595'
select * from celebrity where id = 54235
select * from celebrity where id = 252210
select * from albumgenre where album = 310749
select * from albumgenre where album = 310749
select * from album where gtin = '00044003152595'
select * from albumoverrides where album = 310749
select * from process
select genre, * from song where id in (select song from track where album in (select id from album where gtin in ('00044003152595')))
select * from songoverrides where song in (select song from track where album in (select id from album where gtin in ('00044003152595')))
select * from track where album = (select id from album where gtin = '00044003152595')
select * from trackoverrides where track in (select id from track where album in (select id from album where gtin in ('00044003152595')))
select * from songcelebrity where song in (2475928,
2475929,
2475930) and (country = 248 or country is null)
--begin tran
--commit
--update track set distributionset = 100 where album = 310749

select top 100 * from ingrooveslog.dbo.log where message like '%release%'
select * from ingrooveslog.dbo.log where message like '%00044003152595%'
