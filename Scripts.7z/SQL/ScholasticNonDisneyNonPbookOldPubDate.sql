use AthenaComposite;

declare @Scholastic table (orgUid uniqueidentifier)
declare @organizationName nvarchar(100)
select @organizationname = 'Scholastic Inc.'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @Scholastic
select organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select '00000000-0000-0000-0000-000000000001'

;with pubDateEnum as (
select 1 as Value, 'Publication date' as Role
UNION
select 2 as Value, 'Embargo Date' as Role
UNION
select 9 as Value, 'Public Announcement Date' as Role
UNION
select 10 as Value, 'Trade Announcement Date' as Role
UNION
select 11 as Value, 'Date of first publication' as Role
UNION
select 12 as Value, 'Last reprint date' as Role
UNION
select 13 as Value, 'Out of print / deletion date' as Role
UNION
select 16 as Value, 'Last reissue date' as Role
UNION
select 19 as Value, 'Publication date of print counterpart' as Role
UNION
select 20 as Value, 'Date of first publication in original language' as Role
UNION
select 21 as Value, 'Forthcoming reissue date' as Role
UNION
select 22 as Value, 'Expected availability date after temporary withdrawal' as Role
UNION
select 23 as Value, 'Review embargo date' as Role
UNION
select 25 as Value, 'Publisher''s reservation order deadline' as Role
UNION
select 26 as Value, 'Forthcoming reprint date' as Role
UNION
select 27 as Value, 'Preorder embargo date' as Role
),
SupplyDateEnum as (
select 2 as Value, 'Embargo date' as Role
UNION
select 8 as Value, 'Expected availability date' as Role
UNION
select 18 as Value, 'Last date for returns' as Role
UNION
select 25 as Value, 'Reservation order deadline' as Role
),
FilesWithOnlyMetadata as (
select p.Ordinal from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join @Scholastic s on s.orgUid = p.OrganizationUid
where a.AssetType = 1003 and av.ValidUntilUtc is NULL
EXCEPT
select p.Ordinal from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join @Scholastic s on s.orgUid = p.OrganizationUid
where a.AssetType != 1003 and av.ValidUntilUtc is NULL
),
AppleOnlyTitles as (
select distinct p.Ordinal from product p
join @Scholastic s on s.orgUid = p.OrganizationUid
join ProductRevisions pr on pr.ProductUid = p.ProductUid
join DistributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join DistributionOrderStructureGroupBatches dsb on dsb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join contracts c on c.contractUId = pr.ContractUid 
join retailers r on r.RetailerUid = c.RetailerUid
where r.Code = 'APC')
select p.Ordinal ISBN, pe.Role PublishingDateRole, pd.Value PublishingDate, se.Role SupplyDateRole, sd.Value SupplyDate from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join @Scholastic s on s.orgUid = p.OrganizationUid
join FilesWithOnlyMetadata fm on fm.Ordinal = p.Ordinal
join ProductForms pf on pf.AssetVersionUid = av.AssetVersionUid
left join PublishingDates pd on pd.AssetVersionUid = av.AssetVersionUid
left join SupplyDates sd on sd.AssetVersionUid = av.AssetVersionUid
left join PubDateEnum pe on pe.Value = pd.PublishingDateRole
left join SupplyDateEnum se on se.Value = sd.SupplyDateRole
where p.ordinal NOT in (select Ordinal from AppleOnlyTitles)
and av.ValidUntilUtc is NULL
and (pf.ProductFormTypeValue < 1 or pf.ProductFormTypeValue > 36)
and pe.Role = 'Publication Date'
and pd.Value < getdate()