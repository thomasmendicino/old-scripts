use AthenaComposite;
select 
case 
when ao.RetailerUid is null then 'xcopy \\instor05\inscribe-master--1\ResourceStorage\' + r.Path + ' C:\temp\PublisherFix\' + cast(p.ordinal as nvarchar(13)) + '.onix'
else 'xcopy \\instor05\inscribe-master--1\ResourceStorage\' + r.Path + ' C:\temp\PublisherFix\' + cast(p.ordinal as nvarchar(13)) + '_' + rt.Code + '.onix'
end as Commands
from product p
join asset a on a.productUid = p.productUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join Resources r on r.ResourceUid = av.ResourceUid
left join retailers rt on rt.RetailerUid = ao.RetailerUid
where av.ValidUntilUtc is NULL
and a.ResourceContentType = 100
and p.Ordinal in (
9781625854124,
9781625854124,
9781625856487,
9781625856166,
9781625857040,
9781625854544,
9781625856272,
9781625852380,
9781625855701,
9781625856937,
9781625854605,
9781625857002,
9781625852069,
9781625855015,
9781625853073,
9781625855107,
9781625855589,
9781625855459,
9781625854414,
9781439653739,
9781625853431,
9781625856289,
9781625852410,
9781625856630,
9781625856609,
9781625856104,
9781625855688,
9781625855367,
9781625853363,
9781625854452)