select distinct
                                                           o.ID [Publisher_ID]
														 , count(a.id) as [Total_Title_Count] 
														 , o.name as [Publisher]
														 , isnull(o2.name, '') as [Publisher_Parent]
                                                         , case when o.Active = 1 then 'Active' when o.Active = 0 then 'Inactive' end as [Active_Status]
														 , o.paymentthreshold as [organization_Payment_Threshold]
														 , pm.paymentthreshold as [Payment_Method_Threshold]
														 , isnull(pm.name,'') as [Payment_Method]
														 , roy.rate as [Royalty_Rate]
														 , roy2.rate as [Parent_Royalty_Rate]
														 , coalesce(x.insribeuser, 'No') as [Associated_to_INscribeCatalog]
														 , isnull(p.first,'') as [First_Name]
														 , isnull(p.Last,'') as [Last_Name]
														 , isnull(adds.street1,'') as [Street_1]
														 , isnull(adds.street2,'') as [Street_2]
														 , isnull(adds.city,'') as [City]
														 , isnull(adds.stateorprovince,'') as [State_or_Province]
														 , isnull(US.name,'') as [US_State]
														 , isnull(cap.Name,'') as [CA_Province]
														 , isnull(con.name,'') as [Country]
														 , isnull(adds.postalcode,'') as [Postal_Code]
														 , isnull(e.address,'') as [Email]
														 , isnull(tel.citycode,'') as [Area_Code]
														 , isnull(tel.localnumber,'') as [Phone_Number]
														 , isnull(iu.name,'') as [INDMA_User_Name]
														 , isnull(por.name,'') as [Portal_Association]
														from organization o 
														 left join organization o2 on o2.id = o.parent
														 left join album a on a.organization = o.id
														 left join paymentmethod pm on pm.id = o.paymentmethod
														 left join (select * from association where toperson != (select id from person where first = 'INscribeCatalog')) ass on ass.fromorganization = o.id
														 left join royalty roy on roy.organization = o.id
														 left join royalty roy2 on roy2.organization = o.parent 
														 left join person p on p.id = ass.toperson
														 left join indmauser iu on iu.person = p.id
														 left join address adds on adds.organization = o.id
														 left join country con on con.id = adds.country
														 left join CAprovince cap on cap.id = adds.CAProvince
														 left join email e on e.organization = o.id
														 left join telephone tel on tel.organization = o.id
														 left join portal por on por.id = iu.portal
														 left join USstate Us on Us.id = adds.USstate
														 left join ( select 'Yes'[INsribeUser], FromOrganization from Association where ToPerson=(select id from person where first = 'INscribeCatalog')) x on ass.FromOrganization=x.FromOrganization
														where o.charter = (select id from charter where name ='publisher')
														 and o.name not in ('* Demo E')
														group by 
														 o.name
														 , isnull(o2.name, ''), o.paymentthreshold , pm.paymentthreshold, pm.name
														 , coalesce(x.insribeuser, 'No')
														 , roy.rate , roy2.rate , p.first , p.Last  , adds.street1 , adds.street2 , adds.city , adds.stateorprovince
														 , con.name , cap.Name, adds.postalcode , iu.name, e.address , tel.citycode
														 , tel.localnumber , por.name, US.name, ass.relationship, o.ID, o.Active
														order by o.name