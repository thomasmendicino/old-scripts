
declare @productChangeTypes table(Name varchar(50), Value int)
insert into @productChangeTypes values ('NewProduct', 1)
insert into @productChangeTypes values ('AssetUpdate', 2)
insert into @productChangeTypes values ('MetadataUpdate', 4)
insert into @productChangeTypes values ('Takedown', 8)
insert into @productChangeTypes values ('PartialTakedown', 16)
insert into @productChangeTypes values ('Preorder', 32)
insert into @productChangeTypes values ('Embargo', 64)
insert into @productChangeTypes values ('PriceCampaign', 128)
insert into @productChangeTypes values ('IBookstoreBibliographicChange', 256)
insert into @productChangeTypes values ('ManualReviewRequired', 512)
insert into @productChangeTypes values ('ManualReviewApproved', 1024)
insert into @productChangeTypes values ('ManualReviewRejected', 2048)
insert into @productChangeTypes values ('Reactivation', 4096)
insert into @productChangeTypes values ('DrmFree', 8192)
insert into @productChangeTypes values ('DrmProtected', 16384)


select ct.Name as ProductChangeType, ct.Value, pr.Changetype, prs.ChangeType, * from product p
join productRevisions pr on pr.ProductUid = p.ProductUid
join DistributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join contracts c on c.contractUId = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
left join productRevisionStructures prs on prs.ProductRevisionUid = pr.ProductRevisionUid
cross join @productChangeTypes ct
where 
pr.ChangeType & ct.Value <> 0
and ordinal = '9781927559918' 
and r.code = 'kbo'
order by do.CreatedAtUtc