DECLARE @MetadataResourceContentType int = 100
DECLARE @CoverArtResourceContentType int = 1
DECLARE @EbookResourceContentType int = 28
DECLARE @OrganizationUidList table (organizationName nvarchar(max), organizationUid uniqueidentifier)
DECLARE @Incomplete int = 1
DECLARE @Created int = 2
DECLARE @Verified int = 3
DECLARE @WithErrors int = 4
DECLARE @Takedown int = 5
DECLARE @WorkInProgress int = 6
DECLARE @TitleTypeCode int = 1
DECLARE @PublishingDateRole int = 1
declare @organizationName nvarchar(100)
select @organizationname = 'scholastic inc.'
-- ***** populating @PublishersWithFileNameAssetType *****
DECLARE @OrganizationHierarchy table
(
	[Order] int identity,
	OrganizationUid uniqueidentifier
);

DECLARE @PublishersWithFileNameAssetType table
(
	[Order] int,
	InitialOrganizationUid uniqueidentifier,
	OrganizationUid uniqueidentifier,
	PublisherUid uniqueidentifier,
	[FileNameAssetTypeCount] int
);

DECLARE @OrganizationUid uniqueidentifier
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @OrganizationUidList (organizationName, organizationUid)
select * from org
union all
select * from child

DECLARE OrganizationCursor CURSOR 
  LOCAL STATIC READ_ONLY FORWARD_ONLY
FOR SELECT
	org.OrganizationUid
FROM Organizations org
WHERE org.OrganizationUid IN (select OrganizationUid from @OrganizationUidList)

-- ***** act
OPEN OrganizationCursor
FETCH NEXT FROM OrganizationCursor INTO @OrganizationUid
WHILE @@FETCH_STATUS = 0
BEGIN
DELETE FROM @OrganizationHierarchy

    ;
WITH children AS
(
SELECT
	ParentOrganizationUid,
	OrganizationUid
FROM Organizations
WHERE OrganizationUid = @OrganizationUid UNION ALL SELECT
	parentOrg.ParentOrganizationUid,
	childOrg.ParentOrganizationUid
FROM Organizations parentOrg
INNER JOIN children AS childOrg
	ON parentOrg.OrganizationUid = childOrg.ParentOrganizationUid)
INSERT INTO @OrganizationHierarchy
	SELECT
		OrganizationUid
	FROM children

-- add null item in order to reflect FileNameAssetTypes structure
INSERT INTO @OrganizationHierarchy
	VALUES (NULL)

--SELECT * FROM @OrganizationHierarchy

-- the code gets the first (in the organization hierarchy) publisher/organization which has FileNameAssetType
;
WITH GetFileNameAssetTypes
AS (SELECT
	pub.PublisherUid,
	org.*
FROM @OrganizationHierarchy org
LEFT JOIN Publishers pub
	ON pub.OrganizationUid = org.OrganizationUid
LEFT JOIN FolderProcessorContracts fpc
	ON (fpc.PublisherUid = pub.PublisherUid OR (fpc.PublisherUid IS NULL AND pub.PublisherUid IS NULL))
LEFT JOIN FileNameAssetTypes fnat
	ON fnat.FolderProcessorId = fpc.FolderProcessorId)
INSERT INTO @PublishersWithFileNameAssetType
-- the code calculates file names (as more less correct assumption) base on the first (in the organization hierarchy) publisher/organization which has FileNameAssetType
SELECT TOP 1 * FROM (
	SELECT
		fnat.[Order],
		@OrganizationUid as InitialOrganizationUid,
		fnat.OrganizationUid,
		fnat.PublisherUid,
		COUNT(*) - 1 AS FileNameAssetTypeCount
	FROM GetFileNameAssetTypes fnat
	GROUP BY	fnat.PublisherUid,
				fnat.OrganizationUid,
				fnat.[Order]) as pwfnat
				WHERE pwfnat.FileNameAssetTypeCount > 0
	ORDER BY pwfnat.[Order]

FETCH NEXT FROM OrganizationCursor INTO @OrganizationUid
END
CLOSE OrganizationCursor
DEALLOCATE OrganizationCursor
--SELECT * FROM @PublishersWithFileNameAssetType
-- ***** end of populating @PublishersWithFileNameAssetType *****

IF OBJECT_ID('tempdb..#ValidAssets') IS NOT NULL
    DROP TABLE #ValidAssets
SELECT
	p.ProductUid,
	CONVERT(nvarchar(256), p.Ordinal) AS Ordinal,
	av.AssetVersionUid,
	av.AssetState,
	ao.AssetOverrideUid,
	ao.RetailerUid,
	a.AssetUid,
	a.ResourceContentType,
	a.AssetType,
	pub.PublisherUid,
	p.OrganizationUid
INTO #ValidAssets
FROM AssetOverride ao
INNER JOIN Asset a
	ON ao.AssetUid = a.AssetUid
INNER JOIN AssetVersion av
	ON ao.AssetOverrideUid = av.AssetOverrideUid
INNER JOIN Product p
	ON a.ProductUid = p.ProductUid
INNER JOIN Publishers pub
	ON p.OrganizationUid = pub.OrganizationUid
INNER JOIN ProductForms pf on pf.AssetVersionUid = av.AssetVersionUid
WHERE av.ValidUntilUtc IS NULL
AND (p.OrganizationUid IN (select OrganizationUid from @OrganizationUidList)
AND pf.ProductFormTypeValue = 52
)
--select * from #ValidAssets order by ProductUid    

IF OBJECT_ID('tempdb..#AssetNames') IS NOT NULL
	DROP TABLE #AssetNames
SELECT DISTINCT
	va.ProductUid,
	va.ResourceContentType,
	COALESCE(fo.Path, (SELECT TOP 1
		CASE
			WHEN fnat.Retailer IS NULL 
			THEN va.Ordinal + COALESCE('_' + retailer.Code, '') + fnat.FileExtension
			ELSE va.Ordinal + fnat.FileExtension
		END
	FROM FileNameAssetTypes fnat
	INNER JOIN FolderProcessorContracts fpc
		ON fnat.FolderProcessorId = fpc.FolderProcessorId
	LEFT JOIN Retailers retailer
		ON retailer.RetailerUid = va.RetailerUid
	INNER JOIN @PublishersWithFileNameAssetType pwfnat
		ON (fpc.PublisherUid = pwfnat.PublisherUid OR (fpc.PublisherUid IS NULL AND pwfnat.PublisherUid IS NULL))
	WHERE pwfnat.InitialOrganizationUid = va.OrganizationUid
	AND fnat.AssetType = va.AssetType
	AND fnat.ResourceContentType = va.ResourceContentType
	AND (fnat.Retailer IS NULL OR fnat.Retailer = retailer.Code)
	--get reatailer specific at first
	ORDER BY fnat.Retailer DESC)
	) AS Path 
INTO #AssetNames
FROM #ValidAssets va
LEFT JOIN FolderObjectEBookProductProcessingResults fppr
	ON va.AssetVersionUid = fppr.AssetVersionUid
LEFT JOIN FolderObjects fo
	ON fppr.FolderObjectUid = fo.FolderObjectUid
--select * from #AssetNames order by path

IF OBJECT_ID('tempdb..#AssetNamesStuffed') IS NOT NULL
	DROP TABLE #AssetNamesStuffed
SELECT DISTINCT
    an.ProductUid,
    STUFF((
        SELECT ', ' + REPLACE(REPLACE(REPLACE(an2.[Path], CHAR(9), ''), CHAR(10), ''), CHAR(13), '')
        FROM #AssetNames an2
        WHERE 
            an.ResourceContentType = an2.ResourceContentType
            AND an.ProductUid = an2.ProductUid
        FOR XML PATH('')), 1, 2, '') path,
    an.ResourceContentType
INTO #AssetNamesStuffed
FROM
    #AssetNames an
--select * from #AssetNamesStuffed order by productuid
    	
IF OBJECT_ID('tempdb..#ProductTitle') IS NOT NULL
	DROP TABLE #ProductTitle	
SELECT DISTINCT
	va.ProductUid
	,coalesce(td.TitleStatement, te.TitleText + ' ' + ISNULL(te.Subtitle,'')) Title
INTO #ProductTitle
FROM
    #ValidAssets va
    INNER JOIN TitleDetails td ON va.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
WHERE
    (td.TitleTypeCode is NULL OR td.TitleTypeCode = @TitleTypeCode)
    AND (td.CollectionId is null)
    AND va.ResourceContentType = @MetadataResourceContentType
    AND((td.TitleStatement IS NOT NULL AND te.TitleText IS NULL) 
        OR(td.TitleStatement IS NULL AND te.TitleText IS NOT NULL)
        OR(td.TitleStatement IS NOT NULL OR te.TitleText IS NOT NULL))
	
IF OBJECT_ID('tempdb..#PublishingDate') IS NOT NULL
	DROP TABLE #PublishingDate	
SELECT DISTINCT
	va.ProductUid
	,PD.Value publishingDate
INTO #PublishingDate
FROM
	#ValidAssets va	
	INNER JOIN PublishingDates pd ON va.AssetVersionUid = pd.AssetVersionUid
WHERE
    va.ResourceContentType = @MetadataResourceContentType
    AND pd.PublishingDateRole =@PublishingDateRole
--select * from #PublishingDate

IF OBJECT_ID('tempdb..#SuccesfullyDeliveredAssets') IS NOT NULL
	DROP TABLE #SuccesfullyDeliveredAssets
SELECT DISTINCT
    va.ProductUid
    ,va.AssetVersionUid
    ,va.ResourceContentType
INTO #SuccesfullyDeliveredAssets
FROM
    #ValidAssets va
    INNER JOIN ProductRevisions pr ON va.ProductUid = pr.ProductUid
    INNER JOIN ProductRevisionStructures prs ON pr.ProductRevisionUid = prs.ProductRevisionUid
    INNER JOIN DistributionOrders do ON pr.ProductRevisionUid = do.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON do.DistributionOrderUid = dos.DistributionOrderUid
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    va.AssetVersionUid = prs.AssetVersionUid
    AND ret.Code='DITC'
--SELECT * FROM #SuccesfullyDeliveredAssets 

IF OBJECT_ID('tempdb..#DeliveredAssets') IS NOT NULL
	DROP TABLE #DeliveredAssets
SELECT DISTINCT
    va.ProductUid
    ,CASE 
        WHEN metadata.AssetVersionUid IS NULL THEN 'N'
        ELSE 'Y' END metadataDelivered
    ,CASE 
        WHEN coverart.AssetVersionUid IS NULL THEN 'N'
        ELSE 'Y' END coverartDelivered
    ,CASE 
        WHEN ebook.AssetVersionUid IS NULL THEN 'N'
        ELSE 'Y' END ebookDelivered
INTO #DeliveredAssets
FROM
    #ValidAssets va
    LEFT JOIN #SuccesfullyDeliveredAssets metadata ON va.ProductUid = metadata.ProductUid
    LEFT JOIN #SuccesfullyDeliveredAssets coverart ON va.ProductUid = coverart.ProductUid
    LEFT JOIN #SuccesfullyDeliveredAssets ebook ON va.ProductUid = ebook.ProductUid
WHERE
    (metadata.ResourceContentType=@MetadataResourceContentType OR metadata.ResourceContentType IS NULL)
    AND (coverart.ResourceContentType=@CoverArtResourceContentType OR coverart.ResourceContentType IS NULL)
    AND (ebook.ResourceContentType=@EbookResourceContentType OR ebook.ResourceContentType IS NULL)
--SELECT * FROM #DeliveredAssets order by ProductUid

SELECT DISTINCT
    va.Ordinal ISBN
    ,pt.Title
    ,pd.publishingDate
    ,metadata.path metadataIngested
    ,da.metadataDelivered
    ,coverart.path coverartIngested
    ,da.coverartDelivered
    ,ebook.path ebookIngested
    ,da.ebookDelivered
FROM
    #ValidAssets va
    LEFT JOIN #ProductTitle pt   ON va.ProductUid = pt.ProductUid
    LEFT JOIN #AssetNamesStuffed metadata ON va.ProductUid = metadata.ProductUid AND metadata.ResourceContentType=@MetadataResourceContentType
	LEFT JOIN #AssetNamesStuffed coverart ON va.ProductUid = coverart.ProductUid AND coverart.ResourceContentType=@CoverArtResourceContentType
	LEFT JOIN #AssetNamesStuffed ebook    ON va.ProductUid = ebook.ProductUid AND ebook.ResourceContentType = @EbookResourceContentType
	LEFT JOIN #PublishingDate pd ON va.ProductUid = pd.ProductUid --This is a left join because they might have forgotten to upload metadata
	LEFT JOIN #DeliveredAssets da ON va.ProductUid = da.ProductUid