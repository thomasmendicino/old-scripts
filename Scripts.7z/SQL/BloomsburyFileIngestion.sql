use athenaAssetProcessor;
select distinct
case
	when fo.PathLevel = 2 then left(right(fo.Path, 38),13)
	else left(right(fo.Path, 18),13) 
end as ISBN,
case 
	when fo.PathLevel = 2 then replace(substring(fo.Path, charindex('\',fo.path) +1,len(fo.Path) - charindex('\',fo.Path)),'_xml','.xml')--	right(fo.Path, 38)
	else right(fo.Path, 18)
end as FolderObjectPath,
'ECHO F | xcopy \\instor05\inscribe-master--1\Uploads\BloomsburyPublishing\Migration\' + fo.Path + ' \\instor05\inscribe-master--1\Uploads\BloomsburyPublishing\MigrationTemp\NeedsReadOnlyRepair\' + right(fo.Path, 18) as script,
case 
	when charindex('denied',fpr.ResultingMessage) > 0 then substring(fpr.ResultingMessage,0,charindex('denied',fpr.ResultingMessage) + 7)
	when charindex('XML',fpr.ResultingMessage) > 0 then substring(fpr.ResultingMessage,0,charindex('XML',fpr.ResultingMessage) + 21)
	else fpr.ResultingMessage
end as IngestionFailureReason,
pd.PublishingDateRole, pd.Value
 from folderObjects fo
join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
join FolderObjectEBookProductProcessingResults fpr on fpr.FolderObjectUid = fo.FolderObjectUid
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
join AthenaProductCatalog..product p on cast(p.ordinal as varchar(13)) = left(right(fo.Path, 18),13) 
join AthenaProductCatalog..Asset a on a.ProductUid = p.ProductUid
join AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
join AthenaProductCatalog..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join AthenaProductCatalog..PublishingDates pd on pd.AssetVersionUid = av.AssetVersionUid
where ic.name like '%bloomsbury%'
and fpr.ResultingEventLevel > 1
and av.ValidUntilUtc is null
and right(fo.Path,18) not in 
(select 
--case
--	when fo.PathLevel = 2 then right(fo.Path, 38)
--	else 
	right(fo.Path, 18)
--end 
from folderObjects fo
join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
join FolderObjectEBookProductProcessingResults fpr on fpr.FolderObjectUid = fo.FolderObjectUid
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
where ic.name like '%bloomsbury%'
and fos.Status = 3
--and fo.path like '%xml%'
INTERSECT
select --fo.Path, fo.folderObjectUid,
--case
--	when fo.PathLevel = 2 then right(fo.Path, 38)
--	else 
	distinct right(fo.Path, 18)
--end 
 from folderObjects fo
join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
join FolderObjectEBookProductProcessingResults fpr on fpr.FolderObjectUid = fo.FolderObjectUid
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
join AthenaProductCatalog..product p on p.productUid = fpr.productUid
where ic.name like '%bloomsbury%'
and fos.Status = 2)
order by pd.Value


--18 - access to the path
--82 - BISAC failures
--434 - XML 1.1 failures
--42948 total files (.epub, .jpg, .mobi, .onix)
--all: 311670
--level 1: 309822
--level > 1: 1848

--level = 1 103890

select *  from folderObjects fo
join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
join FolderObjectEBookProductProcessingResults fpr on fpr.FolderObjectUid = fo.FolderObjectUid
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
where ic.name like '%bloomsbury%'
--and fo.Path like '%Bloomsbury20150717-17_xml%'
and fo.Path like '%9781448203314%'



(select right(fo.Path, 18) from folderObjects fo
join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
join FolderObjectEBookProductProcessingResults fpr on fpr.FolderObjectUid = fo.FolderObjectUid
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
where ic.name like '%bloomsbury%'
and fos.Status = 3
--and fo.path like '%xml%'
INTERSECT
select --fo.Path, fo.folderObjectUid,
right(fo.Path, 18)
 from folderObjects fo
join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
join FolderObjectEBookProductProcessingResults fpr on fpr.FolderObjectUid = fo.FolderObjectUid
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
join AthenaProductCatalog..product p on p.productUid = fpr.productUid
where ic.name like '%bloomsbury%'
and fos.Status = 2)
--and fo.path like '%xml%'


use AthenaDistribution;
select count(*) from DistributionOrderStatus
where DistributionOrderStatusId > 10675044
and ResultingMessage like '%Seed history from spreadsheet:%'
--order by DistributionOrderStatusId desc


use AthenaProductCatalog;
select o.OrganizationName, ordinal from product p
join AthenaSecurity..Organizations o on o.OrganizationUid = p.OrganizationUid
where ordinal = 9781943848706






select distinct right(fo.Path, 18)
from folderObjects fo
join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
join FolderObjectEBookProductProcessingResults fpr on fpr.FolderObjectUid = fo.FolderObjectUid
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
where ic.name like '%bloomsbury%'
and fos.Status = 2
and fo.path like '%jpg%'




select distinct 
left(right(fo.Path, 38),13)
from folderObjects fo
join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
join FolderObjectEBookProductProcessingResults fpr on fpr.FolderObjectUid = fo.FolderObjectUid
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
where ic.name like '%bloomsbury%'
and fos.Status = 3
and not exists (select 1 from FolderObjects fo2 join folderoBJectStatus fos2 on fos2.folderOBjectUId = fo2.FolderObjectUid where left(right(fo2.Path, 38),13) = left(right(fo.Path, 38),13) and fos2.Status = 2)
and fo.path like '%onix%'


select * from AthenaDistribution..TransferServiceItmsEndpoints

select * from AthenaDistribution..TransferServiceEmailEndpoints

