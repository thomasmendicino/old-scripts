/*select min(fo.CreatedAtUtc) from folderobjects fo --order by fo.CreatedAtUtc desc
join FolderObjectEBookProductProcessingResults fpp on fpp.FolderObjectUid = fo.FolderObjectUid
where path like '%DemoPublisher_xlsx%'


select count(distinct fo.FolderObjectUid) from folderobjects fo
join FolderObjectEBookProductProcessingResults fpp on fpp.FolderObjectUid = fo.FolderObjectUid
where path like '%scholastic%'
and fo.IsFile = 1
and fo.PathLevel = 1

select * from folderObjects fo
join folderOBjectStatus fos on fos.folderOBjectUid = fo.folderObjectUid
where path like '%demopublisher%' 
order by fos.CreatedATUtC

select * from folderObjects fo
join FolderObjectEBookProductProcessingResults fos on fos.folderOBjectUid = fo.folderObjectUid
where path like '%demopublisher%' 
order by fos.CreatedATUtC
*/


declare @UploadName nvarchar(100)
declare @ParentFolderObject uniqueidentifier
declare @UploadStartTime datetime
declare @IngestionStartTime datetime
declare @IngestionEndTime datetime
declare @HalfwayIngestionTime datetime
declare @IngestionProcessingStartTime datetime
declare @IngestionProcessingEndTime datetime
declare @HalfwayIngestionProcessingTime datetime
declare @Err_message nvarchar(150)
declare @GeneratedFolderObjectIngestion table (FolderObject uniqueidentifier, ID int, Status smallint)
declare @GeneratedFolderObjectProcessing table (FolderObject uniqueidentifier, ID int)


set @UploadName = 'DemoPublisher.xls'
set @UploadName = replace(@UploadName, '.xls','_xls')

IF (select count(distinct fo.folderobjectUid) from folderobjects fo
join FolderObjectEBookProductProcessingResults fpp on fpp.FolderObjectUid = fo.FolderObjectUid
where path like '%' + @UploadName + '%'
and fo.IsFile = 1
and fo.PathLevel = 1) > 1
BEGIN 
SET @Err_message = 'More than one upload found matching "' + @UploadName + '"'
RAISERROR (@Err_message,11,1)
END
ELSE 
BEGIN
select distinct @ParentFolderObject = fo.folderobjectUid from folderobjects fo
join FolderObjectEBookProductProcessingResults fpp on fpp.FolderObjectUid = fo.FolderObjectUid
where path like '%' + @UploadName + '%'
and fo.IsFile = 1
and fo.PathLevel = 1

insert @GeneratedFolderObjectIngestion (folderObject, ID, Status)
select distinct fo.FolderObjectUid,
ROW_NUMBER() OVER (ORDER BY fos.CreatedAtUtc)
, fos.Status from FolderObjects fo
join FolderObjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
where fo.Path like '%' + @UploadName + '%'
and fo.IsFile = 1
and fo.PathLevel = 2
and fos.Status <> 2

select top 1 @IngestionEndTime = fos.CreatedAtUtc from FolderObjectStatus fos
join @GeneratedFolderObjectIngestion gfi on gfi.FolderObject = fos.FolderObjectUid
order by fos.CreatedAtUtc desc

select top 1 @IngestionStartTime = fos.CreatedAtUtc from FolderObjectStatus fos
join @GeneratedFolderObjectIngestion gfi on gfi.FolderObject = fos.FolderObjectUid
order by fos.CreatedAtUtc asc

select @HalfwayIngestionTime = fos.CreatedAtUtc from FolderObjectStatus fos
join @GeneratedFolderObjectIngestion gfi on gfi.FolderObject = fos.FolderObjectUid and gfi.ID = (select max(ID) / 2 from @GeneratedFolderObjectIngestion)

insert @GeneratedFolderObjectProcessing (folderObject, ID)
select distinct fo.FolderObjectUid,
ROW_NUMBER() OVER (ORDER BY fpp.CreatedAtUtc) from FolderObjects fo
join FolderObjectEBookProductProcessingResults fpp on fpp.FolderObjectUid = fo.FolderObjectUid
where fo.Path like '%' + @UploadName + '%'
and fo.IsFile = 1
and fo.PathLevel = 2
and fpp.ResultingEvent = 17

select top 1 @IngestionProcessingEndTime = ppr.CreatedAtUtc from FolderObjectEBookProductProcessingResults ppr
join @GeneratedFolderObjectProcessing gfp on gfp.FolderObject = ppr.FolderObjectUid
order by ppr.CreatedAtUtc desc

select top 1 @IngestionProcessingStartTime = ppr.CreatedAtUtc from FolderObjectEBookProductProcessingResults ppr
join @GeneratedFolderObjectProcessing gfp on gfp.FolderObject = ppr.FolderObjectUid
order by ppr.CreatedAtUtc asc

select @HalfwayIngestionProcessingTime = ppr.CreatedAtUtc from FolderObjectEBookProductProcessingResults ppr
join @GeneratedFolderObjectProcessing gfp on gfp.FolderObject = ppr.FolderObjectUid and gfp.ID = (select max(ID) / 2 from @GeneratedFolderObjectProcessing)

--select * from folderObjects fo
--join @GeneratedFolderObjectProcessing gfp on gfp.FolderObject = fo.FolderObjectUid
--order by gfp.Id

select @UploadStartTime = CreatedAtUtc from folderObjects where FolderObjectUid = @ParentFolderObject
select @UploadName as UploadName
select @ParentFolderObject as ParentFolderObjectUid
select @UploadStartTime as UploadStartTime
select @IngestionStartTime as IngestionStartTime
select @HalfwayIngestionTime as HalfwayIngestionTime
select @IngestionEndTime as IngestionEndTime
select @IngestionProcessingStartTime as IngestionProcessingStartTime
select @HalfwayIngestionProcessingTime as HalfwayIngestionProcessingTime
select @IngestionProcessingEndTime as IngestionProcessingEndTime
select * from @GeneratedFolderObjectProcessing order by ID
select * from @GeneratedFolderObjectIngestion order by ID
END

--select * from FolderObjects where FolderObjectUid= 'E4ADC662-DEBE-4E86-9E27-9D989FCCA9D5'

/*
select * from FolderObjectEBookProductProcessingResults
where folderobjectuid in (
'CCDDB239-61BF-4809-9335-6B14B7A3D028',
'A9E9B79A-FDC8-4249-90F5-06F4CBF01079',
'449A0230-4EB1-4B82-B474-CD54264C5A19',
'72007022-9706-4240-BB9F-0B7207302DCD'
)
order by createdAtUTc
select distinct ResultingEvent from FolderObjectEBookProductProcessingResults where ResultingEventLevel = 1
*/

--select * from folderobjectstatus where folderobjectuid = 'CCDDB239-61BF-4809-9335-6B14B7A3D028'
select * from folderobjectstatus where folderobjectuid = 'B2411540-881F-476C-B0BD-28A28E29DFC0'
select * from FolderObjectEBookProductProcessingResults where folderobjectuid = 'B2411540-881F-476C-B0BD-28A28E29DFC0'
--select * from FolderObjectEBookProductProcessingResults where folderobjectuid = 'CCDDB239-61BF-4809-9335-6B14B7A3D028'

