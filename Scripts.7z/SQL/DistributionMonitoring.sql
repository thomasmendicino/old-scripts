
select cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) as [Date (MM-DD)], count(*) as NumberOfBatchesCreated from BatchStatus 
where ResultingEvent = 87--116
and CreatedAtUtc > '2015-03-16'
group by cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2))
order by cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2))

select cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) as [Date (MM-DD)], count(*) as NumberOfBatchesCompleted from BatchStatus 
where ResultingEvent = 90
and CreatedAtUtc > '2015-03-16'
and ResultingMessage <> 'Batch delivered through Product History Ingestion'
group by cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2))
order by cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2))

--http://grab.by/FQNK

select cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) as [Date (MM-DD)], count(*) as NumberOfOrdersCreated from DistributionOrderStatus 
where ResultingEvent = 103
and CreatedAtUtc > '2015-03-16'
and distributionOrderUid not in (select distributionOrderUid from DistributionOrderStatus where ResultingEventLevel > 3)
group by cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2))
order by cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2))


select cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) as [Date (MM-DD)], count(*) as NumberOfOrdersCompleted from DistributionOrderStatus 
where ResultingEvent = 110
and CreatedAtUtc > '2015-03-16'
and ResultingMessage like 'Finished transfer for Batch%'
group by cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2))
order by cast(datepart(mm,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2)) + '-' + cast(datepart(dd,dateadd(hh,datediff(hh,getutcdate(),getdate()),CreatedAtUtc)) as char(2))
