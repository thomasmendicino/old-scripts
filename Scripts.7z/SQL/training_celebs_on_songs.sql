SELECT     Track.Song, Track.Disc, Track.Track, SongCelebrity.Celebrity, Celebrity.Name as CelebrityName, Song.Name, Album.GTIN, Song.ISRC
FROM         Track INNER JOIN
                      Album ON Track.Album = Album.ID INNER JOIN
                      SongCelebrity INNER JOIN
                      Song ON SongCelebrity.Song = Song.ID ON Track.Song = Song.ID INNER JOIN
                      Celebrity ON Celebrity.ID = SongCelebrity.Celebrity
WHERE		Album.GTIN='698349318520'
ORDER BY Disc ASC, Track ASC, Song ASC

select * from TrackSyndication
select * from Syndication
