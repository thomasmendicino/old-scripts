/*use ingroovesAudit
go
select * from transfer where orderbatchid = 1000001052068
*/

select * from feed 
1000001052069
1000001059157
select * from albumsyndicationview where album = (select ID from album where gtin = '00850717002732')

select * from syndicationorder so 
join syndication s on so.syndication = s.id
where s.syndicationlevel = 9823
and s.musicservice = 7
union all
select * from syndicationorder so 
join syndication s on so.syndication = s.id
where s.syndicationlevel = 2229
and s.musicservice = 655
union all
select * from syndicationorder so 
join syndication s on so.syndication = s.id
where s.syndicationlevel = 2225
and s.musicservice = 655
union all
select * from syndicationorder so 
join syndication s on so.syndication = s.id
where s.syndicationlevel = 2314
and s.musicservice = 655

select * from syndicationordereventlog where syndicationorder = 121601

select * from changerequestimportlogbatch
select top 50 * from importlogentry where 
select top 50 * from importlog where sourcedata like '%1000000890245%' or sourcedata like '%1000001052068%'	or sourcedata like '%1000001052067%'

select * from importorder where orderID in ('1000000890245','1000001052068','1000001052067')

select * from pendingimport where orderID in ('1000000890245','1000001052068','1000001052067')

select * from tracksyndication where syndication = (select ID from syndication where musicservice = 7 and syndicationlevel = 9823)
select * from track where id in (select track from tracksyndication where syndication = (select ID from syndication where musicservice = 7 and syndicationlevel = 9823))
select * from song where id in (select song from track where id in (select track from tracksyndication where syndication = (select ID from syndication where musicservice = 7 and syndicationlevel = 9823)))
select * from album where id in (select album from track where id in (select track from tracksyndication where syndication = (select ID from syndication where musicservice = 7 and syndicationlevel = 9823)))

select * from changerequest cr
join album a on a.id = cr.album
join changerequestbatch crb on cr.changerequestbatch = crb.id
join changerequestimportlogbatch crilb on crilb.changerequestbatch = crb.id
join importlog il on il.id = crilb.importlog
left join importlogentry ile on ile.importlog = il.id
where a.gtin = '00850717002732'

select top 5000 *, a.gtin, csc.country from album a
join countryset cs on a.countryset = cs.id
join countrysetcountry csc on csc.countryset = cs.id
join albumproducttype apt on apt.album = a.id
where cs.id in (3,4,6,7,8,9)
and apt.producttype = 3
