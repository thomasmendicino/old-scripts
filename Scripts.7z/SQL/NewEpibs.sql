USE AthenaComposite

declare @CATime datetime
declare @UTCTime datetime

set @CATime = getdate()
set @UTCTime = getutcdate()

;WITH SingleMainTitle AS (
	SELECT DISTINCT
		p.Ordinal
		, replace(COALESCE(te.TitleText, te.TitlePrefix + ' ' + te.TitleWithoutPrefix),'"','''''') as Title
		, ROW_NUMBER() OVER (PARTITION BY p.Ordinal ORDER BY isnull(te.TitleText,'z') DESC, te.TitleWithoutPrefix ASC) RowNum
	FROM
		Product p
	INNER JOIN Asset a
		ON a.ProductUid = p.ProductUid
	INNER JOIN AssetOverride ao 
		ON ao.AssetUid = a.AssetUid
	INNER JOIN AssetVersion av
		ON av.AssetOverrideUid = ao.AssetOverrideUid
	INNER JOIN TitleDetails td
		on td.AssetVersionUid = av.AssetVersionUid
	INNER JOIN TitleElements te
		ON te.TitleDetailId = td.TitleDetailId
	WHERE av.ValidUntilUtc is NULL)

SELECT
	CASE
		WHEN po.OrganizationName = 'Inscribe Digital' then ''
		ELSE po.OrganizationName
	END AS Publisher
	, o.OrganizationName Imprint
	, p.Ordinal as ISBN
	, ISNULL(s.Title, 'Title unavailable - Incomplete onix record') as Title
	, rat.AssetTypeText AS EpibType
	, CASE
		WHEN a.ResourceContentType = 28 THEN 'Full Content'
		WHEN a.ResourceContentType = 15 THEN 'Sample Content'
		ELSE 'Full Content' 
		END AS ContentType
	, DATEADD(HH,(DATEDIFF(HH,@UTCTime,@CATime)),ValidFromUtc) AS ImportedAt
FROM
	Product p
	INNER JOIN Asset a
		ON a.ProductUid = p.ProductUid
	INNER JOIN AssetOverride ao 
		ON ao.AssetUid = a.AssetUid
	INNER JOIN AssetVersion av
		ON av.AssetOverrideUid = ao.AssetOverrideUid
	LEFT OUTER JOIN SingleMainTitle s
		ON s.Ordinal = p.Ordinal
	INNER JOIN refAssetType rat
		ON rat.AssetTypeId = a.AssetType
	INNER JOIN Organizations o
		ON o.OrganizationUid = p.OrganizationUid
	INNER JOIN Organizations po 
		ON po.OrganizationUid = o.ParentOrganizationUid
WHERE ISNULL(s.RowNum,1) = 1
	AND rat.AssetTypeCode in ('EPUBEPIBK2','EPUBEPIBK3')
	AND av.ValidUntilUtc IS NULL
	AND av.ValidFromUtc > GETUTCDATE()-100
	ORDER BY ISBN, ContentType