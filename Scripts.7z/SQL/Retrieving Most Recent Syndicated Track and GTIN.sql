USE [INgrooves]

Select distinct top(2) Album.GTIN, Syndication.SyndicatedAt from Track
Inner Join Album ON Track.Album = Album.ID
Inner Join TrackSyndication ON Track.ID = TrackSyndication.Track
Inner Join Syndication ON Syndication.ID = TrackSyndication.Syndication
Order By SyndicatedAt DESC