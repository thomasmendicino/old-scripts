;with ParentPublishers as (
select OrganizationName from AthenaComposite..Organizations
where ParentOrganizationUid = '00000000-0000-0000-0000-000000000001'),
DigitalProductCount as (
select distinct p.Ordinal from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
inner join AthenaComposite..ProductForms pf on pf.AssetVersionUid = av.AssetVersionUid
where av.ValidUntilUtc is NULL
and pf.ProductFormTypeValue in (49,50,51,52)),
PhysicalProductCount as (
select distinct p.Ordinal from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
inner join AthenaComposite..ProductForms pf on pf.AssetVersionUid = av.AssetVersionUid
where av.ValidUntilUtc is NULL
and pf.ProductFormTypeValue not in (49,50,51,52)),
Totals as (
select (select count(*) from ParentPublishers) PublisherCount, 
(select count(*) from DigitalProductCount) DigitalProductCount, 
(select count(*) from PhysicalProductCount) PhysicalProductCount)
select PublisherCount, DigitalProductCount, PhysicalProductCount, DigitalProductCount + PhysicalProductCount as TotalProductCount from Totals


;with ActiveCoverFiles as (
select distinct a.AssetUid from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NULL
AND a.ResourceContentType in (1,29)),
ActiveContentFiles as (
select distinct a.AssetUid from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NULL
AND a.ResourceContentType in (28)),
ActiveMetadataFiles as (
select distinct a.AssetUid from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NULL
AND a.ResourceContentType in (100,101,104)),
ActiveSampleFiles as (
select distinct a.AssetUid from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NULL
AND a.ResourceContentType in (15,27)),
FileStorage as (
select sum(r.Length) SizeInBytes from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
inner join AthenaComposite..Resources r on r.ResourceUid = av.ResourceUid
where av.ValidUntilUtc is NULL
),
Totals as (
	select (select count(*) from ActiveCoverFiles) ActiveCoverFiles,
	(select count(*) from ActiveContentFiles) ActiveContentFiles,
	(select count(*) from ActiveMetadataFiles) ActiveMetadataFiles,
	(select count(*) from ActiveSampleFiles) ActiveSampleFiles,
	(select SizeInBytes from FileStorage) SizeInBytes)
SELECT ActiveCoverFiles, ActiveContentFiles, ActiveMetadataFiles, ActiveSampleFiles, ActiveCoverFiles + ActiveContentFiles + ActiveMetadataFiles + ActiveSampleFiles TotalActiveFiles,
case 
when len(SizeInBytes) between 4 and 6 then cast(cast(SizeInBytes / 1024.00 as decimal(18,2)) as nvarchar(max)) + ' KB'
when len(SizeInBytes) between 7 and 9 then cast(cast(SizeInBytes / (1024.00 * 1024) as decimal(18,2)) as nvarchar(max)) + ' MB'
when len(SizeInBytes) between 10 and 12 then cast(cast(SizeInBytes / (1024.00 * 1024 * 1024) as decimal(18,2)) as nvarchar(max)) + ' GB'
when len(SizeInBytes) between 13 and 15 then cast(cast(SizeInBytes / (1024.00 * 1024 * 1024 * 1024) as decimal(18,2)) as nvarchar(max)) + ' TB'
end as ActiveFileSize
from Totals

;with InactiveCoverFiles as (
select distinct a.AssetUid from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NOT NULL
AND a.ResourceContentType in (1,29)),
InactiveContentFiles as (
select distinct a.AssetUid from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NOT NULL
AND a.ResourceContentType in (28)),
InactiveMetadataFiles as (
select distinct a.AssetUid from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NOT NULL
AND a.ResourceContentType in (100,101,104)),
InactiveSampleFiles as (
select distinct a.AssetUid from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NOT NULL
AND a.ResourceContentType in (15,27)),
FileStorage as (
select sum(r.Length) SizeInBytes from AthenaComposite..Product p
inner join AthenaComposite..asset a on a.productUid = p.ProductUid
inner join AthenaComposite..AssetOverride ao on ao.AssetUid = a.AssetUid
inner join AthenaComposite..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
inner join AthenaComposite..Resources r on r.ResourceUid = av.ResourceUid
where av.ValidUntilUtc is NOT NULL
),
Totals as (
	select (select count(*) from InactiveCoverFiles) InactiveCoverFiles,
	(select count(*) from InactiveContentFiles) InactiveContentFiles,
	(select count(*) from InactiveMetadataFiles) InactiveMetadataFiles,
	(select count(*) from InactiveSampleFiles) InactiveSampleFiles,
	(select SizeInBytes from FileStorage) SizeInBytes)
SELECT InactiveCoverFiles, InactiveContentFiles, InactiveMetadataFiles, InactiveSampleFiles, InactiveCoverFiles + InactiveContentFiles + InactiveMetadataFiles + InactiveSampleFiles TotalInactiveFiles,
case 
when len(SizeInBytes) between 4 and 6 then cast(cast(SizeInBytes / 1024.00 as decimal(18,2)) as nvarchar(max)) + ' KB'
when len(SizeInBytes) between 7 and 9 then cast(cast(SizeInBytes / (1024.00 * 1024) as decimal(18,2)) as nvarchar(max)) + ' MB'
when len(SizeInBytes) between 10 and 12 then cast(cast(SizeInBytes / (1024.00 * 1024 * 1024) as decimal(18,2)) as nvarchar(max)) + ' GB'
when len(SizeInBytes) between 13 and 15 then cast(cast(SizeInBytes / (1024.00 * 1024 * 1024 * 1024) as decimal(18,2)) as nvarchar(max)) + ' TB'
end as InactiveFileSize
from Totals

