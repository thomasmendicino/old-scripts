
USE AthenaComposite

;with EpubCheckSuccess AS (
select assetVersionUid 
from AssetVersionValidationResults
where ValidationEvent = 11
),
Numbers AS 
	(select 
		at.AssetTypeCode
		, p.Ordinal as ISBN
		, r.Path
		, ROW_NUMBER() OVER (PARTITION BY at.AssetTypeCode ORDER BY datepart(YEAR, av.validFromUtc) DESC, datepart(MONTH, av.validFromUtc) DESC, r.Length ASC) RowNum
		, r.Length
	from 
		product p
		join asset a on a.ProductUid = p.ProductUid
		join AssetOverride ao on ao.AssetUid = a.AssetUid
		join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		join Resources r on r.ResourceUid = av.ResourceUid
		join refAssetType at on at.AssetTypeId = a.AssetType
		join EpubCheckSuccess es on es.AssetVersionUid = av.AssetVersionUid
	where
		av.ValidUntilUtc is NULL
		and r.Length > 2 --(arbitrary, just making sure it's larger than 0)
		--and av.validfromutc > getdate()-100
		)
select 
	'ECHO F | XCOPY \\instor05\inscribe-master--1\ResourceStorage\' + Path + ' D:\temp\EpubCheckSuccess\' + AssetTypeCode + '\' + cast(ISBN as char(13)) + '_' + AssetTypeCode + '_FullContent_0.epub'
	,AssetTypeCode
	, ISBN
	, Path as PathOnResourceStorage
	, RowNum as MaxSizeRank
	, case 
		when len(Length) > 3 then cast(cast(Length / (1024.00 * 1024) as decimal(18,2)) as nvarchar(max)) + ' MB'
		else cast(cast(Length as decimal(18,2)) as nvarchar(max)) + ' B'
	end as FileSize 
from Numbers
where RowNum < 11
order by 
	AssetTypeCode
	, RowNum ASC