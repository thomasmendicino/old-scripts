use AthenaComposite;

/*

use ReportServer
select sc.Name [Subscription], c.Name [Report]--, substring(ExtensionSettings, (patindex('%<Value>%', ExtensionSettings) + len('<Value>')), (patindex('%</Value>%', ExtensionSettings) - patindex('%<Value>%', ExtensionSettings) - len('<Value>'))) EmailList 
,substring(cast(DataSettings as nvarchar(max)),(charindex('<CommandText>',cast(DataSettings as nvarchar(max))) + 13),(charindex('</CommandText>',cast(DataSettings as nvarchar(max))) - charindex('<CommandText>',cast(DataSettings as nvarchar(max))) - 13)) Query
,s.Description from Subscriptions s
join reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join Schedule sc on sc.scheduleId = rs.ScheduleId
join Catalog c on c.ItemId = s.Report_OID

*/

if object_ID ('tempdb..#ReportResultsFS') is not null
drop table #ReportResultsFS
GO
if object_ID ('tempdb..#ErrFile') is not null
drop table #ErrFile
GO
if object_ID ('tempdb..#Subs') is not null
drop table #Subs
GO
if object_ID ('tempdb..#SubsCursorTest') is not null
drop table #SubsCursorTest
GO

--declare @DeliveryExtension nvarchar(50) = 'Report Server FileShare'
--declare @Schedule nvarchar(100) = 'Scholastic Daily Reports'
--declare @Report nvarchar(100) = 'Failed Ingestion Email'

--declare @subscursor table (DelivExt nvarchar(100), Schedule nvarchar(100), Report nvarchar(200))
declare @subscursor1 nvarchar(100)
declare @subscursor2 nvarchar(100)
declare @subscursor3 nvarchar(100)
declare @subscursor4 nvarchar(100)

create table #subscursorTest (DelivExt nvarchar(100), Schedule nvarchar(100), Report nvarchar(200), Description nvarchar(500))
create table #ReportResultsFS (SubscriptionUid uniqueidentifier, Organization uniqueidentifier, PublisherUid uniqueidentifier, Path nvarchar(1000), Filename nvarchar(200), RenderFormat nvarchar(20), WriteMode nvarchar(50), DateRangeStart datetime, DateRangeEnd datetime)
CREATE TABLE #ErrFile (ExecError INT)
create table #subs (DeliveryExtension nvarchar(50), Schedule nvarchar(100), Report nvarchar(200), Description nvarchar(500))

INSERT #Subs (DeliveryExtension, Schedule, Report, Description)
select DeliveryExtension, sc.Name, c.Name, s.Description from ReportServer..Subscriptions s
join ReportServer..reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join ReportServer..Schedule sc on sc.scheduleId = rs.ScheduleId
join ReportServer..Catalog c on c.ItemId = s.Report_OID
/*  */ where DeliveryExtension = 'Report Server FileShare'

declare @cmd nvarchar(max), @ExecError INT
declare @queryToRun table (SubscriptionId uniqueidentifier, Query nvarchar(max))


declare EmailSubCursor cursor local for
select DeliveryExtension, Schedule, Report, Description
from #Subs

open EmailSubCursor
fetch next from EmailSubCursor into @subscursor1, @subscursor2, @subscursor3, @subscursor4

while @@fetch_status=0
begin
--now I am iterating through these variables, so time to do what I want with them.

insert #subscursorTest (DelivExt, Schedule, Report, Description)
select @subscursor1, @subscursor2, @subscursor3, @subscursor4


insert @queryToRun (SubscriptionID, Query)
select s.SubscriptionId, substring(cast(DataSettings as nvarchar(max)),(charindex('<CommandText>',cast(DataSettings as nvarchar(max))) + 13),(charindex('</CommandText>',cast(DataSettings as nvarchar(max))) - charindex('<CommandText>',cast(DataSettings as nvarchar(max))) - 13)) Query
 from ReportServer..Subscriptions s
 join ReportServer..reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join ReportServer..Schedule sc on sc.scheduleId = rs.ScheduleId
join ReportServer..Catalog c on c.ItemId = s.Report_OID
 where DeliveryExtension = @subscursor1
 and sc.Name = @subscursor2
 and c.Name = @subscursor3
 and s.Description = @subscursor4
select top 1 @cmd = Query from @queryToRun
--print @cmd
--IF @cmd like '%as  _Filename_,%'
--BEGIN
insert #ReportResultsFS (Organization, PublisherUid, Path, Filename, RenderFormat, WriteMode, DateRangeStart, DateRangeEnd )
exec (@cmd)
set @ExecError = (SELECT * FROM #ErrFile)
--END
--else
--BEGIN
--insert #ReportResultsFS ([To], ReplyTo, IncludeReport, IncludeLink, RenderFormat, Subject, Priority, Organization, PublisherUid, DateRangeStart, DateRangeEnd)
--exec (@cmd)
--set @ExecError = (SELECT * FROM #ErrFile)
--END

update #ReportResultsFS set SubscriptionUid = SubscriptionId from @queryToRun where SubscriptionUid is NULL

delete from @queryToRun
fetch next from EmailSubCursor into @subscursor1, @subscursor2, @subscursor3, @subscursor4
end

close EmailSubCursor
deallocate EmailSubCursor
--select * from #subscursorTest
select p.Name Publisher, po.OrganizationName Parent, c.Name Report, sc.Name Schedule, fs.Path + '/' + fs.Filename as FilePath, fs.RenderFormat, fs.DateRangeStart, fs.DateRangeEnd, s.Description, s.LastRunTime, s.LastStatus from #ReportResultsFS fs
join ReportServer..Subscriptions s on s.subscriptionId = fs.SubscriptionUid
join ReportServer..reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join ReportServer..Schedule sc on sc.scheduleId = rs.ScheduleId
join ReportServer..Catalog c on c.ItemId = s.Report_OID
join AthenaComposite..publishers p on p.publisherUid = fs.PublisherUid
join AthenaComposite..organizations o on o.organizationUid = p.OrganizationUid
left join AthenaComposite..organizations po on po.OrganizationUid = o.ParentOrganizationUid
ORDER by p.Name, fs.RenderFormat
--select * from #subscursorTest
--select * from #subs