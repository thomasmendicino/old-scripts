select --a.id, cr.*, crd.* 
distinct a.gtin, o.id, o.name,il.sourcedata, max(cr.processedat) [maxcr]
--distinct il.sourcedata
from album a
inner join changerequest cr on cr.album = a.id
inner join organization o on o.id = a.organization
left join changerequestdetail crd on crd.changerequest = cr.id
inner join changerequestimportlogbatch crilb on crilb.changerequestbatch = cr.changerequestbatch
inner join importlog il on il.id = crilb.importlog
where --cr.processedat > '2011-10-28' and 
a.organization = 26087 --and
--crd.[column] not in ('Sequence','Album','Country','Operator')
and a.gtin in
('00044003151727',
'00044003153837',
'00850717002442',
'00850717002732',
'00044003150621',
'00044003150676',
'00850717002657',
'00044003153264',
'00850717001834',
'00823674473730',
'00823674723927',
'00619061407729',
'00619061241910',
'00619061409020',
'00891954001966',
'00891954001362',
'00891954001188',
'00891954001102',
'00891954001171',
'00891954001201',
'00044003713659',
'00044003713673')
group by a.gtin, o.id, o.name, il.sourcedata
order by il.sourcedata


