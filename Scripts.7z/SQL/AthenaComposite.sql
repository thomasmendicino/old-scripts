-- **********************************************************************
-- Index IX_Asset_ProductUid on table Asset
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_Asset_ProductUid' -- Index Name
             AND so.[Name] = N'Asset')  -- Table Name
CREATE INDEX [IX_Asset_ProductUid] ON [dbo].[Asset]
(
    [ProductUid] ASC
)
INCLUDE
(
    [AssetUid]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_AssetVersionId on table AssetVersion
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_AssetVersionId' -- Index Name
             AND so.[Name] = N'AssetVersion')  -- Table Name
CREATE UNIQUE CLUSTERED INDEX [IX_AssetVersionId] ON [dbo].[AssetVersion]
(
    [AssetVersionId] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_BatchStatus_CreatedAtUtc on table BatchStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_BatchStatus_CreatedAtUtc' -- Index Name
             AND so.[Name] = N'BatchStatus')  -- Table Name
CREATE INDEX [IX_BatchStatus_CreatedAtUtc] ON [dbo].[BatchStatus]
(
    [CreatedAtUtc] ASC
)
INCLUDE
(
    [ResultingMessage]
) 
WITH (FillFactor = 95)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_Contributors_AssetVersionUid on table Contributors
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_Contributors_AssetVersionUid' -- Index Name
             AND so.[Name] = N'Contributors')  -- Table Name
CREATE INDEX [IX_Contributors_AssetVersionUid] ON [dbo].[Contributors]
(
    [AssetVersionUid] ASC
) 
WITH (FillFactor = 95)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderAcceptabilities_ResultingEventLevel on table DistributionOrderAcceptabilities
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderAcceptabilities_ResultingEventLevel' -- Index Name
             AND so.[Name] = N'DistributionOrderAcceptabilities')  -- Table Name
CREATE INDEX [IX_DistributionOrderAcceptabilities_ResultingEventLevel] ON [dbo].[DistributionOrderAcceptabilities]
(
    [ResultingEventLevel] ASC
)
INCLUDE
(
    [DistributionOrderUid],
    [ResultingEvent]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderAcceptabilities_DistributionOrderUid on table DistributionOrderAcceptabilities
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderAcceptabilities_DistributionOrderUid' -- Index Name
             AND so.[Name] = N'DistributionOrderAcceptabilities')  -- Table Name
CREATE INDEX [IX_DistributionOrderAcceptabilities_DistributionOrderUid] ON [dbo].[DistributionOrderAcceptabilities]
(
    [DistributionOrderUid] ASC,
    [ResultingEventLevel] ASC
)
INCLUDE
(
    [ResultingEvent]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrders_ProductRevisionUid on table DistributionOrders
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrders_ProductRevisionUid' -- Index Name
             AND so.[Name] = N'DistributionOrders')  -- Table Name
CREATE INDEX [IX_DistributionOrders_ProductRevisionUid] ON [dbo].[DistributionOrders]
(
    [ProductRevisionUid] ASC
)
INCLUDE
(
    [DistributionOrderUid]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrders_CreatedAtUtc on table DistributionOrders
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrders_CreatedAtUtc' -- Index Name
             AND so.[Name] = N'DistributionOrders')  -- Table Name
CREATE INDEX [IX_DistributionOrders_CreatedAtUtc] ON [dbo].[DistributionOrders]
(
    [CreatedAtUtc] ASC
)
INCLUDE
(
    [DistributionOrderUid],
    [ProductRevisionUid]
) 
WITH (FillFactor = 95)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderStatus_ResultingEvent_CreatedAtUtc on table DistributionOrderStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderStatus_ResultingEvent_CreatedAtUtc' -- Index Name
             AND so.[Name] = N'DistributionOrderStatus')  -- Table Name
CREATE INDEX [IX_DistributionOrderStatus_ResultingEvent_CreatedAtUtc] ON [dbo].[DistributionOrderStatus]
(
    [ResultingEvent] ASC,
    [CreatedAtUtc] ASC
)
INCLUDE
(
    [DistributionOrderStatusId],
    [DistributionOrderUid],
    [ProcessedAtUtc]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderStatus_DistributionOrderUid_ResultingEvent_ResultingEventLevel on table DistributionOrderStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderStatus_DistributionOrderUid_ResultingEvent_ResultingEventLevel' -- Index Name
             AND so.[Name] = N'DistributionOrderStatus')  -- Table Name
CREATE INDEX [IX_DistributionOrderStatus_DistributionOrderUid_ResultingEvent_ResultingEventLevel] ON [dbo].[DistributionOrderStatus]
(
    [DistributionOrderUid] ASC,
    [ResultingEvent] ASC,
    [ResultingEventLevel] ASC
)
INCLUDE
(
    [ProcessedAtUtc]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderStatus_DistributionOrderUid_ProcessedAtUtc on table DistributionOrderStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderStatus_DistributionOrderUid_ProcessedAtUtc' -- Index Name
             AND so.[Name] = N'DistributionOrderStatus')  -- Table Name
CREATE INDEX [IX_DistributionOrderStatus_DistributionOrderUid_ProcessedAtUtc] ON [dbo].[DistributionOrderStatus]
(
    [DistributionOrderUid] ASC,
    [ProcessedAtUtc] ASC,
    [ResultingEventLevel] ASC
)
INCLUDE
(
    [ResultingEvent],
    [ResultingMessage],
    [DistributionOrderStatusId],
    [CreatedAtUtc]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderStatus_CreatedAtUtc on table DistributionOrderStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderStatus_CreatedAtUtc' -- Index Name
             AND so.[Name] = N'DistributionOrderStatus')  -- Table Name
CREATE INDEX [IX_DistributionOrderStatus_CreatedAtUtc] ON [dbo].[DistributionOrderStatus]
(
    [CreatedAtUtc] ASC
)
INCLUDE
(
    [DistributionOrderUid]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderStatus_ResultingEventLevel on table DistributionOrderStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderStatus_ResultingEventLevel' -- Index Name
             AND so.[Name] = N'DistributionOrderStatus')  -- Table Name
CREATE INDEX [IX_DistributionOrderStatus_ResultingEventLevel] ON [dbo].[DistributionOrderStatus]
(
    [ResultingEventLevel] ASC
)
INCLUDE
(
    [DistributionOrderUid],
    [ProcessedAtUtc],
    [ResultingEvent]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderStatus_ProcessedAtUtc_ResultingEventLevel on table DistributionOrderStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderStatus_ProcessedAtUtc_ResultingEventLevel' -- Index Name
             AND so.[Name] = N'DistributionOrderStatus')  -- Table Name
CREATE INDEX [IX_DistributionOrderStatus_ProcessedAtUtc_ResultingEventLevel] ON [dbo].[DistributionOrderStatus]
(
    [ProcessedAtUtc] ASC,
    [ResultingEventLevel] ASC
)
INCLUDE
(
    [DistributionOrderUid],
    [ResultingEvent]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderStructureFulfillments_DistributionOrderStructureId on table DistributionOrderStructureFulfillments
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderStructureFulfillments_DistributionOrderStructureId' -- Index Name
             AND so.[Name] = N'DistributionOrderStructureFulfillments')  -- Table Name
CREATE INDEX [IX_DistributionOrderStructureFulfillments_DistributionOrderStructureId] ON [dbo].[DistributionOrderStructureFulfillments]
(
    [DistributionOrderStructureId] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrders_DistributionOrderUid on table DistributionOrderStructureGroups
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrders_DistributionOrderUid' -- Index Name
             AND so.[Name] = N'DistributionOrderStructureGroups')  -- Table Name
CREATE INDEX [IX_DistributionOrders_DistributionOrderUid] ON [dbo].[DistributionOrderStructureGroups]
(
    [DistributionOrderUid] ASC
)
INCLUDE
(
    [DistributionOrderStructureGroupUid]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderStructureGroups_DistributionOrderUid on table DistributionOrderStructureGroups
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderStructureGroups_DistributionOrderUid' -- Index Name
             AND so.[Name] = N'DistributionOrderStructureGroups')  -- Table Name
CREATE INDEX [IX_DistributionOrderStructureGroups_DistributionOrderUid] ON [dbo].[DistributionOrderStructureGroups]
(
    [DistributionOrderUid] ASC
)
INCLUDE
(
    [DistributionOrderStructureGroupUid]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_DistributionOrderStructures_DistributionOrderStructureGroupUid on table DistributionOrderStructures
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_DistributionOrderStructures_DistributionOrderStructureGroupUid' -- Index Name
             AND so.[Name] = N'DistributionOrderStructures')  -- Table Name
CREATE INDEX [IX_DistributionOrderStructures_DistributionOrderStructureGroupUid] ON [dbo].[DistributionOrderStructures]
(
    [DistributionOrderStructureGroupUid] ASC
)
INCLUDE
(
    [DistributionOrderStructureId],
    [DistributionOrderStructureContractUid]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_EventId on table Events
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_EventId' -- Index Name
             AND so.[Name] = N'Events')  -- Table Name
CREATE UNIQUE CLUSTERED INDEX [IX_EventId] ON [dbo].[Events]
(
    [EventId] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_FolderObjectEBookProductProcessingResults_FolderObjectUid on table FolderObjectEBookProductProcessingResults
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_FolderObjectEBookProductProcessingResults_FolderObjectUid' -- Index Name
             AND so.[Name] = N'FolderObjectEBookProductProcessingResults')  -- Table Name
CREATE INDEX [IX_FolderObjectEBookProductProcessingResults_FolderObjectUid] ON [dbo].[FolderObjectEBookProductProcessingResults]
(
    [FolderObjectUid] ASC
)
INCLUDE
(
    [ProductUid],
    [CreatedAtUtc],
    [ResultingEvent],
    [ResultingMessage]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_FolderObjectEBookProductProcessingResults_ResultingEventLevel on table FolderObjectEBookProductProcessingResults
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_FolderObjectEBookProductProcessingResults_ResultingEventLevel' -- Index Name
             AND so.[Name] = N'FolderObjectEBookProductProcessingResults')  -- Table Name
CREATE INDEX [IX_FolderObjectEBookProductProcessingResults_ResultingEventLevel] ON [dbo].[FolderObjectEBookProductProcessingResults]
(
    [ResultingEventLevel] ASC
)
INCLUDE
(
    [FolderObjectUid],
    [ProductUid],
    [AssetUid],
    [CreatedAtUtc],
    [ResultingEvent],
    [ResultingMessage]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_FolderObjects_FolderObjectUid_ImportFolderConfigurationUid_IsFile on table FolderObjects
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_FolderObjects_FolderObjectUid_ImportFolderConfigurationUid_IsFile' -- Index Name
             AND so.[Name] = N'FolderObjects')  -- Table Name
CREATE INDEX [IX_FolderObjects_FolderObjectUid_ImportFolderConfigurationUid_IsFile] ON [dbo].[FolderObjects]
(
    [ImportFolderConfigurationUid] ASC,
    [IsFile] ASC
)
INCLUDE
(
    [FolderObjectUid],
    [Path]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_FolderObjects_FolderObjectUid_IsFile on table FolderObjects
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_FolderObjects_FolderObjectUid_IsFile' -- Index Name
             AND so.[Name] = N'FolderObjects')  -- Table Name
CREATE INDEX [IX_FolderObjects_FolderObjectUid_IsFile] ON [dbo].[FolderObjects]
(
    [IsFile] ASC
)
INCLUDE
(
    [FolderObjectUid],
    [ImportFolderConfigurationUid],
    [Path]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_FolderObjects_CreatedAtUtc on table FolderObjects
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_FolderObjects_CreatedAtUtc' -- Index Name
             AND so.[Name] = N'FolderObjects')  -- Table Name
CREATE INDEX [IX_FolderObjects_CreatedAtUtc] ON [dbo].[FolderObjects]
(
    [CreatedAtUtc] ASC
)
INCLUDE
(
    [ImportFolderConfigurationUid]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_FolderObjects_ImportFolderConfigurationUid_IsFile_Size on table FolderObjects
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_FolderObjects_ImportFolderConfigurationUid_IsFile_Size' -- Index Name
             AND so.[Name] = N'FolderObjects')  -- Table Name
CREATE INDEX [IX_FolderObjects_ImportFolderConfigurationUid_IsFile_Size] ON [dbo].[FolderObjects]
(
    [ImportFolderConfigurationUid] ASC,
    [IsFile] ASC,
    [Size] ASC
)
INCLUDE
(
    [FolderObjectUid],
    [Path]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_FolderObjects_IsFile_Size on table FolderObjects
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_FolderObjects_IsFile_Size' -- Index Name
             AND so.[Name] = N'FolderObjects')  -- Table Name
CREATE INDEX [IX_FolderObjects_IsFile_Size] ON [dbo].[FolderObjects]
(
    [IsFile] ASC,
    [Size] ASC
)
INCLUDE
(
    [FolderObjectUid],
    [ImportFolderConfigurationUid],
    [Path]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_FolderObjectStatus_Status on table FolderObjectStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_FolderObjectStatus_Status' -- Index Name
             AND so.[Name] = N'FolderObjectStatus')  -- Table Name
CREATE INDEX [IX_FolderObjectStatus_Status] ON [dbo].[FolderObjectStatus]
(
    [Status] ASC
)
INCLUDE
(
    [FolderObjectUid],
    [CreatedAtUtc]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_FolderObjectStatus_FolderObjectUid_Status on table FolderObjectStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_FolderObjectStatus_FolderObjectUid_Status' -- Index Name
             AND so.[Name] = N'FolderObjectStatus')  -- Table Name
CREATE INDEX [IX_FolderObjectStatus_FolderObjectUid_Status] ON [dbo].[FolderObjectStatus]
(
    [FolderObjectUid] ASC,
    [Status] ASC
)
INCLUDE
(
    [CreatedAtUtc]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index ucMSreplication_objects on table MSreplication_objects
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'ucMSreplication_objects' -- Index Name
             AND so.[Name] = N'MSreplication_objects')  -- Table Name
CREATE CLUSTERED INDEX [ucMSreplication_objects] ON [dbo].[MSreplication_objects]
(
    [object_name] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index uc1MSReplication_subscriptions on table MSreplication_subscriptions
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'uc1MSReplication_subscriptions' -- Index Name
             AND so.[Name] = N'MSreplication_subscriptions')  -- Table Name
CREATE UNIQUE CLUSTERED INDEX [uc1MSReplication_subscriptions] ON [dbo].[MSreplication_subscriptions]
(
    [publication] ASC,
    [publisher_db] ASC,
    [publisher] ASC,
    [subscription_type] ASC,
    [transaction_timestamp] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index ci_MSsavedforeignkeycolumns on table MSsavedforeignkeycolumns
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'ci_MSsavedforeignkeycolumns' -- Index Name
             AND so.[Name] = N'MSsavedforeignkeycolumns')  -- Table Name
CREATE CLUSTERED INDEX [ci_MSsavedforeignkeycolumns] ON [dbo].[MSsavedforeignkeycolumns]
(
    [program_name] ASC,
    [constraint_name] ASC,
    [parent_schema] ASC,
    [constraint_column_id] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index nci_MSsavedforeignkeycolumns_timestamp on table MSsavedforeignkeycolumns
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'nci_MSsavedforeignkeycolumns_timestamp' -- Index Name
             AND so.[Name] = N'MSsavedforeignkeycolumns')  -- Table Name
CREATE INDEX [nci_MSsavedforeignkeycolumns_timestamp] ON [dbo].[MSsavedforeignkeycolumns]
(
    [timestamp] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index ci_MSsavedforeignkeyextendedproperties on table MSsavedforeignkeyextendedproperties
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'ci_MSsavedforeignkeyextendedproperties' -- Index Name
             AND so.[Name] = N'MSsavedforeignkeyextendedproperties')  -- Table Name
CREATE CLUSTERED INDEX [ci_MSsavedforeignkeyextendedproperties] ON [dbo].[MSsavedforeignkeyextendedproperties]
(
    [program_name] ASC,
    [constraint_name] ASC,
    [parent_schema] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index nci_MSsavedforeignkeyextendedproperties_timestamp on table MSsavedforeignkeyextendedproperties
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'nci_MSsavedforeignkeyextendedproperties_timestamp' -- Index Name
             AND so.[Name] = N'MSsavedforeignkeyextendedproperties')  -- Table Name
CREATE INDEX [nci_MSsavedforeignkeyextendedproperties_timestamp] ON [dbo].[MSsavedforeignkeyextendedproperties]
(
    [timestamp] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index ci_MSsavedforeignkeys on table MSsavedforeignkeys
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'ci_MSsavedforeignkeys' -- Index Name
             AND so.[Name] = N'MSsavedforeignkeys')  -- Table Name
CREATE CLUSTERED INDEX [ci_MSsavedforeignkeys] ON [dbo].[MSsavedforeignkeys]
(
    [program_name] ASC,
    [constraint_name] ASC,
    [parent_schema] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index nci_MSsavedforeignkeys_timestamp on table MSsavedforeignkeys
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'nci_MSsavedforeignkeys_timestamp' -- Index Name
             AND so.[Name] = N'MSsavedforeignkeys')  -- Table Name
CREATE INDEX [nci_MSsavedforeignkeys_timestamp] ON [dbo].[MSsavedforeignkeys]
(
    [timestamp] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index ci_MSsnapshotdeliveryprogress_progress_token_hash on table MSsnapshotdeliveryprogress
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'ci_MSsnapshotdeliveryprogress_progress_token_hash' -- Index Name
             AND so.[Name] = N'MSsnapshotdeliveryprogress')  -- Table Name
CREATE INDEX [ci_MSsnapshotdeliveryprogress_progress_token_hash] ON [dbo].[MSsnapshotdeliveryprogress]
(
    [progress_token_hash] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index nci_MSsnapshotdeliveryprogress_session_token on table MSsnapshotdeliveryprogress
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'nci_MSsnapshotdeliveryprogress_session_token' -- Index Name
             AND so.[Name] = N'MSsnapshotdeliveryprogress')  -- Table Name
CREATE INDEX [nci_MSsnapshotdeliveryprogress_session_token] ON [dbo].[MSsnapshotdeliveryprogress]
(
    [session_token] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index ucMSsubscription_agents on table MSsubscription_agents
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'ucMSsubscription_agents' -- Index Name
             AND so.[Name] = N'MSsubscription_agents')  -- Table Name
CREATE UNIQUE CLUSTERED INDEX [ucMSsubscription_agents] ON [dbo].[MSsubscription_agents]
(
    [publication] ASC,
    [publisher_db] ASC,
    [publisher] ASC,
    [subscription_type] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index ucMSsubscription_agents_id on table MSsubscription_agents
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'ucMSsubscription_agents_id' -- Index Name
             AND so.[Name] = N'MSsubscription_agents')  -- Table Name
CREATE INDEX [ucMSsubscription_agents_id] ON [dbo].[MSsubscription_agents]
(
    [id] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_Prices_TerritorySupplyDetailId on table Prices
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_Prices_TerritorySupplyDetailId' -- Index Name
             AND so.[Name] = N'Prices')  -- Table Name
CREATE INDEX [IX_Prices_TerritorySupplyDetailId] ON [dbo].[Prices]
(
    [TerritorySupplyDetailId] ASC
)
INCLUDE
(
    [Amount],
    [Currency]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_ProductFormDetails_AssetVersionUid on table ProductFormDetails
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_ProductFormDetails_AssetVersionUid' -- Index Name
             AND so.[Name] = N'ProductFormDetails')  -- Table Name
CREATE INDEX [IX_ProductFormDetails_AssetVersionUid] ON [dbo].[ProductFormDetails]
(
    [AssetVersionUid] ASC,
    [ProductFormDetailValue] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_ProductForms_AssetVersionUid on table ProductForms
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_ProductForms_AssetVersionUid' -- Index Name
             AND so.[Name] = N'ProductForms')  -- Table Name
CREATE INDEX [IX_ProductForms_AssetVersionUid] ON [dbo].[ProductForms]
(
    [AssetVersionUid] ASC
)
INCLUDE
(
    [ProductFormTypeValue]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_ProductRevisionId on table ProductRevision
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_ProductRevisionId' -- Index Name
             AND so.[Name] = N'ProductRevision')  -- Table Name
CREATE UNIQUE CLUSTERED INDEX [IX_ProductRevisionId] ON [dbo].[ProductRevision]
(
    [ProductRevisionId] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_ProductRevisions_ProductUid on table ProductRevisions
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_ProductRevisions_ProductUid' -- Index Name
             AND so.[Name] = N'ProductRevisions')  -- Table Name
CREATE INDEX [IX_ProductRevisions_ProductUid] ON [dbo].[ProductRevisions]
(
    [ProductUid] ASC
)
INCLUDE
(
    [ProductRevisionUid],
    [PublisherUid],
    [ContractUid]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_ProductRevisions_PublisherUid_ProductUid on table ProductRevisions
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_ProductRevisions_PublisherUid_ProductUid' -- Index Name
             AND so.[Name] = N'ProductRevisions')  -- Table Name
CREATE INDEX [IX_ProductRevisions_PublisherUid_ProductUid] ON [dbo].[ProductRevisions]
(
    [PublisherUid] ASC,
    [ProductUid] ASC
)
INCLUDE
(
    [ProductRevisionUid],
    [ContractUid]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_ProductRevisionStructures_ProductRevisionUid on table ProductRevisionStructures
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_ProductRevisionStructures_ProductRevisionUid' -- Index Name
             AND so.[Name] = N'ProductRevisionStructures')  -- Table Name
CREATE INDEX [IX_ProductRevisionStructures_ProductRevisionUid] ON [dbo].[ProductRevisionStructures]
(
    [ProductRevisionUid] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_PublishingDates_PublishingDateRole_AssetVersionUid on table PublishingDates
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_PublishingDates_PublishingDateRole_AssetVersionUid' -- Index Name
             AND so.[Name] = N'PublishingDates')  -- Table Name
CREATE INDEX [IX_PublishingDates_PublishingDateRole_AssetVersionUid] ON [dbo].[PublishingDates]
(
    [PublishingDateRole] ASC,
    [AssetVersionUid] ASC
)
INCLUDE
(
    [Value]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_PublishingStatus_PublishingStatusType_AssetVersionUid on table PublishingStatus
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_PublishingStatus_PublishingStatusType_AssetVersionUid' -- Index Name
             AND so.[Name] = N'PublishingStatus')  -- Table Name
CREATE INDEX [IX_PublishingStatus_PublishingStatusType_AssetVersionUid] ON [dbo].[PublishingStatus]
(
    [PublishingStatusType] ASC,
    [AssetVersionUid] ASC
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_TerritorySupplyDetails_TerritorySupplyId on table TerritorySupplyDetails
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_TerritorySupplyDetails_TerritorySupplyId' -- Index Name
             AND so.[Name] = N'TerritorySupplyDetails')  -- Table Name
CREATE INDEX [IX_TerritorySupplyDetails_TerritorySupplyId] ON [dbo].[TerritorySupplyDetails]
(
    [TerritorySupplyId] ASC
)
INCLUDE
(
    [TerritorySupplyDetailId]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_Texts_TextContentId on table Texts
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_Texts_TextContentId' -- Index Name
             AND so.[Name] = N'Texts')  -- Table Name
CREATE INDEX [IX_Texts_TextContentId] ON [dbo].[Texts]
(
    [TextContentId] ASC
)
INCLUDE
(
    [Value]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_TitleDetails_TitleTypeCode_AssetVersionUid on table TitleDetails
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_TitleDetails_TitleTypeCode_AssetVersionUid' -- Index Name
             AND so.[Name] = N'TitleDetails')  -- Table Name
CREATE INDEX [IX_TitleDetails_TitleTypeCode_AssetVersionUid] ON [dbo].[TitleDetails]
(
    [TitleTypeCode] ASC,
    [AssetVersionUid] ASC,
    [CollectionId] ASC
)
INCLUDE
(
    [TitleDetailId],
    [TitleStatement]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_TitleElements_TitleElementLevel on table TitleElements
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_TitleElements_TitleElementLevel' -- Index Name
             AND so.[Name] = N'TitleElements')  -- Table Name
CREATE INDEX [IX_TitleElements_TitleElementLevel] ON [dbo].[TitleElements]
(
    [TitleElementLevel] ASC
)
INCLUDE
(
    [TitleDetailId],
    [TitleText],
    [TitlePrefix],
    [TitleWithoutPrefix],
    [Subtitle]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

-- **********************************************************************
-- Index IX_TitleElements_TitleDetailId_TitleElementLevel on table TitleElements
-- **********************************************************************
IF NOT EXISTS(SELECT 1
            FROM sysindexes si
            INNER JOIN sysobjects so
                   ON so.id = si.id
           WHERE si.[Name] = N'IX_TitleElements_TitleDetailId_TitleElementLevel' -- Index Name
             AND so.[Name] = N'TitleElements')  -- Table Name
CREATE INDEX [IX_TitleElements_TitleDetailId_TitleElementLevel] ON [dbo].[TitleElements]
(
    [TitleDetailId] ASC,
    [TitleElementLevel] ASC
)
INCLUDE
(
    [TitleText],
    [TitlePrefix],
    [TitleWithoutPrefix],
    [Subtitle]
) 
WITH (FillFactor = 100)
ON [PRIMARY]

GO

