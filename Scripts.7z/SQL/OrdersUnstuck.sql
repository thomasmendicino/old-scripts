;with maxState as (
    select soel.SyndicationOrder, sos.Name [LastState], soel.At from SyndicationOrderEventLog soel
        inner join SyndicationOrderState sos on sos.ID = soel.orderstate
        inner join (select SyndicationOrder, max(at) [MaxAt] 
                    from SyndicationOrderEventLog soel where orderstate != 3 group by SyndicationOrder) x 
            on x.MaxAt = soel.At and x.SyndicationOrder = soel.SyndicationOrder)

select distinct s.syndicationlevel, s.distributionorder, so.* from syndicationorder so 
join syndication s on so.syndication = s.id
join syndicationordereventlog el on el.syndicationorder = so.id
   LEFT JOIN MaxState ms on ms.SyndicationOrder = so.ID
where orderbatchid in ('1000001056121',
'1000001056108',
'1000001056139',
'1000001056136',
'1000001056155',
'1000001056105',
'1000001056134',
'1000001056122',
'1000001056133',
'1000001056120',
'1000001056107',
'1000001056113',
'1000001056125',
'1000001056111',
'1000001056149',
'1000001056123',
'1000001056118',
'1000001056130',
'1000001056141',
'1000001056147',
'1000001056124',
'1000001056143',
'1000001056148',
'1000001056150',
'1000001056112',
'1000001056126',
'1000001056142',
'1000001056106')
and ms.at < '2011-10-28 18:00:00.000'