
/*

Newly Released Titles That need to go to Retailers that Don't Accept Preorders

-- #Retailers we care about
-- #Titles that have successfully gone out as preorders to at least one non-onix feed retailer (as non-retailer specific metadata)
-- #Titles with

*/
declare @CurrentDate datetime
declare @TargetDate datetime
declare @exceptions table (ISBN bigint, Retailer nvarchar(100))
declare @final table (ISBN bigint, Retailer nvarchar(100))
declare @retailersWeCareAbout table (Retailer nvarchar(100))
declare @AllowedPubRetCombo table (Retailer nvarchar(100), OrganizationName nvarchar(250))

select @CurrentDate = cast(datepart(yy, getdate())as nvarchar(4)) + '-' + cast(datepart(mm, getdate())as nvarchar(2)) + '-' + cast(datepart(dd, getdate())as nvarchar(2))
select @TargetDate = dateadd(dd,-7,@CurrentDate)

insert @retailersWeCareAbout (Retailer)
select r.Name Retailer from retailers r
join contracts c on c.retailerUid = r.retailerUid
join ruleSets rs on rs.ruleSetUId = c.ruleSetUid
join publishers p on p.PublisherUid = c.PublisherUid
where rs.Name <> 'Distribution Prohibited' and p.Name = 'INscribe Digital' and c.ValidUntilUtc is null and r.Name <> 'Onix Feed'

insert @AllowedPubRetCombo (Retailer, OrganizationName)
select r.Name Retailer, o.OrganizationName from Retailers r
cross join organizations o
except
select r.Name Retailer, o.OrganizationName Publisher 
from Contracts c
inner join publishers p on p.PublisherUid = c.PublisherUid
inner join Organizations o on o.organizationUid = p.organizationUId
inner join retailers r on r.retailerUid = c.RetailerUid
inner join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where c.ValidUntilUtc is NULL 
and rs.Name = 'Distribution Prohibited'

;with productChangeTypes as (
select 'Preorder' as Name, 32 as Value)
,
SuccessfulDistroOrders as ( -- Products that successfully went out to any retailer as a preorder
select
p.Ordinal ISBN, r.Name Retailer
from
DistributionOrders do
inner join ProductRevisions pr on do.ProductRevisionUid = pr.ProductRevisionUid
inner join contracts c on c.contractUid = pr.ContractUid
inner join Retailers r on r.RetailerUid = c.RetailerUid
inner join product p on p.productUid = pr.productUid
inner join distributionOrderStatus dos on dos.distributionOrderUid = do.distributionOrderUid
inner join productRevisionStructures prs on prs.ProductRevisionUid = pr.ProductRevisionUid
inner join assetVersion av on av.AssetVersionUid = prs.AssetVersionUid
inner join assetOverride ao on ao.assetOverrideUid = av.assetOverrideUid
cross join productChangeTypes ct
where
pr.ChangeType & ct.Value <> 0
and ct.Name = 'Preorder' 
and r.Code <> 'INX'
and dos.ResultingEvent = 110
and ao.RetailerUid is NULL
and av.ValidUntilUtc is NULL)
--select * from SuccessfulDistroOrders
,
AllowedPubRetailerCombos as
(
select r.Name Retailer, o.OrganizationName from Retailers r
cross join organizations o
except
select r.Name Retailer, o.OrganizationName Publisher 
from Contracts c
inner join publishers p on p.PublisherUid = c.PublisherUid
inner join Organizations o on o.organizationUid = p.organizationUId
inner join retailers r on r.retailerUid = c.RetailerUid
inner join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where c.ValidUntilUtc is NULL 
and rs.Name = 'Distribution Prohibited')
--select * from AllowedPubRetailerCombos
,
ReleasedInTargetRange as ( -- Products that have a release date in the desired range
select p.Ordinal ISBN, pd.Value ReleaseDate from product p
inner join Organizations o on o.OrganizationUid = p.OrganizationUid
inner join asset a on a.productUid = p.productUid
inner join assetOverride ao on ao.assetUid = a.assetUid
inner join assetVersion av on av.assetOverrideUid = ao.AssetOverrideUid
inner join publishingDates pd on pd.AssetVersionUid = av.assetVersionUid
inner join SuccessfulDistroOrders sd on sd.ISBN = p.Ordinal
left outer join publishingStatus ps on ps.AssetVersionUid = av.AssetVersionUid
where av.ValidUntilUtc is NULL
and ao.RetailerUid is NULL
and ps.PublishingStatusType not in (1,5,6,7,8,11,12,15,16)
and pd.Value between @TargetDate and @CurrentDate
and o.OrganizationUid not in (select OrganizationUid from Organizations where organizationName = 'Scholastic Inc.')
and o.ParentOrganizationUid not in (select OrganizationUid from Organizations where organizationName = 'Scholastic Inc.')
)
--select * from ReleasedInTargetRange
,
AlreadyDistrod as ( -- Products that have already been delivered to our targeted retailers
select p.Ordinal ISBN, o.OrganizationName Imprint, r.Name Retailer from product p
inner join Organizations o on o.organizationUid = p.OrganizationUid
inner join productRevisions pr on pr.productUid = p.productUid
inner join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
inner join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
inner join contracts c on c.contractUid = pr.contractUid
inner join retailers r on r.retailerUId = c.retailerUid
inner join RetailersWeCareAbout rc on rc.Retailer = r.Name
where dos.ResultingEvent = 110)
--select * from AlreadyDistrod
,
FailedLegitimately as (
select p.Ordinal ISBN,  r.name Retailer from product p
inner join ProductRevisions pr on pr.ProductUid = p.ProductUid
inner join distributionORders do on do.ProductRevisionUid = pr.ProductRevisionUid
inner join contracts c on c.contractUid = pr.contractUid
inner join retailers r on r.retailerUId = c.retaileruid
inner join DistributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
inner join refEventType re on re.EventTypeid = dos.ResultingEvent
inner join DistributionOrderAcceptabilities doa on doa.DistributionOrderUid = do.DistributionOrderUid
inner join refEventType re2 on re2.EventTypeId = doa.ResultingEvent
inner join ReleasedInTargetRange rt on rt.ISBN = p.Ordinal
inner join RetailersWeCareAbout rc on rc.Retailer = r.Name
where (re.Code = 'DINA' and re2.Code in ('REM','CIM','EBM'))
or (re.Code = 'DIMF' and re2.Code = 'UNKN')
or re2.code = 'DIDC')
--select * from FailedLegitimately
,
FullDistro as (
select p.Ordinal ISBN, o.OrganizationName, pd.Value ReleaseDate, r.Retailer from product p
inner join organizations o on o.organizationUid = p.organizationUId
inner join asset a on a.productUid = p.productUid
inner join assetOverride ao on ao.assetUid = a.assetUid
inner join assetVersion av on av.assetOverrideUid = ao.AssetOverrideUid
inner join publishingDates pd on pd.AssetVersionUid = av.assetVersionUid
inner join ReleasedInTargetRange tr on tr.ISBN = p.Ordinal and tr.ReleaseDate = pd.Value
cross join RetailersWeCareAbout r
),
exceptions as (
select sdo.ISBN, sdo.Retailer from SuccessfulDistroOrders sdo
join FullDistro fd on fd.ISBN = sdo.ISBN
UNION
select ISBN, Retailer from FailedLegitimately
UNION
select ISBN, Retailer from AlreadyDistrod)
select * from Exceptions
,
final as 
(select fd.ISBN, fd.Retailer from FullDistro fd
except
select ISBN, Retailer from exceptions)
select * from final

select distinct fd.ISBN, fd.OrganizationName Imprint, fd.ReleaseDate, fd.Retailer from FullDistro fd
inner join final a on a.Retailer = fd.Retailer and fd.ISBN = a.ISBN
inner join AllowedPubRetailerCombos apr on apr.OrganizationName = fd.OrganizationName and fd.Retailer = apr.Retailer
inner join RetailersWeCareAbout rc on rc.Retailer = fd.Retailer
order by ISBN, Retailer
