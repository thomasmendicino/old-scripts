declare @Interval int 
set @Interval = 7
;with parents as (
select OrganizationName, OrganizationUid from Organizations
where ParentOrganizationUid = '00000000-0000-0000-0000-000000000001'),
BusyOrgs as (
select distinct p.Ordinal ISBN, p.OrganizationUid 
from Product p
join ProductRevisions pr on pr.ProductUid = p.ProductUid
join DistributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join DistributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
where dos.ResultingEvent = 103
AND do.CreatedAtUtc > DATEADD(DAY,-@Interval,GETUTCDATE())
),
po as
(select 
	Parents.OrganizationName Organization,
	ISBN
from parents
join BusyOrgs bo on bo.organizationUid = parents.OrganizationUId
UNION
select 
	parents.OrganizationName Organization,
	ISBN
from parents 
join organizations children on children.ParentOrganizationUid = parents.OrganizationUid
join BusyOrgs bo on bo.organizationUid = children.OrganizationUId
UNION
select
	parents.OrganizationName Organization,
	ISBN
from parents 
join organizations children on children.ParentOrganizationUid = parents.OrganizationUid
join organizations grandchildren on grandchildren.ParentOrganizationUid = children.OrganizationUid
join BusyOrgs bo on bo.organizationUid = grandchildren.OrganizationUId),
POcount as 
(SELECT
	Organization, count(ISBN) TotalProducts
	from po
	group by Organization)
--select * from POCount order by TotalProducts desc

select Organization, 
sum(TotalProducts) AS [ProductOrdersCreated]
from 
	(select case when Sequence < 10 then Organization else 'Other' end as Organization, t.TotalProducts, Sequence from 
		(select Organization, TotalProducts, ROW_NUMBER() over (order by TotalProducts desc, Organization asc) as Sequence from POcount
		) t
	) t2
group by t2.Organization, (case when Sequence < 10 then cast(TotalProducts as nvarchar(20)) else Organization end)
order by
	case
		when Organization <> 'Other' then (case when Sequence < 10 then cast(TotalProducts as nvarchar(20)) else Organization end) END desc,
	case 
		when Organization = 'Other' then (case when Sequence < 10 then cast(TotalProducts as nvarchar(20)) else Organization end) END asc