
declare @album int = 824141--(select id from album where gtin = '9781634767408')--824141
;with intermediateprices as ( 
select distinct 
a.GTIN ISBN, 
o.Name Imprint, 
cn.Name Country,--, pmv.AlbumPrice
pt.Name priceTier, 
CASE 
	when cn.Currency = c.ID THEN cast(pmv.AlbumPrice as char(10)) + ' ' + c.Name
	when cn.Currency != c.ID THEN pt.Name
END as Price
, ROW_NUMBER() OVER (PARTITION BY Country ORDER BY CASE 
	when cn.Currency = c.ID THEN cast(pmv.AlbumPrice as char(10)) + ' ' + c.Name
	when cn.Currency != c.ID THEN pt.Name
END ASC) RowNum
, pt.ID
FROM priceTier pt
left JOIN priceTierMapping pm on pm.PriceTier = pt.ID
left join PriceTierMappingView pmv on pmv.priceTier = pt.ID
left join Currency c on c.id = pmv.Currency
left join priceCampaign pc on pc.StartPriceTier = pt.ID
left join album a on a.id = pc.Album
left join organization o on o.id = a.organization
left join Country cn on cn.id = pc.Country --AND cn.Currency = c.ID
where pc.Album = @album)
select ISBN, Imprint, Country, i.PriceTier AS INDMATierName, ISNULL(ltrim(Price),ltrim(cast(pv.AlbumPrice as char(10)) + ' USD')) PriceAmountOrTier 
from intermediateprices i
join PriceTier pt on pt.Name = i.PriceTier
join PriceTierMappingView pv on pv.PriceTier = pt.ID
where isnull(RowNum,1) = 1
and pv.Currency = 1 --USD




