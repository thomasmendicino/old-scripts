
;with mostRecentDistOrder as (
select p.Ordinal, r.Name, max(do.createdAtUtc) CreatedAtutc from AthenaProductCatalog..product p
join ProductRevisions pr on pr.ProductUid = p.ProductUid
join DistributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join Contracts c on c.ContractUid = pr.ContractUid
join Retailers r on r.RetailerUid = c.RetailerUid
where do.CreatedAtUtc > '2015-03-20'
group by ordinal, Name)

select distinct p.ordinal,r.Name, o.OrganizationName, po.OrganizationName parent from DistributionOrders do 
join DistributionOrderstatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join AthenaProductCatalog..product p on p.productuid = pr.ProductUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
join Contracts c on c.contractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostRecentDistOrder m on m.CreatedAtUtc = do.CreatedAtUtc
where do.DistributionOrderUid not in (select distributionOrderUid from DistributionORderStatus dos where dos.ResultingEvent = 110)
and do.DistributionOrderUid not in (select distributionOrderUid from DistributionORderStatus dos where dos.ResultingEventLevel > 3)
and do.CreatedAtUtc > '2015-03-20'
and r.Name not in ('Bowker','MyILibrary','Overdrive')
order by po.OrganizationName, o.OrganizationName, p.Ordinal

