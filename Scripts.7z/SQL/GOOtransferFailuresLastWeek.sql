
declare		@Interval int = 7

	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED	


DECLARE @DateRangeStart DATETIME 
DECLARE @DateRangeEnd DATETIME 

SET @DateRangeStart = Dateadd(dd, -@Interval, Getutcdate()) 
SET @DateRangeEnd = Getutcdate(); 

WITH distributiontitles 
     AS (SELECT pr.productuid, 
                p.ordinal               AS ISBN, 
                r.NAME                  AS Retailer, 
                r.retaileruid, 
                Max(dos.processedatutc) AS ProcessedAtUtc 
         FROM   Athenacomposite..distributionorderstatus dos 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.distributionorderuid = dos.distributionorderuid 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productrevisionuid = do.productrevisionuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                INNER JOIN Athenacomposite..retailers r 
                        ON r.retaileruid = c.retaileruid 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = pr.productuid 
                INNER JOIN Athenacomposite..asset a 
                        ON a.productuid = p.productuid 
                CROSS apply (SELECT TOP 1 assetoverrideuid 
                             FROM   Athenacomposite..assetoverride 
                             WHERE  a.assetuid = assetuid 
                             ORDER  BY retaileruid ASC) ao 
                INNER JOIN Athenacomposite..assetversion av 
                        ON av.assetoverrideuid = ao.assetoverrideuid 
                INNER JOIN Athenacomposite..productforms pf 
                        ON pf.assetversionuid = av.assetversionuid 
         WHERE  pf.productformtypevalue IN ( 49, 50, 51, 52 ) 
			AND r.Code = 'GOO'
         GROUP  BY pr.productuid, 
                   p.ordinal, 
                   r.NAME, 
                   r.retaileruid 
         HAVING Max(dos.processedatutc) BETWEEN 
                @DateRangeStart AND @DateRangeEnd), 
     distributiondataset 
     AS (SELECT DISTINCT isbn, 
                         dt.retailer 
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
         WHERE  ret.code = 'DITC'),
	 invaliddistributiondataset1 
	 as (SELECT DISTINCT isbn, 
                         dt.retailer,
						 do.DistributionOrderUid 
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
         WHERE  dos.resultingeventlevel = 4
                AND (ret.code IN ( 'DIDC','DINA')
				OR (ret.code = 'DIMF' 
				AND (substring(dos.ResultingMessage, 161, 29) IN ('Product does not have any sup','Source metadata contains conf','There are no supported assets'))
				OR substring(dos.ResultingMessage, 0,29) = 'One or more tokens have been')
				OR substring(dos.ResultingMessage, charindex('Package Summary', dos.ResultingMessage)+34,43) = 'were not uploaded because they had problems')					 )
					 ,
	 invaliddistributiondataset2
	 as (SELECT DISTINCT isbn, 
                         dt.retailer,
						 do.DistributionOrderUid
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
				INNER JOIN AthenaComposite..DistributionOrderAcceptabilities doa
						ON doa.DistributionOrderUid = do.DistributionOrderUid
         WHERE dos.resultingeventlevel = 4
                AND ret.code = 'DIMF'
				AND DOA.ResultingEvent IN (10,47,13,131)
				)
		SELECT DISTINCT isbn, 
                         dt.retailer,
						 dos.CreatedAtUtc,
						 dos.ResultingMessage
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
         WHERE  dos.resultingeventlevel > 2 
                AND ret.code = 'DIMF'
				AND do.distributionOrderUid NOT IN (select DistributionOrderUid from invaliddistributiondataset1
				UNION ALL
				select DistributionOrderUid from invaliddistributiondataset2)
				AND dos.ResultingMessage like 'Transfer%'