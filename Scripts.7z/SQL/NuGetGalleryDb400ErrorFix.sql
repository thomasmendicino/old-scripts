
--delete from PackageStatistics
--where PackageKey in
--(select [Key] from Packages where Version like '%-prerelease')

--delete from CuratedPackages
--where PackageKey in
--(select [Key] from Packages where Version like '%-prerelease')

--delete from PackageAuthors
--where PackageKey in
--(select [Key] from Packages where Version like '%-prerelease')

--delete from PackageDependencies
--where PackageKey in
--(select [Key] from Packages where Version like '%-prerelease')

--delete from Packages where Version like '%-prerelease'

declare @packages table (packageKey int)
declare @packagesStable table (packageKey int)

insert into @packagesStable
select
p.[Key]
--, pr.Id, p.Version, p.IsLatest, p.IsLatestStable, p.IsPrerelease
from
Packages p
inner join PackageRegistrations pr on p.PackageRegistrationKey = pr.[Key]
where
p.[Key] =
	(select top(1) [Key]
	from Packages
	where PackageRegistrationKey = p.PackageRegistrationKey and IsPrerelease = 0 and Listed = 1
	order by Version desc)
order by 
pr.Id

insert into @packages
select
p.[Key]
--, pr.Id, p.Version, p.IsLatest, p.IsLatestStable, p.IsPrerelease
from
Packages p
inner join PackageRegistrations pr on p.PackageRegistrationKey = pr.[Key]
where
p.[Key] =
	(select top(1) [Key]
	from Packages
	where PackageRegistrationKey = p.PackageRegistrationKey and IsPrerelease = 1 and Listed = 1
	order by Version desc)
order by 
pr.Id

update Packages 
set IsLatestStable = 1
where [Key] in (select packageKey from @packagesStable)

update Packages 
set IsLatest = 1
where [Key] in (select packageKey from @packages)
