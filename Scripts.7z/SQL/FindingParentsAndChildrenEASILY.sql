--select * from Organizations where organizationname like '%charis%'
declare @OrganizationUid uniqueidentifier = 'B32DE4AE-BAE0-4908-8AB8-E9159BA71DD4';

with Organization as
(
    select child.OrganizationUid, child.OrganizationName, child.ParentOrganizationUid, parent.OrganizationName ParentOrganizationName, 0 as Level
    from Organizations child
         left outer join Organizations parent on child.ParentOrganizationUid = parent.OrganizationUid
    where child.OrganizationUid = @OrganizationUid

    union all

    select child.OrganizationUid, child.OrganizationName, child.ParentOrganizationUid, parent.OrganizationName ParentOrganizationName, r.Level + 1 as Level
    from Organization r
         inner join Organizations parent on parent.OrganizationUid = r.OrganizationUid
         inner join Organizations child on parent.OrganizationUid = child.ParentOrganizationUid
)
select
     Organization.OrganizationUid,
     Organization.OrganizationName,
     Organization.ParentOrganizationName,
     Organization.ParentOrganizationUid,
     Organization.Level
from Organization


/*
---------------------------
*/





declare @organizationName nvarchar(100)
select @organizationname = 'scholastic inc.'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
select * from org
union all
select * from child


/*
*/
use AthenaComposite;

declare @Disney table (orgUid uniqueidentifier)

declare @organizationName nvarchar(100)
select @organizationname = 'disney publishing worldwide, inc.'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @Disney
select organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select '00000000-0000-0000-0000-000000000001'

select * from @Disney



/*
*/
use AthenaComposite;

declare @Scholastic table (orgUid uniqueidentifier)

declare @organizationName nvarchar(100)
select @organizationname = 'Scholastic Inc.'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @Scholastic
select organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select '00000000-0000-0000-0000-000000000001'

select * from @Scholastic

