use INgrooves
go

if OBJECT_ID('tempdb.dbo.#EligibleAlbumFilter_1') is not null
	drop table #EligibleAlbumFilter_1
if OBJECT_ID('tempdb.dbo.#EligibleAlbumFilter_2') is not null
	drop table #EligibleAlbumFilter_2
if OBJECT_ID('tempdb.dbo.#EligibleAlbums') is not null
	drop table #EligibleAlbums

create table #EligibleAlbumFilter_1(Album int)
create table #EligibleAlbumFilter_2(Album int)
create table #EligibleAlbums(Album int)

declare @MusicService					int	=	(select ID from MusicService where Name='itunes')				-- User defined
declare @ContractAuthorityGroup			int	=	(select ID from ContractAuthorityGroup where Name='INgrooves')	-- User defined
declare @MusicServiceOrganization		table(MusicService int, Organization int)
declare @MusicServiceGenre				table(MusicService int, Genre int)
declare @MusicServiceDistributionSets	table(MusicService int, DistributionSet int)
declare @MusicServiceCountrySets		table(MusicService int, CountrySet int)
declare @WorldWideCountrySet			int	=	(	select
														CountrySet
													from CountrySetCountry
													group by
														CountrySet
													having COUNT(Country) =(	select 
																					COUNT(*) 
																				from country
																			)
												)										
declare @ReleasedProcess				int	=	(select ID from Process where Name='Released')	
											
insert into @MusicServiceDistributionSets(MusicService, DistributionSet)
select distinct
	  @MusicService
	, DistributionSet
from DistributionSetItem 
where DistributionType	in (	select 
									DistributionType
								from MusicService ms
									inner join DistributionSetItem i on ms.DistributionSet=i.DistributionSet
								where ms.ID=@MusicService
							)
insert into @MusicServiceCountrySets(MusicService, CountrySet)
select distinct
	  @MusicService							
	, CountrySet
from CountrySetCountry
where Country	in	(	select
							csc.Country
						from CountrySetCountry csc
							inner join MusicService ms on ms.CountrySet=csc.CountrySet
						where ms.ID=@MusicService
					)
				
if ((select AcceptAllPayees from MusicService where ID=@MusicService) = 0)
	begin
		insert into @MusicServiceOrganization(MusicService, Organization)
		select
			  @MusicService
			, Organization
		from MusicServicePayee
		where MusicService=@MusicService
	end
else
	begin 
		insert into @MusicServiceOrganization(MusicService, Organization)
		select
			  @MusicService
			, ID	[Organization]
		from Organization
		except
			select 
				  @MusicService
				, Organization
			from MusicServicePayee
			where MusicService=@MusicService
	end
	
if ((select AcceptAllGenres from MusicService where ID=@MusicService) = 0)
	begin
		insert into @MusicServiceGenre(MusicService, Genre)
		select
			  @MusicService
			, Genre
		from MusicServiceGenre
		where MusicService=@MusicService
	end
else
	begin 
		insert into @MusicServiceGenre(MusicService, Genre)
		select
			  @MusicService
			, ID	[Genre]
		from Genre
		except
			select 
				  @MusicService
				, Genre
			from MusicServiceGenre
			where MusicService=@MusicService
	end
	
delete 
from @MusicServiceOrganization
where Organization in	(	select
								ID
							from Organization
							where CountrySet not in	(	select
															CountrySet
														from @MusicServiceCountrySets
													)
						)
						
;with EligibleContractAlbumFilter -- 8 sec Contracts, ContractAuthority
as
(	select distinct
		Album
	from ContractAlbumViewActive cav
		inner join ContractServiceView csv on csv.MusicService=@MusicService
			and cav.Contract=csv.Contract
		inner join ContractAuthorityGroupMapping m on cav.ContractAuthority=m.ContractAuthority
			and m.ContractAuthorityGroup=@ContractAuthorityGroup
		inner join MusicServiceContractAuthority msca on msca.MusicService=@MusicService
			and cav.ContractAuthority=msca.ContractAuthority
		inner join	(	select 
							  ID	[Contract]
							, c.CountrySet
						from Contract c
							inner join @MusicServiceCountrySets msc on c.CountrySet=msc.CountrySet
					) c on cav.Contract=c.Contract				
), EligibleProductTypeAlbumFilter -- 1 sec ProductTypes
as
(	select distinct
		Album
	from AlbumProductType apt 
		inner join MusicServiceProductType mspt on mspt.MusicService=@MusicService 
			and apt.ProductType=mspt.ProductType				
), EligibleGenreAlbumFilter	--	1 sec Genres
as
(	select distinct
		Album 
	from AlbumGenre ag
		inner join @MusicServiceGenre msg on msg.MusicService=@MusicService
			and ag.Genre=msg.Genre			
)
insert into #EligibleAlbumFilter_1(Album)
select
	Album
from EligibleContractAlbumFilter
intersect 
	select
		Album
	from EligibleProductTypeAlbumFilter
intersect
	select
		Album
	from EligibleGenreAlbumFilter

insert into #EligibleAlbumFilter_2(Album)
select distinct
	ID	[Album]
from Album a
	inner join @MusicServiceOrganization mso on a.Organization=mso.Organization
	inner join @MusicServiceDistributionSets msd on a.DistributionSet=msd.DistributionSet
	inner join @MusicServiceCountrySets msc on a.CountrySet=msc.CountrySet
where a.Process=@ReleasedProcess
	and a.UploadToMS=1

insert into #EligibleAlbums(Album)
select distinct
	e1.Album
from #EligibleAlbumFilter_1 e1
	inner join #EligibleAlbumFilter_2 e2 on e1.Album=e2.Album
except
	(	select
			Album
		from MusicServiceAlbumSelection
		where MusicService=@MusicService
			and Syndicate=0
		union
			select distinct
				Album
			from AlbumSyndicationContractAuthorityView
			where MusicService=@MusicService
		union 
			select
				t.Album
			from Track t
				inner join Song s on t.Song=s.ID
			where s.Process!=@ReleasedProcess
				or s.Path is null
	)
-- Remove albums which will not syndicate because there is no intersecting country between the album and the contract.
;with PossibleConflictingCountriesFilter
as
(	select distinct
		  ea.Album
		, a.CountrySet	[AlbumCountrySet]
		, c.CountrySet	[ContractCountrySet]
	from #EligibleAlbums ea
		inner join album a on ea.Album=a.ID
		inner join ContractAlbumViewActive cav on a.ID=cav.Album
		inner join ContractAuthorityGroupMapping m on cav.ContractAuthority=m.ContractAuthority
			and m.ContractAuthorityGroup=@ContractAuthorityGroup
		inner join Contract c on cav.Contract=c.ID
		inner join ContractServiceView csv on c.ID=csv.Contract
			and csv.MusicService=@MusicService
	where a.CountrySet!=@WorldWideCountrySet
		and c.CountrySet!=@WorldWideCountrySet
		and a.CountrySet!=c.CountrySet	
), NoConflicts 
as
(	select distinct
		pf.Album
	from PossibleConflictingCountriesFilter pf
		inner join CountrySetCountry csc on pf.AlbumCountrySet=csc.CountrySet
		inner join CountrySetCountry csc2 on pf.ContractCountrySet=csc2.CountrySet
			and csc.Country=csc2.Country
)
delete 
from #EligibleAlbums
where Album in (	select 
						Album
					from PossibleConflictingCountriesFilter
					except
						select
							Album
						from NoConflicts					
				)
-- runtime 12:17

select distinct
	  a.Name		[Album Name]
	, a.GTIN		[Album GTIN]
	, a.Catalog		[Album Catalog]
	, o.Name		[Album Organization]
	, o2.Name		[Album Organization Parent]
	, apd.Performer	[Album Performer]
from #EligibleAlbums ea
	inner join album a on ea.album=a.ID
	inner join Organization o on a.Organization=o.ID
	left join Organization o2 on o.Parent=o2.ID
	inner join album_performer_derivation('Various artists', 'No tracks') apd on a.ID=apd.Album
order by 
	  a.Name		
	, a.GTIN		
	, a.Catalog		
	, o.Name		
	, o2.Name		
	, apd.Performer	