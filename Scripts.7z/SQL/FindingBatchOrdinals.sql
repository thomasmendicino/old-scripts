
select distinct do.DistributionOrderUid, p.Ordinal, pub.Name [ProductOwner], r.Name [Retailer],b.batchOrdinal,
case when bs.ResultingEventLevel = 1 then 'Information' when bs.ResultingEventLevel = 2 then 'Warning' when bs.ResultingEventLevel = 3 then 'Error' end as BatchEventLevel, 
bs.ProcessedAtUtc [BatchProcessedAtUtc], bs.ResultingMessage, ret2.Title [RuleResult]
from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
inner join AthenaDistribution..DistributionContracts dc on dc.contractUid = c.contractUid
inner join AthenaDistribution..DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
inner join AthenaDistribution..DistributionOrderStructureGroupBatches dsgb on dsgb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
inner join AthenaDistribution..batches b on b.batchUid = dsgb.batchUid
left outer join AthenaDistribution..batchStatus bs on bs.batchUid = b.batchUid
left outer join AthenaDistribution..DistributionOrderAcceptabilities doa on doa.distributionOrderUId = do.distributionOrderUid
left outer join AthenaEventLog..refEventType ret2 on ret2.EventTypeId = doa.ResultingEvent
where p.ordinal = 9781632060044
and r.code = 'KNB'
order by r.Name, b.BatchOrdinal, bs.ProcessedAtUtc