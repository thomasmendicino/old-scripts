select distinct ar.album, album.name, album.gtin from arearestriction ar
inner join album on ar.album = album.id
where ar.country not in (250)
group by ar.album, album.name, album.gtin
order by album.name