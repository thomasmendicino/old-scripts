Run in INDMA:

select rtrim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(Name, char(146),''),char(225),''),char(227),''), char(198),''), char(133),'...'),char(231),''),char(237),''),char(243),''),char(241),''),char(237),''),char(201),'' )) + ''',' + CONVERT(varchar(23), o.CreatedAt, 121) from organization o where charter = 38 order by o.Name asc

-> results to .txt file stored on athena db server.

Run in Athena:

--drop table #INDMAorgs

create table #INDMAorgs (orgname nvarchar(200), CreatedAt varchar(200))

bulk insert #INDMAorgs
from 'D:\temp\OrgTimestamps.txt'
with (fieldterminator = ''',',
rowterminator = '\n',
firstrow = 1)

DECLARE @PSTShift int
SELECT @PSTShift = DATEDIFF(HOUR,GETDATE(), GETUTCDATE())

UPDATE O
SET 
	CreatedAtUtc = DATEADD(HOUR, @PSTShift, i.CreatedAt)
FROM 
	AthenaBeta03Security..Organizations O
	INNER JOIN AthenaBeta03Security..Organizations PO
		ON PO.OrganizationUid = O.ParentOrganizationUid
	INNER JOIN #INDMAorgs i 
		ON i.orgname = replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(o.OrganizationName, char(146),''),char(225),''),char(227),''), char(198),''), char(133),'...'),char(231),''),char(237),''),char(243),''),char(241),''),char(237),''),char(201),'' )
