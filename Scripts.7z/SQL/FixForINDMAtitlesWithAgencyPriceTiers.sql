create table #AlbumsToUpdate (gtin nvarchar(14), oldTier int, newTier int)
create table #PriceTierMatch (priceTier int, AlbumPrice float, Currency int, NewPriceTier int)

insert #AlbumsToUpdate (gtin, oldTier)
select a.gtin, pc.StartPriceTier from album a
join priceCampaign pc on pc.album = a.id
join priceTier pt on pt.id = pc.StartPriceTier
join priceTierMapping pm on pm.PriceTier = pt.id
join PriceTierMappingValue ptv on ptv.id = pm.PriceTierMappingValue
join priceTierMappingType pmt on pmt.id = ptv.PriceTierMappingType
join importLogEntry ile on ile.SourceId = a.gtin
join organization o on o.id = a.organization
where pmt.Name = 'eBookAgencyPrice'
and o.ID not in (select Org from xxx_AthenaMigratedOrgs)
--select * from #AlbumsToUpdate
insert #PriceTierMatch (priceTier, AlbumPrice, Currency)
select pt.Id, ptv.AlbumPrice, ptv.Currency from priceTier pt 
join priceTierMapping pm on pm.PriceTier = pt.id
join PriceTierMappingValue ptv on ptv.id = pm.PriceTierMappingValue
join priceTierMappingType pmt on pmt.id = ptv.PriceTierMappingType
join #AlbumsToUpdate at on at.oldTier = pt.Id
--select * from #PriceTierMatch
--begin tran
update match set NewPriceTier = pt2.Id from #PriceTierMatch match join 
PriceTierMappingValue ptv on ptv.AlbumPrice = match.AlbumPrice and ptv.Currency = match.Currency
join priceTierMappingType pmt on pmt.id = ptv.PriceTierMappingType
join priceTierMappingValue ptv2 on ptv2.AlbumPrice = ptv.AlbumPrice and ptv2.Currency = ptv.Currency
join priceTierMappingType pmt2 on pmt2.id = ptv2.PriceTierMappingType
join priceTierMapping pm2 on pm2.PriceTierMappingValue = ptv2.ID
join priceTier pt2 on pt2.id = pm2.PriceTier
where pmt.Name = 'eBookAgencyPrice'
and pmt2.Name = 'eBook Price Tier'
--commit
--rollback
--begin tran

update fix set NewTier = match.NewPriceTier from #AlbumsToUpdate fix
join #PriceTierMatch match on match.priceTier = fix.oldTier
--select * from #AlbumsToUpdate 

--begin tran update pc set StartPriceTier = fix.NewTier from #AlbumsToUpdate fix
join album a on a.gtin = fix.gtin 
join priceCampaign pc on pc.album = a.id and pc.StartPriceTier = fix.oldTier


--commit

select a.gtin, pc.StartPriceTier, o.Name as Imprint from album a
join priceCampaign pc on pc.album = a.id
join priceTier pt on pt.id = pc.StartPriceTier
join priceTierMapping pm on pm.PriceTier = pt.id
join PriceTierMappingValue ptv on ptv.id = pm.PriceTierMappingValue
join priceTierMappingType pmt on pmt.id = ptv.PriceTierMappingType
join importLogEntry ile on ile.SourceId = a.gtin
join organization o on o.id = a.organization
where pmt.Name = 'eBookAgencyPrice'
and o.ID not in (select Org from xxx_AthenaMigratedOrgs)
union
select a.gtin, pc.StartPriceTier, o.Name as Imprint from album a
join priceCampaign pc on pc.album = a.id
join priceTier pt on pt.id = pc.StartPriceTier
join priceTierMapping pm on pm.PriceTier = pt.id
join PriceTierMappingValue ptv on ptv.id = pm.PriceTierMappingValue
join priceTierMappingType pmt on pmt.id = ptv.PriceTierMappingType
join importLogEntry ile on ile.SourceId = a.gtin
join organization o on o.id = a.organization
where pt.DescriptionKey like 'ebook_price_tier%'
and o.ID not in (select Org from xxx_AthenaMigratedOrgs)