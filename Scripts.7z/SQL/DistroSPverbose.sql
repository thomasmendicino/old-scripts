USE [AthenaDistribution]
GO

/****** Object:  StoredProcedure [dbo].[Distro]    Script Date: 02/19/2014 17:44:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[Distro]
	@isbn			bigint = '',
	@Retailer		nvarchar(30) = ''
	
AS
BEGIN
	SET NOCOUNT ON;
	

if @Retailer in (select Name from AthenaDistribution..Retailers UNION select SafeName as Name from AthenaDistribution..Retailers UNION select Code as Name from AthenaDistribution..Retailers)
	begin

;with maxAt as
(select max(dos.ProcessedAtUtc) At, do.DistributionOrderUid from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
left outer join AthenaDistribution..DistributionOrderStatus dos on dos.distributionOrderUId = do.distributionOrderUid
group by do.DistributionOrderUid)

select distinct do.DistributionOrderUid, p.Ordinal, pub.Name [ProductOwner], r.Name [Retailer], dos.ProcessedAtUtc, 
case when dos.ResultingEventLevel = 1 then 'Information' when dos.ResultingEventLevel = 2 then 'Warning' when dos.ResultingEventLevel = 3 then 'Error' end as DistEventLevel, 
ret.Code, 
case when ret2.EventLevelId = 1 then 'Information' when ret2.EventLevelId = 2 then 'Warning' when ret2.EventLevelId = 3 then 'Error' end as RuleResultLevel,
ret2.Code RuleResult, 
dos.ResultingMessage + ' / ' + isnull(ret2.Title, '- ?') EventString
from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
left outer join AthenaDistribution..DistributionOrderStatus dos on dos.distributionOrderUId = do.distributionOrderUid
join maxAt m on m.DistributionOrderUId = do.DistributionOrderUid and dos.ProcessedAtUtc = m.At
join AthenaEventLog..refEventType ret on ret.EventTypeId = dos.ResultingEvent
left outer join AthenaDistribution..DistributionOrderAcceptabilities doa on doa.distributionOrderUId = do.distributionOrderUid
left outer join AthenaEventLog..refEventType ret2 on ret2.EventTypeId = doa.ResultingEvent

where p.ordinal = @isbn
and (r.Name = @Retailer or r.SafeName = @Retailer or r.Code = @Retailer)
order by r.Name, dos.ProcessedAtUtc
end
else 
begin 

;with maxAt as
(select max(dos.ProcessedAtUtc) At, do.DistributionOrderUid from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
left outer join AthenaDistribution..DistributionOrderStatus dos on dos.distributionOrderUId = do.distributionOrderUid
group by do.DistributionOrderUid)

select distinct do.DistributionOrderUid, p.Ordinal, pub.Name [ProductOwner], r.Name [Retailer], dos.ProcessedAtUtc, 
case when dos.ResultingEventLevel = 1 then 'Information' when dos.ResultingEventLevel = 2 then 'Warning' when dos.ResultingEventLevel = 3 then 'Error' end as DistEventLevel, 
ret.Code, 
case when ret2.EventLevelId = 1 then 'Information' when ret2.EventLevelId = 2 then 'Warning' when ret2.EventLevelId = 3 then 'Error' end as RuleResultLevel,
ret2.Code RuleResult, 
dos.ResultingMessage + ' / ' + isnull(ret2.Title, '- ?') EventString
from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
left outer join AthenaDistribution..DistributionOrderStatus dos on dos.distributionOrderUId = do.distributionOrderUid
join maxAt m on m.DistributionOrderUId = do.DistributionOrderUid and dos.ProcessedAtUtc = m.At
join AthenaEventLog..refEventType ret on ret.EventTypeId = dos.ResultingEvent
left outer join AthenaDistribution..DistributionOrderAcceptabilities doa on doa.distributionOrderUId = do.distributionOrderUid
left outer join AthenaEventLog..refEventType ret2 on ret2.EventTypeId = doa.ResultingEvent

where p.ordinal = @isbn
order by r.Name, dos.ProcessedAtUtc
end

if @Retailer in (select Name from AthenaDistribution..Retailers UNION select SafeName as Name from AthenaDistribution..Retailers UNION select Code as Name from AthenaDistribution..Retailers)
	begin

select distinct do.DistributionOrderUid, p.Ordinal, pub.Name [ProductOwner], r.Name [Retailer],b.batchOrdinal,
case when bs.ResultingEventLevel = 1 then 'Information' when bs.ResultingEventLevel = 2 then 'Warning' when bs.ResultingEventLevel = 3 then 'Error' end as BatchEventLevel, 
bs.ProcessedAtUtc [BatchProcessedAtUtc], bs.ResultingMessage, ret2.Title [RuleResult]
from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
inner join AthenaDistribution..DistributionContracts dc on dc.contractUid = c.contractUid
inner join AthenaDistribution..DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
inner join AthenaDistribution..DistributionOrderStructureGroupBatches dsgb on dsgb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
inner join AthenaDistribution..batches b on b.batchUid = dsgb.batchUid
left outer join AthenaDistribution..batchStatus bs on bs.batchUid = b.batchUid
left outer join AthenaDistribution..DistributionOrderAcceptabilities doa on doa.distributionOrderUId = do.distributionOrderUid
left outer join AthenaEventLog..refEventType ret2 on ret2.EventTypeId = doa.ResultingEvent

where p.ordinal = @isbn
and (r.Name = @Retailer or r.SafeName = @Retailer or r.Code = @Retailer)
order by r.Name, b.BatchOrdinal, bs.ProcessedAtUtc
end
else 
begin 

select distinct do.DistributionOrderUid, p.Ordinal, pub.Name [ProductOwner], r.Name [Retailer],b.batchOrdinal,
case when bs.ResultingEventLevel = 1 then 'Information' when bs.ResultingEventLevel = 2 then 'Warning' when bs.ResultingEventLevel = 3 then 'Error' end as BatchEventLevel, 
bs.ProcessedAtUtc [BatchProcessedAtUtc], bs.ResultingMessage, ret2.Title [RuleResult]
from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
inner join AthenaDistribution..DistributionContracts dc on dc.contractUid = c.contractUid
inner join AthenaDistribution..DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
inner join AthenaDistribution..DistributionOrderStructureGroupBatches dsgb on dsgb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
inner join AthenaDistribution..batches b on b.batchUid = dsgb.batchUid
left outer join AthenaDistribution..batchStatus bs on bs.batchUid = b.batchUid
left outer join AthenaDistribution..DistributionOrderAcceptabilities doa on doa.distributionOrderUId = do.distributionOrderUid
left outer join AthenaEventLog..refEventType ret2 on ret2.EventTypeId = doa.ResultingEvent

where p.ordinal = @isbn
order by r.Name, b.BatchOrdinal, bs.ProcessedAtUtc
end

if @Retailer in (select Name from AthenaDistribution..Retailers UNION select SafeName as Name from AthenaDistribution..Retailers UNION select Code as Name from AthenaDistribution..Retailers)
	begin
    
select distinct b.batchUid, do.DistributionOrderUid, p.Ordinal, pub.Name [ProductOwner], r.Name [Retailer],b.batchOrdinal,
case when bs.ResultingEventLevel = 1 then 'Information' when bs.ResultingEventLevel = 2 then 'Warning' when bs.ResultingEventLevel = 3 then 'Error' end as BatchEventLevel, 
bs.ProcessedAtUtc [BatchProcessedAtUtc], bs.ResultingMessage
from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
inner join AthenaDistribution..DistributionContracts dc on dc.contractUid = c.contractUid
inner join AthenaDistribution..DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
inner join AthenaDistribution..DistributionOrderStructureGroupBatches dsgb on dsgb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
inner join AthenaDistribution..batches b on b.batchUid = dsgb.batchUid
left outer join AthenaDistribution..batchStatus bs on bs.batchUid = b.batchUid

where p.ordinal = @isbn
and (r.Name = @Retailer or r.SafeName = @Retailer or r.Code = @Retailer)
order by r.Name, b.BatchOrdinal, bs.ProcessedAtUtc

end
else
begin

select distinct b.batchUid, do.DistributionOrderUid, p.Ordinal, pub.Name [ProductOwner], r.Name [Retailer],b.batchOrdinal,
case when bs.ResultingEventLevel = 1 then 'Information' when bs.ResultingEventLevel = 2 then 'Warning' when bs.ResultingEventLevel = 3 then 'Error' end as BatchEventLevel, 
bs.ProcessedAtUtc [BatchProcessedAtUtc], bs.ResultingMessage
from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
inner join AthenaDistribution..DistributionContracts dc on dc.contractUid = c.contractUid
inner join AthenaDistribution..DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
inner join AthenaDistribution..DistributionOrderStructureGroupBatches dsgb on dsgb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
inner join AthenaDistribution..batches b on b.batchUid = dsgb.batchUid
left outer join AthenaDistribution..batchStatus bs on bs.batchUid = b.batchUid

where p.ordinal = @isbn
order by r.Name, b.BatchOrdinal, bs.ProcessedAtUtc

end

if @Retailer in (select Name from AthenaDistribution..Retailers UNION select SafeName as Name from AthenaDistribution..Retailers UNION select Code as Name from AthenaDistribution..Retailers)
	begin

;with maxAt as
(select max(dos.ProcessedAtUtc) At, do.DistributionOrderUid from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
left outer join AthenaDistribution..DistributionOrderStatus dos on dos.distributionOrderUId = do.distributionOrderUid
group by do.DistributionOrderUid)

select do.DistributionOrderUid, p.Ordinal, pub.Name [ProductOwner], r.Name [Retailer],
case when dos.ResultingEventLevel = 1 then 'Information' when dos.ResultingEventLevel = 2 then 'Warning' when dos.ResultingEventLevel = 3 then 'Error' end as EventLevel, 
dos.ProcessedAtUtc, dos.ResultingMessage, ret.Code, ret.Title,
case when m.At is not null then 'Latest DistOrder'
when m.At is null then 'Old' end as [History] from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
left outer join AthenaDistribution..DistributionOrderStatus dos on dos.distributionOrderUId = do.distributionOrderUid
left outer join maxAt m on m.DistributionOrderUId = do.DistributionOrderUid and dos.ProcessedAtUtc = m.At
join AthenaEventLog..refEventType ret on ret.EventTypeId = dos.ResultingEvent

where p.ordinal = @isbn
and (r.Name = @Retailer or r.SafeName = @Retailer or r.Code = @Retailer)
order by r.Name, dos.ProcessedAtUtc

end
else
begin

;with maxAt as
(select max(dos.ProcessedAtUtc) At, do.DistributionOrderUid from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
left outer join AthenaDistribution..DistributionOrderStatus dos on dos.distributionOrderUId = do.distributionOrderUid
group by do.DistributionOrderUid)

select do.DistributionOrderUid, p.Ordinal, pub.Name [ProductOwner], r.Name [Retailer],
case when dos.ResultingEventLevel = 1 then 'Information' when dos.ResultingEventLevel = 2 then 'Warning' when dos.ResultingEventLevel = 3 then 'Error' end as EventLevel, 
dos.ProcessedAtUtc, dos.ResultingMessage, ret.Code, ret.Title,
case when m.At is not null then 'Latest DistOrder'
when m.At is null then 'Old' end as [History] from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
left outer join AthenaDistribution..DistributionOrderStatus dos on dos.distributionOrderUId = do.distributionOrderUid
left outer join maxAt m on m.DistributionOrderUId = do.DistributionOrderUid and dos.ProcessedAtUtc = m.At
join AthenaEventLog..refEventType ret on ret.EventTypeId = dos.ResultingEvent

where p.ordinal = @isbn
order by r.Name, dos.ProcessedAtUtc

end

END
GO


