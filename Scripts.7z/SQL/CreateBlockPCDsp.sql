USE [AthenaDistribution]
GO

/****** Object:  StoredProcedure [dbo].[BlockPCD]    Script Date: 12/9/2014 11:01:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [dbo].[BlockPCD]
	@Bit			nvarchar(5) = ''

	AS
BEGIN
	SET NOCOUNT ON;

	
declare @publisherName nvarchar(100)
declare @publisherUid uniqueidentifier
declare @INXRetailer table (Name nvarchar(50))
declare @ruleSetUid uniqueidentifier
declare @ruleSetUid2 uniqueidentifier

	IF @Bit = 'ON'

	BEGIN

set @publisherName = 'Scholastic Inc.'
select @publisherUid = publisherUid from AthenaDistribution..Publishers where name = @publisherName
insert @INXRetailer (Name) select Name from Retailers where Code = 'INX'
select @ruleSetUid = RuleSetUid from AthenaDistribution..ruleSets where Name = 'Onix Feed rules'
select @ruleSetUid2 = RuleSetUid from AthenaDistribution..ruleSets where Name = 'Distribution Prohibited'

update c set ValidUntilUtc = getUTCdate() from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @INXRetailer)
and c.RuleSetUid = @ruleSetUid
and c.ValidUntilUtc is NULL

update c set ValidUntilUtc = NULL from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @INXRetailer)
and c.RuleSetUid = @ruleSetUid2
and c.ValidFromUtc = '2014-05-30 06:09:28.453'

--This isn't the best approach
--insert AthenaAssetProcessor..ImportFolderConfigurationLocks (ImportFolderConfigurationUid, CreatedAtUtc)
--select ImportFolderConfigurationUid, GetUTCDate() from AthenaAssetProcessor..ImportFolderConfigurations where Name = 'FTP: Scholastic Inc.'
update AthenaAssetProcessor..ImportFolderConfigurations SET ExternalDropHost = NULL WHERE SafeName = 'FtpScholastic'

PRINT 'Scholastic Inc. will NOT go to the PCD Feed now, you may upload Apple-only titles'
	END

	IF @Bit = 'OFF'

	BEGIN
	
set @publisherName = 'Scholastic Inc.'
select @publisherUid = publisherUid from AthenaDistribution..Publishers where name = @publisherName
insert @INXRetailer (Name) select Name from Retailers where Code = 'INX'
select @ruleSetUid = RuleSetUid from AthenaDistribution..ruleSets where Name = 'Onix Feed rules'
select @ruleSetUid2 = RuleSetUid from AthenaDistribution..ruleSets where Name = 'Distribution Prohibited'

IF EXISTS (select 1 from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @INXRetailer)
and c.RuleSetUid = @ruleSetUid
and c.ValidUntilUtc is NULL)
BEGIN
DELETE il from AthenaAssetProcessor..ImportFolderConfigurationLocks il
inner join AthenaAssetProcessor..ImportFolderConfigurations ic on ic.importFolderConfigurationUid = il.ImportFolderConfigurationUId
where ic.Name = 'FTP: Scholastic Inc.'
PRINT 'Scholastic Inc. will go to the PCD Feed now, DO NOT deliver Apple-only titles!!'
END
ELSE
BEGIN
update c set ValidUntilUtc = getUTCdate() from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @INXRetailer)
and c.RuleSetUid = @ruleSetUid2
and c.ValidUntilUtc is NULL

;with mostRecentProhibited as
(select max(c.ValidUntilUtc) ValidUntilUtc, c.retailerUid from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @INXRetailer)
and c.RuleSetUid = @ruleSetUid
group by c.publisherUid, c.retailerUid, c.ruleSetUid
)
update c set ValidUntilUtc = NULL from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostRecentProhibited m on m.ValidUntilUtc = c.ValidUntilUtc and c.RetailerUid = m.retailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @INXRetailer)
and c.RuleSetUid = @ruleSetUid

--DELETE il from AthenaAssetProcessor..ImportFolderConfigurationLocks il
--inner join AthenaAssetProcessor..ImportFolderConfigurations ic on ic.importFolderConfigurationUid = il.ImportFolderConfigurationUId
--where ic.Name = 'FTP: Scholastic Inc.'

update AthenaAssetProcessor..ImportFolderConfigurations SET ExternalDropHost = 'ftp' WHERE SafeName = 'FtpScholastic'

PRINT 'Scholastic Inc. will go to the PCD Feed now, DO NOT deliver Apple-only titles!!'
	END
	END

	IF @Bit not in ('ON','OFF') 
	
	BEGIN

	PRINT 'Please only use ''ON'' or ''OFF'' as the arguments for this stored procedure'
	
	END

	END




GO


