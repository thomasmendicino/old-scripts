select distinct album.name as [Album Name], album.gtin as [Album UPC], s.name as [Song Name], s.ISRC as [Song ISRC], c.name as [Artist] from arearestriction ar
inner join album on ar.album = album.id
inner join albumproducttype apt on album.id = apt.album
left join track t on album.id = t.album
left join song s on t.song = s.id
left join albumcelebrity ac on album.id = ac.album
left join songcelebrity sc on sc.song = s.id
left join celebrity c on sc.celebrity = c.id or ac.celebrity = c.id or album.celebrityperformer = c.id
where ar.country = 44
and ar.operator = '+'
and apt.producttype in (3)
group by album.name, album.gtin, s.name, s.isrc, c.name
order by album.name

select * from encodingstructure where name like '%umg%'
select * from encodingstructureconfiguration where encodingstructure in (119)
select * from encodingconfiguration where id in (27,104)

select * from album where gtin = '00602527829104'
select * from album where gtin = '00602527829029'
select * from track where album = (select id from album where gtin = '00602527829104')
select * from track where album = (select id from album where gtin = '00602527829029')
select path, * from song where id = (select song from track where album = (select id from album where gtin = '00602527829104'))
select path, * from song where id = (select song from track where album = (select id from album where gtin = '00602527829029'))

select * from tracksyndication where track = (select id from track where album = (select id from album where gtin = '00602527829104'))
select * from syndication where id in (select syndication from tracksyndication where track = (select id from track where album = (select id from album where gtin = '00602527829104')))
select * from syndication where id in (select syndication from tracksyndication where track = (select id from track where album = (select id from album where gtin = '00602527829029')))

select * from syndication where id = 234358
select * from syndicationorder where id =  86599 syndication in (236351)
select * from syndicationordereventlog where syndicationorder in (86599) order by at desc ,86607)
select * from 
1 errors: 1:'Cannot transcode recording from .wav to .flac', '\\\Colo-Master\UMG Affiliates\Mobile\2011\September\2011-09-08\053319\00602527829104\00602527829104_30.wav'; 

select * from song where 

select * from song where isrc = 'USUM71111991'
select * from song where isrc = 'USUM71111998'

select top 50 * from importlog where sourcedata like '%00602527829104%'
select * from importlogentry where importlog in (314082,314251,314388)
select * from importitemtype
USUM71111991
select * from song where isrc = 'USUM71113480'

select * from syndicationordereventlog where message like '%\\\Colo-Master\UMG Affiliates\Mobile%'

select s.syndicationlevel, * from syndicationorder so
join syndication s on so.syndication = s.id
where partnername like '%ringtone%' order by submissiondate desc

select * from syndication where id = 237899

select * from encodingprofile

select * from syndicationorder where partnername = 'muzak'
select * from syndicationordereventlog where syndicationorder in (select id from syndicationorder where partnername = 'muzak') and orderstate in (11,6) order by syndicationorder, at

select top 200 * from ingrooveslog.dbo.log where message like '%watermark%'

select * from album where gtin like '%00602527829104%'
select * from track where albu

select * from syndicationorder order by

UMG Affiliates\Mobile\2011\September\2011-09-08\053319\00602527829104\meta.xml
UMG Affiliates\Mobile\2011\September\2011-09-09\053816\00602527829104\meta.xml
UMG Affiliates\Mobile\2011\September\2011-09-09\123630\00602527829104\meta.xml

(select * from musicservice where name like '%airport%')
select * from musicservicetransfersettings where musicservice = (select id from musicservice where name = 'music airport')

select * from assets where r2isrc = 'UMGIM26272'

select * from assets where r2isrc like '%06UMGIM26272%'