(@OrganizationUid nvarchar(36),@eISBNList nvarchar(4000),@DateRangeStart datetime,@DateRangeEnd datetime,@OnSaleDateRangeStart nvarchar(4000),@OnSaleDateRangeEnd nvarchar(4000),@eISBNs nvarchar(4000))/*--*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE N'bcb943a8-8d9d-4817-aa96-7815a66ec1c6',N'52d2d75b-5122-4e9e-a968-1386ac41da88',N'485f4f9b-e2a5-4057-8cf8-bc3809d3f5cf',N'78e84d76-ea31-406a-ab89-86b4500a821e' NVARCHAR(MAX)
DECLARE N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' NVARCHAR(MAX)
DECLARE N'Fixed',N'Reflowable',N'Not Specified' NVARCHAR(MAX)

SELECT top 1 N'bcb943a8-8d9d-4817-aa96-7815a66ec1c6',N'52d2d75b-5122-4e9e-a968-1386ac41da88',N'485f4f9b-e2a5-4057-8cf8-bc3809d3f5cf',N'78e84d76-ea31-406a-ab89-86b4500a821e' = o.OrganizationUid from Organizations o where o.OrganizationName Like '%Disney%'
SET @DateRangeStart = NULL
SET @DateRangeEnd = NULL
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL
SELECT top 1 N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' = r.RetailerUid from Retailers r where r.Name = '3M'

SET @eISBNs = NULL
SET @eISBNList = NULL
SET N'Fixed',N'Reflowable',N'Not Specified' = 'Not Specified';

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

IF OBJECT_ID('tempdb..#ErrorMessages') IS NOT NULL
    DROP TABLE #ErrorMessages
*/

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
    pub.Name AS Publisher,
    cast(p.Ordinal as varchar(20)) AS ISBN,
    p.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	DistributionOrderStatus dos
	INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN Product p ON p.ProductUid = pr.ProductUid
	INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
WHERE
    pub.OrganizationUid IN (N'bcb943a8-8d9d-4817-aa96-7815a66ec1c6',N'52d2d75b-5122-4e9e-a968-1386ac41da88',N'485f4f9b-e2a5-4057-8cf8-bc3809d3f5cf',N'78e84d76-ea31-406a-ab89-86b4500a821e')                           -- Part of the selected publisher hierarchy
    AND (@eISBNs IS NULL OR cast(p.Ordinal as varchar(20)) IN (@eISBNList)) -- In the List of supplied ISBNs
    AND r.retailerUid IN (N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec')
GROUP BY
	pub.Name,
    p.ProductUid,
    p.Ordinal,
    r.Name,
    r.RetailerUid
HAVING                                                                      -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	do.DistributionOrderUid
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
    CROSS APPLY 
        (SELECT 
             TOP 1 ResultingEvent
         FROM	
		     DistributionOrderAcceptabilities 
		 WHERE
	         DistributionOrderUid = do.DistributionOrderUid
	     ORDER BY  
	         CreatedAtUtc DESC) doa
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = doa.ResultingEvent
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleElementLevel = 1                          -- Product Level
    AND CASE pfd.ProductFormDetailValue 
            WHEN 190 THEN 'Fixed' 
            WHEN 189 THEN 'Reflowable'
            ELSE 'Not Specified' END IN (N'Fixed',N'Reflowable',N'Not Specified')
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))

SELECT DISTINCT
	ds2.DistributionOrderUid,
	stuff((
		SELECT CHAR(10) + CHAR(10) + SUBSTRING(ds1.ResultingMessage, 0, 2048)
			+ CASE WHEN len(ds1.ResultingMessage) > 2048 THEN '...' ELSE '' END
		FROM DistributionOrderStatus ds1
		WHERE ds1.DistributionOrderUid = ds2.DistributionOrderUid AND ds1.ResultingEventLevel > 2
		FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS ErrorMessage
INTO
	#ErrorMessages
FROM
	DistributionOrderStatus ds2
	INNER JOIN #DistributionDataset dd on dd.DistributionOrderUid = ds2.DistributionOrderUid
WHERE
	ds2.ResultingEventLevel > 2
 
SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    FailedDate,
    ReasonCode,
    em.ErrorMessage as ReasonDetail
FROM
    #DistributionDataset dd
	INNER JOIN #ErrorMessages em ON em.DistributionOrderUid = dd.DistributionOrderUid
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC,
    ReasonCode
    
    
    
    
    
    
    
    
    
(@OrganizationUid nvarchar(36),@eISBNList nvarchar(4000),@DateRangeStart datetime,@DateRangeEnd datetime,@OnSaleDateRangeStart nvarchar(4000),@OnSaleDateRangeEnd nvarchar(4000),@eISBNs nvarchar(4000))/*--*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE N'4fd43933-a501-4026-8f76-28bffbe54232',N'640b0b16-9c90-4b6c-b402-fb6338f04407',N'2759911d-461e-4075-b86c-c7f288cc7b24',N'05330ee8-9da8-4be5-8a03-73adbb517413',N'6cae0041-c00c-4b6f-ba7c-d910fc389876',N'3506f29a-9ab3-4c40-8d21-228c04a43dfb',N'd0f5649b-8f5a-4537-9f11-1e5fe09c52b1',N'2630c94c-e874-419c-8da8-c15fdec51408',N'a281acdc-740e-465b-b71e-3701b8766ef3',N'fd30bd4c-b4f4-4d97-8f33-291b804ad15d',N'd0c23401-c7b8-4924-b58d-3ccd381b318a',N'b69da51b-cd24-4bab-bd9d-d65ca1b9756b',N'ecb61548-3e98-4d56-abb9-884e16839102',N'b84672c5-2784-48e4-9129-7064b1d296fe',N'2fe8d89b-568e-46ab-a45b-20dc533c9c06',N'53611a1f-b09b-4b68-a8be-bb8159cb8583',N'1bf3630a-84c1-4250-83d3-461600bb17c4',N'2a86d9f0-6574-47ea-bead-35509ab8c983',N'1d66e68f-b02b-4d75-b65f-597190db8844',N'f72739a1-a240-499b-9fe3-cb148cf4ed74',N'cbf5fcf5-00bc-4a40-8995-93a4c0d699bc',N'c476c21c-91dc-4edb-b7bd-10d0cb88affb' NVARCHAR(MAX)
DECLARE N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' NVARCHAR(MAX)
DECLARE N'Fixed',N'Reflowable',N'Not Specified' NVARCHAR(MAX)

SELECT top 1 N'4fd43933-a501-4026-8f76-28bffbe54232',N'640b0b16-9c90-4b6c-b402-fb6338f04407',N'2759911d-461e-4075-b86c-c7f288cc7b24',N'05330ee8-9da8-4be5-8a03-73adbb517413',N'6cae0041-c00c-4b6f-ba7c-d910fc389876',N'3506f29a-9ab3-4c40-8d21-228c04a43dfb',N'd0f5649b-8f5a-4537-9f11-1e5fe09c52b1',N'2630c94c-e874-419c-8da8-c15fdec51408',N'a281acdc-740e-465b-b71e-3701b8766ef3',N'fd30bd4c-b4f4-4d97-8f33-291b804ad15d',N'd0c23401-c7b8-4924-b58d-3ccd381b318a',N'b69da51b-cd24-4bab-bd9d-d65ca1b9756b',N'ecb61548-3e98-4d56-abb9-884e16839102',N'b84672c5-2784-48e4-9129-7064b1d296fe',N'2fe8d89b-568e-46ab-a45b-20dc533c9c06',N'53611a1f-b09b-4b68-a8be-bb8159cb8583',N'1bf3630a-84c1-4250-83d3-461600bb17c4',N'2a86d9f0-6574-47ea-bead-35509ab8c983',N'1d66e68f-b02b-4d75-b65f-597190db8844',N'f72739a1-a240-499b-9fe3-cb148cf4ed74',N'cbf5fcf5-00bc-4a40-8995-93a4c0d699bc',N'c476c21c-91dc-4edb-b7bd-10d0cb88affb' = o.OrganizationUid from Organizations o where o.OrganizationName Like '%Disney%'
SET @DateRangeStart = NULL
SET @DateRangeEnd = NULL
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL
SELECT top 1 N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' = r.RetailerUid from Retailers r where r.Name = '3M'

SET @eISBNs = NULL
SET @eISBNList = NULL
SET N'Fixed',N'Reflowable',N'Not Specified' = 'Not Specified';

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

IF OBJECT_ID('tempdb..#ErrorMessages') IS NOT NULL
    DROP TABLE #ErrorMessages
*/

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
    pub.Name AS Publisher,
    cast(p.Ordinal as varchar(20)) AS ISBN,
    p.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	DistributionOrderStatus dos
	INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN Product p ON p.ProductUid = pr.ProductUid
	INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
WHERE
    pub.OrganizationUid IN (N'4fd43933-a501-4026-8f76-28bffbe54232',N'640b0b16-9c90-4b6c-b402-fb6338f04407',N'2759911d-461e-4075-b86c-c7f288cc7b24',N'05330ee8-9da8-4be5-8a03-73adbb517413',N'6cae0041-c00c-4b6f-ba7c-d910fc389876',N'3506f29a-9ab3-4c40-8d21-228c04a43dfb',N'd0f5649b-8f5a-4537-9f11-1e5fe09c52b1',N'2630c94c-e874-419c-8da8-c15fdec51408',N'a281acdc-740e-465b-b71e-3701b8766ef3',N'fd30bd4c-b4f4-4d97-8f33-291b804ad15d',N'd0c23401-c7b8-4924-b58d-3ccd381b318a',N'b69da51b-cd24-4bab-bd9d-d65ca1b9756b',N'ecb61548-3e98-4d56-abb9-884e16839102',N'b84672c5-2784-48e4-9129-7064b1d296fe',N'2fe8d89b-568e-46ab-a45b-20dc533c9c06',N'53611a1f-b09b-4b68-a8be-bb8159cb8583',N'1bf3630a-84c1-4250-83d3-461600bb17c4',N'2a86d9f0-6574-47ea-bead-35509ab8c983',N'1d66e68f-b02b-4d75-b65f-597190db8844',N'f72739a1-a240-499b-9fe3-cb148cf4ed74',N'cbf5fcf5-00bc-4a40-8995-93a4c0d699bc',N'c476c21c-91dc-4edb-b7bd-10d0cb88affb')                           -- Part of the selected publisher hierarchy
    AND (@eISBNs IS NULL OR cast(p.Ordinal as varchar(20)) IN (@eISBNList)) -- In the List of supplied ISBNs
    AND r.retailerUid IN (N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec')
GROUP BY
	pub.Name,
    p.ProductUid,
    p.Ordinal,
    r.Name,
    r.RetailerUid
HAVING                                                                      -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	do.DistributionOrderUid
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
    CROSS APPLY 
        (SELECT 
             TOP 1 ResultingEvent
         FROM	
		     DistributionOrderAcceptabilities 
		 WHERE
	         DistributionOrderUid = do.DistributionOrderUid
	     ORDER BY  
	         CreatedAtUtc DESC) doa
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = doa.ResultingEvent
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleElementLevel = 1                          -- Product Level
    AND CASE pfd.ProductFormDetailValue 
            WHEN 190 THEN 'Fixed' 
            WHEN 189 THEN 'Reflowable'
            ELSE 'Not Specified' END IN (N'Fixed',N'Reflowable',N'Not Specified')
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))

SELECT DISTINCT
	ds2.DistributionOrderUid,
	stuff((
		SELECT CHAR(10) + CHAR(10) + SUBSTRING(ds1.ResultingMessage, 0, 2048)
			+ CASE WHEN len(ds1.ResultingMessage) > 2048 THEN '...' ELSE '' END
		FROM DistributionOrderStatus ds1
		WHERE ds1.DistributionOrderUid = ds2.DistributionOrderUid AND ds1.ResultingEventLevel > 2
		FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS ErrorMessage
INTO
	#ErrorMessages
FROM
	DistributionOrderStatus ds2
	INNER JOIN #DistributionDataset dd on dd.DistributionOrderUid = ds2.DistributionOrderUid
WHERE
	ds2.ResultingEventLevel > 2
 
SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    FailedDate,
    ReasonCode,
    em.ErrorMessage as ReasonDetail
FROM
    #DistributionDataset dd
	INNER JOIN #ErrorMessages em ON em.DistributionOrderUid = dd.DistributionOrderUid
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC,
    ReasonCode
    
    
    
    
    
    
    
    
(@OrganizationUid nvarchar(36),@eISBNList nvarchar(4000),@DateRangeStart datetime,@DateRangeEnd datetime,@OnSaleDateRangeStart nvarchar(4000),@OnSaleDateRangeEnd nvarchar(4000),@eISBNs nvarchar(4000))/*--*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE N'00000000-0000-0000-0000-000000000001',N'9e1d8850-532d-4704-a6af-3c8bf6dc7ee2',N'033a2f8b-a8dc-43ae-9e19-52dac8583e47',N'34e662d8-2442-45e4-ae57-12ac7c7e052a',N'cc382f86-6202-4b47-9628-62785ec8f077',N'3156cd0d-8fe4-446c-9491-482b0eecf888',N'601c0538-6e12-4873-b42d-e6fedbd794e6',N'65080660-f9a0-485e-92a2-5cf4a30854e6',N'4b02a28d-b7f7-424a-9cea-700ffea500be',N'e2c22698-8568-4a0e-8c03-1705b7e58a5c',N'34e2d303-0047-42e0-b998-944123185253',N'60dffe08-0702-4d1f-895e-9fc5cd57f31c',N'cec3ad29-04f4-4d17-9b8e-671acd0c06b7',N'4bd075e4-aeee-4870-8ff0-071cb0fda1e1',N'b24d6145-a9d9-4824-865c-4b741ac8b682',N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'7d6f4bea-a88c-463a-a819-0de4ac579fa7',N'461f4a2c-49d0-4abc-a2b0-05de1eceb702',N'd824d549-b51b-4ca2-af82-c44e0d3eec2a',N'6fbcf580-b152-482d-aa90-076a5ea94cf7',N'3c7ebaa4-b5b8-425a-a6f6-227c223c34e5',N'84178d32-0d90-4225-a1fb-264f80bfdde2',N'e17dc831-1298-4d5e-b3ce-dc68e2b5bf8a',N'4155ea72-57d1-471e-997f-1376915123f6',N'4c64a71a-cbf1-4446-ac41-bf311db56c84',N'b65e3ef8-3fe6-497d-bd98-8a764cd99c36',N'6fedfc6c-665d-466d-99ca-f8b01f7f396b',N'7feee485-eaf2-4be0-a93b-ed47a8a56ba7',N'9da90633-45b3-4334-a354-05a6b7fa215c',N'7096f34a-2550-48db-9ab4-65e951bb5534',N'1bbfda54-2c6f-4610-9321-f3ae69042b72',N'c3d0f950-024b-433b-8eba-fadfe9d6ba1b',N'4ad5ec58-7ade-4698-941f-a5da1581b893',N'617dfafc-9abf-4d30-b102-cec2cbdfbe6a',N'ebf4660c-910e-4968-9830-e70e9098318d',N'49cf026a-b5b4-4cad-9562-c786812b4bac',N'50508138-193c-4ddc-b69d-862ddb327715',N'b32de4ae-bae0-4908-8ab8-e9159ba71dd4',N'9167e9b0-0742-40c7-8526-e33ac183ebc3',N'20e9d77b-3eb9-4738-8fe1-403ba3b8a8c4',N'b8d66d8b-19de-4d00-bfb7-ded50cc12993',N'd0e0ea4a-e5fa-4b01-8b49-259202a6f1c4',N'3dabbd28-8cf7-45cb-8746-2d0ecd36838c',N'52bd4016-6e7c-4cdb-9d62-27b239e311ad',N'bcb943a8-8d9d-4817-aa96-7815a66ec1c6',N'89a2e8c7-74b4-49d4-bded-fd26ce4902d1',N'77727f05-a7b9-4791-91d1-2d9ca517b6c6',N'9fd6f976-757a-451d-81dc-ae6320dd2493',N'22336ee6-d869-4f2b-8110-647da99705a5',N'd8f06d0d-1832-4041-a672-2efc10fe1079',N'f4a8c921-f34a-4801-8036-968387958f22',N'39e4446b-5bfb-42d4-b0b0-acc5d598ac57',N'f3107f10-0e13-47ba-a75b-9e4b8e6c8df2',N'e2ceacee-9ddd-4b02-833a-b5c49850edaf',N'672fcfa0-3980-47fd-aae3-fb9fb27c2f1c',N'26b30ffe-3f2e-4039-ac03-4e2c2bc3b3bc',N'289ed3fc-a5b1-4b30-b501-e15252595d9f',N'42728bae-b714-4058-a5b2-ab055c944fa6',N'cadcfd90-7b7c-48f6-842d-d0c1e43b2cbc',N'd5db010f-0a0f-47fb-8a0b-0492a48be589',N'cd9cd64f-5a0d-4e09-9895-543f5a43b7e4',N'82827812-e0e0-4f5d-be97-08e6caa150a1',N'3bb141df-c93e-483c-bb89-eb69ed428a66',N'a249a835-f7a4-4427-b93a-8554cefd8bd1',N'5a3258e8-5676-48ff-90c6-7858a0a9a650',N'2a07c5df-5f7e-4ed6-af86-6f3077ff6b3c',N'f83002d4-4ed1-4672-9b33-36e0e87970e4',N'8e42003e-ac6e-4b8b-bb76-78bec1b8d3ab',N'4928b4f9-7910-4c95-9e29-9e51436c6162',N'bacecb01-af5b-4bfd-b138-bb09e78d525a',N'a1e048b4-5e1e-4333-b1c1-6785c197724c',N'dc7765b1-684c-48fa-99df-67ae95ca7ad5',N'dbb9007f-99a8-4bb0-a4bc-ccd7900acd83',N'2b6e1316-a38f-4e06-b4da-f5d71033ee59',N'414cfa83-1c43-4911-993a-b5ff717be5a2',N'f8f04ac8-060b-4274-b80d-1dba1296c66e',N'29020f77-33d7-4a03-82a9-2e8e9733380c',N'83f6b3e3-f62b-43a6-80e1-92c6cc322bb8',N'07bb6b31-3c59-4473-aecf-c8b23c106da6',N'e3cb6a8e-47ad-40c4-b6dd-d95231d1a31a',N'1cde0f88-721b-486f-9d49-b2c002e67145',N'c7993c99-86fd-4f2e-ae9a-8f7afe6f4ed5',N'ca0c91ab-46a4-41cd-bd0b-b46aba477488',N'68f00a4d-f956-43a9-983e-85a18723a8df',N'97d2c33b-c129-41d6-b530-6f0e6dbc64cb',N'c7f6bf63-2c7c-45b6-9d95-832d2ad2a42f',N'8822c822-191f-489d-ac76-94d48e913cfd',N'd21c0b77-501c-4aed-9bcc-73c8d59ae480',N'fb6b6ed0-d317-4124-84b1-c4844cf3ce15',N'953cfdeb-7a52-4e72-b9cb-fde5e3f8099a',N'0d6f2fa4-296b-4f12-bf40-57cd9f57b693',N'b47aa600-3e54-4f2c-bdb7-055221f44304',N'44f0637e-a057-4eb4-ba6a-b0971df41948',N'eddcdebd-e558-4e97-a9bf-77e03384c52a',N'49802113-a867-402d-9d4b-ca760bef0296',N'924fffb6-e2d5-4026-b901-f7aed89272e4',N'6f60a4a2-fd6e-4524-88c2-ed3d7066d49b',N'e6ebfdf4-78bb-44b6-93f7-0e19a00d081c',N'b5e519d9-a058-4748-840a-fad7e8089e70',N'79506cab-8cfa-42a0-863c-774f2edf24ce',N'7e1148a0-aa6c-466d-8f94-4a0f075be79f',N'190179f3-f941-463b-93d6-897caa28534a',N'b8584579-e654-4df2-8fd2-24c6ebc6dfc4',N'9d937936-8ebf-4a5d-bc79-14a07d7be161',N'de233059-74f3-40b4-ad3d-ae1662ca0a4b',N'8ffd404e-17ba-4bd3-8cac-f813550960eb',N'2dedea11-6681-4010-8f09-5f9cdc85eddb',N'4a0a4157-591d-4090-b508-ce4708cd3f0d',N'cbc8b551-389b-45de-a81f-a404c8e159bb',N'c9650b7b-3d5c-40ea-a0ed-cadad3ef0c6b',N'2c13e4ce-983a-4dbe-abe1-3208a6435a3e',N'7dbf26ce-9d95-48a0-aa2c-e67ecb066115',N'93c57340-fdb8-4b7f-a118-d792471c1611',N'273c8054-7f00-44b5-bae3-ae6ae30e7861',N'e990c4b6-6412-4d12-81f2-a19e0719b8dd',N'98a0fa96-b325-4737-a753-5e2290c3876a',N'6246e9b8-2a37-43b7-95ba-3edbb5902618',N'17e29299-63e2-45f4-a3b3-0611bc7eb647',N'b7d1f672-f2b1-4993-9de5-09d4b14e45a7',N'0d361f3e-2017-474c-8458-f8504e38eaf1',N'c14f54f7-56e6-4dd5-9682-4590e0ca28af',N'43ef6457-a5c3-4942-b2a9-99113e68c650',N'2d1d5fa9-fee9-41a8-8a71-ae5b44cc349e',N'3fa65e4d-89ea-4b9d-9e38-297c5b652fc9',N'3666fa07-6217-49e9-a213-069744777424',N'236bddde-ce50-4c00-989c-fbba59ff3459',N'4d457516-98f8-4c3e-9b31-2ab3c3c4c457',N'4586517d-d831-4da0-870a-1938e1962cb0',N'5453afd6-9808-4178-ab93-6156a2cb37a0',N'd65a0143-05e3-4c98-aac6-13e20de21eeb',N'fca143df-e41e-45b6-816a-162454bd8d05',N'4fd43933-a501-4026-8f76-28bffbe54232',N'9450ef7c-e537-4747-bdca-f88ba25c1133',N'1f913e66-ef8a-46d0-96d2-7d19f8310401',N'86c459b1-002f-4bf4-8a65-cd2a23925af0',N'eb33d408-ac1b-4e09-ab87-544896222cbc',N'7f7ec4e6-3987-4c18-be5b-de37e581e4e4',N'c54b1eea-dfda-4aab-b414-a1acbd4be784',N'f5f84e6a-f3ae-481a-a730-992416220a71',N'0034d4ef-be7f-446b-9971-69bd6939cf39',N'eb8acfc6-bb6c-4d2b-939f-391b17913cfd',N'feaf81f8-2dbd-49a3-96d2-e2c47fa3ba37',N'1c7b16d6-8637-49cd-8114-b69664ac5a40',N'98b1bc08-50b4-4ca1-a351-62b0735e9e8e',N'bc7b02d8-2c0b-44b6-83df-0e7b1ebd4330',N'72b6849f-422d-40de-86be-94f67271928d',N'3e725b22-ab4a-40c9-a1c2-16a15de4ce26',N'de63b1f1-a1a3-4c25-a6c2-e506250752dc',N'65ccd475-c44d-461b-af6c-6ad257fe1bef',N'a4e6e850-3f0f-4513-8f26-9bf19231771c',N'6a517183-44b0-40d1-a007-4ab9075735f6',N'cb4127f4-2501-4793-9c85-c38400168f5d',N'db5f7473-31dd-409b-9bf2-2653cc3e17fb',N'f7b53948-328a-4725-b0af-a2922e796664',N'd85a561a-7658-4b28-baca-6c496252cb6d',N'287caec9-caf4-48a1-a723-a2103b387208',N'f7221fdc-8b5f-4846-9711-9fcaed834ec2',N'08295f7f-e71d-4b7e-a696-3414e5404db7',N'fa856430-70d8-436d-a3a5-4eadd059482b',N'adedd8f5-c46d-4ffd-afb7-8e4e4d424dc7',N'ca3fa091-47c8-449b-a4c1-05c3dcfb203c',N'4c53dd59-fea0-47f7-b36a-929b957b7143',N'0b268bd7-327b-47fe-b0f4-ac8d99e94a5f',N'7b76e8a5-f954-4b00-be13-51f6cf8ceb6f',N'5b4edec6-d924-47df-a48b-3480c66e3b7f',N'8e29b1cd-473a-4d28-942f-5951333be1a1',N'69e6c615-892c-41e1-b67b-b534c27b3573',N'e2123171-16b9-47c2-892d-0520e3995b05',N'd31a59c7-ec53-47f6-866f-04cc85cfa692',N'f99d270f-eb28-4055-8122-27699cb657a8',N'b013860d-f12d-4e7b-ac2b-06ffa851d91b',N'0eb5ecf2-31ff-491f-adaf-307b1fb4eff9',N'75abb883-c676-489d-8128-3ac75b10f8b3',N'2d59c58e-4271-4ad8-8966-5dac3fd35124',N'1e2cc5a2-04a6-4b80-baab-155391a602a4',N'd5d41892-4d5f-4bc7-898c-55271c9244a9',N'433c4095-b92e-4f54-83c9-5b21b745416f',N'61cafc49-6352-4ebe-8872-8b5fd5130d27',N'c173986a-cece-453b-80df-e5f2211828ac',N'c0417f85-1a67-45e7-8f76-93b1d1714dc8',N'2239748e-1282-4073-923f-6f76103b1240',N'58f7a68f-8ae1-4397-8d9c-3574a0ccc6a8',N'd9341d36-43f8-4d2d-a775-9d603f0c3ca4',N'6f389fc1-2e6e-460e-9c43-0ffdf404b829',N'4fb43d31-b368-46c2-997d-1fc73420caf9',N'fcde6da5-8b57-485f-ba22-fd1f52be6265',N'61aee3cc-52a7-48c5-83b5-2f291bb94b11',N'7595235f-ef3e-46b0-9137-0bbe563f161b',N'ce77bef8-f6cb-43b4-b66b-e9a234c05600',N'6ad8eaa2-8155-43c6-9f14-a0868f87c71f',N'1079e393-dad2-4e8a-810a-0f500750d9b0',N'39aee0ab-5735-4996-84dc-6ff204d44098',N'2163b2e6-5152-4171-b0f7-012dfd8461d6',N'c9d31d69-9b47-40fb-9196-a323f1e9cba0',N'98987454-af33-4b40-a2f1-b09e249ced32',N'924b19c3-d3ce-4e4c-8f98-6c7218ae5b0a',N'a434e361-2c56-44ec-9c37-a57f241a94c6',N'03f72b09-6c90-48a6-be5e-13c19f662500',N'2fde1c24-6b9e-476f-aad2-f4b410ea23d3',N'b733e1ce-a559-4897-b988-41189c6ab38b',N'bff6d393-efbb-4330-af19-a8b52ddcd1c2',N'b8c00e49-7542-4aa3-a24d-40dffbc74d5d',N'afb63a46-83da-472f-8f0a-aa27447db608',N'9d0c99b1-b9db-44f8-907b-1f53c4443ad8',N'65e37f1c-0555-4812-9c39-13136f5604db',N'cea0b482-a93d-4a25-9c2c-590d34e2dd82',N'142123a4-42da-45ea-a93b-e7c24ca357bc',N'30cfe188-7b91-45a8-a759-bce5cb84bb8a',N'fc26b0f2-7f7d-4f5a-9ac5-cf776892f991',N'84ba00c7-5e84-488d-9fc9-5876482740b3',N'0818327e-e6bd-4951-8690-23c74b69ff18',N'ece23d81-0800-4822-8fea-6286b75320c9',N'113aa838-cca0-4301-b282-a9cecf6ccab8',N'97c6f955-afbe-4892-9aea-3ad158a364b9',N'9a00b812-3350-491b-a36b-f9ab3f45433f',N'de748ae5-aa4d-4a38-8832-4d5619bfbb98',N'8c05eb1c-5372-438f-ae82-7f41d22047aa',N'4b6a43cc-0fff-4fa2-9920-70756ce013e0',N'3eb09000-5d17-4e7d-b3df-120914f429a7',N'913ecd49-2860-4779-b6cb-236ec0b328af',N'0a428e50-b6f0-416e-8d02-a05a6cad5ba4',N'd497dcf2-379c-43fb-9975-c39653972d2c',N'21c19f40-9ea8-4c14-aa43-0e569220f8a9',N'e4f2e8cb-8b8b-4dd5-b374-1bccd895eda3',N'cf610a96-5b4c-4d5b-85a3-60b806d1e70c',N'91516763-3dbe-4d35-a68e-d751d05c4122',N'815ac31c-c055-4e19-bb83-3e30c79ccf89',N'7105fb49-d7b4-4119-94ef-308a22fb08de',N'fb8558a7-b8d2-4416-97e1-c415b35c4357',N'116c0f7b-a599-43fc-a875-247cdd666c81',N'98dd0a42-b4a8-470e-8a92-97b9da6a8a44',N'79ea0af1-720b-4c1e-9d17-69350c855dfb',N'ef88d19a-3623-4c2f-a355-dd7a59b9f1c4',N'642761de-36b9-4597-a23e-c82a41c1b0a0',N'8b062efe-d192-400e-895f-8ba48bb6ee4c',N'f6715b06-62a1-4c28-b8c7-a84b8a640494',N'184158db-10fe-4e32-8d87-031a665c4d18',N'803bcf0c-1ea0-4f09-9fbc-dfaa90e29020',N'cea052a9-2763-4c86-95c8-79da9695003e',N'36a95615-ee8c-4265-8877-270f75312226',N'd4d92c68-2f38-4c4c-8394-81016993d210',N'01604d99-67e3-4c34-98f1-d50428639856',N'a5062424-b827-4e1a-a92b-0029e68e8012',N'809764b3-d330-4e78-a971-9ea69d79dbcb',N'37769634-3cf9-44b1-bc2f-a5f6dffb1ff4',N'53d8968d-7173-4f3f-adff-da72f0cf1260',N'bdf91f3e-1801-4c8e-8fc1-6a0007fce9b7',N'3af12262-0773-4140-9a89-517bd7fc8b2f',N'085b056e-befa-46e2-b6f2-c6a4204aa107',N'a566b466-df24-467a-be66-54cbf3ec25d5',N'd80e6db4-7039-4795-8b4f-6ec363ff534e',N'cd5d9455-031c-4ce8-a1b5-33c3a7454652',N'640b0b16-9c90-4b6c-b402-fb6338f04407',N'2759911d-461e-4075-b86c-c7f288cc7b24',N'05330ee8-9da8-4be5-8a03-73adbb517413',N'6cae0041-c00c-4b6f-ba7c-d910fc389876',N'3506f29a-9ab3-4c40-8d21-228c04a43dfb',N'd0f5649b-8f5a-4537-9f11-1e5fe09c52b1',N'2630c94c-e874-419c-8da8-c15fdec51408',N'a281acdc-740e-465b-b71e-3701b8766ef3',N'fd30bd4c-b4f4-4d97-8f33-291b804ad15d',N'd0c23401-c7b8-4924-b58d-3ccd381b318a',N'b69da51b-cd24-4bab-bd9d-d65ca1b9756b',N'ecb61548-3e98-4d56-abb9-884e16839102',N'b84672c5-2784-48e4-9129-7064b1d296fe',N'2fe8d89b-568e-46ab-a45b-20dc533c9c06',N'53611a1f-b09b-4b68-a8be-bb8159cb8583',N'1bf3630a-84c1-4250-83d3-461600bb17c4',N'2a86d9f0-6574-47ea-bead-35509ab8c983',N'1d66e68f-b02b-4d75-b65f-597190db8844',N'f72739a1-a240-499b-9fe3-cb148cf4ed74',N'cbf5fcf5-00bc-4a40-8995-93a4c0d699bc',N'c476c21c-91dc-4edb-b7bd-10d0cb88affb',N'f2997f28-0b3b-496b-9333-d4753c261845',N'953eca16-453c-4af6-a817-58981b9e6895',N'2ac55743-fe32-40cb-91f5-8b047906f1a2',N'01cc0f82-b305-4918-a39d-e9325d6df64a',N'1f97a380-d1b9-43f1-b80c-80b1b4a13f8d',N'97a610f5-8d74-4233-83f9-db7d099bad01',N'706b4387-439a-432d-8da5-1f6d5651261c',N'eef9b60f-e6ba-498d-ac36-17f187cd7a6f',N'd8800eeb-2c27-4dc7-8340-e180aa096a0c',N'd7e07ea9-a653-41fa-a4ac-ff56047e3cde',N'4d1a93c0-5ce9-49a3-82f7-83876c2e5fe5',N'52a144c9-9674-48c6-95e4-99b685aed94c',N'a81500a4-16ba-403a-af59-973b29d92776',N'617c2942-3499-47d9-8d25-b4fa6cb4e35e',N'b221da1e-1189-42de-bbcc-110c76e1bb49',N'6946c4aa-7327-42be-8faf-31429ee02f87',N'c546a9cc-cbb2-41c3-9a3d-07ef792986d5',N'fc845488-83a6-4ed8-8b1e-911b8018abcd',N'fe4fdf36-9628-4889-8640-dfaf3ec4ddca',N'5d303ff0-7e1a-4571-9cd5-4eebd5942fcf',N'5ab0cef2-a751-4358-90fc-4ba253c56fbf',N'6cd3e34d-fc6e-4c65-ba39-cbb98be96c4f',N'9fd4ab6e-c397-4be8-9c6a-784669f17989',N'1b0c13ac-422d-441c-ac7c-d52e18e86726',N'39584588-1ec2-45e7-9b1e-c0a9b7dcd423',N'51d0c913-8537-4744-9b34-6c59a1307655',N'3bd63b4a-c3ae-4b84-be7b-26a8890def55',N'884ed4b9-858a-49cc-99f9-dad736c03281',N'e076cd11-030a-4460-b6d0-3616c94790c0',N'775904b5-5c31-498f-980a-79ad046ec5a7',N'1ecb6caa-b63b-4ae8-b44d-e6472c1997cc',N'4b8d41d5-d61a-4b95-a8a5-9b4dd67c92eb',N'f70d1e37-da99-47d0-b62d-4c407892c63e',N'56b2fd3f-2e1e-4c1c-86e5-5a4ce788cc17',N'9e83b7d9-d595-4754-818e-a7bded876599',N'22e7d935-314a-4b4a-a259-6d94b7cb0a30',N'd2d8ec2a-18d5-4f2c-8327-74da94255fe6',N'e58e1775-7db1-4d1b-b581-d20e14414077',N'7127ab11-b825-4568-8115-3555e5e92cf3',N'6e1914c0-4170-43ce-8b0a-c835cdf4ea1a',N'f35cc11c-156e-41ba-9903-5dcf050a48a7',N'd541ddeb-50e6-4c79-a3d2-5ae485e27796',N'b341686e-fe98-4cc2-a772-8e1e51a484b3',N'5470d25a-6391-40e1-bf0c-5af5436c0bfd',N'7df916c1-76e5-4f5d-bd8b-7a64fa186d3b',N'66fa01cd-642b-476a-95d4-ed011fcbae2f',N'99a52fb3-4892-45e4-956d-57ce8046b78e',N'ff3de438-232c-4785-aeab-235560215de7',N'1390a0a5-3fe6-467b-bf7b-d8ba5e3a2e67',N'0c0ef816-82ed-4b0b-9909-04e1251d8e93',N'333cd196-cd62-4316-9749-305266bd6017',N'fcd4407f-bf5d-439e-9317-3b94d2b261c2',N'22e27c61-64e0-4ca1-8c5a-c53b4034bcbc',N'225373bf-51a8-4f2b-b736-78e43a73a256',N'aff73b2f-255f-4129-bf28-f7042ef5b2b5',N'cea3fbeb-079d-4770-bad5-09b48f05034d',N'97e56404-d710-42d8-bb4d-7e6e79655f34',N'16567dbf-0366-4466-aae7-1b57c5708af4',N'44fe7152-2cac-43e0-a55e-64446fb96b89',N'16d4b75c-a66d-4f13-85e3-8d23d8b2f73c',N'9e08244e-6c76-438f-998e-61a662126316',N'539c29a4-f85b-4d05-90dc-3069dd75db26',N'1a5edc0d-c8eb-42fe-9fe5-6c04eed564e9',N'43bf2b47-4459-4922-8fac-ee2227993c5e',N'08525a45-8193-4ee1-8e1b-75765d9f2367',N'6ba5bafb-fa17-4b82-b814-9f7193cf8993',N'24fe0e97-3f0a-4e04-8a1b-1938deee178c',N'be8024b1-5960-4f77-9991-be58acf0ed05',N'bd2eba6c-47bb-4068-a5ab-aac30feb98ee',N'5abd1160-53ee-4a1f-9655-c833727ccd64',N'1fccae9e-b9d8-42fd-821c-7fb08f648d72',N'4e4123cd-588b-4284-9971-14c83125af39',N'388a6cb0-b455-47a5-a2a3-95eb7c49313e',N'01a98132-28f6-4579-9f7d-33776cf1f4d6',N'117a90e4-8984-4bf3-bea7-d92b78241c74',N'e2ad8a7c-027f-4619-a000-4197ec3ec202',N'32428a9e-d780-41e6-b7c9-7b3a8d72fa6b',N'9b389c7f-4c77-43d8-9369-7b5f174a7f4a',N'99dd7d44-b1a2-49dd-be8b-1c7df158c703',N'470c6c2c-5184-461f-b42a-90f5505a411c',N'7d68457f-4ddd-40a3-8f5a-acab677eb5bd',N'fd949a79-3ca2-41e0-b09b-06e01741c262',N'2fe1c485-311b-4e5a-bc4c-d10b7b52e217',N'97676df3-7a2e-479b-9b5d-6e2963f3e240',N'5aedfcaf-73ee-4e40-87ee-456eb0f361d7',N'2e2f86ad-17f2-4f35-af8e-56abb8c21512',N'0ef92d05-8cd7-4fe1-b3d0-0102bd7aede6',N'd1cfdca9-7be9-45dc-9b3f-6b2cdcbf6261',N'd08064c8-59c6-46bd-b435-e49531c0849c',N'016d523f-1c55-4f94-9f63-6f173b80c171',N'825248c8-0e18-443b-9fd1-129e1a82c704',N'887105e6-3e25-4f2b-98ef-008f0212eaed',N'1ee8bbde-a239-4a74-9e98-2bb779fda7ee',N'26880b4e-6e1e-4f22-bbd6-a18b93345c24',N'52d2d75b-5122-4e9e-a968-1386ac41da88',N'485f4f9b-e2a5-4057-8cf8-bc3809d3f5cf',N'78e84d76-ea31-406a-ab89-86b4500a821e',N'4a5b3201-2a2c-4687-b554-05ac1568e83d',N'63989ea3-22ac-4ed2-a523-de9c31b745a9',N'556257ee-ddd2-4d4d-8835-6d584889008d',N'585aadc8-3ba2-4212-b56e-0df48e7208ff',N'6d7bbd31-0d2b-4681-86e5-ecb11127ff48',N'dde5f56e-0e2d-4a2f-a5c2-49054c001d0b',N'b906e559-f9d3-4fc1-9155-b6bcef15a52d',N'7c086579-c218-4695-998a-e9d04227ca5c',N'19abbdff-f35f-43c2-837c-42da37b08f47',N'367c90fb-ea8f-4c90-a838-7bbca1db8e63',N'e978c62e-c687-4a86-b063-4f8f4875e582',N'8c5ea4db-1d82-48da-bd6b-81d3772ead08',N'6d5312b4-0cb1-41c5-a4f6-5a794f2f9a8d',N'5180f3e5-a6a4-4793-b5a2-28851674379b',N'ace41370-8073-48a4-bfe3-38a41e341c0a',N'3f61c6f8-1116-4f9f-b766-54c79102ca26',N'c040c6e3-8ae7-4763-b3dd-d356b2bf75bc',N'74bea064-0853-4bd4-b282-6d86797fcb0b',N'6193cf3c-a84d-453a-9307-6311a6e33b8a',N'bd84c49d-24f2-4772-a95f-f06e43add013',N'659af5cf-2c4b-44dd-b779-5b76c927a69e',N'c9cb6143-e27b-4b4f-bbb3-1fa5ecdeac60',N'5ddf227a-a726-4dd5-be1d-6dc6f3728cc4',N'c7e7ce1b-431e-4202-8751-83755ce14df5',N'd4fa286d-8523-4fba-b21f-9fc6e013f312',N'f330e86a-9b7f-4a1d-a1d4-2e504046111c',N'22255e13-787e-41c3-a00a-139d08278811',N'c905760f-c46d-4513-adce-7eb0dc2580a0',N'04cadebf-c5cb-45ae-8b29-6096e4fdb6f9',N'dce2cbf7-08b5-4b2e-8fb3-0170b6c61001',N'73f26575-5faa-4261-a1e4-90b15928e413',N'0edc6506-96b9-4b8a-9910-280fb986a421',N'ff2cec45-ceb5-4d82-965d-c5a44a72cea4',N'30fafe1c-e0db-431f-bb4f-9230c89739ba',N'1f95f1e8-170b-4d3b-aa50-a9a890ad5704',N'1d4a8881-a238-4794-bf72-060a868c081e',N'50144a35-ba23-421b-a4a3-1ae21850d8e1',N'a7bc529d-a62c-4e10-a07c-17d960b02e00',N'381d78b4-fb5f-457b-aa19-4ce976eb5b76',N'18969706-4917-4f3f-b299-1cc068f418db',N'70537376-1d42-46c8-8da6-54127197a586',N'31a974e9-2843-4606-80bd-e26a8bdeb151',N'd134c7ab-82cc-494a-872e-e87c903d9c26',N'd663befe-11f1-44ce-971e-7b477396ad52',N'8e1658d6-37b3-49df-88b0-77b01924bffb',N'c467b20a-5f4d-47ce-8db9-ff3ba17bbfd9',N'0887394f-bb10-4550-905a-e81ce590c5e2',N'95e69157-5696-469e-a4a8-d508cdc5dc3b',N'fb750139-ebd7-465d-9893-8a15145d87c6',N'597c03f4-3a6b-4171-8c33-8ced57f7e955',N'd784c6a1-79da-46ce-bed7-39abc4849770',N'7cc59efc-7953-4454-9a06-7b59d3cdbbae',N'10b7d8e2-e668-418f-98c0-f8cb7a55022a',N'85a76270-6bed-4a2e-9534-0203f372a4e8',N'd60ce2ed-eecc-4dc6-a589-f35b5d344669',N'0086adc0-ae96-42cb-9b05-8fa4226f4838',N'239db60c-d230-4ac5-a92c-4b77db50a153',N'4720d3bd-a03a-458c-ad7b-e864535190a8',N'f4496e56-5370-4dbf-9b2b-33f698e7adfe',N'2bcce841-20d4-45c3-bde7-4b6acbd11fb8',N'423584bc-1041-4d63-8313-f6d32ad3c98e',N'd2d21bb8-555a-4473-a16a-c92ec1757dca',N'784184f8-34fe-4781-a5ce-edca45e2ff8d',N'62fb0f5c-0dcc-425d-9e2a-d54439e1300d',N'e2bee8e7-a4c0-4aa1-9246-81261607e4ea',N'9fc3cd6c-3b98-40ad-85d9-e4521e914e9e',N'33253b61-2cea-4aec-bb35-cb2130a3173e',N'9996c20d-8c6b-4fde-a68f-ed810bf8c40a',N'1ca4e91a-8b0b-40d9-95a4-6fd5823a8328',N'a00a89cc-e89b-4b07-9272-427609403ef1',N'f1683dca-af2f-4179-87ab-4a8d7dbf109f',N'8fda07e4-346b-4e64-8e0a-53aeb014b49f',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9',N'8f3a0b23-425d-4871-b2d2-0284eec1f5b0',N'3554a049-95e3-461f-832b-f955659d6090',N'dc7d305e-d536-4ab1-b28a-a4949be8663b',N'76bc7476-6767-415a-b0e7-ecf0e2a25e54',N'f47870fc-d655-46b4-b311-dc9d2bd2a670',N'd7ba45cd-6b16-479c-8a17-a45bd29c2461',N'5bef393d-3522-494f-942d-fc62f0d06a68' NVARCHAR(MAX)
DECLARE N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' NVARCHAR(MAX)
DECLARE N'Fixed',N'Reflowable',N'Not Specified' NVARCHAR(MAX)

SELECT top 1 N'00000000-0000-0000-0000-000000000001',N'9e1d8850-532d-4704-a6af-3c8bf6dc7ee2',N'033a2f8b-a8dc-43ae-9e19-52dac8583e47',N'34e662d8-2442-45e4-ae57-12ac7c7e052a',N'cc382f86-6202-4b47-9628-62785ec8f077',N'3156cd0d-8fe4-446c-9491-482b0eecf888',N'601c0538-6e12-4873-b42d-e6fedbd794e6',N'65080660-f9a0-485e-92a2-5cf4a30854e6',N'4b02a28d-b7f7-424a-9cea-700ffea500be',N'e2c22698-8568-4a0e-8c03-1705b7e58a5c',N'34e2d303-0047-42e0-b998-944123185253',N'60dffe08-0702-4d1f-895e-9fc5cd57f31c',N'cec3ad29-04f4-4d17-9b8e-671acd0c06b7',N'4bd075e4-aeee-4870-8ff0-071cb0fda1e1',N'b24d6145-a9d9-4824-865c-4b741ac8b682',N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'7d6f4bea-a88c-463a-a819-0de4ac579fa7',N'461f4a2c-49d0-4abc-a2b0-05de1eceb702',N'd824d549-b51b-4ca2-af82-c44e0d3eec2a',N'6fbcf580-b152-482d-aa90-076a5ea94cf7',N'3c7ebaa4-b5b8-425a-a6f6-227c223c34e5',N'84178d32-0d90-4225-a1fb-264f80bfdde2',N'e17dc831-1298-4d5e-b3ce-dc68e2b5bf8a',N'4155ea72-57d1-471e-997f-1376915123f6',N'4c64a71a-cbf1-4446-ac41-bf311db56c84',N'b65e3ef8-3fe6-497d-bd98-8a764cd99c36',N'6fedfc6c-665d-466d-99ca-f8b01f7f396b',N'7feee485-eaf2-4be0-a93b-ed47a8a56ba7',N'9da90633-45b3-4334-a354-05a6b7fa215c',N'7096f34a-2550-48db-9ab4-65e951bb5534',N'1bbfda54-2c6f-4610-9321-f3ae69042b72',N'c3d0f950-024b-433b-8eba-fadfe9d6ba1b',N'4ad5ec58-7ade-4698-941f-a5da1581b893',N'617dfafc-9abf-4d30-b102-cec2cbdfbe6a',N'ebf4660c-910e-4968-9830-e70e9098318d',N'49cf026a-b5b4-4cad-9562-c786812b4bac',N'50508138-193c-4ddc-b69d-862ddb327715',N'b32de4ae-bae0-4908-8ab8-e9159ba71dd4',N'9167e9b0-0742-40c7-8526-e33ac183ebc3',N'20e9d77b-3eb9-4738-8fe1-403ba3b8a8c4',N'b8d66d8b-19de-4d00-bfb7-ded50cc12993',N'd0e0ea4a-e5fa-4b01-8b49-259202a6f1c4',N'3dabbd28-8cf7-45cb-8746-2d0ecd36838c',N'52bd4016-6e7c-4cdb-9d62-27b239e311ad',N'bcb943a8-8d9d-4817-aa96-7815a66ec1c6',N'89a2e8c7-74b4-49d4-bded-fd26ce4902d1',N'77727f05-a7b9-4791-91d1-2d9ca517b6c6',N'9fd6f976-757a-451d-81dc-ae6320dd2493',N'22336ee6-d869-4f2b-8110-647da99705a5',N'd8f06d0d-1832-4041-a672-2efc10fe1079',N'f4a8c921-f34a-4801-8036-968387958f22',N'39e4446b-5bfb-42d4-b0b0-acc5d598ac57',N'f3107f10-0e13-47ba-a75b-9e4b8e6c8df2',N'e2ceacee-9ddd-4b02-833a-b5c49850edaf',N'672fcfa0-3980-47fd-aae3-fb9fb27c2f1c',N'26b30ffe-3f2e-4039-ac03-4e2c2bc3b3bc',N'289ed3fc-a5b1-4b30-b501-e15252595d9f',N'42728bae-b714-4058-a5b2-ab055c944fa6',N'cadcfd90-7b7c-48f6-842d-d0c1e43b2cbc',N'd5db010f-0a0f-47fb-8a0b-0492a48be589',N'cd9cd64f-5a0d-4e09-9895-543f5a43b7e4',N'82827812-e0e0-4f5d-be97-08e6caa150a1',N'3bb141df-c93e-483c-bb89-eb69ed428a66',N'a249a835-f7a4-4427-b93a-8554cefd8bd1',N'5a3258e8-5676-48ff-90c6-7858a0a9a650',N'2a07c5df-5f7e-4ed6-af86-6f3077ff6b3c',N'f83002d4-4ed1-4672-9b33-36e0e87970e4',N'8e42003e-ac6e-4b8b-bb76-78bec1b8d3ab',N'4928b4f9-7910-4c95-9e29-9e51436c6162',N'bacecb01-af5b-4bfd-b138-bb09e78d525a',N'a1e048b4-5e1e-4333-b1c1-6785c197724c',N'dc7765b1-684c-48fa-99df-67ae95ca7ad5',N'dbb9007f-99a8-4bb0-a4bc-ccd7900acd83',N'2b6e1316-a38f-4e06-b4da-f5d71033ee59',N'414cfa83-1c43-4911-993a-b5ff717be5a2',N'f8f04ac8-060b-4274-b80d-1dba1296c66e',N'29020f77-33d7-4a03-82a9-2e8e9733380c',N'83f6b3e3-f62b-43a6-80e1-92c6cc322bb8',N'07bb6b31-3c59-4473-aecf-c8b23c106da6',N'e3cb6a8e-47ad-40c4-b6dd-d95231d1a31a',N'1cde0f88-721b-486f-9d49-b2c002e67145',N'c7993c99-86fd-4f2e-ae9a-8f7afe6f4ed5',N'ca0c91ab-46a4-41cd-bd0b-b46aba477488',N'68f00a4d-f956-43a9-983e-85a18723a8df',N'97d2c33b-c129-41d6-b530-6f0e6dbc64cb',N'c7f6bf63-2c7c-45b6-9d95-832d2ad2a42f',N'8822c822-191f-489d-ac76-94d48e913cfd',N'd21c0b77-501c-4aed-9bcc-73c8d59ae480',N'fb6b6ed0-d317-4124-84b1-c4844cf3ce15',N'953cfdeb-7a52-4e72-b9cb-fde5e3f8099a',N'0d6f2fa4-296b-4f12-bf40-57cd9f57b693',N'b47aa600-3e54-4f2c-bdb7-055221f44304',N'44f0637e-a057-4eb4-ba6a-b0971df41948',N'eddcdebd-e558-4e97-a9bf-77e03384c52a',N'49802113-a867-402d-9d4b-ca760bef0296',N'924fffb6-e2d5-4026-b901-f7aed89272e4',N'6f60a4a2-fd6e-4524-88c2-ed3d7066d49b',N'e6ebfdf4-78bb-44b6-93f7-0e19a00d081c',N'b5e519d9-a058-4748-840a-fad7e8089e70',N'79506cab-8cfa-42a0-863c-774f2edf24ce',N'7e1148a0-aa6c-466d-8f94-4a0f075be79f',N'190179f3-f941-463b-93d6-897caa28534a',N'b8584579-e654-4df2-8fd2-24c6ebc6dfc4',N'9d937936-8ebf-4a5d-bc79-14a07d7be161',N'de233059-74f3-40b4-ad3d-ae1662ca0a4b',N'8ffd404e-17ba-4bd3-8cac-f813550960eb',N'2dedea11-6681-4010-8f09-5f9cdc85eddb',N'4a0a4157-591d-4090-b508-ce4708cd3f0d',N'cbc8b551-389b-45de-a81f-a404c8e159bb',N'c9650b7b-3d5c-40ea-a0ed-cadad3ef0c6b',N'2c13e4ce-983a-4dbe-abe1-3208a6435a3e',N'7dbf26ce-9d95-48a0-aa2c-e67ecb066115',N'93c57340-fdb8-4b7f-a118-d792471c1611',N'273c8054-7f00-44b5-bae3-ae6ae30e7861',N'e990c4b6-6412-4d12-81f2-a19e0719b8dd',N'98a0fa96-b325-4737-a753-5e2290c3876a',N'6246e9b8-2a37-43b7-95ba-3edbb5902618',N'17e29299-63e2-45f4-a3b3-0611bc7eb647',N'b7d1f672-f2b1-4993-9de5-09d4b14e45a7',N'0d361f3e-2017-474c-8458-f8504e38eaf1',N'c14f54f7-56e6-4dd5-9682-4590e0ca28af',N'43ef6457-a5c3-4942-b2a9-99113e68c650',N'2d1d5fa9-fee9-41a8-8a71-ae5b44cc349e',N'3fa65e4d-89ea-4b9d-9e38-297c5b652fc9',N'3666fa07-6217-49e9-a213-069744777424',N'236bddde-ce50-4c00-989c-fbba59ff3459',N'4d457516-98f8-4c3e-9b31-2ab3c3c4c457',N'4586517d-d831-4da0-870a-1938e1962cb0',N'5453afd6-9808-4178-ab93-6156a2cb37a0',N'd65a0143-05e3-4c98-aac6-13e20de21eeb',N'fca143df-e41e-45b6-816a-162454bd8d05',N'4fd43933-a501-4026-8f76-28bffbe54232',N'9450ef7c-e537-4747-bdca-f88ba25c1133',N'1f913e66-ef8a-46d0-96d2-7d19f8310401',N'86c459b1-002f-4bf4-8a65-cd2a23925af0',N'eb33d408-ac1b-4e09-ab87-544896222cbc',N'7f7ec4e6-3987-4c18-be5b-de37e581e4e4',N'c54b1eea-dfda-4aab-b414-a1acbd4be784',N'f5f84e6a-f3ae-481a-a730-992416220a71',N'0034d4ef-be7f-446b-9971-69bd6939cf39',N'eb8acfc6-bb6c-4d2b-939f-391b17913cfd',N'feaf81f8-2dbd-49a3-96d2-e2c47fa3ba37',N'1c7b16d6-8637-49cd-8114-b69664ac5a40',N'98b1bc08-50b4-4ca1-a351-62b0735e9e8e',N'bc7b02d8-2c0b-44b6-83df-0e7b1ebd4330',N'72b6849f-422d-40de-86be-94f67271928d',N'3e725b22-ab4a-40c9-a1c2-16a15de4ce26',N'de63b1f1-a1a3-4c25-a6c2-e506250752dc',N'65ccd475-c44d-461b-af6c-6ad257fe1bef',N'a4e6e850-3f0f-4513-8f26-9bf19231771c',N'6a517183-44b0-40d1-a007-4ab9075735f6',N'cb4127f4-2501-4793-9c85-c38400168f5d',N'db5f7473-31dd-409b-9bf2-2653cc3e17fb',N'f7b53948-328a-4725-b0af-a2922e796664',N'd85a561a-7658-4b28-baca-6c496252cb6d',N'287caec9-caf4-48a1-a723-a2103b387208',N'f7221fdc-8b5f-4846-9711-9fcaed834ec2',N'08295f7f-e71d-4b7e-a696-3414e5404db7',N'fa856430-70d8-436d-a3a5-4eadd059482b',N'adedd8f5-c46d-4ffd-afb7-8e4e4d424dc7',N'ca3fa091-47c8-449b-a4c1-05c3dcfb203c',N'4c53dd59-fea0-47f7-b36a-929b957b7143',N'0b268bd7-327b-47fe-b0f4-ac8d99e94a5f',N'7b76e8a5-f954-4b00-be13-51f6cf8ceb6f',N'5b4edec6-d924-47df-a48b-3480c66e3b7f',N'8e29b1cd-473a-4d28-942f-5951333be1a1',N'69e6c615-892c-41e1-b67b-b534c27b3573',N'e2123171-16b9-47c2-892d-0520e3995b05',N'd31a59c7-ec53-47f6-866f-04cc85cfa692',N'f99d270f-eb28-4055-8122-27699cb657a8',N'b013860d-f12d-4e7b-ac2b-06ffa851d91b',N'0eb5ecf2-31ff-491f-adaf-307b1fb4eff9',N'75abb883-c676-489d-8128-3ac75b10f8b3',N'2d59c58e-4271-4ad8-8966-5dac3fd35124',N'1e2cc5a2-04a6-4b80-baab-155391a602a4',N'd5d41892-4d5f-4bc7-898c-55271c9244a9',N'433c4095-b92e-4f54-83c9-5b21b745416f',N'61cafc49-6352-4ebe-8872-8b5fd5130d27',N'c173986a-cece-453b-80df-e5f2211828ac',N'c0417f85-1a67-45e7-8f76-93b1d1714dc8',N'2239748e-1282-4073-923f-6f76103b1240',N'58f7a68f-8ae1-4397-8d9c-3574a0ccc6a8',N'd9341d36-43f8-4d2d-a775-9d603f0c3ca4',N'6f389fc1-2e6e-460e-9c43-0ffdf404b829',N'4fb43d31-b368-46c2-997d-1fc73420caf9',N'fcde6da5-8b57-485f-ba22-fd1f52be6265',N'61aee3cc-52a7-48c5-83b5-2f291bb94b11',N'7595235f-ef3e-46b0-9137-0bbe563f161b',N'ce77bef8-f6cb-43b4-b66b-e9a234c05600',N'6ad8eaa2-8155-43c6-9f14-a0868f87c71f',N'1079e393-dad2-4e8a-810a-0f500750d9b0',N'39aee0ab-5735-4996-84dc-6ff204d44098',N'2163b2e6-5152-4171-b0f7-012dfd8461d6',N'c9d31d69-9b47-40fb-9196-a323f1e9cba0',N'98987454-af33-4b40-a2f1-b09e249ced32',N'924b19c3-d3ce-4e4c-8f98-6c7218ae5b0a',N'a434e361-2c56-44ec-9c37-a57f241a94c6',N'03f72b09-6c90-48a6-be5e-13c19f662500',N'2fde1c24-6b9e-476f-aad2-f4b410ea23d3',N'b733e1ce-a559-4897-b988-41189c6ab38b',N'bff6d393-efbb-4330-af19-a8b52ddcd1c2',N'b8c00e49-7542-4aa3-a24d-40dffbc74d5d',N'afb63a46-83da-472f-8f0a-aa27447db608',N'9d0c99b1-b9db-44f8-907b-1f53c4443ad8',N'65e37f1c-0555-4812-9c39-13136f5604db',N'cea0b482-a93d-4a25-9c2c-590d34e2dd82',N'142123a4-42da-45ea-a93b-e7c24ca357bc',N'30cfe188-7b91-45a8-a759-bce5cb84bb8a',N'fc26b0f2-7f7d-4f5a-9ac5-cf776892f991',N'84ba00c7-5e84-488d-9fc9-5876482740b3',N'0818327e-e6bd-4951-8690-23c74b69ff18',N'ece23d81-0800-4822-8fea-6286b75320c9',N'113aa838-cca0-4301-b282-a9cecf6ccab8',N'97c6f955-afbe-4892-9aea-3ad158a364b9',N'9a00b812-3350-491b-a36b-f9ab3f45433f',N'de748ae5-aa4d-4a38-8832-4d5619bfbb98',N'8c05eb1c-5372-438f-ae82-7f41d22047aa',N'4b6a43cc-0fff-4fa2-9920-70756ce013e0',N'3eb09000-5d17-4e7d-b3df-120914f429a7',N'913ecd49-2860-4779-b6cb-236ec0b328af',N'0a428e50-b6f0-416e-8d02-a05a6cad5ba4',N'd497dcf2-379c-43fb-9975-c39653972d2c',N'21c19f40-9ea8-4c14-aa43-0e569220f8a9',N'e4f2e8cb-8b8b-4dd5-b374-1bccd895eda3',N'cf610a96-5b4c-4d5b-85a3-60b806d1e70c',N'91516763-3dbe-4d35-a68e-d751d05c4122',N'815ac31c-c055-4e19-bb83-3e30c79ccf89',N'7105fb49-d7b4-4119-94ef-308a22fb08de',N'fb8558a7-b8d2-4416-97e1-c415b35c4357',N'116c0f7b-a599-43fc-a875-247cdd666c81',N'98dd0a42-b4a8-470e-8a92-97b9da6a8a44',N'79ea0af1-720b-4c1e-9d17-69350c855dfb',N'ef88d19a-3623-4c2f-a355-dd7a59b9f1c4',N'642761de-36b9-4597-a23e-c82a41c1b0a0',N'8b062efe-d192-400e-895f-8ba48bb6ee4c',N'f6715b06-62a1-4c28-b8c7-a84b8a640494',N'184158db-10fe-4e32-8d87-031a665c4d18',N'803bcf0c-1ea0-4f09-9fbc-dfaa90e29020',N'cea052a9-2763-4c86-95c8-79da9695003e',N'36a95615-ee8c-4265-8877-270f75312226',N'd4d92c68-2f38-4c4c-8394-81016993d210',N'01604d99-67e3-4c34-98f1-d50428639856',N'a5062424-b827-4e1a-a92b-0029e68e8012',N'809764b3-d330-4e78-a971-9ea69d79dbcb',N'37769634-3cf9-44b1-bc2f-a5f6dffb1ff4',N'53d8968d-7173-4f3f-adff-da72f0cf1260',N'bdf91f3e-1801-4c8e-8fc1-6a0007fce9b7',N'3af12262-0773-4140-9a89-517bd7fc8b2f',N'085b056e-befa-46e2-b6f2-c6a4204aa107',N'a566b466-df24-467a-be66-54cbf3ec25d5',N'd80e6db4-7039-4795-8b4f-6ec363ff534e',N'cd5d9455-031c-4ce8-a1b5-33c3a7454652',N'640b0b16-9c90-4b6c-b402-fb6338f04407',N'2759911d-461e-4075-b86c-c7f288cc7b24',N'05330ee8-9da8-4be5-8a03-73adbb517413',N'6cae0041-c00c-4b6f-ba7c-d910fc389876',N'3506f29a-9ab3-4c40-8d21-228c04a43dfb',N'd0f5649b-8f5a-4537-9f11-1e5fe09c52b1',N'2630c94c-e874-419c-8da8-c15fdec51408',N'a281acdc-740e-465b-b71e-3701b8766ef3',N'fd30bd4c-b4f4-4d97-8f33-291b804ad15d',N'd0c23401-c7b8-4924-b58d-3ccd381b318a',N'b69da51b-cd24-4bab-bd9d-d65ca1b9756b',N'ecb61548-3e98-4d56-abb9-884e16839102',N'b84672c5-2784-48e4-9129-7064b1d296fe',N'2fe8d89b-568e-46ab-a45b-20dc533c9c06',N'53611a1f-b09b-4b68-a8be-bb8159cb8583',N'1bf3630a-84c1-4250-83d3-461600bb17c4',N'2a86d9f0-6574-47ea-bead-35509ab8c983',N'1d66e68f-b02b-4d75-b65f-597190db8844',N'f72739a1-a240-499b-9fe3-cb148cf4ed74',N'cbf5fcf5-00bc-4a40-8995-93a4c0d699bc',N'c476c21c-91dc-4edb-b7bd-10d0cb88affb',N'f2997f28-0b3b-496b-9333-d4753c261845',N'953eca16-453c-4af6-a817-58981b9e6895',N'2ac55743-fe32-40cb-91f5-8b047906f1a2',N'01cc0f82-b305-4918-a39d-e9325d6df64a',N'1f97a380-d1b9-43f1-b80c-80b1b4a13f8d',N'97a610f5-8d74-4233-83f9-db7d099bad01',N'706b4387-439a-432d-8da5-1f6d5651261c',N'eef9b60f-e6ba-498d-ac36-17f187cd7a6f',N'd8800eeb-2c27-4dc7-8340-e180aa096a0c',N'd7e07ea9-a653-41fa-a4ac-ff56047e3cde',N'4d1a93c0-5ce9-49a3-82f7-83876c2e5fe5',N'52a144c9-9674-48c6-95e4-99b685aed94c',N'a81500a4-16ba-403a-af59-973b29d92776',N'617c2942-3499-47d9-8d25-b4fa6cb4e35e',N'b221da1e-1189-42de-bbcc-110c76e1bb49',N'6946c4aa-7327-42be-8faf-31429ee02f87',N'c546a9cc-cbb2-41c3-9a3d-07ef792986d5',N'fc845488-83a6-4ed8-8b1e-911b8018abcd',N'fe4fdf36-9628-4889-8640-dfaf3ec4ddca',N'5d303ff0-7e1a-4571-9cd5-4eebd5942fcf',N'5ab0cef2-a751-4358-90fc-4ba253c56fbf',N'6cd3e34d-fc6e-4c65-ba39-cbb98be96c4f',N'9fd4ab6e-c397-4be8-9c6a-784669f17989',N'1b0c13ac-422d-441c-ac7c-d52e18e86726',N'39584588-1ec2-45e7-9b1e-c0a9b7dcd423',N'51d0c913-8537-4744-9b34-6c59a1307655',N'3bd63b4a-c3ae-4b84-be7b-26a8890def55',N'884ed4b9-858a-49cc-99f9-dad736c03281',N'e076cd11-030a-4460-b6d0-3616c94790c0',N'775904b5-5c31-498f-980a-79ad046ec5a7',N'1ecb6caa-b63b-4ae8-b44d-e6472c1997cc',N'4b8d41d5-d61a-4b95-a8a5-9b4dd67c92eb',N'f70d1e37-da99-47d0-b62d-4c407892c63e',N'56b2fd3f-2e1e-4c1c-86e5-5a4ce788cc17',N'9e83b7d9-d595-4754-818e-a7bded876599',N'22e7d935-314a-4b4a-a259-6d94b7cb0a30',N'd2d8ec2a-18d5-4f2c-8327-74da94255fe6',N'e58e1775-7db1-4d1b-b581-d20e14414077',N'7127ab11-b825-4568-8115-3555e5e92cf3',N'6e1914c0-4170-43ce-8b0a-c835cdf4ea1a',N'f35cc11c-156e-41ba-9903-5dcf050a48a7',N'd541ddeb-50e6-4c79-a3d2-5ae485e27796',N'b341686e-fe98-4cc2-a772-8e1e51a484b3',N'5470d25a-6391-40e1-bf0c-5af5436c0bfd',N'7df916c1-76e5-4f5d-bd8b-7a64fa186d3b',N'66fa01cd-642b-476a-95d4-ed011fcbae2f',N'99a52fb3-4892-45e4-956d-57ce8046b78e',N'ff3de438-232c-4785-aeab-235560215de7',N'1390a0a5-3fe6-467b-bf7b-d8ba5e3a2e67',N'0c0ef816-82ed-4b0b-9909-04e1251d8e93',N'333cd196-cd62-4316-9749-305266bd6017',N'fcd4407f-bf5d-439e-9317-3b94d2b261c2',N'22e27c61-64e0-4ca1-8c5a-c53b4034bcbc',N'225373bf-51a8-4f2b-b736-78e43a73a256',N'aff73b2f-255f-4129-bf28-f7042ef5b2b5',N'cea3fbeb-079d-4770-bad5-09b48f05034d',N'97e56404-d710-42d8-bb4d-7e6e79655f34',N'16567dbf-0366-4466-aae7-1b57c5708af4',N'44fe7152-2cac-43e0-a55e-64446fb96b89',N'16d4b75c-a66d-4f13-85e3-8d23d8b2f73c',N'9e08244e-6c76-438f-998e-61a662126316',N'539c29a4-f85b-4d05-90dc-3069dd75db26',N'1a5edc0d-c8eb-42fe-9fe5-6c04eed564e9',N'43bf2b47-4459-4922-8fac-ee2227993c5e',N'08525a45-8193-4ee1-8e1b-75765d9f2367',N'6ba5bafb-fa17-4b82-b814-9f7193cf8993',N'24fe0e97-3f0a-4e04-8a1b-1938deee178c',N'be8024b1-5960-4f77-9991-be58acf0ed05',N'bd2eba6c-47bb-4068-a5ab-aac30feb98ee',N'5abd1160-53ee-4a1f-9655-c833727ccd64',N'1fccae9e-b9d8-42fd-821c-7fb08f648d72',N'4e4123cd-588b-4284-9971-14c83125af39',N'388a6cb0-b455-47a5-a2a3-95eb7c49313e',N'01a98132-28f6-4579-9f7d-33776cf1f4d6',N'117a90e4-8984-4bf3-bea7-d92b78241c74',N'e2ad8a7c-027f-4619-a000-4197ec3ec202',N'32428a9e-d780-41e6-b7c9-7b3a8d72fa6b',N'9b389c7f-4c77-43d8-9369-7b5f174a7f4a',N'99dd7d44-b1a2-49dd-be8b-1c7df158c703',N'470c6c2c-5184-461f-b42a-90f5505a411c',N'7d68457f-4ddd-40a3-8f5a-acab677eb5bd',N'fd949a79-3ca2-41e0-b09b-06e01741c262',N'2fe1c485-311b-4e5a-bc4c-d10b7b52e217',N'97676df3-7a2e-479b-9b5d-6e2963f3e240',N'5aedfcaf-73ee-4e40-87ee-456eb0f361d7',N'2e2f86ad-17f2-4f35-af8e-56abb8c21512',N'0ef92d05-8cd7-4fe1-b3d0-0102bd7aede6',N'd1cfdca9-7be9-45dc-9b3f-6b2cdcbf6261',N'd08064c8-59c6-46bd-b435-e49531c0849c',N'016d523f-1c55-4f94-9f63-6f173b80c171',N'825248c8-0e18-443b-9fd1-129e1a82c704',N'887105e6-3e25-4f2b-98ef-008f0212eaed',N'1ee8bbde-a239-4a74-9e98-2bb779fda7ee',N'26880b4e-6e1e-4f22-bbd6-a18b93345c24',N'52d2d75b-5122-4e9e-a968-1386ac41da88',N'485f4f9b-e2a5-4057-8cf8-bc3809d3f5cf',N'78e84d76-ea31-406a-ab89-86b4500a821e',N'4a5b3201-2a2c-4687-b554-05ac1568e83d',N'63989ea3-22ac-4ed2-a523-de9c31b745a9',N'556257ee-ddd2-4d4d-8835-6d584889008d',N'585aadc8-3ba2-4212-b56e-0df48e7208ff',N'6d7bbd31-0d2b-4681-86e5-ecb11127ff48',N'dde5f56e-0e2d-4a2f-a5c2-49054c001d0b',N'b906e559-f9d3-4fc1-9155-b6bcef15a52d',N'7c086579-c218-4695-998a-e9d04227ca5c',N'19abbdff-f35f-43c2-837c-42da37b08f47',N'367c90fb-ea8f-4c90-a838-7bbca1db8e63',N'e978c62e-c687-4a86-b063-4f8f4875e582',N'8c5ea4db-1d82-48da-bd6b-81d3772ead08',N'6d5312b4-0cb1-41c5-a4f6-5a794f2f9a8d',N'5180f3e5-a6a4-4793-b5a2-28851674379b',N'ace41370-8073-48a4-bfe3-38a41e341c0a',N'3f61c6f8-1116-4f9f-b766-54c79102ca26',N'c040c6e3-8ae7-4763-b3dd-d356b2bf75bc',N'74bea064-0853-4bd4-b282-6d86797fcb0b',N'6193cf3c-a84d-453a-9307-6311a6e33b8a',N'bd84c49d-24f2-4772-a95f-f06e43add013',N'659af5cf-2c4b-44dd-b779-5b76c927a69e',N'c9cb6143-e27b-4b4f-bbb3-1fa5ecdeac60',N'5ddf227a-a726-4dd5-be1d-6dc6f3728cc4',N'c7e7ce1b-431e-4202-8751-83755ce14df5',N'd4fa286d-8523-4fba-b21f-9fc6e013f312',N'f330e86a-9b7f-4a1d-a1d4-2e504046111c',N'22255e13-787e-41c3-a00a-139d08278811',N'c905760f-c46d-4513-adce-7eb0dc2580a0',N'04cadebf-c5cb-45ae-8b29-6096e4fdb6f9',N'dce2cbf7-08b5-4b2e-8fb3-0170b6c61001',N'73f26575-5faa-4261-a1e4-90b15928e413',N'0edc6506-96b9-4b8a-9910-280fb986a421',N'ff2cec45-ceb5-4d82-965d-c5a44a72cea4',N'30fafe1c-e0db-431f-bb4f-9230c89739ba',N'1f95f1e8-170b-4d3b-aa50-a9a890ad5704',N'1d4a8881-a238-4794-bf72-060a868c081e',N'50144a35-ba23-421b-a4a3-1ae21850d8e1',N'a7bc529d-a62c-4e10-a07c-17d960b02e00',N'381d78b4-fb5f-457b-aa19-4ce976eb5b76',N'18969706-4917-4f3f-b299-1cc068f418db',N'70537376-1d42-46c8-8da6-54127197a586',N'31a974e9-2843-4606-80bd-e26a8bdeb151',N'd134c7ab-82cc-494a-872e-e87c903d9c26',N'd663befe-11f1-44ce-971e-7b477396ad52',N'8e1658d6-37b3-49df-88b0-77b01924bffb',N'c467b20a-5f4d-47ce-8db9-ff3ba17bbfd9',N'0887394f-bb10-4550-905a-e81ce590c5e2',N'95e69157-5696-469e-a4a8-d508cdc5dc3b',N'fb750139-ebd7-465d-9893-8a15145d87c6',N'597c03f4-3a6b-4171-8c33-8ced57f7e955',N'd784c6a1-79da-46ce-bed7-39abc4849770',N'7cc59efc-7953-4454-9a06-7b59d3cdbbae',N'10b7d8e2-e668-418f-98c0-f8cb7a55022a',N'85a76270-6bed-4a2e-9534-0203f372a4e8',N'd60ce2ed-eecc-4dc6-a589-f35b5d344669',N'0086adc0-ae96-42cb-9b05-8fa4226f4838',N'239db60c-d230-4ac5-a92c-4b77db50a153',N'4720d3bd-a03a-458c-ad7b-e864535190a8',N'f4496e56-5370-4dbf-9b2b-33f698e7adfe',N'2bcce841-20d4-45c3-bde7-4b6acbd11fb8',N'423584bc-1041-4d63-8313-f6d32ad3c98e',N'd2d21bb8-555a-4473-a16a-c92ec1757dca',N'784184f8-34fe-4781-a5ce-edca45e2ff8d',N'62fb0f5c-0dcc-425d-9e2a-d54439e1300d',N'e2bee8e7-a4c0-4aa1-9246-81261607e4ea',N'9fc3cd6c-3b98-40ad-85d9-e4521e914e9e',N'33253b61-2cea-4aec-bb35-cb2130a3173e',N'9996c20d-8c6b-4fde-a68f-ed810bf8c40a',N'1ca4e91a-8b0b-40d9-95a4-6fd5823a8328',N'a00a89cc-e89b-4b07-9272-427609403ef1',N'f1683dca-af2f-4179-87ab-4a8d7dbf109f',N'8fda07e4-346b-4e64-8e0a-53aeb014b49f',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e
(@OrganizationUid nvarchar(36),@eISBNList nvarchar(4000),@DateRangeStart datetime,@DateRangeEnd datetime,@OnSaleDateRangeStart nvarchar(4000),@OnSaleDateRangeEnd nvarchar(4000),@eISBNs nvarchar(4000))/*--*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE N'bcb943a8-8d9d-4817-aa96-7815a66ec1c6',N'52d2d75b-5122-4e9e-a968-1386ac41da88',N'485f4f9b-e2a5-4057-8cf8-bc3809d3f5cf',N'78e84d76-ea31-406a-ab89-86b4500a821e' NVARCHAR(MAX)
DECLARE N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' NVARCHAR(MAX)
DECLARE N'Fixed',N'Reflowable',N'Not Specified' NVARCHAR(MAX)

SELECT top 1 N'bcb943a8-8d9d-4817-aa96-7815a66ec1c6',N'52d2d75b-5122-4e9e-a968-1386ac41da88',N'485f4f9b-e2a5-4057-8cf8-bc3809d3f5cf',N'78e84d76-ea31-406a-ab89-86b4500a821e' = o.OrganizationUid from Organizations o where o.OrganizationName Like '%Disney%'
SET @DateRangeStart = NULL
SET @DateRangeEnd = NULL
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL
SELECT top 1 N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' = r.RetailerUid from Retailers r where r.Name = '3M'

SET @eISBNs = NULL
SET @eISBNList = NULL
SET N'Fixed',N'Reflowable',N'Not Specified' = 'Not Specified';

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

IF OBJECT_ID('tempdb..#ErrorMessages') IS NOT NULL
    DROP TABLE #ErrorMessages
*/

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
    pub.Name AS Publisher,
    cast(p.Ordinal as varchar(20)) AS ISBN,
    p.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	DistributionOrderStatus dos
	INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN Product p ON p.ProductUid = pr.ProductUid
	INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
WHERE
    pub.OrganizationUid IN (N'bcb943a8-8d9d-4817-aa96-7815a66ec1c6',N'52d2d75b-5122-4e9e-a968-1386ac41da88',N'485f4f9b-e2a5-4057-8cf8-bc3809d3f5cf',N'78e84d76-ea31-406a-ab89-86b4500a821e')                           -- Part of the selected publisher hierarchy
    AND (@eISBNs IS NULL OR cast(p.Ordinal as varchar(20)) IN (@eISBNList)) -- In the List of supplied ISBNs
    AND r.retailerUid IN (N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec')
GROUP BY
	pub.Name,
    p.ProductUid,
    p.Ordinal,
    r.Name,
    r.RetailerUid
HAVING                                                                      -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	do.DistributionOrderUid
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
    CROSS APPLY 
        (SELECT 
             TOP 1 ResultingEvent
         FROM	
		     DistributionOrderAcceptabilities 
		 WHERE
	         DistributionOrderUid = do.DistributionOrderUid
	     ORDER BY  
	         CreatedAtUtc DESC) doa
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = doa.ResultingEvent
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleElementLevel = 1                          -- Product Level
    AND CASE pfd.ProductFormDetailValue 
            WHEN 190 THEN 'Fixed' 
            WHEN 189 THEN 'Reflowable'
            ELSE 'Not Specified' END IN (N'Fixed',N'Reflowable',N'Not Specified')
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))

SELECT DISTINCT
	ds2.DistributionOrderUid,
	stuff((
		SELECT CHAR(10) + CHAR(10) + SUBSTRING(ds1.ResultingMessage, 0, 2048)
			+ CASE WHEN len(ds1.ResultingMessage) > 2048 THEN '...' ELSE '' END
		FROM DistributionOrderStatus ds1
		WHERE ds1.DistributionOrderUid = ds2.DistributionOrderUid AND ds1.ResultingEventLevel > 2
		FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS ErrorMessage
INTO
	#ErrorMessages
FROM
	DistributionOrderStatus ds2
	INNER JOIN #DistributionDataset dd on dd.DistributionOrderUid = ds2.DistributionOrderUid
WHERE
	ds2.ResultingEventLevel > 2
 
SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    FailedDate,
    ReasonCode,
    em.ErrorMessage as ReasonDetail
FROM
    #DistributionDataset dd
	INNER JOIN #ErrorMessages em ON em.DistributionOrderUid = dd.DistributionOrderUid
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC,
    ReasonCode
(@OrganizationUid nvarchar(36),@eISBNList nvarchar(4000),@DateRangeStart datetime,@DateRangeEnd datetime,@OnSaleDateRangeStart nvarchar(4000),@OnSaleDateRangeEnd nvarchar(4000),@eISBNs nvarchar(4000))/*--*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9' NVARCHAR(MAX)
DECLARE N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' NVARCHAR(MAX)
DECLARE N'Fixed',N'Reflowable',N'Not Specified' NVARCHAR(MAX)

SELECT top 1 N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9' = o.OrganizationUid from Organizations o where o.OrganizationName Like '%Disney%'
SET @DateRangeStart = NULL
SET @DateRangeEnd = NULL
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL
SELECT top 1 N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' = r.RetailerUid from Retailers r where r.Name = '3M'

SET @eISBNs = NULL
SET @eISBNList = NULL
SET N'Fixed',N'Reflowable',N'Not Specified' = 'Not Specified';

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

IF OBJECT_ID('tempdb..#ErrorMessages') IS NOT NULL
    DROP TABLE #ErrorMessages
*/

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
    pub.Name AS Publisher,
    cast(p.Ordinal as varchar(20)) AS ISBN,
    p.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	DistributionOrderStatus dos
	INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN Product p ON p.ProductUid = pr.ProductUid
	INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
WHERE
    pub.OrganizationUid IN (N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9')                           -- Part of the selected publisher hierarchy
    AND (@eISBNs IS NULL OR cast(p.Ordinal as varchar(20)) IN (@eISBNList)) -- In the List of supplied ISBNs
    AND r.retailerUid IN (N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec')
GROUP BY
	pub.Name,
    p.ProductUid,
    p.Ordinal,
    r.Name,
    r.RetailerUid
HAVING                                                                      -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	do.DistributionOrderUid
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
    CROSS APPLY 
        (SELECT 
             TOP 1 ResultingEvent
         FROM	
		     DistributionOrderAcceptabilities 
		 WHERE
	         DistributionOrderUid = do.DistributionOrderUid
	     ORDER BY  
	         CreatedAtUtc DESC) doa
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = doa.ResultingEvent
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleElementLevel = 1                          -- Product Level
    AND CASE pfd.ProductFormDetailValue 
            WHEN 190 THEN 'Fixed' 
            WHEN 189 THEN 'Reflowable'
            ELSE 'Not Specified' END IN (N'Fixed',N'Reflowable',N'Not Specified')
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))

SELECT DISTINCT
	ds2.DistributionOrderUid,
	stuff((
		SELECT CHAR(10) + CHAR(10) + SUBSTRING(ds1.ResultingMessage, 0, 2048)
			+ CASE WHEN len(ds1.ResultingMessage) > 2048 THEN '...' ELSE '' END
		FROM DistributionOrderStatus ds1
		WHERE ds1.DistributionOrderUid = ds2.DistributionOrderUid AND ds1.ResultingEventLevel > 2
		FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS ErrorMessage
INTO
	#ErrorMessages
FROM
	DistributionOrderStatus ds2
	INNER JOIN #DistributionDataset dd on dd.DistributionOrderUid = ds2.DistributionOrderUid
WHERE
	ds2.ResultingEventLevel > 2
 
SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    FailedDate,
    ReasonCode,
    em.ErrorMessage as ReasonDetail
FROM
    #DistributionDataset dd
	INNER JOIN #ErrorMessages em ON em.DistributionOrderUid = dd.DistributionOrderUid
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC,
    ReasonCode
(@OrganizationUid nvarchar(36),@eISBNList nvarchar(4000),@DateRangeStart datetime,@DateRangeEnd datetime,@OnSaleDateRangeStart nvarchar(4000),@OnSaleDateRangeEnd nvarchar(4000),@eISBNs nvarchar(4000))/*--*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9' NVARCHAR(MAX)
DECLARE N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' NVARCHAR(MAX)
DECLARE N'Fixed',N'Reflowable',N'Not Specified' NVARCHAR(MAX)

SELECT top 1 N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9' = o.OrganizationUid from Organizations o where o.OrganizationName Like '%Disney%'
SET @DateRangeStart = NULL
SET @DateRangeEnd = NULL
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL
SELECT top 1 N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' = r.RetailerUid from Retailers r where r.Name = '3M'

SET @eISBNs = NULL
SET @eISBNList = NULL
SET N'Fixed',N'Reflowable',N'Not Specified' = 'Not Specified';

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

IF OBJECT_ID('tempdb..#ErrorMessages') IS NOT NULL
    DROP TABLE #ErrorMessages
*/

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
    pub.Name AS Publisher,
    cast(p.Ordinal as varchar(20)) AS ISBN,
    p.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	DistributionOrderStatus dos
	INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN Product p ON p.ProductUid = pr.ProductUid
	INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
WHERE
    pub.OrganizationUid IN (N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9')                           -- Part of the selected publisher hierarchy
    AND (@eISBNs IS NULL OR cast(p.Ordinal as varchar(20)) IN (@eISBNList)) -- In the List of supplied ISBNs
    AND r.retailerUid IN (N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec')
GROUP BY
	pub.Name,
    p.ProductUid,
    p.Ordinal,
    r.Name,
    r.RetailerUid
HAVING                                                                      -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	do.DistributionOrderUid
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
    CROSS APPLY 
        (SELECT 
             TOP 1 ResultingEvent
         FROM	
		     DistributionOrderAcceptabilities 
		 WHERE
	         DistributionOrderUid = do.DistributionOrderUid
	     ORDER BY  
	         CreatedAtUtc DESC) doa
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = doa.ResultingEvent
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleElementLevel = 1                          -- Product Level
    AND CASE pfd.ProductFormDetailValue 
            WHEN 190 THEN 'Fixed' 
            WHEN 189 THEN 'Reflowable'
            ELSE 'Not Specified' END IN (N'Fixed',N'Reflowable',N'Not Specified')
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))

SELECT DISTINCT
	ds2.DistributionOrderUid,
	stuff((
		SELECT CHAR(10) + CHAR(10) + SUBSTRING(ds1.ResultingMessage, 0, 2048)
			+ CASE WHEN len(ds1.ResultingMessage) > 2048 THEN '...' ELSE '' END
		FROM DistributionOrderStatus ds1
		WHERE ds1.DistributionOrderUid = ds2.DistributionOrderUid AND ds1.ResultingEventLevel > 2
		FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS ErrorMessage
INTO
	#ErrorMessages
FROM
	DistributionOrderStatus ds2
	INNER JOIN #DistributionDataset dd on dd.DistributionOrderUid = ds2.DistributionOrderUid
WHERE
	ds2.ResultingEventLevel > 2
 
SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    FailedDate,
    ReasonCode,
    em.ErrorMessage as ReasonDetail
FROM
    #DistributionDataset dd
	INNER JOIN #ErrorMessages em ON em.DistributionOrderUid = dd.DistributionOrderUid
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC,
    ReasonCode
(@OrganizationUid nvarchar(36),@eISBNList nvarchar(4000),@DateRangeStart datetime,@DateRangeEnd datetime,@OnSaleDateRangeStart nvarchar(4000),@OnSaleDateRangeEnd nvarchar(4000),@eISBNs nvarchar(4000))/*--*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE N'4fd43933-a501-4026-8f76-28bffbe54232',N'640b0b16-9c90-4b6c-b402-fb6338f04407',N'2759911d-461e-4075-b86c-c7f288cc7b24',N'05330ee8-9da8-4be5-8a03-73adbb517413',N'6cae0041-c00c-4b6f-ba7c-d910fc389876',N'3506f29a-9ab3-4c40-8d21-228c04a43dfb',N'd0f5649b-8f5a-4537-9f11-1e5fe09c52b1',N'2630c94c-e874-419c-8da8-c15fdec51408',N'a281acdc-740e-465b-b71e-3701b8766ef3',N'fd30bd4c-b4f4-4d97-8f33-291b804ad15d',N'd0c23401-c7b8-4924-b58d-3ccd381b318a',N'b69da51b-cd24-4bab-bd9d-d65ca1b9756b',N'ecb61548-3e98-4d56-abb9-884e16839102',N'b84672c5-2784-48e4-9129-7064b1d296fe',N'2fe8d89b-568e-46ab-a45b-20dc533c9c06',N'53611a1f-b09b-4b68-a8be-bb8159cb8583',N'1bf3630a-84c1-4250-83d3-461600bb17c4',N'2a86d9f0-6574-47ea-bead-35509ab8c983',N'1d66e68f-b02b-4d75-b65f-597190db8844',N'f72739a1-a240-499b-9fe3-cb148cf4ed74',N'cbf5fcf5-00bc-4a40-8995-93a4c0d699bc',N'c476c21c-91dc-4edb-b7bd-10d0cb88affb' NVARCHAR(MAX)
DECLARE N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' NVARCHAR(MAX)
DECLARE N'Fixed',N'Reflowable',N'Not Specified' NVARCHAR(MAX)

SELECT top 1 N'4fd43933-a501-4026-8f76-28bffbe54232',N'640b0b16-9c90-4b6c-b402-fb6338f04407',N'2759911d-461e-4075-b86c-c7f288cc7b24',N'05330ee8-9da8-4be5-8a03-73adbb517413',N'6cae0041-c00c-4b6f-ba7c-d910fc389876',N'3506f29a-9ab3-4c40-8d21-228c04a43dfb',N'd0f5649b-8f5a-4537-9f11-1e5fe09c52b1',N'2630c94c-e874-419c-8da8-c15fdec51408',N'a281acdc-740e-465b-b71e-3701b8766ef3',N'fd30bd4c-b4f4-4d97-8f33-291b804ad15d',N'd0c23401-c7b8-4924-b58d-3ccd381b318a',N'b69da51b-cd24-4bab-bd9d-d65ca1b9756b',N'ecb61548-3e98-4d56-abb9-884e16839102',N'b84672c5-2784-48e4-9129-7064b1d296fe',N'2fe8d89b-568e-46ab-a45b-20dc533c9c06',N'53611a1f-b09b-4b68-a8be-bb8159cb8583',N'1bf3630a-84c1-4250-83d3-461600bb17c4',N'2a86d9f0-6574-47ea-bead-35509ab8c983',N'1d66e68f-b02b-4d75-b65f-597190db8844',N'f72739a1-a240-499b-9fe3-cb148cf4ed74',N'cbf5fcf5-00bc-4a40-8995-93a4c0d699bc',N'c476c21c-91dc-4edb-b7bd-10d0cb88affb' = o.OrganizationUid from Organizations o where o.OrganizationName Like '%Disney%'
SET @DateRangeStart = NULL
SET @DateRangeEnd = NULL
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL
SELECT top 1 N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' = r.RetailerUid from Retailers r where r.Name = '3M'

SET @eISBNs = NULL
SET @eISBNList = NULL
SET N'Fixed',N'Reflowable',N'Not Specified' = 'Not Specified';

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

IF OBJECT_ID('tempdb..#ErrorMessages') IS NOT NULL
    DROP TABLE #ErrorMessages
*/

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
    pub.Name AS Publisher,
    cast(p.Ordinal as varchar(20)) AS ISBN,
    p.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	DistributionOrderStatus dos
	INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN Product p ON p.ProductUid = pr.ProductUid
	INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
WHERE
    pub.OrganizationUid IN (N'4fd43933-a501-4026-8f76-28bffbe54232',N'640b0b16-9c90-4b6c-b402-fb6338f04407',N'2759911d-461e-4075-b86c-c7f288cc7b24',N'05330ee8-9da8-4be5-8a03-73adbb517413',N'6cae0041-c00c-4b6f-ba7c-d910fc389876',N'3506f29a-9ab3-4c40-8d21-228c04a43dfb',N'd0f5649b-8f5a-4537-9f11-1e5fe09c52b1',N'2630c94c-e874-419c-8da8-c15fdec51408',N'a281acdc-740e-465b-b71e-3701b8766ef3',N'fd30bd4c-b4f4-4d97-8f33-291b804ad15d',N'd0c23401-c7b8-4924-b58d-3ccd381b318a',N'b69da51b-cd24-4bab-bd9d-d65ca1b9756b',N'ecb61548-3e98-4d56-abb9-884e16839102',N'b84672c5-2784-48e4-9129-7064b1d296fe',N'2fe8d89b-568e-46ab-a45b-20dc533c9c06',N'53611a1f-b09b-4b68-a8be-bb8159cb8583',N'1bf3630a-84c1-4250-83d3-461600bb17c4',N'2a86d9f0-6574-47ea-bead-35509ab8c983',N'1d66e68f-b02b-4d75-b65f-597190db8844',N'f72739a1-a240-499b-9fe3-cb148cf4ed74',N'cbf5fcf5-00bc-4a40-8995-93a4c0d699bc',N'c476c21c-91dc-4edb-b7bd-10d0cb88affb')                           -- Part of the selected publisher hierarchy
    AND (@eISBNs IS NULL OR cast(p.Ordinal as varchar(20)) IN (@eISBNList)) -- In the List of supplied ISBNs
    AND r.retailerUid IN (N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec')
GROUP BY
	pub.Name,
    p.ProductUid,
    p.Ordinal,
    r.Name,
    r.RetailerUid
HAVING                                                                      -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	do.DistributionOrderUid
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
    CROSS APPLY 
        (SELECT 
             TOP 1 ResultingEvent
         FROM	
		     DistributionOrderAcceptabilities 
		 WHERE
	         DistributionOrderUid = do.DistributionOrderUid
	     ORDER BY  
	         CreatedAtUtc DESC) doa
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = doa.ResultingEvent
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleElementLevel = 1                          -- Product Level
    AND CASE pfd.ProductFormDetailValue 
            WHEN 190 THEN 'Fixed' 
            WHEN 189 THEN 'Reflowable'
            ELSE 'Not Specified' END IN (N'Fixed',N'Reflowable',N'Not Specified')
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))

SELECT DISTINCT
	ds2.DistributionOrderUid,
	stuff((
		SELECT CHAR(10) + CHAR(10) + SUBSTRING(ds1.ResultingMessage, 0, 2048)
			+ CASE WHEN len(ds1.ResultingMessage) > 2048 THEN '...' ELSE '' END
		FROM DistributionOrderStatus ds1
		WHERE ds1.DistributionOrderUid = ds2.DistributionOrderUid AND ds1.ResultingEventLevel > 2
		FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS ErrorMessage
INTO
	#ErrorMessages
FROM
	DistributionOrderStatus ds2
	INNER JOIN #DistributionDataset dd on dd.DistributionOrderUid = ds2.DistributionOrderUid
WHERE
	ds2.ResultingEventLevel > 2
 
SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    FailedDate,
    ReasonCode,
    em.ErrorMessage as ReasonDetail
FROM
    #DistributionDataset dd
	INNER JOIN #ErrorMessages em ON em.DistributionOrderUid = dd.DistributionOrderUid
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC,
    ReasonCode
(@OrganizationUid nvarchar(36),@eISBNList nvarchar(4000),@DateRangeStart datetime,@DateRangeEnd datetime,@OnSaleDateRangeStart nvarchar(4000),@OnSaleDateRangeEnd nvarchar(4000),@eISBNs nvarchar(4000))/*--*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9' NVARCHAR(MAX)
DECLARE N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' NVARCHAR(MAX)
DECLARE N'Fixed',N'Reflowable',N'Not Specified' NVARCHAR(MAX)

SELECT top 1 N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9' = o.OrganizationUid from Organizations o where o.OrganizationName Like '%Disney%'
SET @DateRangeStart = NULL
SET @DateRangeEnd = NULL
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL
SELECT top 1 N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec' = r.RetailerUid from Retailers r where r.Name = '3M'

SET @eISBNs = NULL
SET @eISBNList = NULL
SET N'Fixed',N'Reflowable',N'Not Specified' = 'Not Specified';

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

IF OBJECT_ID('tempdb..#ErrorMessages') IS NOT NULL
    DROP TABLE #ErrorMessages
*/

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
    pub.Name AS Publisher,
    cast(p.Ordinal as varchar(20)) AS ISBN,
    p.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	DistributionOrderStatus dos
	INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN Product p ON p.ProductUid = pr.ProductUid
	INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
WHERE
    pub.OrganizationUid IN (N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9')                           -- Part of the selected publisher hierarchy
    AND (@eISBNs IS NULL OR cast(p.Ordinal as varchar(20)) IN (@eISBNList)) -- In the List of supplied ISBNs
    AND r.retailerUid IN (N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec')
GROUP BY
	pub.Name,
    p.ProductUid,
    p.Ordinal,
    r.Name,
    r.RetailerUid
HAVING                                                                      -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	do.DistributionOrderUid
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
    CROSS APPLY 
        (SELECT 
             TOP 1 ResultingEvent
         FROM	
		     DistributionOrderAcceptabilities 
		 WHERE
	         DistributionOrderUid = do.DistributionOrderUid
	     ORDER BY  
	         CreatedAtUtc DESC) doa
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = doa.ResultingEvent
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleElementLevel = 1                          -- Product Level
    AND CASE pfd.ProductFormDetailValue 
            WHEN 190 THEN 'Fixed' 
            WHEN 189 THEN 'Reflowable'
            ELSE 'Not Specified' END IN (N'Fixed',N'Reflowable',N'Not Specified')
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))

SELECT DISTINCT
	ds2.DistributionOrderUid,
	stuff((
		SELECT CHAR(10) + CHAR(10) + SUBSTRING(ds1.ResultingMessage, 0, 2048)
			+ CASE WHEN len(ds1.ResultingMessage) > 2048 THEN '...' ELSE '' END
		FROM DistributionOrderStatus ds1
		WHERE ds1.DistributionOrderUid = ds2.DistributionOrderUid AND ds1.ResultingEventLevel > 2
		FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS ErrorMessage
INTO
	#ErrorMessages
FROM
	DistributionOrderStatus ds2
	INNER JOIN #DistributionDataset dd on dd.DistributionOrderUid = ds2.DistributionOrderUid
WHERE
	ds2.ResultingEventLevel > 2
 
SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    FailedDate,
    ReasonCode,
    em.ErrorMessage as ReasonDetail
FROM
    #DistributionDataset dd
	INNER JOIN #ErrorMessages em ON em.DistributionOrderUid = dd.DistributionOrderUid
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC,
    ReasonCode
(@OrganizationUid nvarchar(36),@eISBNList nvarchar(4000),@DateRangeStart datetime,@DateRangeEnd datetime,@OnSaleDateRangeStart nvarchar(4000),@OnSaleDateRangeEnd nvarchar(4000),@eISBNs nvarchar(4000))/*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)

SET @DateRangeStart = NULL
SET @DateRangeEnd = NULL
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

SET @eISBNs = NULL

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

*/

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
    pub.Name AS Publisher,
    [pi].Value AS ISBN,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	DistributionOrderStatus dos
	INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
    AND pub.OrganizationUid IN (N'00000000-0000-0000-0000-000000000001',N'9e1d8850-532d-4704-a6af-3c8bf6dc7ee2',N'033a2f8b-a8dc-43ae-9e19-52dac8583e47',N'34e662d8-2442-45e4-ae57-12ac7c7e052a',N'cc382f86-6202-4b47-9628-62785ec8f077',N'3156cd0d-8fe4-446c-9491-482b0eecf888',N'601c0538-6e12-4873-b42d-e6fedbd794e6',N'65080660-f9a0-485e-92a2-5cf4a30854e6',N'4b02a28d-b7f7-424a-9cea-700ffea500be',N'e2c22698-8568-4a0e-8c03-1705b7e58a5c',N'34e2d303-0047-42e0-b998-944123185253',N'60dffe08-0702-4d1f-895e-9fc5cd57f31c',N'cec3ad29-04f4-4d17-9b8e-671acd0c06b7',N'4bd075e4-aeee-4870-8ff0-071cb0fda1e1',N'b24d6145-a9d9-4824-865c-4b741ac8b682',N'c04f72d6-d385-4713-8ea3-7d62f32096cb',N'7d6f4bea-a88c-463a-a819-0de4ac579fa7',N'461f4a2c-49d0-4abc-a2b0-05de1eceb702',N'd824d549-b51b-4ca2-af82-c44e0d3eec2a',N'6fbcf580-b152-482d-aa90-076a5ea94cf7',N'3c7ebaa4-b5b8-425a-a6f6-227c223c34e5',N'84178d32-0d90-4225-a1fb-264f80bfdde2',N'e17dc831-1298-4d5e-b3ce-dc68e2b5bf8a',N'4155ea72-57d1-471e-997f-1376915123f6',N'4c64a71a-cbf1-4446-ac41-bf311db56c84',N'b65e3ef8-3fe6-497d-bd98-8a764cd99c36',N'6fedfc6c-665d-466d-99ca-f8b01f7f396b',N'7feee485-eaf2-4be0-a93b-ed47a8a56ba7',N'9da90633-45b3-4334-a354-05a6b7fa215c',N'7096f34a-2550-48db-9ab4-65e951bb5534',N'1bbfda54-2c6f-4610-9321-f3ae69042b72',N'c3d0f950-024b-433b-8eba-fadfe9d6ba1b',N'4ad5ec58-7ade-4698-941f-a5da1581b893',N'617dfafc-9abf-4d30-b102-cec2cbdfbe6a',N'ebf4660c-910e-4968-9830-e70e9098318d',N'49cf026a-b5b4-4cad-9562-c786812b4bac',N'50508138-193c-4ddc-b69d-862ddb327715',N'b32de4ae-bae0-4908-8ab8-e9159ba71dd4',N'9167e9b0-0742-40c7-8526-e33ac183ebc3',N'20e9d77b-3eb9-4738-8fe1-403ba3b8a8c4',N'b8d66d8b-19de-4d00-bfb7-ded50cc12993',N'd0e0ea4a-e5fa-4b01-8b49-259202a6f1c4',N'3dabbd28-8cf7-45cb-8746-2d0ecd36838c',N'52bd4016-6e7c-4cdb-9d62-27b239e311ad',N'bcb943a8-8d9d-4817-aa96-7815a66ec1c6',N'89a2e8c7-74b4-49d4-bded-fd26ce4902d1',N'77727f05-a7b9-4791-91d1-2d9ca517b6c6',N'9fd6f976-757a-451d-81dc-ae6320dd2493',N'22336ee6-d869-4f2b-8110-647da99705a5',N'd8f06d0d-1832-4041-a672-2efc10fe1079',N'f4a8c921-f34a-4801-8036-968387958f22',N'39e4446b-5bfb-42d4-b0b0-acc5d598ac57',N'f3107f10-0e13-47ba-a75b-9e4b8e6c8df2',N'e2ceacee-9ddd-4b02-833a-b5c49850edaf',N'672fcfa0-3980-47fd-aae3-fb9fb27c2f1c',N'26b30ffe-3f2e-4039-ac03-4e2c2bc3b3bc',N'289ed3fc-a5b1-4b30-b501-e15252595d9f',N'42728bae-b714-4058-a5b2-ab055c944fa6',N'cadcfd90-7b7c-48f6-842d-d0c1e43b2cbc',N'd5db010f-0a0f-47fb-8a0b-0492a48be589',N'cd9cd64f-5a0d-4e09-9895-543f5a43b7e4',N'82827812-e0e0-4f5d-be97-08e6caa150a1',N'3bb141df-c93e-483c-bb89-eb69ed428a66',N'a249a835-f7a4-4427-b93a-8554cefd8bd1',N'5a3258e8-5676-48ff-90c6-7858a0a9a650',N'2a07c5df-5f7e-4ed6-af86-6f3077ff6b3c',N'f83002d4-4ed1-4672-9b33-36e0e87970e4',N'8e42003e-ac6e-4b8b-bb76-78bec1b8d3ab',N'4928b4f9-7910-4c95-9e29-9e51436c6162',N'bacecb01-af5b-4bfd-b138-bb09e78d525a',N'a1e048b4-5e1e-4333-b1c1-6785c197724c',N'dc7765b1-684c-48fa-99df-67ae95ca7ad5',N'dbb9007f-99a8-4bb0-a4bc-ccd7900acd83',N'2b6e1316-a38f-4e06-b4da-f5d71033ee59',N'414cfa83-1c43-4911-993a-b5ff717be5a2',N'f8f04ac8-060b-4274-b80d-1dba1296c66e',N'29020f77-33d7-4a03-82a9-2e8e9733380c',N'83f6b3e3-f62b-43a6-80e1-92c6cc322bb8',N'07bb6b31-3c59-4473-aecf-c8b23c106da6',N'e3cb6a8e-47ad-40c4-b6dd-d95231d1a31a',N'1cde0f88-721b-486f-9d49-b2c002e67145',N'c7993c99-86fd-4f2e-ae9a-8f7afe6f4ed5',N'ca0c91ab-46a4-41cd-bd0b-b46aba477488',N'68f00a4d-f956-43a9-983e-85a18723a8df',N'97d2c33b-c129-41d6-b530-6f0e6dbc64cb',N'c7f6bf63-2c7c-45b6-9d95-832d2ad2a42f',N'8822c822-191f-489d-ac76-94d48e913cfd',N'd21c0b77-501c-4aed-9bcc-73c8d59ae480',N'fb6b6ed0-d317-4124-84b1-c4844cf3ce15',N'953cfdeb-7a52-4e72-b9cb-fde5e3f8099a',N'0d6f2fa4-296b-4f12-bf40-57cd9f57b693',N'b47aa600-3e54-4f2c-bdb7-055221f44304',N'44f0637e-a057-4eb4-ba6a-b0971df41948',N'eddcdebd-e558-4e97-a9bf-77e03384c52a',N'49802113-a867-402d-9d4b-ca760bef0296',N'924fffb6-e2d5-4026-b901-f7aed89272e4',N'6f60a4a2-fd6e-4524-88c2-ed3d7066d49b',N'e6ebfdf4-78bb-44b6-93f7-0e19a00d081c',N'b5e519d9-a058-4748-840a-fad7e8089e70',N'79506cab-8cfa-42a0-863c-774f2edf24ce',N'7e1148a0-aa6c-466d-8f94-4a0f075be79f',N'190179f3-f941-463b-93d6-897caa28534a',N'b8584579-e654-4df2-8fd2-24c6ebc6dfc4',N'9d937936-8ebf-4a5d-bc79-14a07d7be161',N'de233059-74f3-40b4-ad3d-ae1662ca0a4b',N'8ffd404e-17ba-4bd3-8cac-f813550960eb',N'2dedea11-6681-4010-8f09-5f9cdc85eddb',N'4a0a4157-591d-4090-b508-ce4708cd3f0d',N'cbc8b551-389b-45de-a81f-a404c8e159bb',N'c9650b7b-3d5c-40ea-a0ed-cadad3ef0c6b',N'2c13e4ce-983a-4dbe-abe1-3208a6435a3e',N'7dbf26ce-9d95-48a0-aa2c-e67ecb066115',N'93c57340-fdb8-4b7f-a118-d792471c1611',N'273c8054-7f00-44b5-bae3-ae6ae30e7861',N'e990c4b6-6412-4d12-81f2-a19e0719b8dd',N'98a0fa96-b325-4737-a753-5e2290c3876a',N'6246e9b8-2a37-43b7-95ba-3edbb5902618',N'17e29299-63e2-45f4-a3b3-0611bc7eb647',N'b7d1f672-f2b1-4993-9de5-09d4b14e45a7',N'0d361f3e-2017-474c-8458-f8504e38eaf1',N'c14f54f7-56e6-4dd5-9682-4590e0ca28af',N'43ef6457-a5c3-4942-b2a9-99113e68c650',N'2d1d5fa9-fee9-41a8-8a71-ae5b44cc349e',N'3fa65e4d-89ea-4b9d-9e38-297c5b652fc9',N'3666fa07-6217-49e9-a213-069744777424',N'236bddde-ce50-4c00-989c-fbba59ff3459',N'4d457516-98f8-4c3e-9b31-2ab3c3c4c457',N'4586517d-d831-4da0-870a-1938e1962cb0',N'5453afd6-9808-4178-ab93-6156a2cb37a0',N'd65a0143-05e3-4c98-aac6-13e20de21eeb',N'fca143df-e41e-45b6-816a-162454bd8d05',N'4fd43933-a501-4026-8f76-28bffbe54232',N'9450ef7c-e537-4747-bdca-f88ba25c1133',N'1f913e66-ef8a-46d0-96d2-7d19f8310401',N'86c459b1-002f-4bf4-8a65-cd2a23925af0',N'eb33d408-ac1b-4e09-ab87-544896222cbc',N'7f7ec4e6-3987-4c18-be5b-de37e581e4e4',N'c54b1eea-dfda-4aab-b414-a1acbd4be784',N'f5f84e6a-f3ae-481a-a730-992416220a71',N'0034d4ef-be7f-446b-9971-69bd6939cf39',N'eb8acfc6-bb6c-4d2b-939f-391b17913cfd',N'feaf81f8-2dbd-49a3-96d2-e2c47fa3ba37',N'1c7b16d6-8637-49cd-8114-b69664ac5a40',N'98b1bc08-50b4-4ca1-a351-62b0735e9e8e',N'bc7b02d8-2c0b-44b6-83df-0e7b1ebd4330',N'72b6849f-422d-40de-86be-94f67271928d',N'3e725b22-ab4a-40c9-a1c2-16a15de4ce26',N'de63b1f1-a1a3-4c25-a6c2-e506250752dc',N'65ccd475-c44d-461b-af6c-6ad257fe1bef',N'a4e6e850-3f0f-4513-8f26-9bf19231771c',N'6a517183-44b0-40d1-a007-4ab9075735f6',N'cb4127f4-2501-4793-9c85-c38400168f5d',N'db5f7473-31dd-409b-9bf2-2653cc3e17fb',N'f7b53948-328a-4725-b0af-a2922e796664',N'd85a561a-7658-4b28-baca-6c496252cb6d',N'287caec9-caf4-48a1-a723-a2103b387208',N'f7221fdc-8b5f-4846-9711-9fcaed834ec2',N'08295f7f-e71d-4b7e-a696-3414e5404db7',N'fa856430-70d8-436d-a3a5-4eadd059482b',N'adedd8f5-c46d-4ffd-afb7-8e4e4d424dc7',N'ca3fa091-47c8-449b-a4c1-05c3dcfb203c',N'4c53dd59-fea0-47f7-b36a-929b957b7143',N'0b268bd7-327b-47fe-b0f4-ac8d99e94a5f',N'7b76e8a5-f954-4b00-be13-51f6cf8ceb6f',N'5b4edec6-d924-47df-a48b-3480c66e3b7f',N'8e29b1cd-473a-4d28-942f-5951333be1a1',N'69e6c615-892c-41e1-b67b-b534c27b3573',N'e2123171-16b9-47c2-892d-0520e3995b05',N'd31a59c7-ec53-47f6-866f-04cc85cfa692',N'f99d270f-eb28-4055-8122-27699cb657a8',N'b013860d-f12d-4e7b-ac2b-06ffa851d91b',N'0eb5ecf2-31ff-491f-adaf-307b1fb4eff9',N'75abb883-c676-489d-8128-3ac75b10f8b3',N'2d59c58e-4271-4ad8-8966-5dac3fd35124',N'1e2cc5a2-04a6-4b80-baab-155391a602a4',N'd5d41892-4d5f-4bc7-898c-55271c9244a9',N'433c4095-b92e-4f54-83c9-5b21b745416f',N'61cafc49-6352-4ebe-8872-8b5fd5130d27',N'c173986a-cece-453b-80df-e5f2211828ac',N'c0417f85-1a67-45e7-8f76-93b1d1714dc8',N'2239748e-1282-4073-923f-6f76103b1240',N'58f7a68f-8ae1-4397-8d9c-3574a0ccc6a8',N'd9341d36-43f8-4d2d-a775-9d603f0c3ca4',N'6f389fc1-2e6e-460e-9c43-0ffdf404b829',N'4fb43d31-b368-46c2-997d-1fc73420caf9',N'fcde6da5-8b57-485f-ba22-fd1f52be6265',N'61aee3cc-52a7-48c5-83b5-2f291bb94b11',N'7595235f-ef3e-46b0-9137-0bbe563f161b',N'ce77bef8-f6cb-43b4-b66b-e9a234c05600',N'6ad8eaa2-8155-43c6-9f14-a0868f87c71f',N'1079e393-dad2-4e8a-810a-0f500750d9b0',N'39aee0ab-5735-4996-84dc-6ff204d44098',N'2163b2e6-5152-4171-b0f7-012dfd8461d6',N'c9d31d69-9b47-40fb-9196-a323f1e9cba0',N'98987454-af33-4b40-a2f1-b09e249ced32',N'924b19c3-d3ce-4e4c-8f98-6c7218ae5b0a',N'a434e361-2c56-44ec-9c37-a57f241a94c6',N'03f72b09-6c90-48a6-be5e-13c19f662500',N'2fde1c24-6b9e-476f-aad2-f4b410ea23d3',N'b733e1ce-a559-4897-b988-41189c6ab38b',N'bff6d393-efbb-4330-af19-a8b52ddcd1c2',N'b8c00e49-7542-4aa3-a24d-40dffbc74d5d',N'afb63a46-83da-472f-8f0a-aa27447db608',N'9d0c99b1-b9db-44f8-907b-1f53c4443ad8',N'65e37f1c-0555-4812-9c39-13136f5604db',N'cea0b482-a93d-4a25-9c2c-590d34e2dd82',N'142123a4-42da-45ea-a93b-e7c24ca357bc',N'30cfe188-7b91-45a8-a759-bce5cb84bb8a',N'fc26b0f2-7f7d-4f5a-9ac5-cf776892f991',N'84ba00c7-5e84-488d-9fc9-5876482740b3',N'0818327e-e6bd-4951-8690-23c74b69ff18',N'ece23d81-0800-4822-8fea-6286b75320c9',N'113aa838-cca0-4301-b282-a9cecf6ccab8',N'97c6f955-afbe-4892-9aea-3ad158a364b9',N'9a00b812-3350-491b-a36b-f9ab3f45433f',N'de748ae5-aa4d-4a38-8832-4d5619bfbb98',N'8c05eb1c-5372-438f-ae82-7f41d22047aa',N'4b6a43cc-0fff-4fa2-9920-70756ce013e0',N'3eb09000-5d17-4e7d-b3df-120914f429a7',N'913ecd49-2860-4779-b6cb-236ec0b328af',N'0a428e50-b6f0-416e-8d02-a05a6cad5ba4',N'd497dcf2-379c-43fb-9975-c39653972d2c',N'21c19f40-9ea8-4c14-aa43-0e569220f8a9',N'e4f2e8cb-8b8b-4dd5-b374-1bccd895eda3',N'cf610a96-5b4c-4d5b-85a3-60b806d1e70c',N'91516763-3dbe-4d35-a68e-d751d05c4122',N'815ac31c-c055-4e19-bb83-3e30c79ccf89',N'7105fb49-d7b4-4119-94ef-308a22fb08de',N'fb8558a7-b8d2-4416-97e1-c415b35c4357',N'116c0f7b-a599-43fc-a875-247cdd666c81',N'98dd0a42-b4a8-470e-8a92-97b9da6a8a44',N'79ea0af1-720b-4c1e-9d17-69350c855dfb',N'ef88d19a-3623-4c2f-a355-dd7a59b9f1c4',N'642761de-36b9-4597-a23e-c82a41c1b0a0',N'8b062efe-d192-400e-895f-8ba48bb6ee4c',N'f6715b06-62a1-4c28-b8c7-a84b8a640494',N'184158db-10fe-4e32-8d87-031a665c4d18',N'803bcf0c-1ea0-4f09-9fbc-dfaa90e29020',N'cea052a9-2763-4c86-95c8-79da9695003e',N'36a95615-ee8c-4265-8877-270f75312226',N'd4d92c68-2f38-4c4c-8394-81016993d210',N'01604d99-67e3-4c34-98f1-d50428639856',N'a5062424-b827-4e1a-a92b-0029e68e8012',N'809764b3-d330-4e78-a971-9ea69d79dbcb',N'37769634-3cf9-44b1-bc2f-a5f6dffb1ff4',N'53d8968d-7173-4f3f-adff-da72f0cf1260',N'bdf91f3e-1801-4c8e-8fc1-6a0007fce9b7',N'3af12262-0773-4140-9a89-517bd7fc8b2f',N'085b056e-befa-46e2-b6f2-c6a4204aa107',N'a566b466-df24-467a-be66-54cbf3ec25d5',N'd80e6db4-7039-4795-8b4f-6ec363ff534e',N'cd5d9455-031c-4ce8-a1b5-33c3a7454652',N'640b0b16-9c90-4b6c-b402-fb6338f04407',N'2759911d-461e-4075-b86c-c7f288cc7b24',N'05330ee8-9da8-4be5-8a03-73adbb517413',N'6cae0041-c00c-4b6f-ba7c-d910fc389876',N'3506f29a-9ab3-4c40-8d21-228c04a43dfb',N'd0f5649b-8f5a-4537-9f11-1e5fe09c52b1',N'2630c94c-e874-419c-8da8-c15fdec51408',N'a281acdc-740e-465b-b71e-3701b8766ef3',N'fd30bd4c-b4f4-4d97-8f33-291b804ad15d',N'd0c23401-c7b8-4924-b58d-3ccd381b318a',N'b69da51b-cd24-4bab-bd9d-d65ca1b9756b',N'ecb61548-3e98-4d56-abb9-884e16839102',N'b84672c5-2784-48e4-9129-7064b1d296fe',N'2fe8d89b-568e-46ab-a45b-20dc533c9c06',N'53611a1f-b09b-4b68-a8be-bb8159cb8583',N'1bf3630a-84c1-4250-83d3-461600bb17c4',N'2a86d9f0-6574-47ea-bead-35509ab8c983',N'1d66e68f-b02b-4d75-b65f-597190db8844',N'f72739a1-a240-499b-9fe3-cb148cf4ed74',N'cbf5fcf5-00bc-4a40-8995-93a4c0d699bc',N'c476c21c-91dc-4edb-b7bd-10d0cb88affb',N'f2997f28-0b3b-496b-9333-d4753c261845',N'953eca16-453c-4af6-a817-58981b9e6895',N'2ac55743-fe32-40cb-91f5-8b047906f1a2',N'01cc0f82-b305-4918-a39d-e9325d6df64a',N'1f97a380-d1b9-43f1-b80c-80b1b4a13f8d',N'97a610f5-8d74-4233-83f9-db7d099bad01',N'706b4387-439a-432d-8da5-1f6d5651261c',N'eef9b60f-e6ba-498d-ac36-17f187cd7a6f',N'd8800eeb-2c27-4dc7-8340-e180aa096a0c',N'd7e07ea9-a653-41fa-a4ac-ff56047e3cde',N'4d1a93c0-5ce9-49a3-82f7-83876c2e5fe5',N'52a144c9-9674-48c6-95e4-99b685aed94c',N'a81500a4-16ba-403a-af59-973b29d92776',N'617c2942-3499-47d9-8d25-b4fa6cb4e35e',N'b221da1e-1189-42de-bbcc-110c76e1bb49',N'6946c4aa-7327-42be-8faf-31429ee02f87',N'c546a9cc-cbb2-41c3-9a3d-07ef792986d5',N'fc845488-83a6-4ed8-8b1e-911b8018abcd',N'fe4fdf36-9628-4889-8640-dfaf3ec4ddca',N'5d303ff0-7e1a-4571-9cd5-4eebd5942fcf',N'5ab0cef2-a751-4358-90fc-4ba253c56fbf',N'6cd3e34d-fc6e-4c65-ba39-cbb98be96c4f',N'9fd4ab6e-c397-4be8-9c6a-784669f17989',N'1b0c13ac-422d-441c-ac7c-d52e18e86726',N'39584588-1ec2-45e7-9b1e-c0a9b7dcd423',N'51d0c913-8537-4744-9b34-6c59a1307655',N'3bd63b4a-c3ae-4b84-be7b-26a8890def55',N'884ed4b9-858a-49cc-99f9-dad736c03281',N'e076cd11-030a-4460-b6d0-3616c94790c0',N'775904b5-5c31-498f-980a-79ad046ec5a7',N'1ecb6caa-b63b-4ae8-b44d-e6472c1997cc',N'4b8d41d5-d61a-4b95-a8a5-9b4dd67c92eb',N'f70d1e37-da99-47d0-b62d-4c407892c63e',N'56b2fd3f-2e1e-4c1c-86e5-5a4ce788cc17',N'9e83b7d9-d595-4754-818e-a7bded876599',N'22e7d935-314a-4b4a-a259-6d94b7cb0a30',N'd2d8ec2a-18d5-4f2c-8327-74da94255fe6',N'e58e1775-7db1-4d1b-b581-d20e14414077',N'7127ab11-b825-4568-8115-3555e5e92cf3',N'6e1914c0-4170-43ce-8b0a-c835cdf4ea1a',N'f35cc11c-156e-41ba-9903-5dcf050a48a7',N'd541ddeb-50e6-4c79-a3d2-5ae485e27796',N'b341686e-fe98-4cc2-a772-8e1e51a484b3',N'5470d25a-6391-40e1-bf0c-5af5436c0bfd',N'7df916c1-76e5-4f5d-bd8b-7a64fa186d3b',N'66fa01cd-642b-476a-95d4-ed011fcbae2f',N'99a52fb3-4892-45e4-956d-57ce8046b78e',N'ff3de438-232c-4785-aeab-235560215de7',N'1390a0a5-3fe6-467b-bf7b-d8ba5e3a2e67',N'0c0ef816-82ed-4b0b-9909-04e1251d8e93',N'333cd196-cd62-4316-9749-305266bd6017',N'fcd4407f-bf5d-439e-9317-3b94d2b261c2',N'22e27c61-64e0-4ca1-8c5a-c53b4034bcbc',N'225373bf-51a8-4f2b-b736-78e43a73a256',N'aff73b2f-255f-4129-bf28-f7042ef5b2b5',N'cea3fbeb-079d-4770-bad5-09b48f05034d',N'97e56404-d710-42d8-bb4d-7e6e79655f34',N'16567dbf-0366-4466-aae7-1b57c5708af4',N'44fe7152-2cac-43e0-a55e-64446fb96b89',N'16d4b75c-a66d-4f13-85e3-8d23d8b2f73c',N'9e08244e-6c76-438f-998e-61a662126316',N'539c29a4-f85b-4d05-90dc-3069dd75db26',N'1a5edc0d-c8eb-42fe-9fe5-6c04eed564e9',N'43bf2b47-4459-4922-8fac-ee2227993c5e',N'08525a45-8193-4ee1-8e1b-75765d9f2367',N'6ba5bafb-fa17-4b82-b814-9f7193cf8993',N'24fe0e97-3f0a-4e04-8a1b-1938deee178c',N'be8024b1-5960-4f77-9991-be58acf0ed05',N'bd2eba6c-47bb-4068-a5ab-aac30feb98ee',N'5abd1160-53ee-4a1f-9655-c833727ccd64',N'1fccae9e-b9d8-42fd-821c-7fb08f648d72',N'4e4123cd-588b-4284-9971-14c83125af39',N'388a6cb0-b455-47a5-a2a3-95eb7c49313e',N'01a98132-28f6-4579-9f7d-33776cf1f4d6',N'117a90e4-8984-4bf3-bea7-d92b78241c74',N'e2ad8a7c-027f-4619-a000-4197ec3ec202',N'32428a9e-d780-41e6-b7c9-7b3a8d72fa6b',N'9b389c7f-4c77-43d8-9369-7b5f174a7f4a',N'99dd7d44-b1a2-49dd-be8b-1c7df158c703',N'470c6c2c-5184-461f-b42a-90f5505a411c',N'7d68457f-4ddd-40a3-8f5a-acab677eb5bd',N'fd949a79-3ca2-41e0-b09b-06e01741c262',N'2fe1c485-311b-4e5a-bc4c-d10b7b52e217',N'97676df3-7a2e-479b-9b5d-6e2963f3e240',N'5aedfcaf-73ee-4e40-87ee-456eb0f361d7',N'2e2f86ad-17f2-4f35-af8e-56abb8c21512',N'0ef92d05-8cd7-4fe1-b3d0-0102bd7aede6',N'd1cfdca9-7be9-45dc-9b3f-6b2cdcbf6261',N'd08064c8-59c6-46bd-b435-e49531c0849c',N'016d523f-1c55-4f94-9f63-6f173b80c171',N'825248c8-0e18-443b-9fd1-129e1a82c704',N'887105e6-3e25-4f2b-98ef-008f0212eaed',N'1ee8bbde-a239-4a74-9e98-2bb779fda7ee',N'26880b4e-6e1e-4f22-bbd6-a18b93345c24',N'52d2d75b-5122-4e9e-a968-1386ac41da88',N'485f4f9b-e2a5-4057-8cf8-bc3809d3f5cf',N'78e84d76-ea31-406a-ab89-86b4500a821e',N'4a5b3201-2a2c-4687-b554-05ac1568e83d',N'63989ea3-22ac-4ed2-a523-de9c31b745a9',N'556257ee-ddd2-4d4d-8835-6d584889008d',N'585aadc8-3ba2-4212-b56e-0df48e7208ff',N'6d7bbd31-0d2b-4681-86e5-ecb11127ff48',N'dde5f56e-0e2d-4a2f-a5c2-49054c001d0b',N'b906e559-f9d3-4fc1-9155-b6bcef15a52d',N'7c086579-c218-4695-998a-e9d04227ca5c',N'19abbdff-f35f-43c2-837c-42da37b08f47',N'367c90fb-ea8f-4c90-a838-7bbca1db8e63',N'e978c62e-c687-4a86-b063-4f8f4875e582',N'8c5ea4db-1d82-48da-bd6b-81d3772ead08',N'6d5312b4-0cb1-41c5-a4f6-5a794f2f9a8d',N'5180f3e5-a6a4-4793-b5a2-28851674379b',N'ace41370-8073-48a4-bfe3-38a41e341c0a',N'3f61c6f8-1116-4f9f-b766-54c79102ca26',N'c040c6e3-8ae7-4763-b3dd-d356b2bf75bc',N'74bea064-0853-4bd4-b282-6d86797fcb0b',N'6193cf3c-a84d-453a-9307-6311a6e33b8a',N'bd84c49d-24f2-4772-a95f-f06e43add013',N'659af5cf-2c4b-44dd-b779-5b76c927a69e',N'c9cb6143-e27b-4b4f-bbb3-1fa5ecdeac60',N'5ddf227a-a726-4dd5-be1d-6dc6f3728cc4',N'c7e7ce1b-431e-4202-8751-83755ce14df5',N'd4fa286d-8523-4fba-b21f-9fc6e013f312',N'f330e86a-9b7f-4a1d-a1d4-2e504046111c',N'22255e13-787e-41c3-a00a-139d08278811',N'c905760f-c46d-4513-adce-7eb0dc2580a0',N'04cadebf-c5cb-45ae-8b29-6096e4fdb6f9',N'dce2cbf7-08b5-4b2e-8fb3-0170b6c61001',N'73f26575-5faa-4261-a1e4-90b15928e413',N'0edc6506-96b9-4b8a-9910-280fb986a421',N'ff2cec45-ceb5-4d82-965d-c5a44a72cea4',N'30fafe1c-e0db-431f-bb4f-9230c89739ba',N'1f95f1e8-170b-4d3b-aa50-a9a890ad5704',N'1d4a8881-a238-4794-bf72-060a868c081e',N'50144a35-ba23-421b-a4a3-1ae21850d8e1',N'a7bc529d-a62c-4e10-a07c-17d960b02e00',N'381d78b4-fb5f-457b-aa19-4ce976eb5b76',N'18969706-4917-4f3f-b299-1cc068f418db',N'70537376-1d42-46c8-8da6-54127197a586',N'31a974e9-2843-4606-80bd-e26a8bdeb151',N'd134c7ab-82cc-494a-872e-e87c903d9c26',N'd663befe-11f1-44ce-971e-7b477396ad52',N'8e1658d6-37b3-49df-88b0-77b01924bffb',N'c467b20a-5f4d-47ce-8db9-ff3ba17bbfd9',N'0887394f-bb10-4550-905a-e81ce590c5e2',N'95e69157-5696-469e-a4a8-d508cdc5dc3b',N'fb750139-ebd7-465d-9893-8a15145d87c6',N'597c03f4-3a6b-4171-8c33-8ced57f7e955',N'd784c6a1-79da-46ce-bed7-39abc4849770',N'7cc59efc-7953-4454-9a06-7b59d3cdbbae',N'10b7d8e2-e668-418f-98c0-f8cb7a55022a',N'85a76270-6bed-4a2e-9534-0203f372a4e8',N'd60ce2ed-eecc-4dc6-a589-f35b5d344669',N'0086adc0-ae96-42cb-9b05-8fa4226f4838',N'239db60c-d230-4ac5-a92c-4b77db50a153',N'4720d3bd-a03a-458c-ad7b-e864535190a8',N'f4496e56-5370-4dbf-9b2b-33f698e7adfe',N'2bcce841-20d4-45c3-bde7-4b6acbd11fb8',N'423584bc-1041-4d63-8313-f6d32ad3c98e',N'd2d21bb8-555a-4473-a16a-c92ec1757dca',N'784184f8-34fe-4781-a5ce-edca45e2ff8d',N'62fb0f5c-0dcc-425d-9e2a-d54439e1300d',N'e2bee8e7-a4c0-4aa1-9246-81261607e4ea',N'9fc3cd6c-3b98-40ad-85d9-e4521e914e9e',N'33253b61-2cea-4aec-bb35-cb2130a3173e',N'9996c20d-8c6b-4fde-a68f-ed810bf8c40a',N'1ca4e91a-8b0b-40d9-95a4-6fd5823a8328',N'a00a89cc-e89b-4b07-9272-427609403ef1',N'f1683dca-af2f-4179-87ab-4a8d7dbf109f',N'8fda07e4-346b-4e64-8e0a-53aeb014b49f',N'56d4aff2-5128-4d0a-b6d7-cda84afcde93',N'9b73b5a8-7f8f-4139-ae61-cdbf70817b3d',N'994c28d6-b100-44b6-948c-7539f2879df9',N'60663551-eac4-4598-b82f-8487d4a20f68',N'7d05a8f7-b604-47f9-85fc-863f527ed6c2',N'7a235931-8084-4519-a631-a595b1be8587',N'e101c9b7-34fe-4a03-8d7e-d4ab3c99397f',N'98e9729c-75e0-4f84-bb89-e169e33d0404',N'49112284-8b5c-425c-a752-b7982484ffe1',N'ce553777-85a9-4c7b-80f3-46e9acbdd9dd',N'ab0bf3e8-b3dd-4927-8ce3-1350aa79e5b4',N'c251d4cc-2fa1-42ce-8135-049fd546af88',N'303a0b8d-a6ec-4bfd-80b4-a04f07f024de',N'1afc0956-2878-42e2-97a3-d96d6b12f43a',N'ab041a55-8137-46ce-ad51-d5013d14df0b',N'a7cf0e7f-5062-4ecc-8f88-5978b0999a4f',N'a7b202a4-e403-4339-bf01-784bd2b6643c',N'1d8a007f-c17e-4a48-a6e4-111769baa318',N'c5a22b9d-9a1d-401a-8896-8fdb8570df66',N'1b0b0def-2508-44eb-b2f2-1d34491f9243',N'1104b085-bdc3-4ffc-9b6f-4691614b37c3',N'71d86351-9a4a-4f95-a4fc-f46f81b4ebcc',N'84b21cde-fa56-46f2-812b-81cb399e39cc',N'89f2c509-ff9c-4020-be59-4eccc016e09a',N'3f33a578-19ae-4935-8a70-7f5593c99313',N'6ce5c361-0d0f-4505-bbca-c65b231a71b4',N'dc7e1d19-d514-48d7-a4cd-7d489947000d',N'7d7661f3-5169-4b96-b27e-aa8969d678ad',N'9b1efa11-931b-426c-9947-51278be59269',N'73d1f437-1baf-4e17-ad4e-91b144373e8a',N'77374b85-5c25-4429-8b11-77bd8e373df5',N'd03644b6-03b5-4b14-9969-db8a12d4adf5',N'03fe8fc8-6038-4861-afd1-f74680e1defd',N'7da3a699-a108-4b60-8fff-40be21406150',N'2756da91-cc08-41fe-908b-ef30768d4bbf',N'f9f203fa-a845-40d1-a9e0-ce201dafc6fa',N'42ddf509-7124-4498-96a4-313169691a3d',N'99276569-9c26-45b9-af3c-6d47c46a2a14',N'923cafd8-f345-4460-9d41-bbf675bd3cc2',N'1d926e5e-8e55-4482-9b46-53592140ad2e',N'bd43d351-8bc8-43ad-a2e1-7a1e217ca85a',N'fed8c5fb-bac8-44a5-89e5-524fc3580f04',N'22329fac-5dc5-4ff7-99a2-cef8e4b87e1f',N'fb308b4f-313f-4dad-8f7a-769d9b92d498',N'3bd34e8e-1a1d-4aca-8cb8-1401ac7bc8d5',N'0b3a3a04-54d3-4383-8a71-090f4c29dfc1',N'91da6261-274d-4da7-991a-b6abc65a117f',N'a2c1ee3a-7690-43e1-b4fe-959d76b08788',N'19558751-cbec-42e1-a745-615a51d97d85',N'7edd8d91-7f42-4bad-a289-73479a628231',N'f1d55a8a-860e-4e2d-9aea-50704ef93f1e',N'36b757ab-9118-4511-ad45-ca2174e273af',N'952ffa70-06f9-4055-b287-9c1daf76f470',N'8b75d5b7-4330-418f-b09b-2578f902e1c8',N'f4a5dabb-9be0-45c1-91ea-0f8cdef1a169',N'e5b622b8-e9aa-47a8-a2e3-d32372cdd715',N'12de9834-c0f0-49b7-9412-ef2f4a784775',N'e1c6d9c9-a053-44cd-8867-f9a16760e987',N'854bf83f-53b6-47d3-a63c-dff790010839',N'a60d76e5-5d04-4f8c-a8a0-bd669b340a32',N'3c117336-00e1-40c3-9184-b9ffe56c47da',N'73de21d4-2eb2-4d2e-b819-da5cebb0b6ff',N'5a31eb76-7c0c-46e4-9534-0990393b9e60',N'536685e5-6dcf-4af6-9074-edeabb9bd60e',N'fedd8a27-f9a2-4a75-89e5-66464d478dd6',N'3cb37eb3-bff4-474d-8421-5b4097584c80',N'de176d59-69d4-4dd6-88e9-cbb5a199a195',N'c4f17633-1664-482c-8f07-87aaae526335',N'ab8db03d-89df-4b7e-b436-9a9dd4210125',N'7cac4f58-3bcf-4421-890f-be6d40e1dea0',N'44fca7eb-a2cd-44e0-a4a3-ac24f883898b',N'3dbc83e7-42da-4241-bfad-a5093f995bb9',N'1961bf94-3df6-44e9-9bc1-692aa92bccc7',N'326e1899-c08e-4334-b0a5-ec4de50da1ac',N'b6a7f9d5-ea72-436f-a21a-9b8e8c243abb',N'203887ae-d140-4e48-b172-708b646664e8',N'1a63332f-06c2-48cf-a5bf-2d239c01dc04',N'41ae2668-f8e2-4a3a-b8de-d1400ffb50ee',N'4c2718e5-be33-4821-8122-2e3cd73eda70',N'086dd74f-cb4c-4c29-a40d-efa84f55195e',N'79bb87d5-a904-4007-8afd-d027e3d83089',N'3c944e87-531a-4306-a47f-dd121190fc7c',N'714a2f23-5153-419f-9662-f6b60caaeb1e',N'd93ae5c8-3d9a-48a9-9451-d8cf2cceb21f',N'b5d43313-0d63-4abe-bff5-6501586451e1',N'f93a0857-2bd3-4443-907a-2b40b90490d8',N'c2a9b3ed-987a-4797-a9b0-16bdfa64797f',N'fafaa5b2-eaa0-4ce7-9ba7-67bcbfd63c25',N'86ca5672-de2b-459a-9ae2-9feea1339494',N'810e67b6-5121-456a-8550-a5d672e51646',N'd69b9113-2ec2-41ad-a9e3-d9306c859b61',N'ac544b93-2e7e-4383-a357-7cdb729b202c',N'3196306e-6752-41ac-81c8-d7e5d1a15eb5',N'dd58fcb9-438f-4c0f-b851-c4523c0063b7',N'45576f6f-a5d9-4103-860a-10159ba43a33',N'2a199a9e-d500-4419-afe6-c156d3a2b1ac',N'287ba847-1ded-4bfd-a969-82fb0ba968db',N'7470eccc-fb02-4e2b-ab13-b06273ce407d',N'345a8280-299f-4e0c-90bf-c658aa67de8b',N'c4756bf1-b79c-4791-ae22-ca8e97e913aa',N'440e68c6-f2c7-4a69-82df-5e5a060a844d',N'e427b0ec-d1c4-4e41-bb26-ee00bfb3d271',N'5b6c07df-d131-4a65-a427-b9b131236470',N'1329614d-0ede-4a8d-ac9c-f5c3bb3e6173',N'6dc8f4d1-54a3-4fe1-b6a7-9e5323f632fe',N'160320a3-bf0f-4818-be79-6a6b75c6fc6e',N'bc6f6ea1-79c9-489f-92ff-9ecb64aad013',N'cafad8a3-5eab-4f6d-b689-66c131811ad6',N'0fc32c80-0918-469e-9d23-7d64b7ba2578',N'da1609d5-bedf-48ff-a2ed-d5502e8aa733',N'9a4eed00-680f-4438-9ddd-90bed78aecbe',N'1c26bd17-216e-4a24-89d7-f621d1998d88',N'1bc95401-a771-4183-8a38-41876457c5d3',N'53c6d2a3-7383-4150-8e67-501d35a55e97',N'19dd9358-b36c-4065-b647-c410c161200c',N'06e31860-a1ed-48b8-8e52-b6b372529e00',N'1dbfbee7-f979-48d9-b5b0-cfaac8ca11d1',N'bd3fa46c-dce6-453f-8ff4-20e18b615bf7',N'b021ffe5-08db-4111-8616-13678ae8a558',N'11c5fe7b-e550-4c4f-8fb5-ee79829189e3',N'e815ac7e-9b70-4eb5-83ee-02356ab8e88d',N'aa574d83-1a5a-4789-ae97-f6a47471f04b',N'9adb062e-f5dc-4a0f-b125-62cc55e9b77b',N'5c729fae-a7f6-4fa0-9fcc-9b9598ab1b6e',N'9f6f59a3-09a7-4d1a-8f3c-19ce1a41dab0',N'9f5e7ccf-1802-4286-8813-7fbf247ca8b9',N'8f3a0b23-425d-4871-b2d2-0284eec1f5b0',N'3554a049-95e3-461f-832b-f955659d6090',N'dc7d305e-d536-4ab1-b28a-a4949be8663b',N'76bc7476-6767-415a-b0e7-ecf0e2a25e54',N'f47870fc-d655-46b4-b311-dc9d2bd2a670',N'd7ba45cd-6b16-479c-8a17-a45bd29c2461',N'5bef393d-3522-494f-942d-fc62f0d06a68')     -- Part of the selected publisher hierarchy
    AND (@eISBNs IS NULL OR [pi].Value IN (@eISBNList))   -- In the List of supplied ISBNs
    AND r.retailerUid IN (N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec')
GROUP BY
	pub.Name,
    pr.ProductUid,
    [pi].Value,
    r.Name,
    r.RetailerUid
HAVING                                                     -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS DistributionDate
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190) 
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    dos.ResultingEventLevel <= 2						-- Successfully
    AND ret.Code = 'DITC'
    AND av.ValidUntilUtc IS NULL                        -- Most recent version
    AND pd.PublishingDateRole = 1                       -- Main publishing date
	AND td.TitleTypeCode = 1							-- TitleTypeCode.DistinctiveTitle
	AND te.TitleElementLevel = 1						-- TitleElementLevelCode.Product
    AND CASE pfd.ProductFormDetailValue 
            WHEN 190 THEN 'Fixed' 
            WHEN 189 THEN 'Reflowable'
            ELSE 'Not Specified' END IN (N'Fixed',N'Reflowable',N'Not Specified')
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))

SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    DistributionDate
FROM
    #DistributionDataset
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC