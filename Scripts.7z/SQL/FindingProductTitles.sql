;with ProductTitles as (
select distinct Ordinal, 
COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title
from Product p
join Asset a on a.ProductUid = p.ProductUid
join AssetOverride ao ON ao.AssetUid = a.AssetUid
	and ao.AssetOverrideUid = 
	(
		SELECT TOP 1 AssetOverrideUid
		FROM AssetOverride
		WHERE AssetUid = a.AssetUid 
		ORDER BY RetailerUid -- it puts the NULL retailer override on the top
	)
join AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
join TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
join TitleElements te ON te.TitleDetailId = td.TitleDetailId and te.TitleElementId = (select top 1 TitleElementId from TitleElements where TitleDetailId = td.TitleDetailId order by len(TitleText) desc)
where av.ValidUntilUtc is NULL
and te.TitleElementLevel = 1
)
select ordinal, count(*) from ProductTitles group by ordinal having count(*) > 1