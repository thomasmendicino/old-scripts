--BEGIN TRAN
--ROLLBACK
--COMMIT
IF OBJECT_ID('tempdb.dbo.#MigratingAlbums') IS NOT NULL
DROP TABLE #MigratingAlbums
GO
CREATE TABLE #MigratingAlbums (Album int)

INSERT #MigratingAlbums (Album)
SELECT Id FROM Album WHERE
Gtin IN ('9781624606397',
'9781624606427',
'9781624606403',
'9781624606434',
'9781624606441',
'9781624606687',
'9781624606694',
'9781624606700',
'9781624606724',
'9781624606779',
'9781624606762',
'9781624606786',
'9781624606748',
'9781624606793',
'9781624606809',
'9780792798149',
'9780792798200',
'9780792797432',
'9781624606847')

select cm.*
into #ContractMediaBackup
from #MigratingAlbums a
	inner join ContractMedia cm on a.Album=cm.Album

IF OBJECT_ID('tempdb.dbo.#NewContract') IS NULL
CREATE TABLE #NewContract (Contract int)

INSERT INTO #NewContract (Contract)
VALUES (23869)

DELETE FROM ContractMedia WHERE Album in (
SELECT Album FROM #MigratingAlbums)

INSERT INTO ContractMedia (Contract,Album)
SELECT Contract, Album FROM #MigratingAlbums a
CROSS JOIN #NewContract