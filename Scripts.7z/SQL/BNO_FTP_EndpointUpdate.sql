begin tran
select r.Name Retailer, p.Name ContractPublisher, dc.Name DistroContract, ftp.* from transferServiceFtpEndpoints ftp
join TransferServiceEndpoints ts on ts.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join distributionContracts dc on dc.TransferServiceEndpointUid = ts.TransferServiceEndpointUid
join contracts c on c.contractUId = dc.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where c.ValidUntilUtc is NULL
and r.Code = 'BNO'

update ftp set ProtocolType = 2, HostName = 'sftp-pub.barnesandnoble.com', PortNumber = 22, StartingDirectory = '/', UserName = 'D0763', Password = 'nY9hYgGou' from transferServiceFtpEndpoints ftp
join TransferServiceEndpoints ts on ts.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join distributionContracts dc on dc.TransferServiceEndpointUid = ts.TransferServiceEndpointUid
join contracts c on c.contractUId = dc.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where c.ValidUntilUtc is NULL
and r.Code = 'BNO'
and dc.Name = 'Barnes And Noble Ftp for Cover and Metadata'


update ftp set ProtocolType = 2, HostName = 'sftp-pub.barnesandnoble.com', PortNumber = 22, StartingDirectory = '/', UserName = 'D0453', Password = 'Ans7zaGBr' from transferServiceFtpEndpoints ftp
join TransferServiceEndpoints ts on ts.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join distributionContracts dc on dc.TransferServiceEndpointUid = ts.TransferServiceEndpointUid
join contracts c on c.contractUId = dc.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where c.ValidUntilUtc is NULL
and r.Code = 'BNO'
and dc.Name = 'Barnes And Noble Ftp for Scholastic Cover and Metadata'


update ftp set ProtocolType = 2, HostName = 'sftp-pub.barnesandnoble.com', PortNumber = 22, StartingDirectory = '/', UserName = 'D1553', Password = '#20$K5s' from transferServiceFtpEndpoints ftp
join TransferServiceEndpoints ts on ts.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join distributionContracts dc on dc.TransferServiceEndpointUid = ts.TransferServiceEndpointUid
join contracts c on c.contractUId = dc.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where c.ValidUntilUtc is NULL
and r.Code = 'BNO'
and dc.Name = 'Barnes And Noble Ftp for Dover Publications Cover and Metadata'


update ftp set ProtocolType = 2, HostName = 'sftp-pub.barnesandnoble.com', PortNumber = 22, StartingDirectory = '/', UserName = 'D1551', Password = '9?s$B2g' from transferServiceFtpEndpoints ftp
join TransferServiceEndpoints ts on ts.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join distributionContracts dc on dc.TransferServiceEndpointUid = ts.TransferServiceEndpointUid
join contracts c on c.contractUId = dc.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where c.ValidUntilUtc is NULL
and r.Code = 'BNO'
and dc.Name = 'Barnes And Noble Ftp for Research And Education Association Cover and Metadata'


update ftp set ProtocolType = 2, HostName = 'sftp-pub.barnesandnoble.com', PortNumber = 22, StartingDirectory = '/', UserName = 'D1551', Password = '9?s$B2g' from transferServiceFtpEndpoints ftp
join TransferServiceEndpoints ts on ts.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join distributionContracts dc on dc.TransferServiceEndpointUid = ts.TransferServiceEndpointUid
join contracts c on c.contractUId = dc.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where c.ValidUntilUtc is NULL
and r.Code = 'BNO'
and dc.Name = 'Barnes And Noble Ftp for Creative Homeowner Cover and Metadata'

select r.Name Retailer, p.Name ContractPublisher, dc.Name DistroContract, ftp.* from transferServiceFtpEndpoints ftp
join TransferServiceEndpoints ts on ts.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join distributionContracts dc on dc.TransferServiceEndpointUid = ts.TransferServiceEndpointUid
join contracts c on c.contractUId = dc.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join publishers p on p.PublisherUid = c.PublisherUid
where c.ValidUntilUtc is NULL
and r.Code = 'BNO'
order by p.NAme

--commit