select * from musicservice where name = 'imusica'

select * from album where gtin = '00601091070653'
select * from albumoverrides where album = 315998
select * from track where album = 315998
select * from trackoverrides where track in (select id from track where album = 315998)
select * from song where id in (select song from track where album = 315998)
select * from songoverrides where song in (select song from track where album = 315998)


select * from autosynclog where stagingpath like '%602527856513%'
select * from albumoverrides where album = (select ID from album where gtin = '00619061399628')
select * from changerequestimportlogbatch where changerequestbatch = 123735
select * from changerequestbatch
select * from changerequest where album = (select ID from album where gtin = '00619061399628')
select * from process
select * from albummultidiscmapping where album = (select ID from album where gtin = '00619061399628')
select * from album where gtin = '00619061399628'
select top 100 * from album where coverart like '%.tif%'
select * from track where album = (select ID from album where gtin = '00044003152595')
select * from trackoverrides where track in (select id from track where album = (select ID from album where gtin = '00044003152595'))
select * from song where id in (select song from track where album = (select ID from album where gtin = '00044003152595'))
select * from songoverrides where song in (select song from track where album = (select ID from album where gtin = '00044003152595'))

select top 50 * from autosynclog where stagingpath like '%619061399628%'
select * from album where gtin = '00044003152595'

select * from process
select * from autosynclog where stagingpath like '%00044003152595%'
select * from pendingimport where date between '2011-10-12' and '2011-10-13'
select * from 
select * from pendingimport where orderid = 
select top 50 * from importlogentry where importlog = 326396
select top 100 * from importlog where receivedat between '2011-10-12' and '2011-10-13'
select * from importlogentry where importlog in (select id from importlog where receivedat between '2011-10-12' and '2011-10-13')
where sourcedata like '%619061399628%'
select * from musicservice

select * from distributionsetitem where distributionset in (100,2783)
select * from distributiontype
select * from autosynclog where sourcedata

select * from song where isrc = 'CAV509971804'
select * from track where song in (377203,412106,2511127)
select * from album where id in (40097,42217,313724)

select * from importlogentry
2667
select * from ingrooveslog.dbo.log where message like '%602527856513%'
select * from musicservice where distributionset = 2667
--begin tran
--commit
--update musicservice set DistributionSet = 2667 where name = 'Sonora'
select * from musicservice where name = 'sonora'
select * from musicservice where distributionset = 1 and supportdistributionset = 1

select distributionset from album where gtin = '881034916211'
select distributionset, * from track where album = (select id from album where gtin = '881034916211')
select * from songcut where song = (select song from track where album = (select id from album where gtin = '881034916211'))
select distributionset, * from song where id in (select song from track where album = (select id from album where gtin = '881034916211'))


select distributionset, supportdistributionset, * from musicservice where name = 'Ingroovesmobilewav'
select * from distributionsetitem where distributionset = 2667
select * from distributiontype


select * from album where gtin = '00044003152595'
select * from albumoverrides where album = 310749

select * from countrysetcountry where countryset = 48824