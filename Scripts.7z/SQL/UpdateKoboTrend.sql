IF EXISTS (SELECT NULL FROM TrendFileConfiguration WHERE RegularExpression = 'kobodaily_[\d]{8}_ingrooves.csv$')
BEGIN
DECLARE @KoboConfig int
SELECT @KoboConfig = ID from TrendFileConfiguration WHERE RegularExpression = 'kobodaily_[\d]{8}_ingrooves.csv$'

UPDATE TrendFileHeader
SET [Column] = 'Total_QTY' WHERE TrendFileConfiguration = @KoboConfig AND [Column] = 'Qty'
UPDATE TrendFileHeader
SET Position = 12 WHERE TrendFileConfiguration = @KoboConfig AND [Column] = 'Zip_Code'
UPDATE TrendFileHeader
SET Position = 13 WHERE TrendFileConfiguration = @KoboConfig AND [Column] = 'Billing_Country'

IF NOT EXISTS (SELECT NULL FROM TrendFileHeader WHERE [Column] = 'Imprint' AND Position = 14)
BEGIN
INSERT TrendFileHeader
(TrendFileConfiguration, [Column], Map, Position)
SELECT @KoboConfig, 'kobo_QTY', '', 11
UNION
SELECT @KoboConfig, 'Imprint', '', 14
END
END
