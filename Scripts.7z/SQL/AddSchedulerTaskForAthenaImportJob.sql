/****************************************************/
/* Creates a schedulable task for the Athena Import */
/* Job, and enables automated running of the job ****/
/* once per day at 11:55pm **************************/
/****************************************************/
IF NOT EXISTS (SELECT 1 FROM Task WHERE [Description] = 'Run AthenaImportJob unattended Job')
BEGIN
--BEGIN TRAN
--COMMIT
--ROLLBACK
DECLARE @Parameter int 
DECLARE @JobName nvarchar(50)
DECLARE @ParameterCollection int
DECLARE @TaskType int
DECLARE @Scheduler int
DECLARE @TaskId int
DECLARE @RecurrenceInterval int
DECLARE @TaskNode int

SELECT @TaskType = Id FROM TaskType WHERE StartAPIMethod = 'OneDigital.SchedulerTask.runJob'
SELECT @Parameter = Id FROM Parameter WHERE Name = 'JobName'
SELECT @JobName = Name FROM Job WHERE [Description] = 'Import Athena Titles'
SELECT @Scheduler = Id FROM INDMAUser WHERE Name = 'Scheduler'
SELECT @RecurrenceInterval = Id FROM Recurrence WHERE Name = 'Day'

INSERT ParameterCollection DEFAULT VALUES
SELECT @ParameterCollection = SCOPE_IDENTITY()


INSERT ParameterCollectionItem (ParameterCollection, Parameter, Sequence, StringValue)
SELECT @ParameterCollection, @Parameter, 0, @JobName

INSERT Task (TaskType, WaitUntilReady, ParameterCollection, [Description], INDMAUser)
SELECT @TaskType, 0, @ParameterCollection, 'Run ' + rtrim(@JobName) + ' unattended Job', @Scheduler
SELECT @TaskId = SCOPE_IDENTITY()


INSERT TaskNode (Task, KeepSession_DEPRECATED)
SELECT @TaskId, 0
SELECT @TaskNode = SCOPE_IDENTITY()


INSERT CalendarItem (StartAt, [Enabled], Recurrence, RecurrencePeriods, Priority, TaskNode, InsertAtFront, AutoRemove)
SELECT '2013-04-25 23:55:00.000', 1, @RecurrenceInterval, 1, 10, @TaskNode, 0, 0
END