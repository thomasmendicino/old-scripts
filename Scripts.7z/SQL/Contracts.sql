select
r.Name [Retailer Name],
p.Name [Publisher Name],
dosgc.Name [Distribution Order Structure Group],
tmrct.Name [Structure Resource Content Type],
tmat.Name [Structure Asset Type],
tmat.Description [Structure Asset Type Description],
dosc.PathFormat [Structure Path Format]
from
AthenaUATDistribution..DistributionOrderStructureContracts dosc
inner join AthenaUATDistribution..DistributionOrderStructureGroupContracts dosgc on dosc.DistributionOrderStructureGroupContractUid = dosgc.DistributionOrderStructureGroupContractUid
inner join AthenaUATDistribution..Contracts c on dosgc.ContractUid = c.ContractUid
inner join AthenaUATDistribution..Retailers r on r.RetailerUid = c.RetailerUid
inner join AthenaUATDistribution..Publishers p on c.PublisherUid = p.PublisherUid
inner join AthenaUATProductcatalog..TMAssetType tmat on dosc.AssetType = tmat.ID
inner join AthenaUATProductcatalog..TMResourceContentType tmrct on dosc.ResourceContentType = tmrct.ResourceContentType
where dosgc.Name not like '%Migration%'
order by 
r.Name,
p.Name,
dosgc.Name,
dosc.AssetType,
dosc.ResourceContentType,
dosc.PathFormat

-- INSCRIBEDB
select
r.Name [Retailer Name],
p.Name [Publisher Name],
dosgc.Name [Distribution Order Structure Group],
tmrct.Name [Structure Resource Content Type],
tmat.Name [Structure Asset Type],
tmat.Description [Structure Asset Type Description],
dosc.PathFormat [Structure Path Format]
from
AthenaDistribution..DistributionOrderStructureContracts dosc
inner join AthenaDistribution..DistributionOrderStructureGroupContracts dosgc on dosc.DistributionOrderStructureGroupContractUid = dosgc.DistributionOrderStructureGroupContractUid
inner join AthenaDistribution..Contracts c on dosgc.ContractUid = c.ContractUid
inner join AthenaDistribution..Retailers r on r.RetailerUid = c.RetailerUid
inner join AthenaDistribution..Publishers p on c.PublisherUid = p.PublisherUid
inner join AthenaProductcatalog..TMAssetType tmat on dosc.AssetType = tmat.ID
inner join AthenaProductcatalog..TMResourceContentType tmrct on dosc.ResourceContentType = tmrct.ResourceContentType
where dosgc.Name not like '%Migration%'
order by 
r.Name,
p.Name,
dosgc.Name,
dosc.AssetType,
dosc.ResourceContentType,
dosc.PathFormat
Mike Lavender