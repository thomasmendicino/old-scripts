/*

FINDING THE MOST RECENT SUCCESSFUL ASSET & DISTRIBUTION ORDER FOR A PRODUCT/RETAILER

*/

declare @RetailerName nvarchar(50) = '3M'
declare @Ordinal bigint = 9780983742982

USE AthenaComposite;

SELECT P.Ordinal, RT.Name Retailer, R.[Path], DO.DistributionOrderUid, DO.CreatedAtUTC FROM
Product P
INNER JOIN ProductRevisions PR on PR.ProductUid = P.ProductUid
INNER JOIN DistributionOrders DO on DO.ProductRevisionUid = PR.ProductRevisionUId
INNER JOIN Contracts C on C.ContractUid = PR.ContractUid
INNER JOIN Retailers RT on RT.RetailerUid = C.RetailerUid
INNER JOIN DistributionOrderStatus DOS on DOS.DistributionOrderUid = DO.DistributionOrderUid
INNER JOIN refEventType ET on ET.EventTypeId = DOS.ResultingEvent
INNER JOIN ProductRevisionStructures PRS on PRS.ProductRevisionUid = PR.ProductRevisionUid
INNER JOIN Asset A on A.ProductUid = p.ProductUid
INNER JOIN AssetOverride AO on AO.AssetUid = a.AssetUid
INNER JOIN AssetVersion AV on AV.AssetOverrideUid = AO.AssetOverrideUid and AV.AssetVersionUid = PRS.AssetVersionUid
INNER JOIN Resources R on R.ResourceUid = AV.ResourceUid
WHERE ET.Code = 'DITC'
AND RT.Name = @RetailerName
AND P.Ordinal = @Ordinal
AND A.ResourceContentType = 100