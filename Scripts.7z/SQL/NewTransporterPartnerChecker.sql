
create table xxx_TransporterPartners (DavePartnerName nvarchar(50))
insert xxx_TransporterPartners (DavePartnerName)
select distinct DavePartnerName 
from musicservicedavepartner dp
join musicservice ms on ms.id = dp.musicservice
join musicservicetransfersettings ts on ts.musicservice = ms.id
join transferprotocol tp on tp.id = ts.transferprotocol
where tp.Name = 'ITMSTransporter'
select * from xxx_transporterpartners

--delete from xxx_transporterPartners

;with NewPartner as
(select DavePartnerName from musicservicedavepartner dp
join musicservice ms on ms.id = dp.musicservice
join musicservicetransfersettings ts on ts.musicservice = ms.id
join transferprotocol tp on tp.id = ts.transferprotocol
where tp.Name = 'ITMSTransporter'
except
select DavePartnerName
from xxx_TransporterPartners
)
select 'New Partner ''' + DavePartnerName + ''' uses the Transporter and needs to be added to the Apple Failed Transporter Report.' as [New Apple Partner Checker]
from NewPartner
