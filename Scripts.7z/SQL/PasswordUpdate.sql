select * from indmauser where name = 'thomasm'

/**********************FOR V1:**************************/
--update indmauser set password = '758E5A06ABC1A996389AF18565F93420' where name = 'thomasm'
--update indmauser set RenewPassword = 0, PasswordIssuedAt = '2020-01-01' where name = 'thomasm'
--update backdoor set password = '0941652ED9DEF21C29E15DD6BF6CBFD4' where INDMAuser = (select ID from INDMAuser where Name = 'thomasm')
--update backdoor set RenewPassword = 0, PasswordIssuedAt = '2020-01-01' where INDMAuser = (select ID from INDMAuser where Name = 'thomasm')
/**********************For Zeus:************************/
--update indmauser set password = '2D63DFDAF7F6EB8179B8A05F40FE8F90' where name = 'thomasm'
