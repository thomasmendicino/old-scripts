WITH AggregatesHelper (Syndication,TotalProducts,TotalByteSize) AS
                                          (
                                          SELECT BillingReport.Syndication AS Syndication,
                                                 COUNT(DISTINCT BillingProduct.Product) AS TotalProducts,
                                                 SUM(BillingProduct.ByteSize) AS TotalByteSize
                                          FROM [BillingReport]
                                           INNER JOIN [BillingProduct] 
                                            ON BillingReport.ID=BillingProduct.BillingReport
                                          GROUP BY BillingReport.Syndication
                                          ),
                                          EncodingProfileHelper (Syndication,AudioCodec,AudioBitRate,AudioTrackCount,UMGOwnedFormatCode) AS
                                          (
                                          SELECT BillingReport.Syndication AS Syndication,
                                                 EncodingProfile.AudioCodec AS AudioCodec,
                                                 EncodingProfile.AudioBitrate AS AudioBitRate,
                                                 CONVERT(VARCHAR(50),COUNT(Track.ID)) AS AudioTrackCount,
                                                 EncodingConfiguration.UMGOwnedFormatCode AS UMGOwnedFormatCode
                                          FROM [SyndicationOrder]
                                            INNER JOIN ([BillingReport]
                                            INNER JOIN ([Track]
                                            INNER JOIN ([Album]
                                            INNER JOIN ([BillingProduct]
                                            INNER JOIN ([BillingProductEncodingConfiguration]
                                            INNER JOIN ([EncodingConfiguration]
                                            INNER JOIN [EncodingProfile]
                                           ON EncodingConfiguration.EncodingProfile=EncodingProfile.ID)
                                           ON BillingProductEncodingConfiguration.EncodingConfiguration=EncodingConfiguration.ID)
                                           ON BillingProduct.ID=BillingProductEncodingConfiguration.BillingProduct)
                                           ON Album.ID=BillingProduct.Product)
                                           ON Track.Album=Album.ID)
                                           ON BillingReport.ID=BillingProduct.BillingReport)
                                           ON SyndicationOrder.Syndication=BillingReport.Syndication
                                          GROUP BY BillingReport.Syndication,
                                                   BillingProduct.Product,
                                                   Track.ID,
                                                   EncodingProfile.AudioCodec,
                                                   EncodingProfile.AudioBitrate,
                                                   EncodingConfiguration.UMGOwnedFormatCode
                                          ),
                                          CelebrityHelper (Album,Artist) AS
                                          (
                                          SELECT AlbumCelebrity.Album AS Album,
                                                 Celebrity.Name AS Artist
                                          FROM [AlbumCelebrity] 
                                            INNER JOIN [Celebrity]
                                           ON AlbumCelebrity.Celebrity=Celebrity.ID
                                          )
                                          SELECT SyndicationOrder.PartnerName AS 'Business Partner',
                                                 SyndicationOrder.OrderBatchId AS 'Order ID (DAVe Batch ID)',
                                                 SyndicationOrder.OrderId AS 'HAL ID',
                                                 SyndicationOrder.SubmissionDate AS 'Order Date/Time',
                                                 (SELECT TOP 1 At FROM SyndicationOrderEventLog
                                                  WHERE SyndicationOrderEventLog.SyndicationOrder=SyndicationOrder.ID
                                                   AND SyndicationOrderEventLog.OrderState=11 ORDER BY ID) AS 'Delivery Date/Time',
                                                 Syndication.TransferredAt AS 'Order Close Date/Time',
                                                 AggregatesHelper.TotalProducts AS 'Total Products',
                                                 SyndicationOrder.AudioTrackCount AS 'Total Tracks',
                                                 SyndicationOrder.AudioEncodeCount AS 'Total Encodes',
                                                 SyndicationOrder.AudioEncodeCount AS 'Total Streams',
                                                 SyndicationOrder.AudioTrackCount AS 'Total Baseline Billable Units',
                                                 (CASE
                                                     WHEN (SyndicationOrder.AudioEncodeCount/SyndicationOrder.AudioTrackCount)>4 THEN ((SyndicationOrder.AudioEncodeCount/SyndicationOrder.AudioTrackCount)-4)*SyndicationOrder.AudioTrackCount
                                                     ELSE 0
                                                 END) AS 'Total Additional Billable Units',
                                                 AggregatesHelper.TotalByteSize AS 'Total Order Size Bytes',
                                                 Album.GTIN AS 'Product Number',
                                                 (SELECT TOP 1 Name FROM Celebrity WHERE Celebrity.ID=Album.CelebrityPerformer) AS 'Product Artist',
                                                 Album.Name AS 'Product Title',
                                                 Track.Disc AS Vol,
                                                 Track.Track AS 'Track #',
                                                 (SELECT Song.ISRC FROM Song WHERE Song.ID=Track.Song) AS ISRC,
                                                 (SELECT TOP 1 Name FROM Celebrity WHERE Celebrity.ID=Album.CelebrityPerformer) AS 'Track Artist',
                                                 (SELECT Song.Name FROM Song WHERE Song.ID=Track.Song) AS 'Track Title',
                                                 (SyndicationOrder.AudioEncodeCount/SyndicationOrder.AudioTrackCount) AS 'Encodes Per Track',
                                                 (SyndicationOrder.AudioEncodeCount/SyndicationOrder.AudioTrackCount) AS 'Streams Per Track',
                                                 1 AS 'Baseline Billable Units',
                                                 1 AS 'Additional Billable Units',
                                                 (STUFF((SELECT DISTINCT ',' + EncodingProfileHelper.AudioCodec
                                                         FROM EncodingProfileHelper
                                                         WHERE EncodingProfileHelper.Syndication=SyndicationOrder.Syndication
                                                  FOR XML PATH(''), TYPE, ROOT).value('root[1]','nvarchar(max)'),1,1,'')) AS 'Protocol Names',
                                                 (STUFF((SELECT DISTINCT ',' + EncodingProfileHelper.AudioTrackCount,'*',
                                                                               EncodingProfileHelper.AudioCodec,':',
                                                                               EncodingProfileHelper.UMGOwnedFormatCode
                                                         FROM EncodingProfileHelper
                                                         WHERE EncodingProfileHelper.Syndication=SyndicationOrder.Syndication
                                                  FOR XML PATH(''), TYPE, ROOT).value('root[1]','nvarchar(max)'),1,1,'')) AS 'Format Codes'
                                          FROM [TrackSyndication]
                                            INNER JOIN ([Song]
                                            INNER JOIN ([Track]
                                            INNER JOIN ([Album]
                                            INNER JOIN ((SELECT DISTINCT BillingProduct.BillingReport AS br,
                                                                         BillingProduct.Product AS pr
                                                         FROM BillingProduct) bp
                                            INNER JOIN ([BillingReport]
                                            INNER JOIN ([SyndicationOrder]
                                            INNER JOIN ([Syndication]
                                            INNER JOIN AggregatesHelper
                                           ON AggregatesHelper.Syndication=Syndication.ID)
                                           ON Syndication.ID=SyndicationOrder.Syndication)
                                           ON SyndicationOrder.Syndication=BillingReport.Syndication)
                                           ON BillingReport.ID=bp.br)
                                           ON bp.pr=Album.ID)
                                           ON Album.ID=Track.Album)
                                           ON Track.Song=Song.ID)
                                           ON Track.ID=TrackSyndication.Track AND (Song.ResourceType=1 OR Song.ResourceType IS NULL) AND Syndication.ID=TrackSyndication.Syndication
                                          WHERE SyndicationOrder.AudioTrackCount > 0
                                           AND Syndication.TransferredAt BETWEEN '2011-06-01' AND '2011-07-01'
                                           AND PartnerId=1
                                          ORDER BY 'Delivery Date/Time',
                                                   'Order ID (DAVe Batch ID)'