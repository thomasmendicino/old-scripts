SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- adjust database name
use AthenaResourceStorage

DECLARE @onixReference varchar(MAX)
SELECT @onixReference = xmlCol

-- adjust path to point to the resource accesible from database server
FROM OPENROWSET(Bulk 'C:\Athena\trunk\DomainServices\Scripts\Database\QueryableOnixResources\ONIX_BookProduct_3.0.2_reference_SQlServer_withA305.xsd', SINGLE_CLOB)
as results(xmlCol)

DECLARE @onixSchema XML
SET @onixSchema = CONVERT(XML, @onixReference)

CREATE XML SCHEMA COLLECTION Onix302Reference AS @onixSchema
GO

CREATE TABLE OnixResources
(
    [ResourceUid] [uniqueidentifier] NOT NULL,
    [Content] xml(Onix302Reference) NULL,
    [IsChanged] [bit] NULL,
    CONSTRAINT [PK_OnixResources] PRIMARY KEY CLUSTERED 
    (
        [ResourceUid] ASC
    )
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)
ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

--drop table AthenaUATResourceStorage..OnixResources
--drop xml schema COLLECTION Onix302Reference