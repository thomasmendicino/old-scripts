SET NOCOUNT ON 

IF OBJECT_ID('tempdb..#TMFailedDistributionDataSet') IS NOT NULL DROP TABLE #TMFailedDistributionDataSet
GO
create table #TMFailedDistributionDataSet 
(
	[ID] [bigint],
	[FailedDate] [datetime],
	[Code] [nvarchar](10),
	[TheReason] [nvarchar](1000),
	[DistributionORderUId] [uniqueidentifier] ,
	[Rank] [smallint])
declare @ordinal bigint = 9781417402915
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @pacificTime int
DECLARE @DistributionTitles table (Title nvarchar(200), ContentType nvarchar(50), OrgUid uniqueidentifier, ISBN bigint, OnSaleDate datetime,
    ProductUid uniqueidentifier,
    RetailerUid uniqueidentifier,
    Retailer nvarchar(50),
    ProcessedAtUtc datetime,
    distributionOrderUId uniqueidentifier)
--DECLARE @DistributionDataSet table (FailedDate datetime, TheReason nvarchar(1000), DistributionORderUId uniqueidentifier, [Rank] smallint)

SET @pacificTime = datediff(hh,getUTCdate(),getdate()) 
SET @DateRangeStart = '2012-10-01'
SET @DateRangeEnd = getUTCdate()
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

SET @eISBNs = NULL

DELETE FROM #TMFailedDistributionDataSet

;with MaxAt as (select max(ProcessedAtUtc) [MaxProcessedAtUTC], pr.ProductUid, r.Name from AthenaUATComposite..distributionOrderStatus dos
join AthenaUATComposite..distributionOrders do on do.distributionORderUId = dos.DistributionOrderUId
join AthenaUATComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaUATComposite..contracts c on c.contractUid = pr.contractUId
join AthenaUATComposite..retailers r on r.retailerUId = c.retailerUid
where pr.ProductUid = (select productUid from AthenaUATComposite..product where ordinal = @ordinal)
group by pr.productUid, r.Name
having max(ProcessedAtUtc) > @DateRangeStart),

FailedOrders as (
select do.DistributionOrderUid from AthenaUATComposite..DistributionOrders do
join AthenaUATComposite..DistributionOrderStatus dos on dos.distributionOrderUid = do.distributionORderUId
join AthenaUATComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaUATComposite..contracts c on c.contractUid = pr.contractUId
join AthenaUATComposite..retailers r on r.retailerUId = c.retailerUid
join MaxAt m on m.ProductUid = pr.productUid and m.Name = r.Name and m.MaxProcessedAtUTC = dos.ProcessedAtUTC
where dos.ResultingEventLevel = 4
and pr.ProductUid = (select productUid from AthenaUATComposite..product where ordinal = @ordinal))

INSERT @DistributionTitles (Title, ContentType, OrgUid, ISBN, OnSaleDate, ProductUid, RetailerUid, Retailer, ProcessedAtUtc, distributionOrderUId)
SELECT DISTINCT
coalesce(td.TitleStatement, te.TitleText, TitlePrefix + ' ' + TitleWithoutPrefix) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pub.OrganizationUid AS OrgUid,
    [pi].Value AS ISBN,
	pd.Value AS OnSaleDate,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    dos.ProcessedAtUtc AS ProcessedAtUtc,
    F.distributionOrderUId
FROM
	AthenaUATComposite..DistributionOrderStatus dos
	INNER JOIN AthenaUATComposite..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaUATComposite..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaUATComposite..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaUATComposite..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaUATComposite..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaUATComposite..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN AthenaUATComposite..asset a on a.productUid = p.productUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AthenaUATComposite..AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AthenaUATComposite..assetVersion av on av.assetOverrideUid = ao.assetOverrideUId
    INNER JOIN AthenaUATComposite..TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN AthenaUATComposite..TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN AthenaUATProductCatalog..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN AthenaUATProductCatalog..ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN AthenaUATComposite..productForms pf on pf.assetVersionUid = av.AssetVersionUid
    INNER JOIN AthenaUATComposite..ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
    INNER JOIN FailedOrders f on f.DistributionOrderUid = do.DistributionOrderUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
	AND pf.ProductFormTypeValue IN (49,50,51,52)
	--AND dos.ProcessedAtUtc BETWEEN @DateRangeStart AND @DateRangeEnd
	AND av.ValidUntilUtc is NULL
	AND p.ordinal = @ordinal
    
--select * from @DistributionTitles

INSERT #TMFailedDistributionDataSet (FailedDate, TheReason, Code, DistributionORderUId, [Rank])
SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
    left(ret.Title,1000) AS TheReason,
	ret.Code,
	dt.DistributionORderUId,
	1 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaUATComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
	INNER JOIN AthenaUATComposite..DistributionOrderAcceptabilities doa on doa.distributionOrderUid = do.distributionOrderUid
	INNER JOIN AthenaUATComposite..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaUATComposite..refEventType ret on ret.EventTypeId = doa.ResultingEvent
WHERE
    doa.ResultingEventLevel > 2
    AND ret.Code = 'REM'
    
	--select * from @DistributionDataSet
	
	select distinct
	'Excluded' as 'Distribution Status',
	Retailer as 'Retailer Name',
	a.distributionOrderUid,
    ISBN,
	case 
when po.OrganizationName = 'INscribe Digital' then o.OrganizationName
when ppo.OrganizationName = 'INscribe Digital' then po.OrganizationName
when pppo.OrganizationName = 'INscribe Digital' then ppo.OrganizationName
when ppppo.OrganizationName = 'INscribe Digital' then pppo.OrganizationName
when po.OrganizationName is NULL then o.OrganizationName
end as [TopLevelParent],
o.OrganizationName [Imprint],
    Title,
    ContentType, 
    OnSaleDate,
    Retailer,
    dateadd(hh,(datediff(hh,getUTCdate(),getdate())),a.FailedDate) as FailedDate,
	a.Code,
    a.TheReason as Reason
from AthenaUATComposite..distributionOrders do
	cross apply (
		select top 1 distributionOrderUid, TheReason, Code, FailedDate from #TMFailedDistributionDataSet d
		where do.distributionOrderuid = d.distributionOrderUid
		order by [Rank] asc, TheReason desc) a
	join @DistributionTitles dt on dt.DistributionOrderUid = do.distributionOrderUid
	join AthenaUATComposite..productRevisions pr on pr.productRevisionUid = do.productRevisionUid
	join AthenaUATProductCatalog..product p on p.productUid = pr.productUid
	join AthenaUATSecurity..organizations o on o.organizationUid = p.organizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations po on po.organizationUid = o.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations ppo on ppo.organizationUid = po.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations pppo on pppo.organizationUid = ppo.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations ppppo on ppppo.organizationUid = pppo.ParentOrganizationUid

/*    ---- 

*/


SET NOCOUNT ON 

IF OBJECT_ID('tempdb..#TMFailedDistributionDataSet') IS NOT NULL DROP TABLE #TMFailedDistributionDataSet
GO
create table #TMFailedDistributionDataSet 
(
	[ID] [bigint],
	[FailedDate] [datetime],
	[Code] [nvarchar](10),
	[TheReason] [nvarchar](1000),
	[DistributionORderUId] [uniqueidentifier] ,
	[Rank] [smallint])
declare @ordinal bigint = 9781417402915
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @pacificTime int
DECLARE @DistributionTitles table (Title nvarchar(200), ContentType nvarchar(50), OrgUid uniqueidentifier, ISBN bigint, OnSaleDate datetime,
    ProductUid uniqueidentifier,
    RetailerUid uniqueidentifier,
    Retailer nvarchar(50),
    ProcessedAtUtc datetime,
    distributionOrderUId uniqueidentifier)
--DECLARE @DistributionDataSet table (FailedDate datetime, TheReason nvarchar(1000), DistributionORderUId uniqueidentifier, [Rank] smallint)

SET @pacificTime = datediff(hh,getUTCdate(),getdate()) 
SET @DateRangeStart = '2012-10-01'
SET @DateRangeEnd = getUTCdate()
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

SET @eISBNs = NULL

DELETE FROM #TMFailedDistributionDataSet

;with MaxAt as (select max(ProcessedAtUtc) [MaxProcessedAtUTC], pr.ProductUid, r.Name from AthenaUATComposite..distributionOrderStatus dos
join AthenaUATComposite..distributionOrders do on do.distributionORderUId = dos.DistributionOrderUId
join AthenaUATComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaUATComposite..contracts c on c.contractUid = pr.contractUId
join AthenaUATComposite..retailers r on r.retailerUId = c.retailerUid
where pr.ProductUid = (select productUid from AthenaUATComposite..product where ordinal = @ordinal)
group by pr.productUid, r.Name
having max(ProcessedAtUtc) > @DateRangeStart),

FailedOrders as (
select do.DistributionOrderUid from AthenaUATComposite..DistributionOrders do
join AthenaUATComposite..DistributionOrderStatus dos on dos.distributionOrderUid = do.distributionORderUId
join AthenaUATComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaUATComposite..contracts c on c.contractUid = pr.contractUId
join AthenaUATComposite..retailers r on r.retailerUId = c.retailerUid
join MaxAt m on m.ProductUid = pr.productUid and m.Name = r.Name and m.MaxProcessedAtUTC = dos.ProcessedAtUTC
where dos.ResultingEventLevel = 4
and pr.ProductUid = (select productUid from AthenaUATComposite..product where ordinal = @ordinal))

INSERT @DistributionTitles (Title, ContentType, OrgUid, ISBN, OnSaleDate, ProductUid, RetailerUid, Retailer, ProcessedAtUtc, distributionOrderUId)
SELECT DISTINCT
coalesce(td.TitleStatement, te.TitleText, TitlePrefix + ' ' + TitleWithoutPrefix) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pub.OrganizationUid AS OrgUid,
    [pi].Value AS ISBN,
	pd.Value AS OnSaleDate,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    dos.ProcessedAtUtc AS ProcessedAtUtc,
    F.distributionOrderUId
FROM
	AthenaUATComposite..DistributionOrderStatus dos
	INNER JOIN AthenaUATComposite..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaUATComposite..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaUATComposite..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaUATComposite..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaUATComposite..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaUATComposite..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN AthenaUATComposite..asset a on a.productUid = p.productUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AthenaUATComposite..AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AthenaUATComposite..assetVersion av on av.assetOverrideUid = ao.assetOverrideUId
    INNER JOIN AthenaUATComposite..TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN AthenaUATComposite..TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN AthenaUATProductCatalog..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN AthenaUATProductCatalog..ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN AthenaUATComposite..productForms pf on pf.assetVersionUid = av.AssetVersionUid
    INNER JOIN AthenaUATComposite..ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
    INNER JOIN FailedOrders f on f.DistributionOrderUid = do.DistributionOrderUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
	AND pf.ProductFormTypeValue IN (49,50,51,52)
	--AND dos.ProcessedAtUtc BETWEEN @DateRangeStart AND @DateRangeEnd
	AND av.ValidUntilUtc is NULL
	AND p.ordinal = @ordinal
    
--select * from @DistributionTitles

INSERT #TMFailedDistributionDataSet (FailedDate, TheReason, Code, DistributionORderUId, [Rank])
SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
    left(ret.Title,1000) AS TheReason,
	ret.Code,
	dt.DistributionORderUId,
	1 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaUATComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
	INNER JOIN AthenaUATComposite..DistributionOrderAcceptabilities doa on doa.distributionOrderUid = do.distributionOrderUid
	INNER JOIN AthenaUATComposite..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaUATComposite..refEventType ret on ret.EventTypeId = doa.ResultingEvent
WHERE
    doa.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC','DINA','REM')                          -- Not distributed based on contract
                
UNION

	SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
	left(dos.ResultingMessage,1000) AS TheReason,
	ret.Code,
    dt.DistributionORderUId,
	2 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaUATComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
    INNER JOIN AthenaUATComposite..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaUATComposite..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaUATComposite..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC','REM','DINA')                          -- Not distributed based on contract

UNION    

	SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
    left(ret.Title,1000) AS TheReason,
	ret.Code,
    dt.DistributionORderUId,
	3 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaUATComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
    INNER JOIN AthenaUATComposite..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaUATComposite..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaUATComposite..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC','REM','DINA')                          -- Not distributed based on contract
    
	--select * from @DistributionDataSet
	
	select distinct
	'Error' as 'Distribution Status',
	Retailer as 'Retailer Name',
	a.distributionOrderUid,
    ISBN,
	case 
when po.OrganizationName = 'INscribe Digital' then o.OrganizationName
when ppo.OrganizationName = 'INscribe Digital' then po.OrganizationName
when pppo.OrganizationName = 'INscribe Digital' then ppo.OrganizationName
when ppppo.OrganizationName = 'INscribe Digital' then pppo.OrganizationName
when po.OrganizationName is NULL then o.OrganizationName
end as [TopLevelParent],
o.OrganizationName [Imprint],
    Title,
    ContentType, 
    OnSaleDate,
    Retailer,
    dateadd(hh,(datediff(hh,getUTCdate(),getdate())),a.FailedDate) as FailedDate,
	a.Code,
    a.TheReason as Reason
from AthenaUATComposite..distributionOrders do
	cross apply (
		select top 1 distributionOrderUid, TheReason, Code, FailedDate from #TMFailedDistributionDataSet d
		where do.distributionOrderuid = d.distributionOrderUid
		order by [Rank] asc, TheReason desc) a
	join @DistributionTitles dt on dt.DistributionOrderUid = do.distributionOrderUid
	join AthenaUATComposite..productRevisions pr on pr.productRevisionUid = do.productRevisionUid
	join AthenaUATProductCatalog..product p on p.productUid = pr.productUid
	join AthenaUATSecurity..organizations o on o.organizationUid = p.organizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations po on po.organizationUid = o.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations ppo on ppo.organizationUid = po.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations pppo on pppo.organizationUid = ppo.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations ppppo on ppppo.organizationUid = pppo.ParentOrganizationUid


/*


*/
--DECLARE @DateRangeStart DateTime
--DECLARE @DateRangeEnd DateTime
--DECLARE @OnSaleDateRangeStart DateTime
--DECLARE @OnSaleDateRangeEnd DateTime
--DECLARE @eISBNs NVARCHAR(MAX)

SET @DateRangeStart = NULL
SET @DateRangeEnd = getUTCdate()
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

SET @eISBNs = '9781417402915'

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

;with #DistributionTitles as (
SELECT
    pub.Name AS Publisher,
    [pi].Value AS ISBN,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
FROM
	AthenaUATDistribution..DistributionOrderStatus dos
	INNER JOIN AthenaUATDistribution..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaUATDistribution..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaUATDistribution..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaUATDistribution..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaUATDistribution..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaUATProductCatalog..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN AthenaUATProductCatalog..ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
	INNER JOIN AthenaUATSecurity..Organizations o on o.organizationUid = pub.organizationUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
--    AND pub.OrganizationUid IN (@OrganizationUidList)     -- Part of the selected publisher hierarchy
--    AND (@eISBNs IS NULL OR [pi].Value IN (@eISBNList))   -- In the List of supplied ISBNs
    AND p.ordinal = @eISBNs
GROUP BY
	pub.Name,
    pr.ProductUid,
    [pi].Value,
    r.Name,
    r.RetailerUid
HAVING                                                     -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)),
	#DistributionDataset as (
    
SELECT DISTINCT
    Publisher,
    ISBN,
    coalesce(td.TitleStatement, te.TitleText) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS DistributionDate
FROM
	#DistributionTitles dt
    INNER JOIN AthenaUATDistribution..ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN AthenaUATDistribution..Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN AthenaUATDistribution..DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN AthenaUATDistribution..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaUATProductCatalog..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN asset a on a.productUid = p.productUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN AthenaUATProductCatalog..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN AthenaUATProductCatalog..ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190) 
    INNER JOIN AthenaUATEventLog..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel <= 2
    AND ret.Code = 'DITC'
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleText IS NOT NULL                          -- Only display the title elements with TitleText
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL)
	))
SELECT
    ISBN,
case 
when po.OrganizationName = 'INscribe Digital' then o.OrganizationName
when ppo.OrganizationName = 'INscribe Digital' then po.OrganizationName
when pppo.OrganizationName = 'INscribe Digital' then ppo.OrganizationName
when ppppo.OrganizationName = 'INscribe Digital' then pppo.OrganizationName
when po.OrganizationName is NULL then o.OrganizationName
end as [TopLevelParent],
    Publisher [Imprint],
    --'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    dateadd(hh,(datediff(hh,getUTCdate(),getdate())),DistributionDate) as DistributionDate
FROM
    #DistributionDataset dt
    join AthenaUATDistribution..Publishers p on p.Name = dt.Publisher
    join AthenaUATSecurity..Organizations o on o.organizationUId = p.organizationUId
    LEFT OUTER JOIN AthenaUATSecurity..Organizations po on po.organizationUid = o.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations ppo on ppo.organizationUid = po.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations pppo on pppo.organizationUid = ppo.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations ppppo on ppppo.organizationUid = pppo.ParentOrganizationUid
    
ORDER BY
    DistributionDate DESC,
    Title ASC