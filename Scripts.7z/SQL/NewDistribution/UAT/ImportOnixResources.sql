-- adjust database names in queriies
-- adjust path to point to the resource accesible from database server

/*
--Run this to create a batch file to copy resources to a local drive.
USE AthenaUATComposite;
DECLARE @resourceStoragePath varchar(256) = '\\nexentaqa01\athenauat\AthenaData\ResourceStorage\'
declare @Blooms table (orgUid uniqueidentifier)

declare @organizationName nvarchar(100)
select @organizationname = 'Bloomsbury Publishing'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @Blooms
select organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select '00000000-0000-0000-0000-000000000001'

SELECT
r.ResourceUid,
@resourceStoragePath + r.Path,
'xcopy ' + @resourceStoragePath + r.Path + ' F:\Athena\ResourceStorage\' + r.Path
FROM
AthenaUATResourceStorage..Resources r
inner join AthenaUATProductCatalog..AssetVersion av on r.ResourceUid = av.ResourceUid
inner join AthenaUATProductCatalog..AssetOverride ao on av.AssetOverrideUid = ao.AssetOverrideUid
inner join AthenaUATProductCatalog..Asset a on ao.AssetUid = a.AssetUid
inner join AthenaUATProductCatalog..Product p on p.ProductUid = a.ProductUid
inner join AthenaUATSecurity..Organizations o on o.OrganizationUid = p.organizationUid
inner join AthenaUATProductCatalog..productForms pf on pf.assetVersionUid = av.assetVersionUid
WHERE
a.ResourceContentType = 100
and a.AssetType = 1003
and av.ValidUntilUtc is null
and not exists
    (select 1 from AthenaUATResourceStorage..OnixResources
     where ResourceUid = r.ResourceUid)
and o.OrganizationUid in (select orgUid from @Blooms)
and pf.ProductFormTypeValue > 21

	 
*/

DECLARE @resourceStoragePath varchar(256) = 'F:\Athena\ResourceStorage\'
declare @Blooms table (orgUid uniqueidentifier)

declare @organizationName nvarchar(100)
select @organizationname = 'Bloomsbury Publishing'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @Blooms
select organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select '00000000-0000-0000-0000-000000000001'

DECLARE @OnixResources
TABLE (
    RowNumber int identity(1,1),
    ResourceUid uniqueidentifier,
    ResourcePath nvarchar(1024)
)

INSERT @OnixResources
SELECT
r.ResourceUid,
@resourceStoragePath + r.Path
FROM
AthenaUATResourceStorage..Resources r
inner join AthenaUATProductCatalog..AssetVersion av on r.ResourceUid = av.ResourceUid
inner join AthenaUATProductCatalog..AssetOverride ao on av.AssetOverrideUid = ao.AssetOverrideUid
inner join AthenaUATProductCatalog..Asset a on ao.AssetUid = a.AssetUid
inner join AthenaUATProductCatalog..Product p on p.ProductUid = a.ProductUid
inner join AthenaUATSecurity..Organizations o on o.OrganizationUid = p.organizationUid
inner join AthenaUATProductCatalog..productForms pf on pf.assetVersionUid = av.assetVersionUid
WHERE
a.ResourceContentType = 100
and a.AssetType = 1003
and av.ValidUntilUtc is null
and not exists
    (select 1 from AthenaUATResourceStorage..OnixResources
     where ResourceUid = r.ResourceUid)
and o.OrganizationUid in (select orgUid from @Blooms)
and pf.ProductFormTypeValue > 21

declare @currentResourceCount int = 1
declare @totalResourcesCount int

select @totalResourcesCount = count(*) from @OnixResources

while @currentResourceCount <= @totalResourcesCount
begin

    insert AthenaUATResourceStorage..OnixResources(ResourceUid, IsChanged)
    select
        r.ResourceUid, 0
    from
        @OnixResources r
    where
        r.RowNumber = @currentResourceCount

    declare @updateContentsQuery varchar(2048)

    select @updateContentsQuery =
    'update AthenaUATResourceStorage..OnixResources set Content = (SELECT * FROM OPENROWSET(BULK ''' + ResourcePath + ''', SINGLE_BLOB) as x) where ResourceUid = ''' + convert(varchar(50), ResourceUid) + ''''
    from
        @OnixResources
    where
        RowNumber = @currentResourceCount

    print convert(varchar(50), @currentResourceCount) + '. ' + @updateContentsQuery

    begin try
        exec (@updateContentsQuery)
    end try
    begin catch
        print 'Error:'
        print error_message()
        delete AthenaUATResourceStorage..OnixResources
        where
            ResourceUid = (select r.ResourceUid from @OnixResources r where r.RowNumber = @currentResourceCount)
    end catch

    set @currentResourceCount = @currentResourceCount + 1
end

--delete AthenaUATResourceStorage..OnixResources


--select * from AthenaUATResourceStorage..OnixResources