declare @temp table (isbn nvarchar(13))
insert @temp (isbn)
--select 'select ''' + left(right(FilePath,18),13) + ''' union' from AthenaImport where Imported =0 and InitialImportAt > '2015-09-01' and ImportAttempt < 6
select left(right(FilePath,18),13) from AthenaImport where Imported =0 and InitialImportAt > '2015-09-01' and ImportAttempt < 6

select * from @temp t
left join album a on a.gtin = t.isbn
where a.gtin is null

--update AthenaImport set ImportAttempt = 0 where

select o.Name from album a
join organization o on o.id = a.Organization where a.gtin = '9781501308994'

select * from AthenaImport where filepath like '%9781484728703%' 
select parent,* from organization where name like '%willia%brow%'



select * from Job where Condition is not null

select * from AthenaImport where UpdatedAt > '2015-10-01' and Imported = 0

--msxsl.exe \\ftp\ebooksftpdata\productionftp\athenaimports\importqueue\228127_20150731\9781780436326\9781780436326.onix CollateralDetail.xslt -o \\ftp\ebooksftpdata\productionftp\athenaimports\importqueue\228127_20150731\9781780436326\9781780436326.onix

select * from athenaImport where filepath like '%9780823426836%'

select 'move \\instor02\ebooksftpdata\productionftp\athenaimports\importqueue\' + left(FilePath,30) + 'Error\201509\' + right(FilePath,18) + ' \\instor02\ebooksftpdata\productionftp\athenaimports\importqueue\' + FilePath
from AthenaImport where Filepath like '250454%' and Imported = 0

select 'move \\instor02\ebooksftpdata\productionftp\athenaimports\importqueue\' + left(FilePath,30) + 'Error\201509\' + replace(right(FilePath,18),'onix','jpg') + ' \\instor02\ebooksftpdata\productionftp\athenaimports\importqueue\' + replace(FilePath,'onix','jpg')
from AthenaImport where Filepath like '250454%' and Imported = 0

select * from organization o
join organization co on co.parent = o.id
where o.charter = 38 

select parent,* from organization where charter = 38 and name = 'M-Y Books Ltd.'
select parent,* from Organization where id = 37725
select * from organization where parent = 37725
select * from album where organization = 37725
select * from album where organization in (select id from organization where parent = 37725)

select o.Name, * from album a
join organization o on o.id = a.organization
join organization co on co.parent= o.id
join album a2 on a2.Organization = co.id
where o.charter = 38
and o.id <> 74530
and co.id <> 29623

