Hi Thomas, there is a change to UAT security - devs asked for SHOWPLAN - here is the updates script ```--INSCRIBE database server security setup script
--Create server logins if not exist yet 
USE master
GO
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INGROOVES\INSCRIBE_Developers')
CREATE LOGIN [INGROOVES\INSCRIBE_Developers] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INGROOVES\INSCRIBE_QA')
CREATE LOGIN [INGROOVES\INSCRIBE_QA] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INGROOVES\INSCRIBE_ApplicationSupport')
CREATE LOGIN [INGROOVES\INSCRIBE_ApplicationSupport] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INGROOVES\INSCRIBE_SI')
CREATE LOGIN [INGROOVES\INSCRIBE_SI] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
EXEC sp_addsrvrolemember 'INGROOVES\INSCRIBE_SI', 'sysadmin';
GO

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INGROOVES\DBA')
CREATE LOGIN [INGROOVES\DBA] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
EXEC sp_addsrvrolemember 'INGROOVES\DBA', 'sysadmin';
GO

--Get a list of all Athena databases on the server; create database users for specified logins and grant the permissions
Use master
GO

DECLARE @dbname VARCHAR(50)   
DECLARE @statement NVARCHAR(max)

DECLARE db_cursor CURSOR 
LOCAL FAST_FORWARD
FOR  
SELECT name
FROM MASTER.dbo.sysdatabases
WHERE name like 'Athena%'
OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @dbname  
WHILE @@FETCH_STATUS = 0  
BEGIN  

SET @statement = 'use '+@dbname +'; '
SET @statement = @statement + '
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''cust_db_ViewDefinition'' AND type = ''R'')
CREATE ROLE cust_db_ViewDefinition AUTHORIZATION dbo;
GRANT VIEW DEFINITION ON SCHEMA::DBO TO cust_db_ViewDefinition;
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''cust_db_ShowPlan'' AND type = ''R'')
CREATE ROLE cust_db_ShowPlan AUTHORIZATION dbo;
GRANT SHOWPLAN TO cust_db_ShowPlan
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''cust_db_SelectExecute'' AND type = ''R'')
CREATE ROLE cust_db_SelectExecute AUTHORIZATION dbo;
GRANT SELECT, EXECUTE, REFERENCES ON SCHEMA::DBO TO cust_db_SelectExecute;
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''cust_db_IUD'' AND type = ''R'')
CREATE ROLE cust_db_IUD AUTHORIZATION dbo;
GRANT INSERT, UPDATE, DELETE ON SCHEMA::DBO TO cust_db_IUD;
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''INGROOVES\INSCRIBE_Developers'')
CREATE USER [INGROOVES\INSCRIBE_Developers] FOR LOGIN [INGROOVES\INSCRIBE_Developers];
EXEC sp_addrolemember N''cust_db_ViewDefinition'',N''INGROOVES\INSCRIBE_Developers'';
EXEC sp_addrolemember N''cust_db_SelectExecute'',N''INGROOVES\INSCRIBE_Developers'';
EXEC sp_addrolemember N''cust_db_IUD'',N''INGROOVES\INSCRIBE_Developers'';
EXEC sp_addrolemember N''cust_db_ShowPlan'',N''INGROOVES\INSCRIBE_Developers'';
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''INGROOVES\INSCRIBE_QA'')
CREATE USER [INGROOVES\INSCRIBE_QA] FOR LOGIN [INGROOVES\INSCRIBE_QA];
EXEC sp_addrolemember N''cust_db_ViewDefinition'',N''INGROOVES\INSCRIBE_QA'';
EXEC sp_addrolemember N''cust_db_SelectExecute'',N''INGROOVES\INSCRIBE_QA'';
EXEC sp_addrolemember N''cust_db_IUD'',N''INGROOVES\INSCRIBE_QA'';
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''INGROOVES\INSCRIBE_ApplicationSupport'')
CREATE USER [INGROOVES\INSCRIBE_ApplicationSupport] FOR LOGIN [INGROOVES\INSCRIBE_ApplicationSupport];
EXEC sp_addrolemember N''cust_db_ViewDefinition'',N''INGROOVES\INSCRIBE_ApplicationSupport'';
EXEC sp_addrolemember N''cust_db_SelectExecute'',N''INGROOVES\INSCRIBE_ApplicationSupport'';
EXEC sp_addrolemember N''cust_db_IUD'',N''INGROOVES\INSCRIBE_ApplicationSupport'';
'

exec sp_executesql @statement

FETCH NEXT FROM db_cursor INTO @dbname  
END  
CLOSE db_cursor  
DEALLOCATE db_cursor 

```