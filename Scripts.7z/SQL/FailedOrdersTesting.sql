--******* Failed Distribution... Last 12 hours
--*******

DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @pacificTime int
--DECLARE @FailedOrders table (DistributionOrderUid uniqueidentifier)

SET @pacificTime = datediff(hh,getUTCdate(),getdate()) 
SET @DateRangeStart = dateadd(hh,-20,getUTCdate())
SET @DateRangeEnd = getUTCdate()
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

SET @eISBNs = NULL

;with MaxAt as (select max(ProcessedAtUtc) [MaxProcessedAtUTC], pr.ProductUid, r.Name from AthenaDistribution..distributionOrderStatus dos
join AthenaDistribution..distributionOrders do on do.distributionORderUId = dos.DistributionOrderUId
join AthenaDistribution..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaDistribution..contracts c on c.contractUid = pr.contractUId
join AthenaDistribution..retailers r on r.retailerUId = c.retailerUid
group by pr.productUid, r.Name
having max(ProcessedAtUtc) > @DateRangeStart),
--insert @FailedOrders (DistributionOrderUId)
FailedOrders as (
select do.DistributionOrderUid from AthenaDistribution..DistributionOrders do
join AthenaDistribution..DistributionOrderStatus dos on dos.distributionOrderUid = do.distributionORderUId
join AthenaDistribution..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaDistribution..contracts c on c.contractUid = pr.contractUId
join AthenaDistribution..retailers r on r.retailerUId = c.retailerUid
join MaxAt m on m.ProductUid = pr.productUid and m.Name = r.Name and m.MaxProcessedAtUTC = dos.ProcessedAtUTC
where dos.ResultingEventLevel = 4),
#DistributionTitles as(
SELECT DISTINCT
    pub.Name AS Publisher,
    [pi].Value AS ISBN,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    dos.ProcessedAtUtc AS ProcessedAtUtc,
    F.distributionOrderUId
FROM
	AthenaDistribution..DistributionOrderStatus dos
	INNER JOIN AthenaDistribution..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaDistribution..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaDistribution..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaDistribution..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaDistribution..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaProductCatalog..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN asset a on a.productUid = p.productUid
    INNER JOIN assetOverride ao on ao.assetUid = a.assetUid
    INNER JOIN assetVersion av on av.assetOverrideUid = ao.assetOverrideUId
    INNER JOIN productForms pf on pf.assetVersionUid = av.AssetVersionUid
    INNER JOIN AthenaProductCatalog..ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
    INNER JOIN FailedOrders f on f.DistributionOrderUid = do.DistributionOrderUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
	AND pf.ProductFormTypeValue IN (49,50,51,52)

GROUP BY
	pub.Name,
    pr.ProductUid,
    [pi].Value,
    r.Name,
    r.RetailerUid,
    dos.ProcessedAtUtc,
    F.DistributionOrderUid
HAVING                                                     -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)),

--select * from #distributionTitles where ISBN = '9780486311296'

	#DistributionStatusDataSet as (    
SELECT DISTINCT
    Publisher,
    ISBN,
    coalesce(td.TitleStatement, te.TitleText) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	--doa.ResultingEvent as DOAresultingEvent,
	dos.ResultingEvent as DOSresultingEvent,
    rtrim(rtrim(replace(replace(dos.ResultingMessage, CHAR(10), ' '), CHAR(13), ' '))) AS ReasonDetail,
    dt.DistributionORderUId
FROM
	#DistributionTitles dt
    INNER JOIN AthenaDistribution..ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN AthenaDistribution..Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN AthenaDistribution..DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN AthenaDistribution..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaProductCatalog..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaProductCatalog..Asset a on a.productUid = p.productUid
	--LEFT OUTER JOIN AthenaDistribution..DistributionOrderAcceptabilities doa on doa.DistributionOrderUid = do.DistributionOrderUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN AthenaProductCatalog..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN AthenaProductCatalog..ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN AthenaEventLog..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
	--LEFT OUTER JOIN AthenaEventLog..refEventType ret2 ON ret2.EventTypeId = doa.ResultingEvent
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleText IS NOT NULL                          -- Only displayt the title elements with TitleText
	AND ret.EventLevelId > 2
	--AND isnull(ret.EventLevelId,0) > 2
	--AND (ret2.EventLevelId > 2 or ret2.EventLevelId is null)
    --and rtrim(rtrim(replace(replace(dos.ResultingMessage, CHAR(10), ' '), CHAR(13), ' '))) <> 'Distribution Order is not acceptable for distribution:   '
	--and ret.Code <> 'DINA'
	--and (doa.ResultingEvent <> 0 or doa.ResultingEvent is null)
    ),
	#DistributionAcceptabilityDataset as
	(
	SELECT DISTINCT
    Publisher,
    ISBN,
    coalesce(td.TitleStatement, te.TitleText) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	doa.ResultingEvent as DOAresultingEvent,
	--dos.ResultingEvent as DOSresultingEvent,
    rtrim(rtrim(replace(replace(dos.ResultingMessage, CHAR(10), ' '), CHAR(13), ' '))) AS ReasonDetail,
    dt.DistributionORderUId
FROM
	#DistributionTitles dt
    INNER JOIN AthenaDistribution..ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN AthenaDistribution..Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN AthenaDistribution..DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN AthenaDistribution..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaProductCatalog..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaProductCatalog..Asset a on a.productUid = p.productUid
	INNER JOIN AthenaDistribution..DistributionOrderAcceptabilities doa on doa.DistributionOrderUid = do.DistributionOrderUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN AthenaProductCatalog..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN AthenaProductCatalog..ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN AthenaEventLog..refEventType ret ON ret.EventTypeId = doa.ResultingEvent
	WHERE
    doa.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleText IS NOT NULL                          -- Only displayt the title elements with TitleText
	AND ret.EventLevelId > 2
	)
	select * from #distributionStatusDataset
	union
	select * from #distributionAcceptabilityDataset order by ISBN, Retailer-- where ISBN = 9780486311296

	--169
	--172
SELECT DISTINCT
	ISBN,
case 
when po.OrganizationName = 'INscribe Digital' then o.OrganizationName
when ppo.OrganizationName = 'INscribe Digital' then po.OrganizationName
when pppo.OrganizationName = 'INscribe Digital' then ppo.OrganizationName
when ppppo.OrganizationName = 'INscribe Digital' then pppo.OrganizationName
when po.OrganizationName is NULL then o.OrganizationName
end as [TopLevelParent],
	Publisher [Imprint],
    dt.Title,
    ContentType,
    OnSaleDate,
    Retailer,
    dateadd(hh,@pacificTime,max(FailedDate)) as FailedDate,
    ReasonCode,
	/*case when doa.ResultingMessage is NULL
	then 
	ISNULL(left(stuff((select replace(', ' + ReasonDetail,CHAR(13),'') from #DistributionDataset dt
	where dt.ISBN = p.Ordinal and dt.Publisher = pub.Name and dt.Retailer = r.Name for xml path ('')),1,1,''),1000) --as [Reason1],
	+ stuff((select distinct '; '+ ret.Title + '' from AthenaEventLog..refEventType ret join athenadistribution..distributionORderAcceptabilities doa on doa.ResultingEvent = ret.EventTypeID where doa.ResultingEvent = ret.EventTypeId and doa.distributionOrderUid = dt.distributionOrderUId and doa.ResultingEventLevel > 2 for xml path ('')),1,1,''),
	left(stuff((select replace(', ' + ReasonDetail + ';',CHAR(13),'') from #DistributionDataset dt
	where dt.ISBN = p.Ordinal and dt.Publisher = pub.Name and dt.Retailer = r.Name for xml path ('')),1,1,''),1000) )
	else 
	stuff((select distinct '; '+ ret.Title + '' from AthenaEventLog..refEventType ret join athenadistribution..distributionORderAcceptabilities doa on doa.ResultingEvent = ret.EventTypeID where doa.ResultingEvent = ret.EventTypeId and doa.distributionOrderUid = dt.distributionOrderUId and doa.ResultingEventLevel > 2 for xml path ('')),1,1,'')
	end
	as [ReasonDetail]*/
	-- consider using this instead
	/*left(isnull(dt.ReasonDetail,'') +
	isnull(stuff((select distinct '; '+ ret.Title + '' from AthenaEventLog..refEventType ret join Athenadistribution..distributionORderAcceptabilities doa on doa.ResultingEvent = ret.EventTypeID where doa.ResultingEvent = ret.EventTypeId and doa.distributionOrderUid = dt.distributionOrderUId and doa.ResultingEventLevel > 2 for xml path ('')),1,1,''),''),1000) as [ReasonDetail]
	*/

FROM
    #DistributionDataset dt
    join AthenaDistribution..Publishers pub on pub.Name = dt.Publisher
    join AthenaSecurity..Organizations o on o.organizationUId = pub.organizationUId
    LEFT OUTER JOIN AthenaSecurity..Organizations po on po.organizationUid = o.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations ppo on ppo.organizationUid = po.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations pppo on pppo.organizationUid = ppo.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations ppppo on ppppo.organizationUid = pppo.ParentOrganizationUid
	join AthenaDistribution..retailers r on r.Name = dt.Retailer
	join AthenaProductCatalog..product p on p.Ordinal = dt.ISBN
    LEFT OUTER JOIN AthenaDistribution..DistributionORders do on do.distributionOrderUid = dt.distributionOrderUid
    LEFT OUTER JOIN AthenaDistribution..DistributionOrderAcceptabilities doa on doa.distributionORderUId = do.distributionORderUid and doa.ResultingEventLevel = 4
    LEFT OUTER JOIN AthenaEventLog..refEventType ret on ret.EventTypeId = doa.ResultingEvent
	group by ISBN,o.organizationname, po.organizationname,ppo.organizationname,pppo.organizationname,ppppo.organizationName, dt.Publisher,dt.Title,ContentType,OnSaleDate,Retailer,ReasonCode,p.Ordinal, pub.Name, r.Name, doa.ResultingEventLevel, ret.EventLevelId, ret.Title,ret.EventTypeId,doa.ResultingEvent, dt.DistributionORderUid, doa.ResultingMessage, dt.ReasonDetail
ORDER BY
	ISBN,
    OnSaleDate DESC,
    dt.Title ASC,
    ReasonCode


	