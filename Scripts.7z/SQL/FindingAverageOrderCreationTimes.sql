
with Orders as (select distinct p.Ordinal, r.Name, do.CreatedAtUtc from DistributionOrders do
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join athenaproductcatalog..product p on p.productUid = pr.ProductUid
join contracts c on c.contractUid = pr.ContractUid
join publishers pu on pu.publisherUid = c.PublisherUid
join retailers r on r.retailerUid = c.retailerUId
join AthenaAssetProcessor..FolderObjectEBookProductProcessingResults fpr on fpr.ProductUid = p.ProductUid
join AthenaAssetProcessor..folderobjects fo on fo.FolderObjectUid = fpr.FolderObjectUid
where 
do.CreatedAtUtc > '2014-10-31 14:00:00.000'
and dos.ResultingEvent = 103
and pu.Name = 'Scholastic Inc.'
and fo.path like '20141030.4%'
and r.code = 'BIS'
),
cte as (
SELECT
   ROW_NUMBER() OVER (PARTITION BY Orders.name ORDER BY CreatedAtUtc) row,
   Ordinal,
   Name,
   CreatedAtUtc
 FROM Orders),
 results as(
SELECT 
   a.name ,
   a.CreatedAtUtc CreatedAt1,
   b.CreatedAtUtc CreatedAt2,
   a.Ordinal, 
   datediff(s,b.CreatedAtUtc, a.CreatedAtUtc) TimeBetween
   --a.CreatedAtUtc - ISNULL(b.CreatedAtUtc,0)
FROM
   cte a
   LEFT  JOIN cte b
   on a.name = b.name
    and a.row = b.row+1
),
averaged as (
select avg(TimeBetween) average, a.Name from results a
group by a.Name)
select a.Name, a.CreatedAt1, a.CreatedAt2, a.Ordinal, a.TimeBetween, b.average
from results a
join averaged b on b.Name = a.Name


select distinct p.Ordinal, r.Name, do.CreatedAtUtc from DistributionOrders do
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join athenaproductcatalog..product p on p.productUid = pr.ProductUid
join contracts c on c.contractUid = pr.ContractUid
join publishers pu on pu.publisherUid = c.PublisherUid
join retailers r on r.retailerUid = c.retailerUId
join AthenaAssetProcessor..FolderObjectEBookProductProcessingResults fpr on fpr.ProductUid = p.ProductUid
join AthenaAssetProcessor..folderobjects fo on fo.FolderObjectUid = fpr.FolderObjectUid
where 
do.CreatedAtUtc > '2014-10-31 14:00:00.000'
and dos.ResultingEvent = 103
and pu.Name = 'Scholastic Inc.'
and fo.path like '20141030.4%'
and r.code = 'BIS'
order by do.CreatedAtUtc