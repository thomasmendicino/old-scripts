/**************************/
begin tran
declare @publisherName nvarchar(100)
declare @publisherUid uniqueidentifier
declare @AllRetailers table (Name nvarchar(50))
declare @ruleSetUid uniqueidentifier

set @publisherName = 'RosettaBooks'
select @publisherUid = publisherUid from AthenaDistribution..Publishers where name = @publisherName
insert @AllRetailers (Name) select Name from Retailers where Code <> 'INX'
select @ruleSetUid = RuleSetUid from AthenaDistribution..ruleSets where Name = 'Distribution Prohibited'


select max(c.ValidUntilUtc) ValidUntilUtc, c.retailerUid from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @AllRetailers)
and c.RuleSetUid = @ruleSetUid
group by c.publisherUid, c.retailerUid, c.ruleSetUid
order by c.RetailerUid

select * from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @AllRetailers)
and c.RuleSetUid = @ruleSetUid
and c.ValidUntilUtc is null


--OPEN THE FEED FOR DISTRIBUTION
/*update c set ValidUntilUtc = getUTCdate() from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @AllRetailers)
and c.RuleSetUid = @ruleSetUid
and c.ValidUntilUtc is NULL
*/


--CLOSE THE FEED FOR DISTRIBUTION
/*;with mostRecentProhibited as
(select max(c.ValidUntilUtc) ValidUntilUtc, c.retailerUid from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @AllRetailers)
and c.RuleSetUid = @ruleSetUid
group by c.publisherUid, c.retailerUid, c.ruleSetUid
)
update c set ValidUntilUtc = NULL from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostRecentProhibited m on m.ValidUntilUtc = c.ValidUntilUtc and c.RetailerUid = m.retailerUid
where p.publisherUId = @publisherUid
and r.Name in (select Name from @AllRetailers)
and c.RuleSetUid = @ruleSetUid
*/

--commit


--rollback