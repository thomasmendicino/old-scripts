--begin transaction
--rollback
--build out for Nook Press
--commit
-- --------------------------------------------------
--  Update Database Configuration
-- --------------------------------------------------
IF NOT EXISTS (SELECT NULL FROM MusicService where Name = 'Nook Press')             --Determines if retailer already exists in DB         
BEGIN																		--there is a duplicate key constraint on the music service table/if you try to enter another music service with the same name, the insert fails			
declare @msname nvarchar(50)                                                    -- variables are declared with an @ sign and data_type
declare @msprefix nvarchar(50)
declare @msurl nvarchar(100)
declare @syndicator_type_name nvarchar (40)
declare @encodingconfiguration nvarchar (100)
declare @encodingconfiguration2 nvarchar (100)
declare @SampleEncodingConfiguration nvarchar(100)
declare @mainextension nvarchar(4)
declare @image_ext nvarchar(4)
declare @image_height int
declare @image_width int
declare @image_quality int
declare @image_dpi int
declare @msid int
declare @fields xml
declare @has_logo int
declare @max_encode_rate int
declare @min_encode_rate int
declare @msGenreMappingTypeId int
declare @country nvarchar(2)
declare	@transferProtocol nvarchar(50)
declare	@server nvarchar(50)
declare	@port int
declare	@passive bit
declare	@username nvarchar(50)
declare	@password nvarchar(50)
declare	@private_key varbinary(5000)
declare	@contractauthority nvarchar(100)
declare @contractauthority2 nvarchar(100)
declare @AcceptAllPayees bit
declare @Supportalbumonly bit
declare @Supporttrackalbumonly bit
declare @SupportClearance bit
declare @UseAlbumPriceTier bit
declare @UseTrackPriceTier bit
declare @PriceTierMappingTypeId int
declare @SupportChangeRequests bit
declare @AcceptAllGenres bit
declare @SupportAreaRestrictions bit
declare @AcceptsExplicit bit
declare @FallbackToINgroovesGenres bit
declare @Priority int
declare @DisplayToClient bit
declare @MetadataOnly bit
declare @RequireWholeAlbum bit
declare @uploadroot nvarchar(200)
declare @SupportNonUniqueISRCs int;
declare @musicservicetype nvarchar(50)
declare @musicservicetypeid int;
declare @syndicator_type_id int;
declare @genremapping_type_name nvarchar(50)
declare @useContractAuthorityServiceProviderIdentity bit
declare @shortProviderId nvarchar(100)
declare @longProviderId nvarchar(100)
declare @providerDirectory nvarchar(100)
declare @shortProviderId2 nvarchar(100)
declare @longProviderId2 nvarchar(100)
declare @providerDirectory2 nvarchar(100)
declare @useCoverArt bit
declare @addTransferJobAndSettings bit
declare @addConcurrentTransferJobParameter bit
Declare @CountryRestriction varchar(50)
Declare @addCountryRestriction bit
Declare @crid int
declare @productTypeName1 nvarchar(50)
declare @productTypeName2 nvarchar(50)
declare @productTypeName3 nvarchar(50)
declare @productTypeID1 int
declare @productTypeID2 int
declare @productTypeID3 int
declare @DistributionTypeName1 nvarchar(100)
declare @DistributionTypeName2 nvarchar(100)
declare @DistributionTypeName3 nvarchar(100)
declare @DistributionTypeName4 nvarchar(100)


-- set variables
set @msname = 'Nook Press'							-- the human readable name, but no apostrophes!
set @msprefix = 'NookPress'							-- like the name, but no spaces or punctuation (used for share names, etc)
set @msurl = 'http://NookPress.com'						-- the music service url
set @syndicator_type_name = 'Nook Press'					-- syndicator and copier use for the music service
set @genremapping_type_name = null
set @PriceTierMappingTypeId = (select ID from PriceTierMappingType where Name='INgrooves Rate Card')
set @fields = null
set	@contractauthority = 'INscribeDigital'
set @country = 'US'				-- Country name in A2 format
set @AcceptAllPayees = 1        --standard
set @Supportalbumonly = 1     --should be on signed agreement
set @Supporttrackalbumonly = 0    --should be on signed agreement
set @SupportClearance = 1       --support clearance/change requests for xml updates
set @SupportChangeRequests = 1      --support clearance/change requests for xml updates
set @AcceptAllGenres = 1       --standard
set @SupportAreaRestrictions = 1  -- area restrictions if they have the ability to restrict content to various countries/rarely 0.  Means accepts only albums cleared for ALL WW
set @AcceptsExplicit = 1       --ask retailer
set @FallbackToINgroovesGenres = 0  --accepts all genres in db
set @Priority = 99               --standard
set @DisplayToClient = 1        --standard
set @UseAlbumPriceTier =1
set @UseTrackPriceTier =0
set @MetadataOnly = 0   
set @RequireWholeAlbum=0         
set @SupportNonUniqueISRCs = 1;                          --ask retailer
set @musicservicetype = 'Online';							--standard	
set @productTypeName1 = 'Ebook'
set @productTypeName2 = 'Enhanced_Ebook'
set @productTypeName3 = 'FixedFormat_Ebook'						-- There could be many Product Types for one music service
set @DistributionTypeName1 = 'eBookEPUB Download'
set @DistributionTypeName2 = 'eBookPDF Download'				--only used if supports streaming



--Set variables for ContractAuthorityServiceProviderIdentity
set @useContractAuthorityServiceProviderIdentity = 1;         --standard
set @shortProviderId = 'ING';
set @longProviderId = 'INgrooves';
set @providerDirectory = 'Isolation';

-- set variables for encoding
set @max_encode_rate=2000									-- Always set to 2000
set @min_encode_rate=200									-- Always set to 200

set @encodingconfiguration = 'ePub eBook Format'		-- Description from encodingconfiguration table

-- set transfer information
set @addTransferJobAndSettings = 0                          -- If 0 it won't add a transfer job nor transfersettings
set @addConcurrentTransferJobParameter = 0                  -- Set to 1 if FTP, SFTP, or FTPSImplicit
set	@transferProtocol = 'SFTP'								-- FTP or SFTP or FileCopy or ...
-- set cover art variables

set @useCoverArt = 1                                        -- If 0 it won't add cover art
set @image_ext = '.jpg'										-- cover file art image format(in agreement)
set @image_width = 1500
set @image_height = 1500
set @image_quality = 90
set @image_dpi = 300		

set @has_logo = 0											-- Set to 1 if there are logos for this music service(can this be done once pushed to prod?)


declare @distributionSet int
declare @supportDistributionSet int
-- get or create distributionset
create table #MatchDistributions (DistributionType int, Allow bit)
      insert into #MatchDistributions select id, 1 from DistributionType where name = @DistributionTypeName1 
	  union 
	  select id, 1 from DistributionType where name = @DistributionTypeName2

	

    
exec get_distribution_set_id @distributionSet out
drop table #MatchDistributions


--get or create supportdistributionset
select @supportDistributionSet = id from 
    (select id from distributionset
    except
    select distributionset from distributionsetitem) x




-- set Single Country Restriction (default for UMG services)
Set @addCountryRestriction = 0                        -- set to 1 to add the country restriction
Set @CountryRestriction = 'United States of America'    -- the country to restrict to, check names from Country table


-- FOR DELETION OF THE MUSIC SERVICE USE THE NEW MusicServiceCleanup.sql during development

------------------------ INSERTING  syndicator type name -------------------------
set @syndicator_type_id = null                        
if not exists( select 1 from SyndicatorType where name = @syndicator_type_name )             
begin
    insert into SyndicatorType( name) select @syndicator_type_name;            --If syndicator name doesn't exist then add it to SyndicatorType table.
    select @syndicator_type_id = SCOPE_IDENTITY();							-- Adds an ID to the SyndicatorType Table
end
ELSE
begin
    select @syndicator_type_id = id from SyndicatorType where Name=@syndicator_type_name
end

-- insert genre mapping type												--If genre mapping name exists, set name and ID from already existing in 
if @genremapping_type_name is not null
Begin
    set @msGenreMappingTypeId = null
    select @msGenreMappingTypeId = id from GenreMappingType where name=@genremapping_type_name

    if @msGenreMappingTypeId is null                                         -- If genre mapping name is null, should create new genre based on name of retailer? 
    begin
	    insert GenreMappingType (Name) select @genremapping_type_name

	    select @msGenreMappingTypeId = SCOPE_IDENTITY()                       --Adds an ID to the SyndicatorType Table
    end
End

-- Insert new encodingstructure  
declare @encodingStructureID int

set @encodingStructureID = null
select @encodingStructureID = id from encodingStructure where name=@msname

if @encodingStructureID is null
begin
	insert encodingStructure(Name)
	values (@msname)

	select @encodingStructureID = SCOPE_IDENTITY()
end


declare @countryid int
set @countryid = null
select @countryid = id from country where A2=@country

select @musicservicetypeid=id from musicservicetype where name = @musicservicetype

-- insert musicservice
insert musicservice (name, volume, columnprefix, PublicURL, country,  genremappingtype, AcceptAllPayees,
                     Supportalbumonly, SupportTrackAlbumOnly, AcceptAllGenres, SupportAreaRestrictions,
                     AcceptsExplicit, FallbackToINgroovesGenres, Priority,
                     DisplayToClient, MetadataOnly, SyndicatorType, Fields,
                     encodingStructure, musicservicetype, SupportNonUniqueISRCs, UseAlbumPriceTier, UseTrackPriceTier, PriceTierMappingType,
                     SupportClearance, SupportChangeRequests, DistributionSet, SupportDistributionSet,RequireWholeAlbum)
select @msname, @msprefix, @msprefix, @msurl, @countryid, @msGenreMappingTypeId, @AcceptAllPayees,
       @Supportalbumonly, @Supporttrackalbumonly, @AcceptAllGenres, @SupportAreaRestrictions,
       @AcceptsExplicit, @FallbackToINgroovesGenres, @Priority,
       @DisplayToClient, @MetadataOnly, @syndicator_type_id, @Fields, @encodingStructureID,
       @musicservicetypeid, @SupportNonUniqueISRCs,  @UseAlbumPriceTier, @UseTrackPriceTier, @PriceTierMappingTypeId,
       @SupportClearance, @SupportChangeRequests, @DistributionSet, @SupportDistributionSet, @RequireWholeAlbum

select @msid = SCOPE_IDENTITY()

-- insert contract authority
declare @contractauthority_id int
select @contractauthority_id = id from contractauthority where folderprefix = @contractauthority

if not exists (select NULL from musicservicecontractauthority where musicservice = @msid and contractauthority = @contractauthority_id)
begin
    insert musicservicecontractauthority (MusicService, ContractAuthority)
	values (@msid, @contractauthority_id)
end

--also insert the identity in: ContractAuthorityServiceProviderIdentity
if @useContractAuthorityServiceProviderIdentity = 1
Begin
    Insert into ContractAuthorityServiceProviderIdentity
    (ContractAuthority, MusicService, ProviderIdentityShort, ProviderIdentityLong, ProviderDirectory)
    values
    (@contractauthority_id, @msid, @shortProviderId, @longProviderId, @providerDirectory)
End

-- insert musicservice media type table
insert MusicServiceMediaType (MusicService, MediaType, ForTrack, ForSong)
select @msid, 45, 1, 0

-- insert MusicServiceProductType
select @productTypeID1 = id from ProductType where Name = @productTypeName1
select @productTypeID2 = id from ProductType where Name = @productTypeName2
select @productTypeID3 = id from ProductType where Name = @productTypeName3

insert into MusicServiceProductType (ContractAuthority, MusicService, ProductType)
values (@contractauthority_id, @msid, @productTypeID1)

insert into MusicServiceProductType (ContractAuthority, MusicService, ProductType)
values (@contractauthority_id, @msid, @productTypeID2)

insert into MusicServiceProductType (ContractAuthority, MusicService, ProductType)
values (@contractauthority_id, @msid, @productTypeID3)
-- setup for primary image
if @useCoverArt = 1
Begin
    declare @imageformatid int

    exec @imageformatid = add_image_configuration @image_ext, @image_width, @image_height, @image_quality, @image_dpi

    insert musicserviceimageformat (musicservice, ImageFormat)
    select @msid, @imageformatid
End

-- insert the music logo if one exists
if @has_logo = 1
begin
	insert musicservicelogo (MusicService, URL, ClientInterface, IncludesFullName)
	select @msid, '/images/INDMA/' + lower(@msprefix) + '_logo.gif', 0, 0
	UNION ALL
	select @msid, '/images/INDMA/' + lower(@msprefix) + '_sm_client.gif', 1, 0
	UNION ALL
	select @msid, '/images/INDMA/' + lower(@msprefix) + '_bg_client.gif', 1, 1
end



--Insert the Encoding Structure Configurations
--This needs to go here so the insert max and min encoding rate parameters add all necessary units
INSERT INTO [dbo].[EncodingStructureConfiguration]
           ([EncodingStructure]
           ,[Main]
           ,[EncodingConfiguration]
           ,[SongCutType]
           ,[CustomId]
           ,[SampleProfile]
           ,[OutSourceType])
     SELECT
           @encodingstructureID
           ,1
           ,(SELECT ID from encodingconfiguration where description=@encodingconfiguration)
           ,NULL
           ,NULL
           ,NULL
           ,NULL

-- add the transfer job (if applicable)
if @addTransferJobAndSettings = 1
Begin
    declare @TransferProtocolID int
    select @TransferProtocolID = ID from TransferProtocol where name = @TransferProtocol

    insert MusicServiceTransferSettings
          (MusicService, TransferProtocol, Server, Port, Passive, Username, Password, PrivateKey, UploadRoot, ContractAuthority, Resume)
    values
	    (
	    @msid,
	    @TransferProtocolID,
	    @server,
	    @port,
	    @passive,
	    @username,
	    @password,
	    @private_key,
	    @uploadroot,
	    @contractauthority_id,
		1
	    )

-- create the transfer job, and add job parameters
    insert job (name, description, musicservice, priority, unit, progress, SupportStartOver)
    select 'TransferTo' + @msprefix + '_INgrooves_DFM', 'Transfer To ' + @msname + '(INgrooves DFM)', @msid, 15, 1, 0, 1

    declare @xfer_jobid int
    select @xfer_jobid = SCOPE_IDENTITY()

    insert jobparameter(job, parameter, sequence, unit)
    values (@xfer_jobid, 28, 10, 1)

    -- the following may apply if transfer is via ftp, ftps, or sftp
   if @addConcurrentTransferJobParameter = 1
    begin
        insert jobparameter (job, parameter, sequence, IntValue)
        select job.id, parameter.id, 20, 1
        from job, parameter
        where job.name = 'TransferTo' + @msprefix + '_INgrooves_DFM' and
              parameter.name='MaxConcurrentTransfer'
    end


      insert jobparameter (job, parameter, sequence)
    select job.id, parameter.id, 40
    from job, parameter
    where job.name = 'TransferTo' + @msprefix + '_INgrooves_DFM' and
          parameter.name='SyndicationLevel'
End

--Adding area restriction
--********************************
declare @arid int

if @addCountryRestriction = 1
Begin
    select @crid=id from Country where name = @CountryRestriction

    select @arid = id from AreaRestriction where musicservice=@msid and country=@crid
    if @arid is null
    begin
        insert AreaRestriction (MusicService, Operator, Country, Sequence)
        values (@msid, '+', @crid, 0)
    end
End


insert into
encodingstructureconfigurationproducttype 
select id,
22
from encodingstructureconfiguration where encodingstructure = 
(select encodingstructure from musicservice where name = @msname)
union
select id,
23
from encodingstructureconfiguration where encodingstructure = 
(select encodingstructure from musicservice where name = @msname)
union
select id,
24
from encodingstructureconfiguration where encodingstructure = 
(select encodingstructure from musicservice where name = @msname)

End



-- commit

--the following queries are for testing: --replace (Zefr) with the new retailer name
--select * from MusicService where name like '%Zefr%'
--select * from MusicServiceLogo where musicservice in (select id from MusicService where name like '%Zefr%')
--select imageformat from MusicServiceImageFormat where MusicService in (select ID from MusicService where name like '%Zefr%')
--select * from imageformat where id = (select imageformat from MusicServiceImageFormat where MusicService=(select ID from MusicService where name like '%Zefr%'))
--select * from EncodingStructure where name like '%Zefr%'
--select * from EncodingStructureConfiguration where EncodingStructure in (select ID from encodingstructure where name like '%Zefr%')
--select * from EncodingStructureConfigurationProductType where EncodingStructureConfiguration in (select ID from EncodingStructureConfiguration where EncodingStructure in (select ID from encodingstructure where name like '%Zefr%'))
--select * from job where MusicService=(select ID from MusicService where name like '%Zefr%')
--select * from jobparameter where job in (select id from job where MusicService=(select ID from MusicService where name like '%Zefr%'))
--select * from MusicServiceTransferSettings where musicservice in (select id from MusicService where name like '%Zefr%')
--select * from musicservicecontractauthority where musicservice in (select id from MusicService where name like '%Zefr%')
--select c.name from countrysetcountry csc join musicservice ms on ms.countryset = csc.countryset join country c on c.id = csc.country where ms.name = 'Zefr'



--select * from country where name = 'United States of America'

--select * from imageformat where id = 25

--select count(*), imageformat from musicserviceimageformat where imageformat in (select id from imageformat where extension = '.jpg') group by imageformat order by imageformat

--select * from imageformat where id in (11,25,14,33,41,53,59,83,87,204)

--select count(encodingstructure), encodingstructure, encodingconfiguration from encodingstructureconfiguration group by encodingstructure, encodingconfiguration 
--select * from job where name like '%Zefr%'
--select * from encodingstructureconfigurationproducttype where encodingstructureconfiguration in (87,88)
--select * from producttype
--select * from encodingstructureconfiguration
--select * from sampleprofile where length = 30 and FadeIn = 0.15 and FadeOut = 2 and Start = 0 
--select * from job where name like '%Zefr%'


