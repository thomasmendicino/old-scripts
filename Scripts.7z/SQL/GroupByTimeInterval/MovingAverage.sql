
;with 
recentlyAddedProducts as (
	select p.Ordinal, min(ValidFromUtc) AddedAt from product p
	join asset a on a.ProductUid = p.ProductUid
	join AssetOverride ao on ao.AssetUid = a.AssetUid
	join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
	join AthenaSecurity..OrgHierarchy('Scholastic Inc.') oh on oh.organizationUId = p.OrganizationUid
	where pf.ProductFormTypeValue in (49,50,51,52)
	group by p.Ordinal),
WeeklyIngestionStats as (
	select count(Ordinal) ProductCount, DateAdd(DAY, 7 * (DateDiff(DAY, '20000101', AddedAt) / 7), '20000101') As ProductIngestion
	,ROW_NUMBER() OVER (ORDER BY DateAdd(DAY, 7 * (DateDiff(DAY, '20000101', AddedAt) / 7), '20000101') ASC) RowNum
	from recentlyAddedProducts
	group by DateAdd(DAY, 7 * (DateDiff(DAY, '20000101', AddedAt) / 7), '20000101'))
	SELECT ProductIngestion
		, ProductCount
		--the following functions are not available until SQL Server 2012
	--AVG(ProductCount) OVER (ORDER BY ProductIngestion ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) 
	--AVG(ProductCount) OVER (PARTITION BY ProductIngestion ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING)        AS AverageWeeklyAddition
	--LAG(ProductCount, 1) OVER (ORDER BY ProductIngestion) AS CountPrev
		,AVG(ProductCount) OVER (PARTITION BY DATEPART(MONTH,ProductIngestion),1, DATEPART(YEAR,ProductIngestion),1) as MonthlyAverage
	FROM WeeklyIngestionStats
	GROUP BY ProductIngestion, DATEPART(MONTH,ProductIngestion), DATEPART(YEAR,ProductIngestion), ProductCount
	ORDER BY ProductIngestion
	