

;with DOEvents AS
(select DateAdd(minute, 15 * (DateDiff(minute, '20000101', dateadd(hh,-8,dos.CreatedAtUtc)) / 15), '20000101') As EventCreationTime,
dos.ResultingEvent
From DistributionOrderStatus dos
where dos.CreatedAtUtc > GETUTCDATE()-3),
Counts as (
Select EventCreationTime, count(ResultingEvent) As NumEvents
From DOEvents
Group By EventCreationTime)
select EventCreationTime
,NumEvents
,AVG(NumEvents) OVER (PARTITION BY DATEPART(DAY,EventCreationTime),1, DATEPART(HOUR,EventCreationTime),1) as HourlyAverage
FROM Counts
order by EventCreationTime