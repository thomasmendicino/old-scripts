
use AthenaDistribution;
begin tran
select * from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is null
and dc.name = 'Follett Ftp for All INscribe Digital Content'

update ftp set HostName = 'ftp.follettebooks.com', StartingDirectory = '/', UserName = 'insc5702', Password = '6vF98d28'
from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is null
and dc.name = 'Follett Ftp for All INscribe Digital Content'

/*update ftp set HostName = 'ftp.ingrooves.com', StartingDirectory = '/Follett', UserName = 'productionftp', Password = 'inscribe'
from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is null
and dc.name = 'Follett Ftp for All INscribe Digital Content'*/

select * from TransferServiceFtpEndpoints ftp
join distributioncontracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is null
and dc.name = 'Follett Ftp for All INscribe Digital Content'

--commit