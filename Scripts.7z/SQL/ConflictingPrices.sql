;with conflictingPrices as (select p.Ordinal from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join TerritorySupplyDetails td on td.TerritorySupplyId = ts.TerritorySupplyId
join prices pr on pr.TerritorySupplyDetailId = td.TerritorySupplyDetailId
join CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
group by av.AssetVersionUid, cs.CountrySetUid, pr.EffectiveFromUtc, pr.EffectiveToUtc, pr.PriceType, pr.Qualifier, pr.IsTaxIncluded, pr.PriceCode, pr.PriceCodeTypeName
having count(*) > 1)