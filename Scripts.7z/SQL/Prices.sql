
select pd.ordinal, p.Amount, pf.ProductFormTypeValue from prices p
join territorySupplyDetails tsd on tsd.territorySupplyDetailId = p.territorySupplyDetailId
join territorySupplies ts on ts.territorySupplyId = tsd.territorySupplyId
join assetVersion av on av.assetVersionUId = ts.assetVersionUId
join assetOverride ao on ao.assetOverrideUid =av.assetOverrideUId
join asset a on a.assetUid = ao.assetUid
join product pd on pd.productuId = a.productUId
join productForms pf on pf.assetVersionUId = av.assetVersionUid
where Amount is not null and amount not like '%99'
and av.validUntilUtc is null
