--begin tran
--commit
--rollback
BEGIN TRY

IF OBJECT_ID('tempdb.dbo.#Changes') IS NOT NULL
 DROP TABLE #Changes
CREATE TABLE #Changes (Album int, oldAlbumOrg int, oldSongOrg int, oldCelebOrg int, newOrg int, At datetime)

IF object_ID('dbo.#TMerror') IS NOT NULL 
DROP TABLE #TMerror
CREATE TABLE #TMerror (Album int, Song int, NewOrganization int, ErrorNumber nvarchar(max), ErrorProcedure nvarchar(max), ErrorLine nvarchar(max), ErrorState nvarchar(max), ErrorMessage nvarchar(max))

DECLARE @DesiredOrgName nvarchar(50) = 'Charisma House'
DECLARE @DeprecatedOrgName nvarchar(50) = 'Passio'
DECLARE @DesiredOrg int
SELECT @DesiredOrg = ID FROM Organization WHERE Name = @DesiredOrgName
DECLARE @DeprecatedOrg int
SELECT @DeprecatedOrg = ID FROM Organization WHERE Name = @DeprecatedOrgName
DECLARE @Album table (Album int)
--select @DesiredOrgname
--select @DeprecatedOrgName
INSERT INTO @Album
SELECT DISTINCT ID FROM Album WHERE Organization = @DeprecatedOrg AND GTIN IN ('9781616386412',
'9781616386764',
'9781616387181',
'9781616387228',
'9781616388348',
'9781616388676',
'9781616389710',
'9781621360339',
'9781621360360',
'9781621360377',
'9781621360438',
'9781621360490',
'9781621362043',
'9781621362081',
'9781621362272',
'9781621362562',
'9781621362609',
'9781621362647',
'9781621362722',
'9781621362807',
'9781621362937',
'9781621363033',
'9781621365112',
'9781621365204',
'9781621365266',
'9781621365648',
'9781621365778',
'9781621365860',
'9781621366560',
'9781629986135')

--select * from @Album
DECLARE @AlbumId int

DECLARE Album_Cursor CURSOR LOCAL FOR
SELECT Album FROM @Album


OPEN Album_Cursor
FETCH NEXT FROM album_cursor INTO @AlbumId

WHILE @@fetch_status= 0 
BEGIN

DECLARE @newOrg int = @DesiredOrg
DECLARE @oldAlbumOrg int = (SELECT DISTINCT Organization FROM Album WHERE ID = @AlbumId)
DECLARE @oldSongOrg int = (SELECT DISTINCT S.Organization FROM Album A
INNER JOIN Track T on T.Album = A.ID
INNER JOIN Song S on T.Song = S.ID
WHERE A.ID = @AlbumId AND S.Organization <> @DesiredOrg)
DECLARE @oldCelebOrg int = (SELECT DISTINCT C.Organization FROM Album A
INNER JOIN AlbumCelebrity AC on AC.Album = A.ID
INNER JOIN Celebrity C on C.ID = AC.Celebrity
WHERE A.ID = @AlbumID)

EXEC change_album_owner @AlbumID, @newOrg

INSERT #Changes (Album, oldAlbumOrg, oldSongOrg, oldCelebOrg, newOrg, At)
SELECT @AlbumId, @oldAlbumOrg, @oldSongOrg, @oldCelebOrg, @newOrg, getdate()


FETCH NEXT FROM Album_Cursor INTO @AlbumId
WAITFOR DELAY '00:00:00.500'
END

 CLOSE Album_Cursor
   DEALLOCATE Album_Cursor
   
  END TRY
  
BEGIN CATCH

INSERT #TMerror (Album, NewOrganization, ErrorNumber, ErrorProcedure, ErrorLine, ErrorState, ErrorMessage)
VALUES(@AlbumId, @NewOrg, ERROR_NUMBER(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_STATE(), ERROR_MESSAGE())

END CATCH


SELECT * FROM #TMerror
SELECT * FROM #Changes


SELECT A.ID [Album], A.GTIN [ISBN], S.ID [Song], Cel.Name [Celebrity], R.Name [Role], OOA.Name [Old Album Organization], OOS.Name [Old Song Organization], OOC.Name [Old Celebrity Organization],
NOA.Name [New Album Organization], NOS.Name [New Song Organization], NOC.Name [New Celebrity Organization] FROM 
#Changes C
INNER JOIN Album A ON A.ID = C.Album
LEFT OUTER JOIN Organization OOS on OOS.ID = C.oldSongOrg
INNER JOIN Organization OOA on OOA.ID = C.oldAlbumOrg
INNER JOIN Organization OOC on OOC.ID = C.oldCelebOrg
INNER JOIN AlbumCelebrity AC on AC.Album = A.ID
INNER JOIN Celebrity Cel on Cel.ID = AC.Celebrity
INNER JOIN Organization NOA on NOA.ID = A.Organization
LEFT OUTER JOIN Track T on T.Album = A.ID
LEFT OUTER JOIN Song S on T.Song = S.ID
LEFT OUTER JOIN Organization NOS on NOS.ID = S.Organization
INNER JOIN Organization NOC on NOC.ID = Cel.Organization
INNER JOIN [Role] R on R.ID = AC.[Role]