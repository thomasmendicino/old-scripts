/*
[select soel.syndicationorder,
sos.Name SOEL_OrderState,
soel.Message SOEL_EventMessage,
soel.At,so.ID,so.OrderId,
so.orderbatchid,
so.partnername,
so.placername,
so.submissiondate,
so.orderstatemessage
 from SyndicationOrderEventLog soel
inner join SyndicationOrder so on so.ID = soel.SyndicationOrder
inner join syndicationorderstate sos on soel.orderstate = sos.ID
where so.OrderState = 3 
and soel.orderstate= 14
and soel.at < '2011-04-21 13:00:00.000'
--and soel.orderstate = 14
order by soel.at desc, soel.syndicationorder desc]

intersect

[select soel.syndicationorder,
sos.Name SOEL_OrderState,
soel.Message SOEL_EventMessage,
soel.At,
so.ID,
so.OrderId,
so.orderbatchid,
so.partnername,
so.placername,
so.submissiondate,
so.orderstatemessage
 from SyndicationOrderEventLog soel
inner join SyndicationOrder so on so.ID = soel.SyndicationOrder
inner join syndicationorderstate sos on soel.orderstate = sos.ID
where so.OrderState = 3 
and soel.orderstate != 11
and soel.at < '2011-04-21 13:00:00.000'
--and soel.orderstate = 14
order by soel.syndicationorder desc, soel.at desc]


[select so.ID syndicationorder_id,
soel.orderstate soel_orderstate
from syndicationordereventlog soel
inner join syndicationorder so on so.id = soel.syndicationorder
where so.OrderState = 3 
and soel.orderstate = 14
and soel.at < '2011-04-21 13:00:00.000'
order by soel.at desc,
soel.syndicationorder desc]

intersect

select so.ID syndicationorder_id, 
soel.orderstate soel_orderstate 
from syndicationordereventlog soel 
inner join syndicationorder so on so.id = soel.syndicationorder 
where so.OrderState = 3 
and soel.orderstate= 14 
and soel.at > '2011-04-19 13:00:00.000' 
order by soel.at desc, 
soel.syndicationorder desc

*/
select so.ID syndicationorder_id,
soel.orderstate soel_orderstate
from syndicationordereventlog soel
inner join syndicationorder so on so.id = soel.syndicationorder
where so.OrderState = 3 
and soel.orderstate = '14'
and soel.at < '2011-04-21 13:00:00.000'
intersect
select so.ID syndicationorder_id, 
soel.orderstate soel_orderstate 
from syndicationordereventlog soel 
inner join syndicationorder so on so.id = soel.syndicationorder 
where so.OrderState = 3 
and soel.orderstate != '11'
and soel.at > '2011-04-21 12:00:00.000'












