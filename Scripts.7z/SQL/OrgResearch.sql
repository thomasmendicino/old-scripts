--See if there are any contract restrictions for the org

select * from organization where charter = 38 and name = 'light messages publishing'

select * from organization where charter = 38 and parent = (select id from organization where charter = 38 and name = 'light messages publishing')

--Find all contracts associated with the org
select * from contract where organization in (
select id from organization where charter = 38 and name = 'light messages publishing'
union
select id from organization where charter = 38 and parent = (select id from organization where charter = 38 and name = 'light messages publishing')
)

--Check if there are any music services associated to the contract. If contract.ExcludeServices = 1, then any music services in this table are NOT allowed. 
--If ExcludeServices = 0, then ONLY music services in this table are allowed.
select * from contractMusicService where contract = (select id from contract where organization in (
select id from organization where charter = 38 and name = 'light messages publishing'
union
select id from organization where charter = 38 and parent = (select id from organization where charter = 38 and name = 'light messages publishing')
))


--See if there are any album level contracts associated to the org's catalog
select * from album where organization in (
select id from organization where charter = 38 and name = 'light messages publishing'
union
select id from organization where charter = 38 and parent = (select id from organization where charter = 38 and name = 'light messages publishing')
)