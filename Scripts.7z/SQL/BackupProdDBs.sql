---------------------------------------************************------------------------
BACKUP DATABASE AthenaEventLog TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaEventLog.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO

---------------------------------------************************------------------------
BACKUP DATABASE AthenaMigrator TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaMigrator.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO

---------------------------------------************************------------------------
BACKUP DATABASE AthenaProductCatalog TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaProductCatalog.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO

---------------------------------------************************------------------------
BACKUP DATABASE AthenaReportCatalog TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaReportCatalog.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO

---------------------------------------************************------------------------
BACKUP DATABASE AthenaResourceStorage TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaResourceStorage.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO

---------------------------------------************************------------------------
BACKUP DATABASE AthenaSecurity TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaSecurity.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO

---------------------------------------************************------------------------
BACKUP DATABASE AthenaAssetProcessor TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaAssetProcessor.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO

---------------------------------------************************------------------------
/*BACKUP DATABASE AthenaComposite TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaComposite.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO*/

---------------------------------------************************------------------------
BACKUP DATABASE AthenaDistribution TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaDistribution.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO
---------------------------------------************************------------------------
BACKUP DATABASE AUTOINDEXRECS TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AUTOINDEXRECS.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO
---------------------------------------************************------------------------
BACKUP DATABASE ReportServer TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\ReportServer.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO
---------------------------------------************************------------------------
BACKUP DATABASE ReportServerTempDB TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\ReportServerTempDB.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO
---------------------------------------************************------------------------
BACKUP DATABASE AthenaDistribution TO  DISK = N'D:\Backups\INSCRIBEDB\20150608\AthenaDistribution.bak' 
WITH  RETAINDAYS =0, NOFORMAT, 
INIT,  
MEDIANAME = N'Backup full daily',  
NAME = N'Backup full daily', 
NOSKIP, 
NOREWIND, 
NOUNLOAD,  
COMPRESSION,
STATS = 10
GO