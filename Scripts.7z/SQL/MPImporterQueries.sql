select top 10 * from autosynclog order by downloaded desc

update autosynclog set state = 2, errormessage = null, stagingpath = '\\nas2\WamNet-Staging\2011\10\26\23\00850717001834' where id = 219494
select top 50 * from pendingimport order by date desc
autosync pkg
select * from autosyncstate

--insert autosynclog (WNPackageID, StagingPath, State, Downloaded, AutoSyncBundleType)
select 'ThomasTest', '\\nas2\WamNet-Staging\2011\10\00850717001834', 2, getdate(), 1
select top 50 * from album a
join arearestriction ar on ar.album = a.id
update autosynclog set state = 2 where id = 221098
select * from ingrooveslog.dbo.log
select * from album where gtin = '00044003152595'
select * from album where gtin = '00619061399529'
select * from albumoverrides where album = (select ID from album where gtin = '00619061399529')
select * from track where album = (select ID from album where gtin = '00619061399529')
select * from trackoverrides where track in (select id from track where album = (select ID from album where gtin = '00619061399529'))
select * from song where id in (select song from track where album = (select ID from album where gtin = '00619061399529'))
select * from songoverrides where song in (select song from track where album = (select ID from album where gtin = '00619061399529'))


update album set gtin = null, process = 1, MediaPortalIncomplete = 1 where id = 251464



select * from album where gtin = '00619061399529'
--update album set gtin = NULL where ID = 251462

\\fileserver2\WNStaging\2011-10-25\17_11_23\00824953009626
select * from changerequest cr
join album a on a.id = cr.album
join changerequestbatch crb on cr.changerequestbatch = crb.id
join changerequestimportlogbatch crilb on crilb.changerequestbatch = crb.id
join importlog il on il.id = crilb.importlog
left join importlogentry ile on ile.importlog = il.id
where a.gtin = '00044003152595'
select top 5000 *, a.gtin, csc.country from album a
join countryset cs on a.countryset = cs.id
join countrysetcountry csc on csc.countryset = cs.id
join albumproducttype apt on apt.album = a.id
where cs.id in (3,4,6,7,8,9)
and apt.producttype = 3

select * from producttype

--where a.gtin = '601811130025'
select * from countrysetcountry where countryset = 8

select * from syndication where musicservice = (select id from musicservice where name = 'itunes') order by syndicatedat desc
select * from tracksyndication where syndication = (select top 1 id from syndication where musicservice = (select id from musicservice where name = 'itunes') order by syndicatedat desc)

select * from job where name not like '%copy%' and name not like '%encode%' and name not like '%transfer%'

