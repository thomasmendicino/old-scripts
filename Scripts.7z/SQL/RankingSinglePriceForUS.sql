select p.Ordinal, pr.Amount,
ROW_NUMBER() OVER (PARTITION BY p.Ordinal order by PriceType asc, pr.Qualifier asc, pr.IsTaxIncluded asc) AS ROWNum
 from product p
join asset a on a.ProductUid = p.ProductUid
cross apply (
	select top 1 AssetOverrideUid
	from AssetOverride
	where AssetOverride.AssetUid = a.AssetUid
	order by RetailerUid asc) ao
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join TerritorySupplyDetails td on td.TerritorySupplyId = ts.TerritorySupplyId
join CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
--join refCountryCode rc on rc.CountryCode = cs.
join Prices pr on pr.TerritorySupplyDetailId = td.TerritorySupplyDetailId
where av.ValidUntilUtc is null
AND pr.Currency = 174
AND pr.PriceCode is null
AND CountryList like '%us%'
AND CHARINDEX('US',CountryList) % 2 != 0
AND pr.EffectiveToUtc is NULL