create table #pages (ID int identity(1,1), name char(2))
create table #versions (ISBN bigint, Retailer nvarchar(10), ID int identity(0,1))
;with mostrecentstatus as (
select pr.ProductUid, max(dos.DistributionOrderStatusId) MaxDistroOrderStatusId, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
where dos.CreatedAtUtc > getdate()-365
and r.code not in ('OST','ENT','SNY','FLK')
group by pr.productUid, r.code),
mostrecentisbatch as (
select dos.DistributionOrderUid, dos.CreatedAtUtc, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join refEventType et on et.EventTypeId = dos.ResultingEvent
join mostrecentstatus m on m.ProductUid = pr.ProductUid and m.MaxDistroOrderStatusId = dos.DistributionOrderStatusId and r.code = m.Retailer
where 
et.EventLevelId < 4 --ERROR
AND et.Code NOT IN ('DIDC','DITC') --Distribution Disabled by Contract, Distribution Order Transfer Complete
AND dos.CreatedAtUtc < GETUTCDATE()-1) -- this is just to ignore batches in the last day that may not have had fulfillment attempted yet.
insert #versions (Retailer, ISBN)
select distinct m.Retailer, p.Ordinal as ISBN from mostrecentisbatch m
join DistributionOrders do on do.DistributionOrderUid = m.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.productUid
order by m.Retailer, p.Ordinal


declare @results table (Commands nvarchar(max), Retailer char(3))
declare @position1 int
declare @position2 int
declare @rowcount int = 100
insert #pages (name)
select top 26 1 from organizations;

declare pageCursor cursor local for
select ID from #pages
open pagecursor
fetch next from pageCursor into @position1
while @@fetch_status=0
begin
set @position1 = @position1 * @rowcount
set @position2 = @position1 + @rowcount
insert @results (Commands, Retailer)
select distinct 
'Distribution.Launcher.exe -a CreateAndProcessDistributionOrders --product-list ' + STUFF((select ','+ cast(p2.Ordinal as nvarchar(100)) from product p2
join #versions v2 on v2.ISBN = p2.Ordinal
where v2.Retailer = v.Retailer
and v2.ID between @position1 and @position2
for xml path ('')),1,1,'')  
+ ' --retailer-list ' + v.Retailer as Commands, 
 v.Retailer 
from product p
 join #versions v on v.ISBN = p.Ordinal
where v.ID between @position1 and @position2 

fetch next from pageCursor into @position1
end
select * from @results
close pageCursor
deallocate pageCursor