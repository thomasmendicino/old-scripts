declare @productChangeTypes2 table(Name varchar(50), Value int)
insert into @productChangeTypes2 values ('NewProduct', 1)
insert into @productChangeTypes2 values ('AssetUpdate', 2)
insert into @productChangeTypes2 values ('MetadataUpdate', 4)
insert into @productChangeTypes2 values ('Takedown', 8)
insert into @productChangeTypes2 values ('PartialTakedown', 16)
insert into @productChangeTypes2 values ('Preorder', 32)
insert into @productChangeTypes2 values ('Embargo', 64)
insert into @productChangeTypes2 values ('PriceCampaign', 128)
insert into @productChangeTypes2 values ('IBookstoreBibliographicChange', 256)
insert into @productChangeTypes2 values ('ManualReviewRequired', 512)
insert into @productChangeTypes2 values ('ManualReviewApproved', 1024)
insert into @productChangeTypes2 values ('ManualReviewRejected', 2048)
insert into @productChangeTypes2 values ('Reactivation', 4096)
insert into @productChangeTypes2 values ('DrmFree', 8192)
insert into @productChangeTypes2 values ('DrmProtected', 16384)


select ct.Name as ProductChangeType, ct.Value, cto.OverrideChangetype,p.Ordinal,r.Name,* 
from ProductChangeTypeOverrideOrders cto 
cross join @productChangeTypes2 ct
join AthenaComposite..product p on p.productUid = cto.productUid
join AthenaComposite..contracts c on c.ContractUid = cto.ContractUid
join AthenaComposite..Retailers r on r.RetailerUid = c.RetailerUid
where 
cto.OverrideChangeType & ct.Value <> 0
and ordinal = 9781619634473
and r.code = 'APC'