;with SingleMainTitle AS (
	SELECT DISTINCT
		p.Ordinal
		, replace(COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ','') + te.TitleWithoutPrefix),'"','''''') as Title
		, ROW_NUMBER() OVER (PARTITION BY p.Ordinal ORDER BY TitleElementLevel, isnull(te.TitleText,'z') DESC, te.TitleWithoutPrefix ASC) RowNum
	FROM
		Product p
	INNER JOIN Asset a
		on a.ProductUid = p.ProductUid
	INNER JOIN AssetOverride ao
		on ao.AssetUid = a.AssetUid
	INNER JOIN AssetVersion av
		on av.AssetOverrideUid = ao.AssetOverrideUid
	INNER JOIN TitleDetails td
		on td.AssetVersionUid = av.AssetVersionUid
	INNER JOIN TitleElements te
		ON te.TitleDetailId = td.TitleDetailId)