
declare @productChangeTypes table(Name varchar(50), Value int)
insert into @productChangeTypes values ('NewProduct', 1)
insert into @productChangeTypes values ('AssetUpdate', 2)
insert into @productChangeTypes values ('MetadataUpdate', 4)
insert into @productChangeTypes values ('Takedown', 8)
insert into @productChangeTypes values ('PartialTakedown', 16)
insert into @productChangeTypes values ('Preorder', 32)
insert into @productChangeTypes values ('Embargo', 64)
insert into @productChangeTypes values ('PriceCampaign', 128)
insert into @productChangeTypes values ('IBookstoreBibliographicChange', 256)
;with #changeTypes as (
select pr.ProductRevisionUid, ct.Name as ProductChangeType, ct.Value
from ProductRevisions pr
cross join @productChangeTypes ct
where pr.ChangeType & ct.Value <> 0
)
select * from athenabeta03productcatalog..product p
join productRevisions pr on pr.productUid = p.productUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.retailerUId = c.retailerUId
join #changeTypes ct on ct.ProductRevisionUid = pr.ProductRevisionUid
where
p.ordinal = 9780545646536
--and r.name = 'flipkart'
order by pr.ProductRevisionUid

/* ****************************************************************/



declare @pubStatus table (Name varchar(50), Value int)
insert into @pubStatus values ('Unspecified',0)
insert into @pubStatus values ('Cancelled',1)
insert into @pubStatus values ('Forthcoming',2)
insert into @pubStatus values ('Postponed indefinitely',3)
insert into @pubStatus values ('Active',4)
insert into @pubStatus values ('No longer our product',5)
insert into @pubStatus values ('Out of stock indefinitely',6)
insert into @pubStatus values ('Out of print',7)
insert into @pubStatus values ('Inactive',8)
insert into @pubStatus values ('Unknown',9)
insert into @pubStatus values ('Remaindered',10)
insert into @pubStatus values ('Withdrawn from sale',11)
insert into @pubStatus values ('Recalled',12)
insert into @pubStatus values ('Recalled',15)
insert into @pubStatus values ('Temporarily withdrawn from sale',16)

declare @productChangeTypes table(Name varchar(50), Value int)
insert into @productChangeTypes values ('NewProduct', 1)
insert into @productChangeTypes values ('AssetUpdate', 2)
insert into @productChangeTypes values ('MetadataUpdate', 4)
insert into @productChangeTypes values ('Takedown', 8)
insert into @productChangeTypes values ('PartialTakedown', 16)
insert into @productChangeTypes values ('Preorder', 32)
insert into @productChangeTypes values ('Embargo', 64)
insert into @productChangeTypes values ('PriceCampaign', 128)
insert into @productChangeTypes values ('IBookstoreBibliographicChange', 256)
;with #changeTypes as (
select pr.ProductRevisionUid, ct.Name as ProductChangeType, ct.Value
from ProductRevisions pr
cross join @productChangeTypes ct
where pr.ChangeType & ct.Value <> 0
)
select distinct ProductRevisionOrdinal, tps.Name [PublishingStatus], p.Ordinal, pr.ProductRevisionUid, ct.ProductChangeType, ct.Value
from ProductRevisions pr
join product p on p.productUid = pr.productUid
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join assetVersion av on av.AssetOverrideUid= ao.AssetOverrideUid
join resources r on r.ResourceUid = av.ResourceUid
join publishingStatus ps on ps.assetVersionUid = av.assetVersionUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join @pubStatus tps on tps.Value = ps.PublishingStatusType
join #changeTypes ct on ct.ProductRevisionUid = pr.ProductRevisionUid
where
--tps.Name not in ('forthcoming','active')
p.ordinal = 9780545668033
and av.validUntilUtc is null
and a.ResourceContentType in (100,101)
order by pr.ProductRevisionUid