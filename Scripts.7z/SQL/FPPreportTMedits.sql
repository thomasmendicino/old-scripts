/*-- Uncomment to debug
declare @PPRViolationStart as date = null
declare @PPRViolationEnd as date = null
declare @OrganizationUid as uniqueidentifier
DECLARE @OrganizationUidList NVARCHAR(MAX)
--SET @PPRViolationStart='2015-04-04'
--SET @PPRViolationEnd='2015-06-08'
SET @OrganizationUidList =  '{6F8AEA58-A1F1-4782-B5AB-F07F7FCE4CE2}' 
declare @wholesaleGTagency bit = 0
DECLARE @PublicationDateRangeStart as date= NULL 
DECLARE @PublicationDateRangeEnd as date= null
DECLARE @eISBNs as NVARCHAR(MAX) = '9780954702335'
DECLARE @eISBNList as NVARCHAR(MAX) = '9780954702335'
--*/ --Debug

declare @ValidationReportStartDate as date = @PPRViolationStart
declare @ValidationReportEndDate as date = @PPRViolationEnd

IF(@ValidationReportEndDate is not null)
    SET @ValidationReportEndDate = dateadd(day, 1, @ValidationReportEndDate);
IF(@ValidationReportEndDate is null)
    SET @ValidationReportEndDate = '2100-01-01'
    
IF (@ValidationReportStartDate is not null and @ValidationReportStartDate = @ValidationReportEndDate)
    SET @ValidationReportEndDate = dateadd(day, 1, @ValidationReportStartDate);
IF(@ValidationReportStartDate is null)
    SET @ValidationReportStartDate = '1900-01-01'   

declare @ReportPublicationDateRangeStart as date = @PublicationDateRangeStart
declare @ReportPublicationDateRangeEnd as date = @PublicationDateRangeEnd

IF(@ReportPublicationDateRangeStart is null)
    SET @ReportPublicationDateRangeStart = '1900-01-01' 
    
IF(@ReportPublicationDateRangeEnd is null)
    SET @ReportPublicationDateRangeEnd = '2100-01-01'

DECLARE @MetadataResourceContentType int = 100
DECLARE @TitleTypeCode int = 1
DECLARE @PublishingDateRole int = 1
DECLARE @Book int = 14; 
DECLARE @Hardback int = 15; 
DECLARE @PaperbackOrSoftback int = 16; 
DECLARE @WholesalePrice int = 1; 
DECLARE @AgencyPrice int = 14;

IF OBJECT_ID('tempdb..#Orgs') IS NOT NULL 
DROP TABLE #Orgs 

CREATE TABLE #Orgs (ID uniqueidentifier NOT NULL,
PRIMARY KEY (ID))

INSERT INTO #Orgs (ID)
SELECT DISTINCT 
    org.OrganizationUid 
FROM 
    Organizations org
WHERE 
    org.OrganizationUid IN (@OrganizationUidList)
       
IF OBJECT_ID('tempdb..#CountrySetCountries') IS NOT NULL 
DROP TABLE #CountrySetCountries 

CREATE TABLE #CountrySetCountries (
ID int IDENTITY (1,1) NOT NULL,
Country char(2), CountrySetUid uniqueidentifier NOT NULL, CountryList varchar(504)
PRIMARY KEY (CountrySetUid ASC, ID ASC) 
)
INSERT INTO #CountrySetCountries (Country, CountrySetUid, CountryList)
SELECT r.country, r.CountrySetUid, r.CountryList 
FROM 
( 
SELECT substring(cs.CountryList, v.number+1, 2) as country, v.number as RowNumber, cs.CountrySetUid, cs.CountryList 
FROM CountrySets cs 
join master..spt_values v on v.number &lt; len(cs.CountryList) 
WHERE v.type = 'P' 
) r 
WHERE (RowNumber % 2) = 0 


IF OBJECT_ID('tempdb..#PublishingDatesPerCountrySet') IS NOT NULL 
DROP TABLE #PublishingDatesPerCountrySet 

CREATE TABLE #PublishingDatesPerCountrySet (ID int IDENTITY (1,1), value datetime, AssetVersionUid uniqueidentifier not null, PDcountryId int
PRIMARY KEY (AssetVersionUid, ID),
)

INSERT INTO #PublishingDatesPerCountrySet (value, AssetVersionUid, PDcountryId)
SELECT
    pd.Value,
    av.AssetVersionUid,
    rcc.CountryCodeId PDcountryId
FROM
    PublishingDates pd
    INNER JOIN AssetVersion av ON pd.AssetVersionUid = av.AssetVersionUid
    INNER JOIN #CountrySetCountries csc on pd.CountrySetUid = csc.CountrySetUid
    INNER JOIN refCountryCode rCC on csc.country = rCC.CountryCode
    INNER JOIN AssetOverride ao on av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN Asset a ON ao.AssetUid = a.AssetUid
    INNER JOIN Product p ON a.ProductUid = p.ProductUid
    INNER JOIN Organizations org ON p.OrganizationUid = org.OrganizationUid
    INNER JOIN #Orgs ON #Orgs.ID = org.OrganizationUid
    INNER JOIN PprViolations ppr ON av.AssetVersionUid = ppr.AssetVersionUid
WHERE
    pd.PublishingDateRole = @PublishingDateRole
    AND av.ValidUntilUtc IS NULL
    AND ((ppr.ValidationDateUtc BETWEEN @ValidationReportStartDate AND @ValidationReportEndDate)OR ppr.ValidationDateUtc IS NULL)
    
IF OBJECT_ID('tempdb..#ValidMetaData') IS NOT NULL 
    DROP TABLE #ValidMetaData 
CREATE TABLE  #ValidMetaData ( ID int IDENTITY(1,1)
    ,AssetVersionUid uniqueidentifier NOT NULL
    ,ProductUid uniqueidentifier
    ,OrganizationUid uniqueidentifier
    ,Ordinal bigint
    ,ValidFROMUtc datetime
    ,Title nvarchar(max)
    ,[Language] varchar(250)
    ,PublishingDate datetime
    ,OrganizationName nvarchar(256)
    ,retailerUid uniqueidentifier
    ,productFormType int
PRIMARY KEY (AssetVersionUid, ID))

INSERT INTO #ValidMetaData (
    AssetVersionUid 
    ,ProductUid 
    ,OrganizationUid 
    ,Ordinal 
    ,ValidFROMUtc 
    ,Title 
    ,[Language] 
    ,PublishingDate 
    ,OrganizationName 
    ,retailerUid 
    ,productFormType)
SELECT DISTINCT
    av.AssetVersionUid
    ,p.ProductUid
    ,p.OrganizationUid
    ,p.Ordinal
    ,av.ValidFROMUtc
    ,COALESCE(TD.TitleStatement,te.TitleText + ' ' + ISNULL(te.Subtitle,'')) as Title
    ,rLC.LanguageText Language
    ,pd.Value PublishingDate
    ,org.OrganizationName
    ,ao.retailerUid
    ,pf.ProductFormTypeValue productFormType
FROM
    AssetOverride ao
    INNER JOIN Asset a ON ao.AssetUid = a.AssetUid
    INNER JOIN AssetVersion av ON ao.AssetOverrideUid = av.AssetOverrideUid
    INNER JOIN Product p ON a.ProductUid = p.ProductUid
    INNER JOIN Organizations org ON p.OrganizationUid = org.OrganizationUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    LEFT JOIN ProductLanguages pl ON av.AssetVersionUid = pl.AssetVersionUid
    LEFT JOIN refLanguageCode rLC ON pl.ProductLanguageCode = rLC.LanguageCodeId
    INNER JOIN #PublishingDatesPerCountrySet pd ON av.AssetVersionUid = pd.AssetVersionUid
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
WHERE
    a.ResourceContentType = @MetadataResourceContentType
    AND (td.TitleTypeCode is NULL OR td.TitleTypeCode = @TitleTypeCode)
    AND (td.CollectionId is null)
    AND av.ValidUntilUtc IS NULL    
    AND (pd.Value BETWEEN @ReportPublicationDateRangeStart AND @ReportPublicationDateRangeEnd)
            AND (@eISBNs IS NULL or p.Ordinal IN (@eISBNList)) 

IF OBJECT_ID('tempdb..#WholesalePrices') IS NOT NULL 
    DROP TABLE #WholesalePrices
CREATE TABLE #WholesalePrices (
    AssetversionUid uniqueidentifier NOT NULL
   ,WholesalePrice decimal(18,2)
   ,WholesalePriceCurrency int
   ,CountryCodeId int
   ,EffectiveFromDate date
   ,EffectiveToDate date
   ,ID int IDENTITY(1,1)
   PRIMARY KEY (AssetversionUid, CountryCodeID, ID))
INSERT INTO #WholesalePrices (AssetversionUid,WholesalePrice,WholesalePriceCurrency,CountryCodeId, EffectiveFromDate,EffectiveToDate)
SELECT DISTINCT
    m.AssetversionUid
    ,p.Amount WholesalePrice
    ,p.Currency WholesalePriceCurrency
    ,rcc.CountryCodeId
    ,p.EffectiveFromUtc
    ,p.EffectiveToUtc
FROM 
    #ValidMetaData m   
    INNER JOIN TerritorySupplies ts ON m.AssetVersionUid = ts.AssetVersionUid
    INNER JOIN TerritorySupplyDetails tsd ON ts.TerritorySupplyId = tsd.TerritorySupplyId
    INNER JOIN Prices p ON tsd.TerritorySupplyDetailId = p.TerritorySupplyDetailId
    INNER JOIN #CountrySetCountries csc on ts.CountrySetUid = csc.CountrySetUid
    INNER JOIN PprViolations v ON m.AssetVersionUid = v.AssetVersionUid
    INNER JOIN refCountryCode rCC on v.Country = rCC.CountryCodeId AND rCC.CountryCode = csc.country    
WHERE 
    p.PriceType = @WholesalePrice
    AND P.IsTaxIncluded = 0
    AND p.PriceCodeTypeName IS NULL
--SELECT * FROM #WholesalePrices

IF OBJECT_ID('tempdb..#Releasetype') IS NOT NULL 
    DROP TABLE #Releasetype
    
CREATE TABLE #Releasetype (
     AssetversionUid uniqueidentifier NOT NULL
    ,PriceCodeTypeName nvarchar(max)
    ,PriceCode nvarchar(max)
    ,CountryCodeId int
    PRIMARY KEY (AssetversionUid, CountryCodeId))
INSERT INTO #Releasetype (AssetversionUid,PriceCodeTypeName,PriceCode,CountryCodeId)
SELECT DISTINCT
    m.AssetversionUid
    ,p.PriceCodeTypeName
    ,p.PriceCode
    ,rcc.CountryCodeId
FROM 
    #ValidMetaData m   
    INNER JOIN TerritorySupplies ts ON m.AssetVersionUid = ts.AssetVersionUid
    INNER JOIN TerritorySupplyDetails tsd ON ts.TerritorySupplyId = tsd.TerritorySupplyId
    INNER JOIN Prices p ON tsd.TerritorySupplyDetailId = p.TerritorySupplyDetailId
    INNER JOIN #CountrySetCountries csc on ts.CountrySetUid = csc.CountrySetUid
    INNER JOIN refCountryCode rCC on rCC.CountryCode = csc.country  
WHERE 
    p.PriceType = @WholesalePrice 
    AND p.PriceCodeTypeName IS NOT NULL
--SELECT * FROM #Releasetype

IF OBJECT_ID('tempdb..#relatedProducts') IS NOT NULL 
    DROP TABLE #relatedProducts
CREATE TABLE #relatedProducts (
    AssetVersionUid uniqueidentifier NOT NULL,
    RelatedProductUid uniqueidentifier,
    RelatedOrdinal bigint,
    RelatedProductFormType int,
    pBookPublishingDate datetime
    PRIMARY KEY (AssetVersionUid) )
INSERT INTO #relatedProducts (AssetVersionUid, RelatedProductUid, RelatedOrdinal, RelatedProductFormType, pBookPublishingDate)  
SELECT DISTINCT 
    vmd.AssetVersionUid,
    rProduct.ProductUid RelatedProductUid,
    rProduct.Ordinal RelatedOrdinal,
    pf.ProductFormTypeValue RelatedProductFormType,
    pd.Value pBookPublishingDate
FROM
    #ValidMetadata vmd
    INNER JOIN PprViolations pprv ON vmd.AssetVersionUid = pprv.AssetVersionUid
    INNER JOIN ProductRelation pr ON pprv.ProductRelationId = pr.ProductRelationId
    INNER JOIN ProductIdentifier pid ON pr.ProductIdentifierId = pid.ProductIdentifierId
    INNER JOIN Product rProduct ON pid.ProductUid = rProduct.ProductUid
    INNER JOIN Asset a ON rProduct.ProductUid = a.ProductUid
    INNER JOIN AssetOverride ao ON a.AssetUid = ao.AssetUid
    INNER JOIN AssetVersion rProductMetadata ON ao.AssetOverrideUid = rProductMetadata.AssetOverrideUid
    INNER JOIN ProductForms pf ON rProductMetadata.AssetVersionUid = pf.AssetVersionUid
    INNER JOIN PublishingDates pd ON rProductMetadata.AssetVersionUid = pd.AssetVersionUid
WHERE
    a.ResourceContentType = @MetadataResourceContentType
    AND rProductMetadata.ValidUntilUtc IS NULL
    AND pd.PublishingDateRole = @PublishingDateRole


;with Tiers as (
select ROW_NUMBER() OVER (order by CurrencyCodeId, Amount) t,
	Amount as Value,
	CurrencyCodeId as Currency 
	from refPriceTierLookup rp
join refCurrencyCode c on c.CurrencyCode = rp.CurrencyCode)
--select * from Tiers order by Currency
,
Tiers2 as (
	select t1.Currency, t1.Value Low, 
	case when coalesce(t2.Value,'0') = 0 then '999999.99'
	else t2.Value end as High from Tiers t1
	left join Tiers t2
	on t1.t = t2.t -1)
,
Suggestions as (
select p.MaximumPrice, p.EbookCurrency Currency, t2.Currency SuggestedCurrency, t2.Low SuggestedPrice from PprViolations p
join Tiers2 t2
on (p.MaximumPrice &gt; t2.Low)
and (p.MaximumPrice &lt;= t2.High)
and t2.Currency = p.EbookCurrency)

SELECT DISTINCT
    M.OrganizationName      [PublisherName],
    M.Ordinal               [ProductOrdinal],
    M.ProductFormType       [ProductFormType],
    M.Title                 [ProductTitle],
    'iBookstore'            [RetailerName],
    rt.PriceCode            [ReleaseType],
    v.ValidationDateUtc [ViolationDate],
    STUFF(( SELECT ' ' + rCountryC.CountryCode
            FROM PprViolations v2
                INNER JOIN refCountryCode rCountryC     ON v2.Country = rCountryC.CountryCodeId
            WHERE 
                v.AssetVersionUid = v2.AssetVersionUid 
                AND v.BeginDateUtc = v2.BeginDateUtc
                AND ((v.EndDateUtc is null and v2.EndDateUtc is null) or v.EndDateUtc = v2.EndDateUtc)
                and v.ValidationDateUtc = v2.ValidationDateUtc
                AND v.MaximumPrice = v2.MaximumPrice
                AND v.EbookCurrency = v2.EbookCurrency
                AND V.EbookPrice = V2.EbookPrice
            ORDER BY rCountryC.CountryCode
            FOR XML PATH('')),1, 1, '') [Country],
    M.Language              [Language],
    M.PublishingDate        [eBookPubDate],
	s.SuggestedPrice as MaximumPrice,
    wp.WholesalePrice       [WholesalePrice],
    wCC.CurrencyCode        [WholesalePriceCurrency],
    v.EbookPrice            [AgencyPrice],
    eCC.CurrencyCode        [AgencyPriceCurrency],
    rp.pBookPublishingDate  [pPublicationDate],
    rp.RelatedOrdinal       [RelatedProductOrdinal],
    CASE rp.RelatedProductFormType               
        WHEN @Book THEN 'MassMarket'
        WHEN @Hardback THEN 'Hardcover'
        WHEN @PaperbackOrSoftback THEN 'Paperback'
        ELSE CONVERT(VARCHAR(10),rp.RelatedProductFormType) END
                            [RelatedProductFormType],
    v.PbookPrice,
    prcc.CurrencyCode       [PbookCurrency],
    v.BeginDateUtc          [ViolationDateStartUtc],
    v.EndDateUtc            [ViolationDateEndUtc]
FROM
    PprViolations v
    INNER JOIN #ValidMetadata M             ON M.AssetVersionUid = V.AssetVersionUid 
    INNER JOIN #relatedProducts rp          ON M.AssetVersionUid = rp.AssetVersionUid
    LEFT JOIN #Releasetype rt               ON v.AssetVersionUid = rt.AssetVersionUid AND v.Country = rt.CountryCodeId
    INNER JOIN #WholesalePrices wp          ON (wp.AssetVersionUid = v.AssetVersionUid AND wp.CountryCodeId = v.Country)
    INNER JOIN refCurrencyCode eCC          ON v.EbookCurrency = eCC.CurrencyCodeId
    INNER JOIN refCurrencyCode prCC         ON v.PbookCurrency = prCC.CurrencyCodeId
    INNER JOIN refCurrencyCode wCC          ON wp.WholesalePriceCurrency = wCC.CurrencyCodeId
	INNER JOIN Suggestions s				ON s.MaximumPrice = v.MaximumPrice AND s.Currency = v.EbookCurrency
WHERE
    (@wholesaleGTagency = 0 OR (@wholesaleGTagency = 1 AND wp.WholesalePrice &gt; v.EbookPrice))
    AND (
        (NOT EXISTS (
            SELECT 1 
            FROM #WholesalePrices wp2
            WHERE wp2.AssetversionUid = wp.AssetversionUid
                AND wp2.CountryCodeId = wp.CountryCodeId
                AND wp2.EffectiveFromDate &lt;= v.BeginDateUtc
                AND wp2.EffectiveToDate &gt;= v.EndDateUtc)
        AND (wp.EffectiveFromDate IS NULL AND wp.EffectiveToDate IS NULL))
    OR (wp.EffectiveFromDate &lt;= v.BeginDateUtc AND wp.EffectiveToDate &gt;= v.EndDateUtc))
