/* !!!
!!!
NOTE: CHECK THE RECOVERY MODE FOR DBs 
!!!
FROM Marina: 
' You are not supposed to keep UAT databases on full recovery model without running proper backups. UATEventLog.ldf grew to 1TB. It should be a rule to change the recovery model to simple after each refresh or whatever procedure you have.'


!!!!Change DB Owner to sa:

 change db owner to 'sa'. It defaults to your name and it's not good for managing the databases: sp_changedbowner 'sa'
*/

Athena Database sanitizing:

-- AssetProcessor..ImportFolderConfigurations -- host name + automated sweep settings
UPDATE AthenaUATFolderScan..FolderConfigurations set Host = 'localhost', ExternalDropHost = NULL,ExternalDropPath= NULL, ExternalDropUser= NULL, ExternalDropDomain = NULL, ExternalDropPassword=NULL

-- Email settings
UPDATE AthenaUATSecurity..aspnet_Membership set Email = 'thomas@ingrooves.com',LoweredEmail = 'thomas@ingrooves.com',Password = 'N54WCnc0ZkNSGoxDrZf9C3BJiTA=', PasswordSalt = 'GwP0d4Pd3tovgwe2g04C3Q==' where Email != 'nikolay@ingrooves.com'
UPDATE AthenaUATSecurity..EavValueVarchars set Value = 'thomas@ingrooves.com' where Value LIKE '%_@__%.__%'

-- Transporter settings
UPDATE AthenaUATDistribution.TransferServiceItmsEndpoint SET ProviderName = 'testmusicprovider'

-- Transfer notification settings
UPDATE AthenaUATDistribution..TransferServiceEmailEndpoints set [to] ='jon@ingrooves.com,thomas@ingrooves.com,abdul@ingrooves.com'

--update ftp settings
update AthenaUATDistribution.TransferServiceFtpEndpoint set protocoltype = 1
update AthenaUATDistribution.TransferServiceFtpEndpoint set hostname = 'ftp.ingrooves.com'
update AthenaUATDistribution.TransferServiceFtpEndpoint set portnumber = 21
update AthenaUATDistribution.TransferServiceFtpEndpoint set username ='ingroovestest'
update AthenaUATDistribution.TransferServiceFtpEndpoint set password ='ingrooves'
update AthenaUATDistribution.TransferServiceFtpEndpoint set maxretries = 10
update AthenaUATDistribution.TransferServiceFtpEndpoint set passive = 1

--update ftp settings
update fte set StartingDirectory = 'UAT_RetailersTestUploadNewDistro/' + te.SafeName + '/'
from AthenaUATDistribution..TransferServiceFtpEndpoints fte
join transferServiceEndpoints te on te.TransferServiceEndpointUid = fte.TransferServiceEndpointUid

