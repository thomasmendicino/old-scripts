	select distinct
		p.Ordinal ISBN
		, o.OrganizationName Imprint
		, case 
			when etp.EpubTechnicalProtectionType is null then 'DRM-Free'
			when etp.EpubTechnicalProtectionType = 1 then 'DRM-Free'
			when etp.EpubTechnicalProtectionType > 1 then 'DRM-Protected'
			end as 'DRM Status'
		, case 
			when etp.EpubTechnicalProtectionType is null then NULL
			when etp.EpubTechnicalProtectionType = 1 then '00 - None'
			when etp.EpubTechnicalProtectionType = 2 then '01 - DRM'
			when etp.EpubTechnicalProtectionType = 3 then '02 - Digital Watermarking'
			when etp.EpubTechnicalProtectionType = 4 then '03 - Adobe DRM'
			when etp.EpubTechnicalProtectionType = 5 then '04 - Apple DRM'
			when etp.EpubTechnicalProtectionType = 6 then '05 - OMA DRM'
			end as 'DRM Type'		
	from Product p
		join asset a on a.ProductUid = p.ProductUid
		join AssetOverride ao on ao.AssetUid = a.AssetUid
		join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		join organizations o on o.OrganizationUid = p.OrganizationUid
	    left outer join EpubTechnicalProtections etp on etp.AssetVersionUid = av.AssetVersionUid
		join AthenaSecurity..OrgHierarchy('Arcadia publishing Inc.') oh on oh.organizationUId = o.OrganizationUid
		join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
	WHERE av.ValidUntilUtc is NULL
		and a.ResourceContentType = 100
		and pf.ProductFormTypeValue > 47
		