begin tran
use AthenaProductCatalog;
declare @organizationName nvarchar(100)
select @organizationname = 'scholastic inc.'
declare @organizationName1 nvarchar(100)
select @organizationname1 = 'Courier'
declare @organizationName2 nvarchar(100)
select @organizationname2 = 'Island Press'
declare @organizationName3 nvarchar(100)
select @organizationname3 = 'Liquid Silver Books'
declare @organizationName4 nvarchar(100)
select @organizationname4 = 'Harvard'
declare @OrgTable table (organizationUId uniqueidentifier)

;with org as (
select o.organizationName, o.ParentOrganizationUid from athenasecurity..organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from athenasecurity..organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from athenasecurity..organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from athenasecurity..organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @OrgTable (organizationUid)
select organizationUid from child

;with org as (
select o.organizationName, o.ParentOrganizationUid from athenasecurity..organizations o
where organizationname = @organizationName1
union all
select po.organizationname, po.ParentOrganizationUid from athenasecurity..organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from athenasecurity..organizations po
where organizationName = @organizationName1
union all
select o.organizationName, o.organizationUId from athenasecurity..organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @OrgTable (organizationUid)
select organizationUid from child

;with org as (
select o.organizationName, o.ParentOrganizationUid from athenasecurity..organizations o
where organizationname = @organizationName2
union all
select po.organizationname, po.ParentOrganizationUid from athenasecurity..organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from athenasecurity..organizations po
where organizationName = @organizationName2
union all
select o.organizationName, o.organizationUId from athenasecurity..organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @OrgTable (organizationUid)
select organizationUid from child

;with org as (
select o.organizationName, o.ParentOrganizationUid from athenasecurity..organizations o
where organizationname = @organizationName3
union all
select po.organizationname, po.ParentOrganizationUid from athenasecurity..organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from athenasecurity..organizations po
where organizationName = @organizationName3
union all
select o.organizationName, o.organizationUId from athenasecurity..organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @OrgTable (organizationUid)
select organizationUid from child

;with org as (
select o.organizationName, o.ParentOrganizationUid from athenasecurity..organizations o
where organizationname = @organizationName4
union all
select po.organizationname, po.ParentOrganizationUid from athenasecurity..organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from athenasecurity..organizations po
where organizationName = @organizationName4
union all
select o.organizationName, o.organizationUId from athenasecurity..organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @OrgTable (organizationUid)
select organizationUid from child

--select * from @OrgTable ot
--join AthenaSecurity..organizations o on o.organizationUId = ot.organizationUId

select * from AthenaReportCatalog..ReportTypePublishers where publisherUId in (
select p.publisherUid from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaDistribution..publishers p on p.publisherUId = rtp.PublisherUid
except
select p.publisherUid from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join @OrgTable ot on ot.organizationUId = p.OrganizationUid
)

update AthenaReportCatalog..ReportTypePublishers set Enabled = 0 where publisherUId in (
select p.publisherUid from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaDistribution..publishers p on p.publisherUId = rtp.PublisherUid
except
select p.publisherUid from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join @OrgTable ot on ot.organizationUId = p.OrganizationUid
)

select * from AthenaReportCatalog..ReportTypePublishers where publisherUId in (
select p.publisherUid from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaDistribution..publishers p on p.publisherUId = rtp.PublisherUid
except
select p.publisherUid from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join @OrgTable ot on ot.organizationUId = p.OrganizationUid
)

select * from AthenaReportCatalog..ReportTypePublishers where publisherUId in (
select p.publisherUid from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join @OrgTable ot on ot.organizationUId = p.OrganizationUid
)
commit