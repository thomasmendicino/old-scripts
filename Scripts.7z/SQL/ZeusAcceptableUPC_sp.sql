USE [Zeus]
GO
/****** Object:  StoredProcedure [dbo].[return_results_ms]    Script Date: 04/12/2012 16:25:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[return_results_ms]
@Msname nvarchar(50) = ''
AS
BEGIN
select aa.id [Asset Id], at.description [Asset Type], aa.r2isrc [R2ISRC], a.id [Album ID], a.gtin [Album GTIN], s.id [SongId], s.DistributionISRC [DISRC], ms.name [musicService], c.A2 [Country], dr.enumerationName [Distribution Rule], rr.enumerationname [Result], drv.[Timestamp] from distributionruleresultview drv 
inner join ruleresult rr on rr.id = drv.ruleresult 
left outer join musicservice ms on ms.id = drv.musicservice
left outer join album a on a.id = drv.album
left outer join localalbum la on la.album = a.id
left outer join distributionrule dr on dr.id = drv.distributionrule
left outer join country c on c.id = drv.country
left outer join track t on drv.track = t.id
left outer join song s on t.song = s.id
left outer join localtrack lt on lt.track = drv.track
left outer join assets aa on aa.id = drv.asset
left outer join assettype at on at.id = aa.assettype
where ms.name = @msname
order by rr.enumerationname desc, [timestamp] asc
END