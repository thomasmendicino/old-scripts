--begin tran
--commit

/*
--begin tran
--rollback
insert SongCelebrity (Song, Celebrity, Role)
select 2529606, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2529606, 313563, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2529607, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2529607, 295999, 2
insert SongCelebrity (Song, Celebrity, Role)
select 2529607, 300225, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2529608, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2529608, 313564, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2529609, 289050, 1

insert SongCelebrity (Song, Celebrity, Role)
select 2529610, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2529610, 313565, 2
insert SongCelebrity (Song, Celebrity, Role)
select 2529610, 313566, 2
insert SongCelebrity (Song, Celebrity, Role)
select 2529610, 313567, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2529611, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2529611, 313565, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2529612, 289050, 1

insert SongCelebrity (Song, Celebrity, Role)
select 2529613, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2529613, 313568, 2


insert SongCelebrity (Song, Celebrity, Role)
select 2529615, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2529615, 313569, 2
insert SongCelebrity (Song, Celebrity, Role)
select 2529615, 313570, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2529617, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2529617, 313571, 2
insert SongCelebrity (Song, Celebrity, Role)
select 2529617, 313572, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2529616, 289050, 1

insert SongCelebrity (Song, Celebrity, Role)
select 2529618, 289050, 1

insert SongCelebrity (Song, Celebrity, Role)
select 2552039, 289050, 1

insert SongCelebrity (Song, Celebrity, Role)
select 2552040, 289050, 1

insert SongCelebrity (Song, Celebrity, Role)
select 2552041, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2552041, 313564, 2

insert SongCelebrity (Song, Celebrity, Role)
select 2552042, 289050, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2552042, 313564, 2
*/
--begin tran
--rollback
--commit

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529606

update song set Organization = (select top 1 Organization from SongOverrides where Name = 'Amen' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Name = (select top 1 Name from SongOverrides where Name = 'Amen' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Mix = (select top 1 Mix from SongOverrides where Name = 'Amen' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Name = 'Amen' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Name = 'Amen' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Name = 'Amen' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Name = 'Amen' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where (ID = 2529607)

update song set Organization = (select top 1 Organization from SongOverrides where Name = 'Trouble On My Mind' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Name = (select top 1 Name from SongOverrides where Name = 'Trouble On My Mind' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Mix = (select top 1 Mix from SongOverrides where Name = 'Trouble On My Mind' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Name = 'Trouble On My Mind' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Name = 'Trouble On My Mind' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Name = 'Trouble On My Mind' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Name = 'Trouble On My Mind' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where (ID = 2529608)

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529609

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529610

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529611

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529612

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529613

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529615

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529616

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529617

update song set Organization = (select top 1 Organization from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
PLine = (select top 1 PLine from SongOverrides where Mix is NULL and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2529618
--begin tran
--commit
--rollback
update song set Organization = (select top 1 Organization from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Mix = 'Music Video',
Explicit = (select top 1 Explicit from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
CLine = (select top 1 CLine from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where ID = 2552039

update song set Organization = (select top 1 Organization from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Mix = (select top 1 Mix from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
CLine = (select top 1 PLine from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where (ID = 2552040)

update song set Organization = (select top 1 Organization from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Mix = (select top 1 Mix from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
CLine = (select top 1 PLine from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where (ID = 2552041)

update song set Organization = (select top 1 Organization from SongOverrides where Mix = 'Music Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))order by song asc),
Mix = (select top 1 Mix from SongOverrides where Mix = 'Behind The Scenes Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Explicit = (select top 1 Explicit from SongOverrides where Mix = 'Behind The Scenes Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732'))and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Performer = (select top 1 Performer from SongOverrides where Mix = 'Behind The Scenes Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Genre = (select top 1 Genre from SongOverrides where Mix = 'Behind The Scenes Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
CLine = (select top 1 PLine from SongOverrides where Mix = 'Behind The Scenes Video' and Song in (select Song from track where album = (select ID from album where gtin = '00850717002732')) and Country = (select DefaultCountry from Album where gtin = '00850717002732')order by song asc),
Process = 1, MediaPortalIncomplete = 0 where (ID = 2552042)


--begin tran
--rollback
--commit
update track set Fields = ((select top 1 Fields from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')))),
UMGRightTypeCore = ((select top 1 UMGRightTypeCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')))),
UMGLabelCore = ((select top 1 UMGLabelCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')))),
UMGLabelLocal = ((select top 1 UMGLabelLocal from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')))),
DistributionSet = ((select top 1 DistributionSet from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')))),
UMGOwningTerritory = 'US' where album = (select ID from album where gtin = '00850717002732')

--select * from albumoverrides where album = 310749
--select * from albumcelebrity where album = 310749

--begin tran
--commit
declare @gtin nvarchar (14)
declare @AlbumCelebrity int
set @gtin = '00850717002732'
set @AlbumCelebrity = (select Celebrity from AlbumCelebrity where Album = (select id from Album where gtin = '00850717002732') and country = (select defaultcountry from album where gtin = @gtin))
insert AlbumCelebrity (Album, Celebrity, Role)
select (select ID from album where gtin = @gtin), @AlbumCelebrity, (select role from AlbumCelebrity where Album = (select id from album where gtin = @gtin) and country = (select defaultcountry from album where gtin = @gtin))

--insert AlbumGenre (Album, Genre, Sequence)
select (select ID from album where gtin = '00850717002732'), 11, 1

--rollback
--begin tran
--commit
update album set ReleaseDate = (select ReleaseDate from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
Fields = (select Fields from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
Organization = (select Organization from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
CLine = (select CLine from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
PLine = (select PLine from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
SalesStartDate = (select SalesStartDate from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
UMGproducttype = (select umgproducttype from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
UMGlabelcore = (select umglabelcore from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
UMGlabellocal = (select umglabellocal from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
DistributionSet = (select DistributionSet from AlbumOverrides where album = (select id from album where gtin = '00850717002732') and Country = (select DefaultCountry from Album where gtin = '00850717002732')),
process = 1, UMGAccount = 4, UMGOwningTerritory = 'US' where gtin = '00850717002732'


select * from albumcelebrity where album = (select id from album where gtin in ('00850717002732'))
select * from songcelebrity where song in (select song from track where album =(select id from album where gtin in ('00850717002732'))) and country = 34
select * from celebrity where id = 54235
select * from celebrity where id = 252210
select * from albumgenre where album = 310749
select * from albumgenre where album = (select id from album where gtin in ('00850717002732'))
select * from album where gtin = '00044003153264'
select * from albumoverrides where album = 310749
select * from process
select genre, * from song where id in (select song from track where album in (select id from album where gtin in ('00044003153264')))
select * from songoverrides where song in (select song from track where album in (select id from album where gtin in ('00850717002732')))
select * from track where album = (select id from album where gtin = '00850717002732')
select * from trackoverrides where track in (select id from track where album in (select id from album where gtin in ('00850717002732')))
select * from songcelebrity where song in (2475928,
2475929,
2475930) and (country = 248 or country is null)
--begin tran
--commit


select top 100 * from ingrooveslog.dbo.log where message like '%release%'
select * from ingrooveslog.dbo.log where message like '%00850717002732%'

select * from songcelebrity where song in (select song from track where album =(select id from album where gtin = '00850717002732')) and country = 34
select defaultcountry, * from album where gtin = '00850717002732' --34
select * from albumoverrides where album = (select id from album where gtin = '00850717002732') and country = 34
select * from track where album = (select id from album where gtin = '00850717002732')
select * from trackoverrides where track in (select id from track where album = (select id from album where gtin = '00850717002732'))and country = 34
select * from song where id in (select song from track where album =(select id from album where gtin = '00850717002732'))
select * from songoverrides where song in (select song from track where album =(select id from album where gtin = '00850717002732')) and country = 34
select * from songcelebrity where song in (select song from track where album =(select id from album where gtin = '00850717002732')) and country = 34

select * from track where album in (select id from album where gtin in ('00823674473730',
'00823674723927',
'00619061407729',
'00619061241910',
'00619061409020')) and country = (select defaultcountry from album where gtin 

select * from album where gtin = '00823674473730'
select * from track where album = (select id from album where gtin = '00823674473730')
select * from song where id in (select song from track where album = (select id from album where gtin = '00823674473730'))
select * from songoverrides where song in (select song from track where album = (select id from album where gtin = '00823674473730')) and country = (select defaultcountry from album where gtin = '00823674473730')

select * from album where gtin = '00823674723927'
select * from track where album = (select id from album where gtin = '00823674723927')
select * from song where id in (select song from track where album = (select id from album where gtin = '00823674723927'))
select * from songoverrides where song in (select song from track where album = (select id from album where gtin = '00823674723927')) and country = (select defaultcountry from album where gtin = '00823674723927')

select * from album where gtin = '00619061407729'
select * from track where album = (select id from album where gtin = '00619061407729')
select * from song where id in (select song from track where album = (select id from album where gtin = '00619061407729'))
select * from songoverrides where song in (select song from track where album = (select id from album where gtin = '00619061407729')) and country = (select defaultcountry from album where gtin = '00619061407729')

select * from album where gtin = '00823674473730'
select * from track where album = (select id from album where gtin = '00823674473730')
select * from song where id in (select song from track where album = (select id from album where gtin = '00823674473730'))
select * from songoverrides where song in (select song from track where album = (select id from album where gtin = '00823674473730')) and country = (select defaultcountry from album where gtin = '00823674473730')

select * from album where gtin = '00619061241910'
select * from track where album = (select id from album where gtin = '00619061241910')
select * from song where id in (select song from track where album = (select id from album where gtin = '00619061241910'))
select * from songoverrides where song in (select song from track where album = (select id from album where gtin = '00619061241910')) and country = (select defaultcountry from album where gtin = '00619061241910')

select * from album where gtin = '00619061409020'
select * from track where album = (select id from album where gtin = '00619061409020')
select * from song where id in (select song from track where album = (select id from album where gtin = '00619061409020'))
select * from songoverrides where song in (select song from track where album = (select id from album where gtin = '00619061409020')) and country = (select defaultcountry from album where gtin = '00619061409020')


select defaultcountry, * from album where gtin ='00850717002732' --34
select defaultcountry, * from album where gtin = '00850717002732' --248
select * from albumoverrides where album = (select id from album where gtin = '00850717002732') and country = 34
select * from track where album = (select id from album where gtin = '00850717002732')
select * from trackoverrides where track in (select id from track where album = (select id from album where gtin = '00850717002732')) and country =34
select * from song where id in (select song from track where album =(select id from album where gtin = '00850717002732'))
select * from songoverrides where song in (select song from track where album =(select id from album where gtin = '00850717002732')) and country = 34