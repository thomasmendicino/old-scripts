use reportserver;
select SubscriptionId, DataSettings from Subscriptions where DataSettings like '%instor%'

select 'update Subscriptions set DataSettings = ''' + replace(replace(cast(DataSettings as nvarchar(max)),'''',''''''),'instor05','instor05.ingrooves.com') + ''' where SubscriptionId = ' + '''' + cast(SubscriptionId as nvarchar(max)) + '''' from Subscriptions where DataSettings like '%instor%'
--ROLLBACK