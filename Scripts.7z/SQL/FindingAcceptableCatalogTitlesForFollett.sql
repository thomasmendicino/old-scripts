/*

Query to find all titles in the catalog that should be acceptable for distribution to a new retailer, though with less granularity than what the system will perform.
Query takes into consideration asset types, allowed distribution, and contract restrictions.

This query is for Follett. 
1. Follett requires full content for preorders. This means we can restrict allowable titles to those with the right assets.
2. Follett only allows EPUB2R or DOCPDF
*/

use athenaComposite;

declare @RetailerName nvarchar(50)
declare @RetailerUid uniqueidentifier
declare @ContractOwner nvarchar(50)
declare @ContractUid uniqueidentifier
declare @AssetType1 nvarchar(10)
declare @AssetType2 nvarchar(10)
declare @AssetType3 nvarchar(10)
declare @AssetType4 nvarchar(10)
declare @AssetType5 nvarchar(10)
declare @AssetType6 nvarchar(10)
declare @AssetType7 nvarchar(10)
declare @AssetType8 nvarchar(10)
declare @AssetType9 nvarchar(10)
declare @XorgContract nvarchar(50)
declare @XorgRules nvarchar(50)

set @RetailerName = 'Follett'
select @RetailerUid = RetailerUid from Retailers where Name = @RetailerName
set @ContractOwner = 'INscribe Digital'
select @ContractUid = OrganizationUid from Organizations where OrganizationName = @ContractOwner
set @AssetType1 = 'EPUB2R'
set @AssetType2 = 'DOCPDF'
set @AssetType3 = ''
set @AssetType4 = ''
set @AssetType5 = ''
set @AssetType6 = ''
set @AssetType7 = ''
set @AssetType8 = ''
set @AssetType9 = ''

--select * from tmassettype where name in (@assetType1, @AssetType2)


create table #RestrictedOrganizationsByContract (Imprint uniqueidentifier)
--used to remove scholastic imprints
select @XorgContract = p.Name from contracts c
join publishers p on p.publisherUid = c.publisherUid
join retailers r on r.retailerUid = c.retailerUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where r.Name = @RetailerName
and p.Name <> @ContractOwner
and rs.Name = 'General Validation rules'
and c.ValidUntilUtc is NULL

;with child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @XorgContract
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)

insert #RestrictedOrganizationsByContract (Imprint)
select organizationUid from child
--select * from #RestrictedOrganizationsByContract r
--join organizations o on o.OrganizationUid = r.Imprint

create table #RestrictedOrganizationsByRuleSet (Imprint uniqueidentifier)
--includes all publishers that are restricted from distributing to this retailer
;with XorgRules as (
select o.OrganizationName, o.organizationUid from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
join organizations o on o.organizationUid = p.OrganizationUid
where c.ValidUntilUtc is NULL
and r.Name = @RetailerName
and rs.Name = 'Distribution Prohibited'
UNION ALL
select o.OrganizationName, o.organizationUid from organizations o
join XorgRules x on x.organizationUid = o.ParentOrganizationUid)

insert #RestrictedOrganizationsByRuleSet (Imprint)
select distinct organizationUid from XorgRules

--select * from #RestrictedOrganizationsByRuleSet r
--join organizations o on o.OrganizationUid = r.Imprint

create table #TitlesWithAllowedAssets (ISBN bigint, [Owner] uniqueidentifier)

insert #TitlesWithAllowedAssets (ISBN, [Owner])
select distinct p.Ordinal, p.OrganizationUid from product p
inner join asset a on a.productUid = p.ProductUid
inner join TMassetType tat on tat.ID = a.AssetType
where tat.Name in (@assetType1, @AssetType2, @AssetType3, @AssetType4, @AssetType5, @AssetType6, @AssetType7, @AssetType8, @AssetType9)


select distinct p.Ordinal [ISBN], o.OrganizationName [Imprint], po.organizationName [Parent] 
from product p
join organizations o on o.OrganizationUid = p.OrganizationUid
left join organizations po on po.OrganizationUid = o.ParentOrganizationUid
where p.Ordinal in (select Ordinal from #TitlesWithAllowedAssets)
and o.organizationUid not in (select Imprint from #RestrictedOrganizationsByContract)
and o.organizationUid not in (select Imprint from #RestrictedOrganizationsByRuleSet)
order by o.OrganizationName, po.OrganizationName
