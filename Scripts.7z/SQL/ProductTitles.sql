
with ProductTitle as
(
select
Product.ProductUid,
(select top 1 TitleElement.TitleText from
AthenaProductCatalog.dbo.ProductTitles Title
inner join AthenaProductCatalog.dbo.TitleDetails TitleDetail on Title.ProductTitleId = TitleDetail.ProductTitleId
inner join AthenaProductCatalog.dbo.TitleElements TitleElement on TitleDetail.TitleDetailId = TitleElement.TitleDetailId
where
Title.ProductUid = Product.ProductUid
and Title.Country is null
and Title.RetailerUid is null
and TitleElement.TitleText is not null
and Title.ValidUntilUtc is null) Title
from
AthenaProductCatalog.dbo.Product Product)
select Product.Ordinal, ProductTitle.Title, o.OrganizationName from AthenaProductCatalog.dbo.Product Product
inner join ProductTitle on ProductTitle.ProductUid = Product.ProductUid
inner join AthenaSecurity..organizations o on o.organizationUId = product.OrganizationUid