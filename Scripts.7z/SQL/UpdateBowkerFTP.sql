
use athenadistribution

select dc.Name, * from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name like '%bowker%'
and c.ValidUntilUtc is null
order by dc.Name

begin tran
update ftp set HostName = 'ftp.bowker.com', StartingDirectory = '/', UserName = 'ebinscribe', Password = 'BOW!ebook55', Passive = 1
from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is null
and dc.Name = 'Bowker Ftp for INscribe Digital eBook'

update ftp set HostName = 'ftp.bowker.com', StartingDirectory = '/', UserName = 'inscribe', Password = 'BOW!nscribe55', Passive = 1
from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is null
and dc.Name = 'Bowker Ftp for INscribe Digital Metadata and Cover'

update ftp set HostName = 'ftp.bowker.com', StartingDirectory = '/', UserName = 'ebinscribe', Password = 'BOW!ebook55', Passive = 1
from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is null
and dc.Name = 'Bowker Ftp for Scholastic eBook'

update ftp set HostName = 'ftp.bowker.com', StartingDirectory = '/Scholastic', UserName = 'inscribe', Password = 'BOW!nscribe55', Passive = 1
from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is null
and dc.Name = 'Bowker Ftp for Scholastic Metadata and Cover'

select dc.Name, * from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join contracts c on c.ContractUid = dc.ContractUid
where dc.Name like '%bowker%'
and c.ValidUntilUtc is null
order by dc.Name

--commit
--rollback