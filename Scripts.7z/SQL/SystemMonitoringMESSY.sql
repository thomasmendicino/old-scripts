use AthenaAssetProcessor;

select distinct fo.Path, fo.CreatedAtUtc from folderObjects fo
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
where ic.name like '%scholastic%'
and fo.CreatedAtUtc > getutcdate()-1
and pathLevel = 2
and fo.path not like '20141030.1\Scholastic20141029Fixed_xlsx%'

select * from folderobjects where path like '%9780545487849%'


use AthenaDistribution;
select * from transferServiceFtpEndpoints ftp
join transferServiceEndpoints ts on ts.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join DistributionContracts dc on dc.TransferServiceEndpointUid = ts.TransferServiceEndpointUid
join contracts c on c.contractUid = dc.contractUid
where dc.name like '%follett%'
and c.ValidUntilUtc is null

select * from AthenaProductCatalog..product p
join AthenaSecurity..organizations o on o.organizationUid = p.OrganizationUid
where p.ordinal = 9780545208857
select * from AthenaSecurity..organizations where organizationUId = '4FD43933-A501-4026-8F76-28BFFBE54232'

select * from AthenaAssetProcessor..folderobjects fo
join AthenaAssetProcessor..folderobjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
where path like '%9780545666466%'

select * from AthenaProductCatalog..product where ordinal = 9780545754354

select * from AthenaAssetProcessor..folderobjects where path like '%ScholasticApplePartA_xlsx%'
select * from AthenaAssetProcessor..folderobjects where path like '%Scholastic20141029Fixed_xlsx%'
select * from AthenaAssetProcessor..folderobjects where path like '%Scholastic_20141030123449_xml%'

select * from AthenaAssetProcessor..folderobjects fo
join AthenaAssetProcessor..folderobjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
where path like '%Scholastic20141029Fixed_xlsx%'
and fos.Status = 1
except
select * from AthenaAssetProcessor..folderobjects fo
join AthenaAssetProcessor..folderobjectStatus fos on fos.FolderObjectUid = fo.FolderObjectUid
where path like '%Scholastic20141029Fixed_xlsx%'
and fos.Status = 2


select db_name(p.dbid)[Database], p.hostname, p.cmd, t.text, p.loginame, p.program_name, p.spid, p.blocked [BlockingSpid], p.waittime
 , bp.cmd [BlockingCMD], blocked.text [BlockingQuery], bp.loginame [BlockingLogin], bp.program_name [BlockinProgram], bp.waittime [BlockingWaittime]
from sys.sysprocesses p
 cross apply sys.dm_exec_sql_text(p.sql_handle) t
 left join sys.sysprocesses bp on p.blocked=bp.spid
 outer apply sys.dm_exec_sql_text(bp.sql_handle) blocked
order by cast(p.blocked as bit) desc, p.waittime desc



select * from AthenaProductCatalog..product where ordinal = 9780545719308
 order by Ordinal
select * from athenasecurity..Organizations where organizationuid = 'B5E519D9-A058-4748-840A-FAD7E8089E70'


select * from distributionOrders where DistributionOrderUid = '0d473c1a-0efe-42ce-b478-686772440b44'
select * from ProductRevisions where ProductRevisionUid = '0373513F-8203-458F-B99E-7E29E5A6F9C9'
select * from AthenaProductCatalog..product where ProductUid = 'C480117E-DD95-400F-B631-7927C67986B2'


select distinct 'select * from athenaassetprocessor..folderobjects where path like ' + '''' + '%' + cast(ordinal as nvarchar(14)) + '%''' /*, dateadd(hh,-7,do.CreatedAtUtc) CreatedAt */from distributionOrders do
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join athenaproductcatalog..product p on p.productUid = pr.ProductUid
join contracts c on c.contractUid = pr.ContractUid
join publishers pu on pu.publisherUid = c.PublisherUid
where 
 do.CreatedAtUtc > getUTCdate()-2
and pu.Name = 'Scholastic Inc.'
--order by do.CreatedAtUtc desc

select * from athenaassetprocessor..folderobjects where path like '%9780439023122%'

select * from contracts c
join publishers p on p.PublisherUid = c.PublisherUid
join Retailers r on r.RetailerUid = c.RetailerUid
where c.contractUid = '1D21B5A0-5111-4F9D-8A8A-4C0827F59B30'


--created = 23105
--23255 --23282 
--not acceptable = 18010
--18229
--other = 9818
--10011

use athenadistribution;
select distinct ordinal, dateadd(hh,-7,do.CreatedAtUtc) CreatedAt, do.DistributionOrderUid, r.Name/*, fo.Path, dos.*/ from distributionOrders do
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join athenaproductcatalog..product p on p.productUid = pr.ProductUid
join contracts c on c.contractUid = pr.ContractUid
join publishers pu on pu.publisherUid = c.PublisherUid
join retailers r on r.retailerUid = c.retailerUId
join AthenaAssetProcessor..FolderObjectEBookProductProcessingResults fpr on fpr.ProductUid = p.ProductUid
join AthenaAssetProcessor..folderobjects fo on fo.FolderObjectUid = fpr.FolderObjectUid
where 
 do.CreatedAtUtc > getUTCdate()-2
 and dos.ResultingEvent = 103
and pu.Name = 'Scholastic Inc.'
and fo.path like '20141030.5%'
order by CreatedAt desc

select ordinal, dateadd(hh,-7,do.CreatedAtUtc) CreatedAt, dos.* from distributionOrders do
--select r.Name, count(*) from DistributionOrders do
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join athenaproductcatalog..product p on p.productUid = pr.ProductUid
join contracts c on c.contractUid = pr.ContractUid
join publishers pu on pu.publisherUid = c.PublisherUid
join retailers r on r.retailerUid = c.retailerUId
where 
 do.CreatedAtUtc > getUTCdate()-2
 and dos.ResultingEvent = 104
--and pu.Name = 'Scholastic Inc.'
--group by r.Name
order by do.CreatedAtUtc desc

select ordinal, dateadd(hh,-7,do.CreatedAtUtc) CreatedAt, dos.* from distributionOrders do
--select r.Name, count(*) from DistributionOrders do
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join athenaproductcatalog..product p on p.productUid = pr.ProductUid
join contracts c on c.contractUid = pr.ContractUid
join publishers pu on pu.publisherUid = c.PublisherUid
join retailers r on r.retailerUid = c.retailerUId
where 
 do.CreatedAtUtc > getUTCdate()-2
 and dos.ResultingEvent not in (103,104)
--and pu.Name = 'Scholastic Inc.'
--group by r.Name
order by do.CreatedAtUtc desc

select top 5 * from AthenaEventLog..refeventType where EventTypeId = 103



select /*row_number() OVER (order by count(*)desc),*/ r.Name retailer, count(*) OrdersCreated from DistributionOrders do
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join athenaproductcatalog..product p on p.productUid = pr.ProductUid
join contracts c on c.contractUid = pr.ContractUid
join publishers pu on pu.publisherUid = c.PublisherUid
join retailers r on r.retailerUid = c.retailerUId
join AthenaAssetProcessor..FolderObjectEBookProductProcessingResults fpr on fpr.ProductUid = p.ProductUid
join AthenaAssetProcessor..folderobjects fo on fo.FolderObjectUid = fpr.FolderObjectUid
where 
 do.CreatedAtUtc > getUTCdate()-1
 and dos.ResultingEvent = 103
and pu.Name = 'Scholastic Inc.'
and fo.path like '20141030.5%'
group by r.name
order by OrdersCreated desc

select * from AthenaAssetProcessor..FileNameAssetTypes fn
join AthenaAssetProcessor..FolderProcessors fp on fp.FolderProcessorId = fn.FolderProcessorId
join AthenaAssetProcessor..FolderProcessorContracts fpc on fpc.FolderProcessorId = fp.FolderProcessorId
join AthenaDistribution..publishers p on p.publisherUid = fpc.PublisherUid
where p.name = 'scholastic inc.' and FileExtension like '%epub3%'

select * from AthenaAssetProcessor..FolderProcessorContracts
select * from AthenaAssetProcessor..FileNameAssetTypes

with cte as
(SELECT
   ROW_NUMBER() OVER (PARTITION BY table.name ORDER BY id) row,
   name,
   score
 FROM table)
SELECT 
   a.name ,
   a.score - ISNULL(b.score,0)
FROM
   cte a
   LEFT  JOIN cte b
   on a.name = b.name
    and a.row = b.row+1

with Orders as (select distinct p.Ordinal, r.Name, do.CreatedAtUtc from DistributionOrders do
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join athenaproductcatalog..product p on p.productUid = pr.ProductUid
join contracts c on c.contractUid = pr.ContractUid
join publishers pu on pu.publisherUid = c.PublisherUid
join retailers r on r.retailerUid = c.retailerUId
join AthenaAssetProcessor..FolderObjectEBookProductProcessingResults fpr on fpr.ProductUid = p.ProductUid
join AthenaAssetProcessor..folderobjects fo on fo.FolderObjectUid = fpr.FolderObjectUid
where 
do.CreatedAtUtc > '2015-01-28 01:00:00.000'
and dos.ResultingEvent = 103
--and pu.Name = 'Scholastic Inc.'
--and fo.path like '20141030.5%'
--and r.code = 'BIS'
),
cte as (
SELECT
   ROW_NUMBER() OVER (PARTITION BY Orders.name ORDER BY CreatedAtUtc) row,
   Ordinal,
   Name,
   CreatedAtUtc
 FROM Orders),
 results as(
SELECT 
   a.name ,
   a.CreatedAtUtc CreatedAt1,
   b.CreatedAtUtc CreatedAt2,
   a.Ordinal, 
   datediff(s,b.CreatedAtUtc, a.CreatedAtUtc) TimeBetween
   --a.CreatedAtUtc - ISNULL(b.CreatedAtUtc,0)
FROM
   cte a
   LEFT  JOIN cte b
   on a.name = b.name
    and a.row = b.row+1
),
averaged as (
select avg(TimeBetween) average, a.Name from results a
group by a.Name)
select a.Name, a.CreatedAt1, a.CreatedAt2, a.Ordinal, a.TimeBetween, b.average
from results a
join averaged b on b.Name = a.Name



declare @pacifictime int
select @pacifictime = datediff(hh,getUTCdate(),getdate())
select distinct p.Ordinal, r.Name, dateadd(hh,@pacifictime, do.CreatedAtUtc) CreatedAt from DistributionOrders do
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join athenaproductcatalog..product p on p.productUid = pr.ProductUid
join contracts c on c.contractUid = pr.ContractUid
join publishers pu on pu.publisherUid = c.PublisherUid
join retailers r on r.retailerUid = c.retailerUId
join AthenaAssetProcessor..FolderObjectEBookProductProcessingResults fpr on fpr.ProductUid = p.ProductUid
join AthenaAssetProcessor..folderobjects fo on fo.FolderObjectUid = fpr.FolderObjectUid
where 
do.CreatedAtUtc > '2014-10-31 14:00:00.000'
and dos.ResultingEvent = 103
and pu.Name = 'Scholastic Inc.'
and fo.path like '20141030.5%'
--and r.code = 'BIS'
order by CreatedAt desc


declare @pacifictime int
select @pacifictime = datediff(hh,getUTCdate(),getdate())
select top 50 dateadd(hh,@pacifictime, bs.ProcessedAtUtc) ProcessedAt, ret.Name, * from batches b
join BatchStatus bs on bs.BatchUid = b.BatchUid
join AthenaEventLog..refEventType ret on ret.EventTypeId = bs.ResultingEvent
order by bs.CreatedAtUtc desc







select db_name(p.dbid)[Database], p.hostname, p.cmd, t.text, p.loginame, p.program_name, p.spid, p.blocked [BlockingSpid], p.waittime
 , bp.cmd [BlockingCMD], blocked.text [BlockingQuery], bp.loginame [BlockingLogin], bp.program_name [BlockinProgram], bp.waittime [BlockingWaittime]
from sys.sysprocesses p
 cross apply sys.dm_exec_sql_text(p.sql_handle) t
 left join sys.sysprocesses bp on p.blocked=bp.spid
 outer apply sys.dm_exec_sql_text(bp.sql_handle) blocked
order by cast(p.blocked as bit) desc, p.waittime desc, p.spid


USE AthenaProductCatalog;
GO
select top 1000 * from __MigrationHistory

select * from AthenaAssetProcessor..ImportFolderConfigurations where ImportFolderConfigurationUid= 'B5357F3C-1EA5-4D03-BC22-EF6E00D9935B'

--insert importFolderConfigurationLocks

select * from AthenaAssetProcessor..importfolderconfigurationlocks

