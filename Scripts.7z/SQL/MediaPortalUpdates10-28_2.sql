/*

select defaultcountry, * from album where gtin = '00044003153837' --248
select * from albumoverrides where album = (select id from album where gtin = '00044003153837')
select * from track where album = (select id from album where gtin = '00044003153837')
select * from trackoverrides where track in (select id from track where album = (select id from album where gtin = '00044003153837'))
select * from song where id in (select song from track where album =(select id from album where gtin = '00044003153837'))
select * from songoverrides where song in (select song from track where album =(select id from album where gtin = '00044003153837'))
--begin tran
--rollback  
--commit
*/

-----ONLY works if ALL songs have SAME information for DEFAULT country in overrides table
if exists (select NULL from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837'))
begin

if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridemasterusedownload = 1)
begin
update song set masterusedownload = (select masterusedownload from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridemasterusestreaming = 1) 
begin
update song set masterusestreaming = (select masterusestreaming from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837'))  where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridemasteruseburn = 1)
begin
update song set masteruseburn = (select masteruseburn from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837'))  where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridemasteruseportable = 1)
begin
update song set masteruseportable = (select masteruseportable from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridemasteruselimited = 1)
begin
update song set masteruselimited = (select masteruselimited from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridepayee = 1)
begin
update song set organization = (select organization from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridename = 1)
begin
update song set name = (select name from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridemix = 1)
begin
update song set mix = (select mix from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideexplicit = 1)
begin
update song set explicit = (select explicit from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
update song set explicitedited = (select explicitedited from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideperformer = 1)
begin
update song set performer = (select performer from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridegenre = 1)
begin
update song set genre = (select genre from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideCline = 1)
begin
update song set CLine = (select CLine from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridePLine = 1)
begin
update song set PLine = (select PLine from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
if exists (select null from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideDistributionISRC = 1)
begin
update song set DistributionISRC = (select DistributionISRC from songoverrides where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where id in (select song from track where album = (select id from album where gtin = '00044003153837'))
end
end
update song set MediaPortalIncomplete = 0 where id in (select song from track where album = (select id from album where gtin = '00044003153837'))


if exists (select null from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837'))
begin
insert songcelebrity(song, celebrity, Role, Updated)
 select 2545561, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
insert songcelebrity(song, celebrity, Role, Updated)
 select 2545562,(select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545563,(select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545564,(select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545565,(select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545566, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545567, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545568, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545569, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545570, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545571, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545572, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545573, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0
 insert songcelebrity(song, celebrity, Role, Updated)
 select 2545574, (select celebrity from songcelebrity where song = (select top 1 song from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')),1,0

end

if exists (select null from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideAlbumOnly = 1)
begin
update track set AlbumOnly = (select AlbumOnly from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where album = (select id from album where gtin = '00044003153837')
end
if exists (select null from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideLinerNotes = 1)
begin
update track set LinerNotes = (select LinerNotes from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where album = (select id from album where gtin = '00044003153837')
end
if exists (select null from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideTermsNotes = 1)
begin
update track set TermsNotes = (select TermsNotes from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where album = (select id from album where gtin = '00044003153837')
end
if exists (select null from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideDistributionSet = 1)
begin
update track set DistributionSet = (select DistributionSet from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where album = (select id from album where gtin = '00044003153837')
end
if exists (select null from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overridePreorderOnly = 1)
begin
update track set PreOrderOnly = (select PreOrderOnly from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where album = (select id from album where gtin = '00044003153837')
end
if exists (select null from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideUserRingtone = 1)
begin
update track set UserRingtone = (select UserRingtone from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where album = (select id from album where gtin = '00044003153837')
end
if exists (select null from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideUMGRightTypeCore = 1)
begin
update track set UMGRightTypeCore = (select UMGRightTypeCore from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where album = (select id from album where gtin = '00044003153837')
end
if exists (select null from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideUMGLabelCore = 1)
begin
update track set UMGLabelCore = (select UMGLabelCore from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where album = (select id from album where gtin = '00044003153837')
end
if exists (select null from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837') and overrideUMGLabelLocal = 1)
begin
update track set UMGLabelLocal = (select UMGLabelLocal from trackoverrides where track = (select top 1 ID from track where album = (select id from album where gtin = '00044003153837')) and country = (select defaultcountry from album where gtin = '00044003153837')) where album = (select id from album where gtin = '00044003153837')
end


if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideReleaseDate = 1)
begin
update album set ReleaseDate = (select ReleaseDate from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideAlbumOnly = 1)
begin
update album set AlbumOnly = (select AlbumOnly from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideAlbumAsset = 1)
begin
update album set CoverArt = (select CoverArt from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
/*if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideOwner = 1)
begin
update album set Organization = (select Organization from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end*/
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideName = 1)
begin
update album set Name = (select Name from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideMix = 1)
begin
update album set Mix = (select Mix from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideLinerNotes = 1)
begin
update album set LinerNotes = (select LinerNotes from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideCLine = 1)
begin
update album set CLine = (select CLine from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overridePLine = 1)
begin
update album set PLine = (select PLine from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
/*if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overridePerformer = 1)
begin
update album set CelebrityPerformer = (select CelebrityPerformer from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end*/
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideSalesStartDate = 1)
begin
update album set SalesStartDate = (select SalesStartDate from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overridePreorderStartDate = 1)
begin
update album set PreorderStartDate = (select PreorderStartDate from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overridePreorderPreviews = 1)
begin
update album set PreorderPreviews = (select PreorderPreviews from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideUMGProductType = 1)
begin
update album set UMGProductType = (select UMGProductType from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideUMGLabelCore = 1)
begin
update album set UMGLabelCore = (select UMGLabelCore from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideUMGLabelLocal = 1)
begin
update album set UMGLabelLocal = (select UMGLabelLocal from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end
if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideDistributionSet = 1)
begin
update album set DistributionSet = (select DistributionSet from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')) where gtin = '00044003153837'
end

if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overrideAlbumGenre = 1)
begin
insert AlbumGenre (Album, Genre, Sequence)
select (select ID from album where gtin = '00044003153837'), (select genre from albumgenre where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')), 1
end

if exists (select null from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837') and overridePerformer = 1)
begin
insert AlbumCelebrity (Album, Celebrity, Role)
select (select ID from album where gtin = '00044003153837'), (select CelebrityPerformer from albumoverrides where album = (select id from album where gtin = '00044003153837') and country = (select defaultcountry from album where gtin = '00044003153837')), 1
end


/*

select defaultcountry, * from album where gtin in ('00044003153837',
'00850717002442',
'00850717002732',
'00044003150621',
'00044003150676',
'00850717002657',
'00044003153264',
'00850717001834')
*/