--BEGIN TRAN
--ROLLBACK
--COMMIT
DECLARE @TrendFileConfigurationName NVARCHAR(200)
DECLARE @CSVFileType INT
SET @TrendFileConfigurationName = 'Amazon eBookBase Daily US'
SELECT
	@CSVFileType = [ID]
	FROM [FileType]
	WHERE [Name] = 'CSV'

--Update header names and mappings
UPDATE [TrendFileHeader]
	SET	[Column] = 'ASIN',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 1
UPDATE [TrendFileHeader]
	SET	[Column] = 'ASIN name',
		[Map] = 'Album'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 2
UPDATE [TrendFileHeader]
	SET	[Column] = 'ID type',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 3
UPDATE [TrendFileHeader]
	SET	[Column] = 'External ID',
		[Map] = 'GTIN'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 4
UPDATE [TrendFileHeader]
	SET	[Column] = 'Product group',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 5
UPDATE [TrendFileHeader]
	SET	[Column] = 'Release date',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 6
UPDATE [TrendFileHeader]
	SET	[Column] = 'Customer orders',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 7
UPDATE [TrendFileHeader]
	SET	[Column] = 'Units shipped',
		[Map] = 'Quantity'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 8
UPDATE [TrendFileHeader]
	SET	[Column] = 'Shipped COGS',
		[Map] = 'Revenue'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 9
UPDATE [TrendFileHeader]
	SET	[Column] = 'Units returned by customers',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 10
UPDATE [TrendFileHeader]
	SET	[Column] = 'Category',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 11
UPDATE [TrendFileHeader]
	SET	[Column] = 'Subcategory',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 12
UPDATE [TrendFileHeader]
	SET	[Column] = 'Author/artist/actor',
		[Map] = 'Artist'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 13

--Update FileType to CSV. Amazon now supplies comma-separated as opposed to tab-separated csv files.
UPDATE [TrendFileConfiguration]
	SET [FileType] = @CSVFileType
	FROM [TrendFileConfiguration]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName

--Delete extra headers that are no longer supplied in Amazon trend files.
IF EXISTS (SELECT 1
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] > 13)
DELETE [TrendFileHeader]
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] > 13
        
--Update TrendFileConfiguration HeaderSize, as the new statements skip the first 7 rows.
UPDATE [TrendFileConfiguration]
    SET [HeaderSize] = 7
    WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName