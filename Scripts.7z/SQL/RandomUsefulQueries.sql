
Create Database Ingrooves_20110507_1330  on 
(NAME = Ingrooves_Data, FILENAME = 'C:\DB Snapshot\INgrooves_data_20110507_1530.ss'),
(NAME = Primary_file2, FILENAME = 'C:\DB Snapshot\INgrooves_primary2_20110507_1530.ss'),
(NAME = Primary_file3, FILENAME = 'C:\DB Snapshot\INgrooves_primary3_20110507_1530.ss'),
(NAME = IndexGroup_file1, FILENAME = 'C:\DB Snapshot\INgrooves_index1_20110507_1530.ss'), 
(NAME = IndexGroup_file2, FILENAME = 'C:\DB Snapshot\INgrooves_index2_20110507_1530.ss'), 
(NAME = IndexGroup_file3, FILENAME = 'C:\DB Snapshot\INgrooves_index3_20110507_1530.ss'),
(NAME = CacheGRoup_file1, FILENAME = 'C:\DB Snapshot\INgrooves_cache1_20110507_1530.ss'), 
(NAME = CacheGRoup_file2, FILENAME = 'C:\DB Snapshot\INgrooves_cache2_20110507_1530.ss'), 
(NAME = CacheGRoup_file3, FILENAME = 'C:\DB Snapshot\INgrooves_cache3_20110507_1530.ss') 
as snapshot of INgrooves
GO


select * from pricecampaign pc
inner join track t on pc.track = t.id
inner join song s on t.song = s.id
where s.isrc in ('USA2P1132773','USA2P1132774','USA2P1132775')

select * from pricecampaign
where album = 182494
where track in (1222008,
1222009,
1222010)


productmonitor = component upc
select * from pricetiermapping
where pricetiermappingtype = 10

select * from pricetiermappingtype


select * albummultidiscmapping disc 1 = upc1, disc2 = upc2

package upc = album 
select * from 1 album tracks

and also, that UPCs can be encoded more than once (which I think was the inconsistency with billingproductencodingconfiguration) so th

1 comp upc in dist monitor
that upc points to 14 tracks


disc not stored correctly in autosync
10 tracks on component upc for disc 2

602517812307  package upc into tracks

missing productmonitor, distributionmonitor should key package upc

find on album, and on multidiscalbummapping, you have a multidisc mapping

cUPC and track number



BusinessPartnerName
musicservice.id joined to syndication.musicservice

DAVeOrderBatchID
syndicationorder.orderbatchid

HALID
syndicationorder.id

OrderDateTime
syndicationorder.submissiondate?


DeliveryDateTime

CloseDateTime
select s.syndicationlevel, so.* from syndicationorder so
left join syndication s on so.syndication = s.id
order by submissiondate desc


insert into daveusercontext (indmauser, active, usercontext, systemid, deliverydeletionday, deliveryaccesseddays, deliveryemaildays,vendorcontactid, encodecap, email)
values (3961, 1, 'US_177', 'uat_umg.umusic.com', 30,30,10,1821,50000, 'thomas@ingrooves.com')



select * from pricetier
where id in (select pricetier from pricetiermapping
where pricetiermappingtype = 10)
or id = 11



                           select * from encodingprofile
                           --where audiobitrate = '320000'
                           --where id in (200,208,205)
                           where id = 3
                           --flac,aac,mp4
                           
                           select * from encoder
                           where id in (5)
                           --5,11
                           
                           select * from encodingconfiguration
                           where --encodingprofile = 200
                           id in (45,41,61)
                            umgownedformatcode = 10016
                           or umgownedformatcode = 67
                           or umgownedformatcode = 66
                           
select * from syndication s
inner join syndicationorder so on s.id = so.syndication
where s.transferredat >= '2011-05-01'
and so.audiotrackcount >= 1
and s.syndicatedat >= '2011-05-01'

select * from billingreaplog

use ingrooves
select * from syndicationordereventlog
where syndicationorder = 3622
select * from syndicationorder
where id = 3622
/*

select * from syndicationorder
where orderbatchid = 1000000886181

select * from syndication
where id = 115160




where id = 115404
DELETE BillingProductEncodingConfiguration
DELETE BillingProduct
DELETE BillingReport
DELETE FROM BillingReapLog
WHERE ID > 1

select sum(bytesize) from billingproduct
where billingreport = 141

select distinct so.id SyndOrder, so.orderid, so.orderbatchid, so.linkedbatchid, so.partnerid, so.submissiondate, so.syndication, s.syndicationlevel, so.packagecount, so.audiotrackcount, so.audioencodecount, s.transferredat, sos.name orderstate, soel.at EventTime from syndicationorder so
inner join syndication s on so.syndication = s.id
inner join syndicationordereventlog soel on so.id = soel.syndicationorder
inner join syndicationorderstate sos on soel.orderstate = sos.id
where soel.orderstate in (10,11,12,13,6,7)
and so.id in (2919,2920,2953,2984,3061,3190)
and so.audioencodecount > 0


SElect * From
SyndicationOrder INNER JOIN (BillingReport
INNER JOIN (BillingProduct
INNER JOIN BillingProductEncodingConfiguration
ON BillingProduct.ID=BillingProductEncodingConfiguration.BillingProduct)
ON BillingReport.ID=BillingProduct.BillingReport)
ON SyndicationOrder.Syndication=BillingReport.Syndication
WHERE SyndicationOrder.ID=2919
order by BillingProductEncodingConfiguration.id

select * from syndication
where transferredat > '2011-05-09 11:01:06.077'

                           
SELECT Syndication.ID AS Syndication,
                                  DistributionMonitor.StartedAt AS DistributionStartedAt
                           FROM ([Syndication]
                             INNER JOIN ([SyndicationOrder]
                             INNER JOIN [DistributionMonitor]
                              ON SyndicationOrder.ID=DistributionMonitor.SyndicationOrder)
                              ON Syndication.ID=SyndicationOrder.Syndication)
                           WHERE Syndication.TransferredAt>'2011-05-09 11:01:06.077'
*/

--Find TOTALBYTES per HAL Business Partner Summary
select sum(bp.bytesize) from billingproduct bp
inner join billingreport br on bp.billingreport = br.id
inner join syndicationorder so on br.syndication = so.syndication
where so.id in (select so.id from syndicationorder so
inner join syndication s on so.syndication = s.id
where so.partnerid = 330
and s.transferredat > '2011-05-01'
and so.audioencodecount > 0)

--Find TOTALBYTES per HAL Billing Order
select sum(bp.bytesize) from billingproduct bp
inner join billingreport br on bp.billingreport = br.id
inner join syndicationorder so on br.syndication = so.syndication
where so.id = 3076

--Find Bytes per order detail
select bp.bytesize, bp.* from billingproduct bp
inner join billingreport br on bp.billingreport = br.id
inner join syndicationorder so on br.syndication = so.syndication
where so.id = 3076


select distinct so.id SyndOrder, so.orderid, so.orderbatchid, so.partnername, so.linkedbatchid, so.partnerid, so.submissiondate, so.syndication, s.syndicationlevel, so.packagecount, so.audiotrackcount, so.audioencodecount, so.coverartcount, s.transferredat, sos.name orderstate, soel.at EventTime, so.vidcvrartcount, so.epacketcount, so.ipacketcount, so.pubphotocount, so.wallpapercount, so.vididximgcount, so.metadatacount from syndicationorder so
inner join syndication s on so.syndication = s.id
inner join syndicationordereventlog soel on so.id = soel.syndicationorder
inner join syndicationorderstate sos on soel.orderstate = sos.id
where soel.orderstate in (11,12,13,6)
and soel.at >= '2011-05-01'
--and so.id in (2919,2920,2953,2984,3061,3190)
and so.audioencodecount > 0
and s.transferredat is not null

select * from syndicationorder
where orderid = 1000000700030
select * from syndication
where id = 110005


select * from BillingProductEncodingConfiguration
where billingproduct in (select id from billingproduct where billingreport = 12)
order by billingproduct

select * from encodingconfigurationmonitor ecm
inner join productmonitor pm on ecm.productmonitor = pm.id
inner join distributionmonitor dm on pm.distributionmonitor = dm.id
inner join encodingmonitor em on pm.id = em.productmonitor
inner join syndicationorder so on so.syndication = dm.syndication
where so.id = 2920
order by pm.completedat desc

select pm.* from distributionmonitor dm 
inner join productmonitor pm on dm.id = pm.distributionmonitor
where dm.id = 2864

select * from productmonitor
where id = 69465
where product is null
and completedat is not null

select * from encodingmonitor em
inner join
productmonitor pm on em.productmonitor = pm.id
inner join
distributionmonitor dm on pm.distributionmonitor = dm.id
inner join
syndication s on dm.syndication = s.id
inner join syndicationorder so
on s.id = so.syndication
where em.bytesize is null
and em.completedat > '2011-05-01'
and s.transferredat is not null
--and productmonitor in (select id from productmonitor where 

select syndication from distributionmonitor
where id in (3622)

select * from syndication
where id in (115481)select syndication from distributionmonitor
where id in (3725,3724,3580,3565,3561,3560,3559,3557,3555,3081))

select * from syndicationorder
where syndication in (select syndication from distributionmonitor
where id in (3725,3724,3580,3565,3561,3560,3559,3557,3555,3081))

select * from syndicationorder
where orderbatchid = 1000000886181

select * from distributionmonitor
where syndication = 115160

select * from productmonitor
where distributionmonitor = 2870

select * from encodingmonitor
where productmonitor = 52819

select * from billingproduct
where billingreport = 863

select * from billingreport
where syndication = 115160
/*
select * from TrackSyndication where Syndication=115911

select * from Track where ID in (1949510,654175)

select * from Song where Song.ID=708675
*/

select * from syndicationorder
where id = 3666

select * from TrackSyndication where Syndication=115160
select * from Track where ID in (1535580,1535581)
select * from song where id in (1553762,1553763)

select * from syndicationordereventlog
where syndicationorder = 2930

select * from 