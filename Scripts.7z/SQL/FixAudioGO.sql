--BEGIN TRAN

DECLARE @OldAudioGoPub uniqueidentifier
DECLARE @BlackstoneAudioInc uniqueidentifier
DECLARE @AudioGO uniqueIdentifier

SELECT @OldAudioGoPub = PublisherUid 
FROM AthenaDistribution..Publishers 
WHERE OrganizationUid = '00000000-0000-0000-0000-000000000000'

SELECT @BlackstoneAudioInc = OrganizationUid
FROM AthenaSecurity..Organizations
WHERE OrganizationName = 'Blackstone Audio, Inc.'

SELECT @AudioGO = OrganizationUid
FROM AthenaSecurity..Organizations
WHERE OrganizationName = 'AudioGO'

DELETE 
FROM AthenaDistribution..Contracts
WHERE PublisherUid = @OldAudioGoPub

DELETE 
FROM AthenaDistribution..Publishers 
WHERE PublisherUid = @OldAudioGoPub

UPDATE o
SET ParentOrganizationUid = @BlackstoneAudioInc
FROM AthenaSecurity..Organizations o
WHERE o.OrganizationUid = @AudioGO

--ROLLBACK
--COMMIT