
select rc.Name ContentType, tat.AssetTypeText AssetType, p.Ordinal ISBN, 
av.AssetVersionUid,
case 
when len(r.Length) between 4 and 6 then cast(cast(r.Length / 1024.00 as decimal(18,2)) as nvarchar(max)) + ' KB'
when len(r.Length) between 7 and 9 then cast(cast(r.Length / (1024.00 * 1024) as decimal(18,2)) as nvarchar(max)) + ' MB'
when len(r.Length) between 10 and 12 then cast(cast(r.Length / (1024.00 * 1024 * 1024) as decimal(18,2)) as nvarchar(max)) + ' GB'
else cast(cast(r.Length as decimal(18,2)) as nvarchar(max)) + ' B'
end as FileSize, 
cast(cast(r.Length / 1024.00 as decimal(18,2)) as nvarchar(max)) as SizeInKB,
cast(cast(r.Length / (1024.00 * 1024) as decimal(18,2)) as nvarchar(max)) as SizeInMB,
r.Length as SizeInBytes, r.Path, 
case when ao.RetailerUid is NULL then 'N'
else 'Y' end as RetailerSpecificAsset,
isnull(ret.Name ,'') as Retailer from product p
join asset a on a.ProductUid = p.ProductUid
join assetOverride ao on ao.assetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join resources r on r.resourceUid = av.ResourceUid
join refassetType tat on tat.AssetTypeId = a.AssetType
join @Disney d on d.orgUid = p.OrganizationUid
join TMResourceContentType rc on rc.ResourceContentType = a.ResourceContentType
left join retailers ret on ret.RetailerUid = ao.RetailerUid
where av.ValidUntilUtc is NULL
and rc.Name in ('FullContent','SampleContent')
and (tat.AssetTypeText like '%EPUB%' or tat.AssetTypeText like '%EPIB%')
order by ordinal, rc.Name