use ingrooves;
with ebookPrices as
(
select GTIN, pmv.AlbumPrice, pc.Country as Territory, 1 as [Rank], pc.ID from Album a
join albumProductType apt on apt.album = a.id 
join productType prt on prt.id = apt.productType
join priceCampaign pc on pc.album = a.ID
join PriceTier pt on pt.id = pc.StartPriceTier
join PriceTierMappingView pmv on pmv.PriceTier = pt.ID
join country c on c.id = pc.Country
where prt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and pmv.Currency = 1
and pt.DescriptionKey like '%ebook_price_tier%'
and pc.country = 250
and pc.MusicService is NULL
and pc.EndDate is NULL
UNION
select GTIN, pmv.AlbumPrice, pc.Country as Territory, 2 as [Rank], pc.ID from Album a
join albumProductType apt on apt.album = a.id 
join productType prt on prt.id = apt.productType
join priceCampaign pc on pc.album = a.ID
join PriceTier pt on pt.id = pc.StartPriceTier
join PriceTierMappingView pmv on pmv.PriceTier = pt.ID
where prt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and pmv.Currency = 1
and pt.DescriptionKey like '%ebook_price_tier%'
and pc.country is NULL
and pc.MusicService is NULL
and pc.EndDate is NULL
), 
RankedEbookPrices as (
select GTIN, min([Rank]) [Rank], min(ID) PriceCampaign from ebookPrices
group by GTIN),
SingleEbookPrice as (
select e.GTIN, AlbumPrice, isnull(cast(c.A2 as nvarchar(5)), 'WORLD') as Territory from RankedEbookPrices r
join ebookPrices e on e.gtin = r.gtin and r.[Rank] = e.[Rank] and e.ID = r.PriceCampaign
left join country c on c.id = e.Territory),
pivoter1 (Sequence, ISBN, Genre) as
(
select case when ag.Sequence = 1 then 'PrimaryGenre' when ag.Sequence = 2 then 'SecondGenre' when ag.Sequence = 3 then 'ThirdGenre' when ag.Sequence = 4 then 'FourthGenre' end as Sequence, a.gtin ISBN, g.Name [Genre] from album a 
join albumGenre ag on ag.album = a.id 
join genre g on g.id = ag.genre 
join masterGenre mg on mg.id = g.masterGenre
join albumProductType apt on apt.album = a.id 
join productType pt on pt.id = apt.productType
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)),

pivoter2 (Sequence2, ISBN2, BISAC) as
(
select case when ag.Sequence = 1 then 'PrimaryBISAC' when ag.Sequence = 2 then 'SecondBISAC' when ag.Sequence = 3 then 'ThirdBISAC' when ag.Sequence = 4 then 'FourthBISAC' end as Sequence2, a.gtin ISBN2, g.Code [BISAC] from album a 
join albumGenre ag on ag.album = a.id 
join genre g on g.id = ag.genre 
join albumProductType apt on apt.album = a.id 
join productType pt on pt.id = apt.productType
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)
)

select distinct gtin [ISBN], 
Name [Title], [Series], [Author], [OrgID], [Imprint], [ParentOrgID], [Parent], 
case when [AthAlbum] is NULL then cast(datepart(yy,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(4)) + '-' +  cast(datepart(mm,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(2)) + '-' + cast(datepart(dd,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(2)) else cast(datepart(yy,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(4)) + '-' + cast(datepart(mm,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(2)) + '-' + cast(datepart(dd,coalesce(SalesStartDate, ReleaseDate)) as nvarchar(2)) end as [OnSaleDate],
AlbumPrice as PriceInUSD, Territory as PricingValidFor,
case when MigratedAt is not null then 'ATHENA' when [AthAlbum] is NULL then 'INDMA' else 'ATHENA' end as [InitialImportSystem],
[PrimaryGenre], isnull([SecondGenre],'') [SecondGenre], isnull([ThirdGenre],'') [ThirdGenre], isnull([FourthGenre],'') [FourthGenre],
[PrimaryBISAC], isnull([SecondBISAC],'') [SecondBISAC], isnull([ThirdBISAC],'') [ThirdBISAC], isnull([FourthBISAC],'') [FourthBISAC]
from 
(
select a.Name, isnull(a.Mix, '') [Series], isnull(c.Name,'') [Author], mg.Name [MasterGenre], cast(o.id as varchar(10)) as OrgID, o.Name [Imprint], isnull(cast(po.id as varchar(10)),'') as ParentOrgID, isnull(po.Name,'') [Parent], 
a.gtin, pv.Genre, pv.Sequence, pv2.Sequence2, pv2.ISBN2, pv2.BISAC, aa.ID [AthAlbum], a.SalesStartDate, a.ReleaseDate, amo.MigratedAt, cast(sp.AlbumPrice as nvarchar(7)) AlbumPrice, sp.Territory
from album a
inner join organization o on o.id = a.organization
left outer join organization po on po.id = o.parent
inner join albumGenre ag on ag.album = a.id
inner join genre g on g.id = ag.genre
inner join masterGenre mg on mg.id = g.masterGenre
left outer join AthenaAlbum aa on aa.album = a.id
inner join albumProductType apt on apt.album = a.id
inner join productType pt on pt.id = apt.productType
left join SingleEbookPrice sp on sp.GTIN = a.GTIN
left join pivoter1 pv on pv.ISBN = a.gtin
left join pivoter2 pv2 on pv2.ISBN2 = a.gtin
left join (select min(ac.id) minAC, ac.album from albumcelebrity ac
group by ac.album) mac on mac.album = a.id
left join albumCelebrity ac on ac.id = mac.minAC
left join Celebrity c on c.id = ac.celebrity
left join xxx_athenaMigratedOrgs amo on amo.org = o.id
where pt.Name in ('Ebook','Enhanced_Ebook','FixedFormat_Ebook')
and a.process in (1,5)
) as SourceQuery
pivot
(max(Genre) for Sequence
in ([PrimaryGenre],[SecondGenre],[ThirdGenre], [FourthGenre])) as pvt1
pivot
(max(BISAC) for Sequence2
in ([PrimaryBISAC],[SecondBISAC],[ThirdBISAC], [FourthBISAC])) as pvt2
order by Imprint, ISBN

