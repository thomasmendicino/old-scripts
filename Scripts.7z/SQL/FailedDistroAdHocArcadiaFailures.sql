--******* Failed Distribution... Last 12 hours
--*******
use athenacomposite;
SET NOCOUNT ON 

DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @pacificTime int
DECLARE @DistributionTitles table (Title nvarchar(200), ContentType nvarchar(50), OrgUid uniqueidentifier, ISBN bigint, OnSaleDate datetime,
    ProductUid uniqueidentifier,
    RetailerUid uniqueidentifier,
    Retailer nvarchar(50),
    ProcessedAtUtc datetime,
    distributionOrderUId uniqueidentifier)
DECLARE @DistributionDataSet table (FailedDate datetime, TheReason nvarchar(1000), DistributionORderUId uniqueidentifier, [Rank] smallint)

declare @organizationUIdList table (orgUid uniqueidentifier)
SET @pacificTime = datediff(hh,getUTCdate(),getdate()) 
SET @DateRangeStart = GETUTCDATE()-200
SET @DateRangeEnd = getutcdate()
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

DELETE FROM AthenaDistribution..TMFailedDistributionDataSet

;with MaxAt as (select max(ProcessedAtUtc) [MaxProcessedAtUTC], pr.ProductUid, r.Name from AthenaComposite..distributionOrderStatus dos
join AthenaComposite..distributionOrders do on do.distributionORderUId = dos.DistributionOrderUId
join AthenaComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaComposite..contracts c on c.contractUid = pr.contractUId
join AthenaComposite..retailers r on r.retailerUId = c.retailerUid
group by pr.productUid, r.Name
having max(ProcessedAtUtc) > @DateRangeStart),

FailedOrders as (
select do.DistributionOrderUid from AthenaComposite..DistributionOrders do
join AthenaComposite..DistributionOrderStatus dos on dos.distributionOrderUid = do.distributionORderUId
join AthenaComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaComposite..contracts c on c.contractUid = pr.contractUId
join AthenaComposite..retailers r on r.retailerUId = c.retailerUid
join MaxAt m on m.ProductUid = pr.productUid and m.Name = r.Name and m.MaxProcessedAtUTC = dos.ProcessedAtUTC
where dos.ResultingEventLevel = 4)

INSERT @DistributionTitles (Title, ContentType, OrgUid, ISBN, OnSaleDate, ProductUid, RetailerUid, Retailer, ProcessedAtUtc, distributionOrderUId)
SELECT DISTINCT
coalesce(td.TitleStatement, te.TitleText, TitlePrefix + ' ' + TitleWithoutPrefix) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pub.OrganizationUid AS OrgUid,
    [pi].Value AS ISBN,
	pd.Value AS OnSaleDate,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    dos.ProcessedAtUtc AS ProcessedAtUtc,
    F.distributionOrderUId
FROM
	AthenaComposite..DistributionOrderStatus dos
	INNER JOIN AthenaComposite..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaComposite..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaComposite..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaComposite..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaComposite..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaComposite..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN AthenaComposite..asset a on a.productUid = p.productUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AthenaComposite..AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AthenaComposite..assetVersion av on av.assetOverrideUid = ao.assetOverrideUId
    INNER JOIN AthenaComposite..TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN AthenaComposite..TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN AthenaProductCatalog..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN AthenaProductCatalog..ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN AthenaComposite..productForms pf on pf.assetVersionUid = av.AssetVersionUid
    INNER JOIN AthenaComposite..ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
    INNER JOIN FailedOrders f on f.DistributionOrderUid = do.DistributionOrderUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
	AND pf.ProductFormTypeValue IN (49,50,51,52)
	AND dos.ProcessedAtUtc BETWEEN @DateRangeStart AND @DateRangeEnd
	AND av.ValidUntilUtc is NULL
	--AND r.Code = 'SRD'
	--AND p.Ordinal = 9781625845696
	AND r.Code not in ('KDP', 'OST','ENT', 'SNY')
	AND p.organizationUId in ( select organizationUid from AthenaSecurity..OrgHierarchy('Arcadia Publishing Inc.'))
--	AND pub.OrganizationUid IN (select orgUid as OrganizationUId from @organizationUIdList)  
	/*('E3CB6A8E-47AD-40C4-B6DD-D95231D1A31A',
'22E27C61-64E0-4CA1-8C5A-C53B4034BCBC',
'225373BF-51A8-4F2B-B736-78E43A73A256',
'AFF73B2F-255F-4129-BF28-F7042EF5B2B5',
'CEA3FBEB-079D-4770-BAD5-09B48F05034D',
'97E56404-D710-42D8-BB4D-7E6E79655F34')*/

--select * from @DistributionTitles

INSERT AthenaDistribution..TMFailedDistributionDataSet (FailedDate, TheReason, Code, DistributionORderUId, [Rank])
SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
    left(ret.Title,1000) AS TheReason,
	ret.Code,
	dt.DistributionORderUId,
	1 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
	INNER JOIN AthenaComposite..DistributionOrderAcceptabilities doa on doa.distributionOrderUid = do.distributionOrderUid
	INNER JOIN AthenaComposite..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaComposite..refEventType ret on ret.EventTypeId = doa.ResultingEvent
WHERE
    doa.ResultingEventLevel > 2
    AND ret.Code NOT IN ('REM','DIDC','DINA','EAVE')                          -- Not distributed based on contract
                
UNION

	SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
	left(dos.ResultingMessage,1000) AS TheReason,
	ret.Code,
    dt.DistributionORderUId,
	2 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
    INNER JOIN AthenaComposite..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaComposite..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaComposite..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC','REM','DINA')                          -- Not distributed based on contract

UNION    

	SELECT DISTINCT
    dt.ProcessedAtUtc AS FailedDate,
    left(ret.Title,1000) AS TheReason,
	ret.Code,
    dt.DistributionORderUId,
	3 as [Rank]
FROM
	@DistributionTitles dt
    INNER JOIN AthenaComposite..DistributionOrders do ON do.DistributionOrderUid = dt.distributionOrderUid
    INNER JOIN AthenaComposite..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaComposite..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaComposite..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC','REM','DINA')                          -- Not distributed based on contract
    
	--select * from @DistributionDataSet
	
	select distinct
    ISBN,
	case 
when po.OrganizationName = 'INscribe Digital' then o.OrganizationName
when ppo.OrganizationName = 'INscribe Digital' then po.OrganizationName
when pppo.OrganizationName = 'INscribe Digital' then ppo.OrganizationName
when ppppo.OrganizationName = 'INscribe Digital' then pppo.OrganizationName
when po.OrganizationName is NULL then o.OrganizationName
end as [TopLevelParent],
o.OrganizationName [Imprint],
    Title,
    ContentType, 
    OnSaleDate,
    Retailer,
    a.FailedDate,
	a.Code,
    a.TheReason as Reason
from AthenaComposite..distributionOrders do
	cross apply (
		select top 1 distributionOrderUid, TheReason, Code, FailedDate from AthenaDistribution..TMFailedDistributionDataSet d
		where do.distributionOrderuid = d.distributionOrderUid
		order by [Rank] asc, TheReason desc) a
	join @DistributionTitles dt on dt.DistributionOrderUid = do.distributionOrderUid
	join AthenaComposite..productRevisions pr on pr.productRevisionUid = do.productRevisionUid
	join AthenaProductCatalog..product p on p.productUid = pr.productUid
	join AthenaSecurity..organizations o on o.organizationUid = p.organizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations po on po.organizationUid = o.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations ppo on ppo.organizationUid = po.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations pppo on pppo.organizationUid = ppo.ParentOrganizationUid
	LEFT OUTER JOIN AthenaSecurity..Organizations ppppo on ppppo.organizationUid = pppo.ParentOrganizationUid
	--where a.TheReason not like '%There are no supported assets assigned to the title%'
	--and a.TheReason not like '%asset validation has errors%'
	--and a.TheReason not like '%more than one TitleElement%'
	--and a.TheReason not like '%Missing DistributionOrderStructureGroupContract, DistributionContract%'
	--and a.TheReason not like '%Object reference%ValidateContributors%'
	--and a.Code not in ('EBM','CIM','QPNF','CIVF')
	--where TheReason LIKE '%No Publisher element%'
--	AND TheReason not LIKE '%No Publisher element%'
	order by Retailer, TopLevelParent, Imprint, Code,ISBN
	--select * from TMFailedDistributionDataSet order by distributionorderuid

	/*
	9781625850928
	9781439653715,978143965372
	9781439610015,9781439610022
	select * from product p
	join productRevisions pr on pr.productUid = p.ProductUid
	join DistributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
	join DistributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
	where p.ordinal = 9781439653715
	and do.CreatedAtUtc > getdate()
	*/


	--9781439654408 OVD
	--9781625854902