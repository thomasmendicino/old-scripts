USE AthenaDistribution;
begin tran

declare @Parent uniqueidentifier
declare @Imprint uniqueidentifier

select @Parent = OrganizationUid from AthenaSecurity..organizations where OrganizationName = 'Harvard'
select @Imprint = OrganizationUid from AthenaSecurity..organizations where OrganizationName = 'Harvard University Press'

update AthenaSecurity..Organizations SET ParentOrganizationUid = @Parent where OrganizationUId = @Imprint

declare @ruleSetUid uniqueidentifier
declare @HarvardPub uniqueidentifier
declare @HUPpub uniqueidentifier
select @ruleSetUid = ruleSetUid from RuleSets where name = 'Distribution Prohibited'
select @HarvardPub = PublisherUid from Publishers where Name = 'Harvard'
select @HUPpub = PublisherUid from Publishers where Name = 'Harvard University Press'

update contracts set PublisherUid = @HarvardPub where publisherUId = @HUPpub and ruleSetUid = @ruleSetUid and ValidUntilUtc is NULL

--rollback
--commit
