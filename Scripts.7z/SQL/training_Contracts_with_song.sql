use [Ingrooves]

Select top(100) Contract.Starts as Contract_Starts, Track.Track as Track_No, Song.Performer as Artist, Contract.Ends as Contract_Ends, Syndication.SyndicatedBy, Album.Name as Album_Name, Song.Name as Song_Name from Album
inner join Song ON Album.SongPerformer = Song.ID
inner join Track ON Album.ID = Track.Album -- also try switching song for album
inner join TrackSyndication ON Track.ID = TrackSyndication.Track
inner join Syndication ON TrackSyndication.Syndication = Syndication.ID
inner join Contract ON TrackSyndication.Contract = Contract.ID
where Contract.Ends is not null and SyndicatedBy is not null
Order by Track.Track