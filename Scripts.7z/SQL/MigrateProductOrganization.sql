begin tran
declare @old nvarchar(30) = 'Lyrical Press'
declare @new nvarchar(30) = 'Lyrical Shine'
declare @oldUid uniqueidentifier
declare @newUid uniqueidentifier
select @oldUid = organizationUid from AthenaSecurity..organizations where OrganizationName = @old
select @newUId = organizationUid from AthenaSecurity..organizations where OrganizationName = @new

UPDATE AthenaProductCatalog..Product set OrganizationUid = @newUid where OrganizationUid = @oldUid and Ordinal in (9781616509194,9781616509217,9781601833426,9781601833402,9781601833389)


--commit