
select UACT.Name, UAT.Name, A.GTin, t.ID [track], a2.ID [asset], oc.Country, oc.Destinationcountry, ob.*, oi.* from orderitem oi 
join orderitemcomponent oic on oic.orderitem = oi.id
join umgassetcomponenttype uact on uact.id = oic.umgassetcomponentType
join umgassettype uat on uat.id = oi.umgassetType
join orderALbum oa on oa.id = oi.orderalbum
join album a on oa.album = a.id
left join track t on oi.track = t.id
left join assets a2 on a2.id = oi.assets
join orderCountry oc on oc.id = oa.orderCountry
join [order] o on o.id = oc.[order] 
left join orderbatch ob on ob.id = oi.orderbatch
where o.ID = 1000002022841