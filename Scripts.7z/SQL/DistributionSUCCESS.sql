use AthenaComposite;


declare @OverdriveUid uniqueidentifier 
select @OverdriveUid = RetailerUid from Retailers where Name = 'overdrive'
declare @titles table (isbn bigint)

;with OverdriveDelivered as (
select distinct p.Ordinal from product p 
join productRevisions pr on pr.productUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join DistributionOrderStructureGroups dsg on dsg.distributionOrderUid = do.DistributionOrderUid
join DistributionOrderStructureGroupBatches dsb on dsb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join DistributionOrderStatus dos on dos.distributionOrderUid = do.DistributionOrderUid
join contracts c on c.ContractUid = pr.contractUid
join DistributionContracts dc on dc.DistributionContractUid = dsg.DistributionContractUid
where c.RetailerUid = @OverdriveUid
and dos.ResultingEvent = 110)
--select * from OverdriveDelivered
,LatestWasTakedown as (
select distinct p.ordinal from product p
join OverdriveDelivered od on od.Ordinal = p.Ordinal
join productRevisions pr on pr.productUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join (select p2.ordinal, max(do.CreatedAtUtc) At
from product p2
join productRevisions pr on pr.productUid = p2.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join OverdriveDelivered od on od.ordinal = p2.ordinal
group by p2.Ordinal) a on a.Ordinal = p.ordinal and a.At = do.CreatedAtUtc
where pr.ChangeType = 8)

insert @titles (isbn)
select p.Ordinal from product p
join asset a on a.productUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join OverdriveDelivered od on od.ordinal = p.ordinal
WHERE av.ValidUntilUtc is NULL and a.ResourceContentType = 100
AND p.Ordinal not in (select Ordinal from LatestWasTakedown)
AND (ao.RetailerUid = @OverdriveUid or (ao.RetailerUid is null and not exists(select 1 from AssetOverride ao where ao.RetailerUid = @OverdriveUid and ao.assetUid = a.assetUid)))


DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @OrganizationUIdList table (orgUID uniqueidentifier)

SET @DateRangeStart = '2015-05-01 16:00:00.000'
SET @DateRangeEnd = '2015-06-01 16:00:00.000'
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

SET @eISBNs = NULL

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses


;with #DistributionTitles as (
SELECT
    pub.Name AS Publisher,
    [pi].Value AS ISBN,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
FROM
	AthenaDistribution..DistributionOrderStatus dos
	INNER JOIN AthenaDistribution..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaDistribution..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaDistribution..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaDistribution..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaDistribution..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaProductCatalog..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN AthenaProductCatalog..ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
	INNER JOIN AthenaSecurity..Organizations o on o.organizationUid = pub.organizationUid
	INNER JOIN DistributionOrderStructureGroups dg on dg.DistributionOrderUid = do.DistributionOrderUid
	INNER JOIN DistributionContracts dc on dc.DistributionContractUid = dg.DistributionContractUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
--    AND (@eISBNs IS NULL OR [pi].Value IN (@eISBNList))   -- In the List of supplied ISBNs
AND r.Name = 'Overdrive'
AND dc.Description <> 'Product History Ingestion Contract'

GROUP BY
	pub.Name,
    pr.ProductUid,
    [pi].Value,
    r.Name,
    r.RetailerUid
HAVING                                                     -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)),
	#DistributionDataset as (
    
SELECT DISTINCT
    Publisher,
    ISBN,
    --coalesce(td.TitleStatement, te.TitleText) AS Title,
    --CASE pfd.ProductFormDetailValue 
        --WHEN 190 THEN 'Fixed' 
        --WHEN 189 THEN 'Reflowable'
        --ELSE 'Not Specified' END AS ContentType, 
    --pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS DistributionDate
FROM
	#DistributionTitles dt
    INNER JOIN AthenaDistribution..ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN AthenaDistribution..Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN AthenaDistribution..DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN AthenaDistribution..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaProductCatalog..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN asset a on a.productUid = p.productUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    
    INNER JOIN AthenaEventLog..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel <= 2
    AND ret.Code = 'DITC'
    AND av.ValidUntilUtc IS NULL        )                  -- Most recent version
    
    


SELECT
    Publisher OrganizationName,
	ISBN [ProductOrdinal],
	--Title,
	Retailer RetailerName,
	' ' as ' ',
	dateadd(hh,(datediff(hh,getUTCdate(),getdate())),DistributionDate) as [OrderCreatedAtUtc],
    dateadd(hh,(datediff(hh,getUTCdate(),getdate())),DistributionDate) as [PacketValidatedAtUtc],
    dateadd(hh,(datediff(hh,getUTCdate(),getdate())),DistributionDate) as[SyndicationStartedAtUtc],
    dateadd(hh,(datediff(hh,getUTCdate(),getdate())),DistributionDate) as[SyndicationCompletedAtUtc],
	ISBN as [BatchNumber],
	dateadd(hh,(datediff(hh,getUTCdate(),getdate())),DistributionDate) as [TransferStartedAtUtc],
    dateadd(hh,(datediff(hh,getUTCdate(),getdate())),DistributionDate) as [TransferCompletedAtUtc],
    dateadd(hh,(datediff(hh,getUTCdate(),getdate())),DistributionDate) as [EventCreatedAt],
	'Distribution Order Transfer Complete' as EventName
FROM
    #DistributionDataset dt
    join AthenaDistribution..Publishers p on p.Name = dt.Publisher
    join AthenaSecurity..Organizations o on o.organizationUId = p.organizationUId    
ORDER BY
    OrganizationName,
    ProductOrdinal,
	RetailerName,
	EventCreatedAt