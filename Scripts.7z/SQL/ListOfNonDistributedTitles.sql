IF OBJECT_ID('tempdb..#FullDistro') IS NOT NULL
    DROP TABLE #FullDistro
	GO

CREATE TABLE #FullDistro (ISBN bigint, Retailer char(3), DistroDate datetime, Redeliver bit)
;with DreamSpinnerTitles as (
	select p.Ordinal from product p
	join asset a on a.ProductUid = p.ProductUid
	join AssetOverride ao on ao.AssetUid = a.AssetUid
	join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
	join AthenaSecurity..OrgHierarchy('Dreamspinner Press') oh on oh.organizationUId = p.OrganizationUid
	WHERE av.ValidUntilUtc is NULL 
		AND pf.ProductFormTypeValue > 40),
ContractedRetailers AS (
	select r.Code from Retailers r
	where Name in ('3M',
	'Amazon eBookBase',
	'Baker and Taylor',
	'Barnes And Noble',
	'Bookshare',
	'Bowker',
	'Follett',
	'Google Books',
	'iBookstore',
	'KDP',
	'Kobo',
	'Mackin',
	'Onix Feed',
	'OverDrive',
	'Gardners',
	'Chegg',
	'MyILibrary',
	'Scribd',
	'Hoopla'))
INSERT #FullDistro (ISBN, Retailer, Redeliver)
select Ordinal, Code, 1
FROM DreamspinnerTitles
CROSS JOIN ContractedRetailers

--select * from #FullDistro

;with DreamSpinnerTitles as (
	select p.Ordinal from product p
	join asset a on a.ProductUid = p.ProductUid
	join AssetOverride ao on ao.AssetUid = a.AssetUid
	join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
	join AthenaSecurity..OrgHierarchy('Dreamspinner Press') oh on oh.organizationUId = p.OrganizationUid
	WHERE av.ValidUntilUtc is NULL 
		AND pf.ProductFormTypeValue > 40),
DreamspinnerDistro as (
	select p.Ordinal, r.Code, dos.ProcessedAtUtc from product p
	join productRevisions pr on pr.ProductUid = p.ProductUid
	join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
	join DistributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
	join Contracts c on c.ContractUid = pr.ContractUid
	join Retailers r on r.RetailerUid = c.RetailerUid
	where dos.ResultingEvent = 110
		and dos.ProcessedAtUtc > getdate()-30)

UPDATE fd
SET DistroDate = dd.ProcessedAtUtc
	, Redeliver = 0
FROM DreamspinnerDistro dd
INNER JOIN #FullDistro fd on fd.Retailer = dd.Code AND fd.ISBN = dd.Ordinal

--declare @results table (ISBN bigint, RetailerString nvarchar(500), PublishingDate datetime, PublishingDateRole nvarchar(100), PublishingStatus nvarchar(100))
--SELECT * from #FullDistro
--insert @results (ISBN, RetailerString, PublishingDate, PublishingDateRole, PublishingStatus)
;with results as (
SELECT DISTINCT
	cast(p.Ordinal as char(13)) as ISBN
	--, fd.Retailer as RetailerCode
	, STUFF ((select ',' + fd2.Retailer from #FullDistro fd2
		WHERE fd2.ISBN = fd.ISBN AND fd2.Redeliver = fd.Redeliver for xml path ('')),1,1,'') as RetailerString
	, pd.Value as PublishingDate
	, case 
		when pd.PublishingDateRole = 1 then 'Publishing Date'
		when pd.PublishingDateRole = 13 then 'Deletion Date'
	end as PublishingDateRole
	, case 
		when ps.PublishingStatusType = 7 then 'Out of print'
		when ps.PublishingStatusType = 4 then 'Active'
		else cast(ps.PublishingStatusType as NVARCHAR(2))
		end as PublishingStatus
FROM Product p
	INNER JOIN asset a on a.ProductUid = p.ProductUid
	INNER JOIN AssetOverride ao on ao.AssetUid = a.AssetUid
	INNER JOIN AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	INNER JOIN PublishingDates pd on pd.AssetVersionUid = av.AssetVersionUid
	LEFT OUTER JOIN PublishingStatus ps on ps.AssetVersionUid = av.AssetVersionUid
	INNER JOIN #FullDistro fd on fd.ISBN = p.Ordinal
	INNER JOIN Retailers r on r.Code = fd.Retailer
WHERE fd.Redeliver = 1
and ps.PublishingStatusType <> 7
and Value < '2015-03-16')

select distinct 
	STUFF((select ',' + r2.ISBN from results r2
				WHERE r2.RetailerString = r.RetailerString for xml path ('')),1,1,'') as ISBNString
,RetailerString, len(RetailerString) as stringlength from results r
order by len(RetailerString) desc, RetailerString
