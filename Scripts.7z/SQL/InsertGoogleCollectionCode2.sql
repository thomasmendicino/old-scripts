
begin tran
declare @publisherUid uniqueidentifier
declare @CollectionCode nvarchar(7)
declare @pubAttUid uniqueidentifier
declare @babel table (PublisherUid uniqueidentifier)
set @CollectionCode = 'BTPQ8BX'
select @pubAttUid = publisherAttributeUid from athenadistribution..publisherAttributes where Name = 'Google Collection Code'

insert @babel (PublisherUid)
select p.PublisherUid from athenasecurity..organizations o
join athenadistribution..publishers p on p.OrganizationUid = o.OrganizationUid
left join athenadistribution..publisherAttributeValues pav on pav.PublisherUid = p.PublisherUid and pav.PublisherAttributeUid = @pubAttUid
where (organizationname like '%babelcub%' or ParentOrganizationUid = 'C04F72D6-D385-4713-8EA3-7D62F32096CB')
and pav.Value is null

if not exists (select 1 from publisherAttributeValues where PublisherAttributeUid = @pubAttUid and PublisherUId in (select publisherUId from @babel)
begin
insert athenadistribution..publisherAttributeValues (PublisherAttributeValueUid, PublisherAttributeUid, Value, PublisherUid)
select newid(), @pubAttUid, @CollectionCode, PublisherUid from @babel
end
else
begin
PRINT 'Check PubAttValues table, there is a possible conflict'
end
--commit
--rollback

/*
Checking/Finding codes
*/
declare @pubAttUid uniqueidentifier
declare @publisherUid uniqueidentifier
declare @babel table (organizationUid uniqueidentifier)
insert @babel (organizationUid)
select organizationUid from organizations where organizationname like '%babelcub%' or ParentOrganizationUid = 'C04F72D6-D385-4713-8EA3-7D62F32096CB'
declare @pubAttUid uniqueidentifier
select @pubAttUid = publisherAttributeUid from athenadistribution..publisherAttributes where Name = 'Google Collection Code'
--select @publisherUid = publisherUid from AthenaDistribution.. Publishers where name like '%babelcube%'

select 
    p.Name Publisher
    , pav.Value CollectionCode
    , po.OrganizationName Parent 
FROM 
    AthenaDistribution..publishers p
    join athenasecurity..organizations o 
        on o.OrganizationUid = p.OrganizationUid
    join athenasecurity..organizations po 
        on po.OrganizationUid = o.ParentOrganizationUid
    left join athenadistribution..publisherAttributeValues pav 
        on pav.PublisherUid = p.PublisherUid 
        and pav.PublisherAttributeUid = @pubAttUid
where p.Name like '%Disney%'
order by p.Name



select * from athenasecurity..organizations where organizationname like '%babelcub%' or ParentOrganizationUid = 'C04F72D6-D385-4713-8EA3-7D62F32096CB'
select publisherUid from AthenaDistribution.. Publishers where name like '%babelcube%'


```
declare @pubAttUid uniqueidentifier
declare @CollectionCode nvarchar(7)
select @pubAttUid = publisherAttributeUid 
    from athenadistribution..publisherAttributes 
    where Name = 'Google Collection Code'
set @CollectionCode = '123TEST'

insert athenadistribution..publisherAttributeValues (PublisherAttributeValueUid, PublisherAttributeUid, Value, PublisherUid)
select 
newid()
, @pubAttUid
, @CollectionCode
, PublisherUid 
from Publishers
where Name = ''
```