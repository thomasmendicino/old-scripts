Album 00824953010226, Track No 1 not found
select * from album where gtin like '%824953010226%'
select * from album where gtin like '%824953009626%'
select * from track where album = 35502
--begin tran
--update album set GTIN = NULL where GTIN = '824953009626' --Album.ID = 35502
--update album set GTIN = '824953009626' where ID = 35502
--commit

--begin tran
--update album set GTIN = NULL where GTIN = '824953010226' --Album.ID = 35536
--update album set GTIN = '824953010226' where ID = 35536
--commit

select dp.musicservice, so.partnername, ms.name, s.syndicationlevel, * from syndicationorder so
join syndication s on so.syndication = s.id 
join musicservicedavepartner dp on dp.davepartnerid = so.partnerid
join musicservice ms on ms.id = dp.musicservice
where orderstate = 3
select * from albumsyndicationview where album = (select id from album where gtin = '00824953009626') order by syndicatedat desc
select * from syndication where syndicationlevel = 2538 and musicservice = 282
select * from syndicationorder where syndication = 244917
select * from syndicationorder where syndication = 267950
select * from syndicationordereventlog where syndicationorder = 95880
Album 00824953009626, Track No 3 not found
Album 00824953003129, Track No 4 not found
select * from album where gtin = '00824953009626'
select * from track where album = (select id from album where gtin = '00824953009626')
select * from song where id in (select song from track where album = (select id from album where gtin = '00824953009626'))

select * from 

select * from syndicationorder where orderbatchid = 1000001036125

5 errors: 1:'Cannot transcode recording from .wma to .flac', '\\\Colo-Master\HAS\2011\06\16\02\00044003733138\6_USSJ10806914_jNgmJ.wma'; 2:'Could not create sample', '\\\Colo-Master\HAS\2011\06\16\02\00044003733138\6_USSJ10806914_jNgmJ.wma'; 3:'Could no...'

select * from albummultidiscmapping where album = (select id from album where gtin = '00044003733138')

00795041971821