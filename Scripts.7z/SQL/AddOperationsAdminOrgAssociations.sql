/*

Adds user associations to the OperationsAdmin user for all organizations

*/
use AthenaSecurity;
begin tran
--rollback
--commit

declare @TopParent uniqueidentifier
declare @ExistingAssociations table (organizationUid uniqueidentifier)
declare @OpsAdmin uniqueidentifier

select @TopParent = '00000000-0000-0000-0000-000000000001'
select @OpsAdmin = UserId from AthenaSecurity..aspnet_Users where UserName = 'OperationsAdmin'

insert @ExistingAssociations (organizationUid)
select uo.OrganizationUid from AthenaSecurity..aspnet_Users asu
inner join AthenaSecurity..UserOrganizations uo on uo.UserUid = asu.UserId
where asu.UserId = @OpsAdmin

insert AthenaSecurity..UserOrganizations (UserUid, OrganizationUid)
select @OpsAdmin, OrganizationUid from AthenaSecurity..Organizations
WHERE organizationUid not in (
select OrganizationUid from @ExistingAssociations
UNION
select @TopParent)