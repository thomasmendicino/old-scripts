IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[reset_jobs_and_sessions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[reset_jobs_and_sessions]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Execute this stored procedure with 'Jobs and
-- Sessions' parameter when deploying new code
-- to application servers.
--
-- Execute with parameter 'Jobs' to delete from
-- the Object and JobFunction tables if the grid
-- needs to be reset (restarting INgroovesJob
-- and INgroovesFunction).
--
-- In case there is ever a reason to only reset 
-- sessions and not jobs, you can specify
-- 'Sessions' in the second parameter.
-- =============================================
CREATE PROCEDURE [dbo].[reset_jobs_and_sessions]
	@DatabaseServer	nvarchar(max),	-- string must = @@SERVERNAME	
	@Instruction	nvarchar(max)	-- 'Jobs' or 'Sessions' or 'Jobs and Sessions'
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE	@DBServerMessage nvarchar(max)
	SET		@DBServerMessage = 'Your first parameter must be the name of the database server.'

	IF @DatabaseServer != CAST(@@SERVERNAME as nvarchar(max))
		BEGIN
			RAISERROR (@DBServerMessage, 18, 1)
			RETURN -1
		END
	
	DECLARE @InstructionMessage nvarchar(max)
	SET		@InstructionMessage = 'Your second parameter must be either ''Jobs'' or ''Sessions'' or ''Jobs and Sessions'''
	
	IF @Instruction not in ('Jobs','Sessions','Jobs and Sessions')
		BEGIN
			RAISERROR (@InstructionMessage, 18, 1)
			RETURN -1
		END
	
	IF @Instruction = 'Jobs'
	OR @Instruction = 'Jobs and Sessions'
		BEGIN
			DELETE FROM JobFunction
			DELETE FROM Object
		END
	
	IF @Instruction = 'Sessions'
	OR @Instruction = 'Jobs and Sessions'
		BEGIN
			DELETE FROM Lock
			DELETE FROM [tempdb].[dbo].[ASPStateTempApplications]
			DELETE FROM [tempdb].[dbo].[ASPStateTempSessions]
			DELETE FROM [tempdb].[dbo].[INgroovesTempAPI]
			DELETE FROM [tempdb].[dbo].[INgroovesTempSessionAddition]
			DELETE FROM [tempdb].[dbo].[INgroovesTempSessions]
			DELETE FROM [tempdb].[dbo].[INgroovesTempViewState]
		END
	
	IF @Instruction = 'Jobs' and @@ERROR = 0
		BEGIN
			PRINT 'You have successfully reset job data (JobFunction, Object tables) in database '+CAST(DB_Name() as nvarchar(max))+'.'
		END

	IF @Instruction = 'Sessions' and @@ERROR = 0
		BEGIN
			PRINT 'You have successfully reset session data (Lock table and tempdb session tables) in database '+CAST(DB_Name() as nvarchar(max))+'.'
		END

	IF @Instruction = 'Jobs and Sessions' and @@ERROR = 0
		BEGIN
			PRINT 'You have successfully reset job and session data (JobFunction, Object, Lock and tempdb session tables) in database '+CAST(DB_Name() as nvarchar(max))+'.'
		END
END

GO