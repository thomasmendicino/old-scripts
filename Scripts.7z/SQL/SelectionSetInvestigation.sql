select * from syndicationorder

--rollback
--begin tran
select * into #albumset_ca1_and_9
from contractalbumview cav
where cav.contractauthority = 1
or cav.contractauthority = 9

select * from contractalbumview

select * into #albumset_ca9
from contractalbumview cav
where cav.contractauthority = 9

with #albumset_ca1_9 (album, contractauthority) AS (select album, contractauthority from contractalbumview cav where cav.contractauthority in (1,9))

select distinct a.gtin, len(a.gtin) #digits from #albumset_ca1_9
inner join album a on a.id = #albumset_ca1_9.album
inner join countrysetcountry csc on csc.countryset = a.countryset
inner join country c on csc.country = c.id
inner join selections s on s.objectid = a.id
inner join selectionset ss on s.selectionset = ss.id
where a.id in (s.selectionset = (select id from selectionset where name = 'emusicrelunsyndacc'))
and csc.country not in (250,44)
and len(a.gtin) = 14
 
'80330753529616',
'80330753532982'))
and csc.country not in (250,44)


select * from countrysetcountry

select * from album

--begin tran


select distinct a.gtin, len(a.gtin) from selections s
inner join album a on a.id = s.objectid
inner join arearestriction ar on a.id = ar.album
inner join country c on ar.country = c.id
where s.selectionset = (select id from selectionset where name = 'emusicrelunsyndacc')
and len(a.gtin) = 14
and ar.country != 250
and ar.operator = '+'

select countryset from album