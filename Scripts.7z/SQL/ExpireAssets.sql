
begin tran
select r.Path, Ordinal, tat.Name, av.ValidUntilUtc 
from athenaProductCatalog..product p
join athenaProductCatalog..asset a on a.productUid = p.productUid
join athenaProductCatalog..AssetOverride ao on ao.assetUid = a.assetUid
join athenaProductCatalog..assetVersion av on av.assetOverrideUid = ao.assetOverrideUid
join athenaResourceStorage..resources r on r.resourceUid = av.resourceUid
join TMAssetType tat on tat.id = a.assetTYpe
where av.validUntilutc is null
and tat.Name = 'EPUB2R'
and ordinal in
(9781625176295,
9781625176288,
9781625176271,
9781625176264,
9781625176257,
9781625176240)


update av set ValidUntilUtc = GETUTCDATE()
from athenaProductCatalog..product p
join athenaProductCatalog..asset a on a.productUid = p.productUid
join athenaProductCatalog..AssetOverride ao on ao.assetUid = a.assetUid
join athenaProductCatalog..assetVersion av on av.assetOverrideUid = ao.assetOverrideUid
join athenaResourceStorage..resources r on r.resourceUid = av.resourceUid
join TMAssetType tat on tat.id = a.assetTYpe
where av.validUntilutc is null
and tat.Name = 'EPUB2R'
and ordinal in
(9781625176295,
9781625176288,
9781625176271,
9781625176264,
9781625176257,
9781625176240)

select r.Path, Ordinal, tat.Name, av.ValidUntilUtc 
from athenaProductCatalog..product p
join athenaProductCatalog..asset a on a.productUid = p.productUid
join athenaProductCatalog..AssetOverride ao on ao.assetUid = a.assetUid
join athenaProductCatalog..assetVersion av on av.assetOverrideUid = ao.assetOverrideUid
join athenaResourceStorage..resources r on r.resourceUid = av.resourceUid
join TMAssetType tat on tat.id = a.assetTYpe
where av.validUntilutc is null
and tat.Name = 'EPUB2R'
and ordinal in
(9781625176295,
9781625176288,
9781625176271,
9781625176264,
9781625176257,
9781625176240)