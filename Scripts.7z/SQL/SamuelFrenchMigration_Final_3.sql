BEGIN TRANSACTION
--COMMIT TRANSACTION
--ROLLBACK TRANSACTION

SET NOCOUNT ON
DECLARE @DesiredOrgName nvarchar(20) = 'Samuel French'
DECLARE @DeprecatedOrgName nvarchar(20) = 'Samuel French, Inc.'
DECLARE @DesiredOrg int
SELECT @DesiredOrg = ID FROM Organization WHERE Name = @DesiredOrgName
DECLARE @DeprecatedOrg int
SELECT @DeprecatedOrg = ID FROM Organization WHERE Name = @DeprecatedOrgName


UPDATE Celebrity SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg and Name in (
select Name from Celebrity where Organization = (select id from organization where name = 'samuel french, inc.')
except
select Name from Celebrity where Organization = (select id from organization where name = 'samuel french'))
DECLARE @Celebrity nvarchar(10) = @@ROWCOUNT

PRINT @Celebrity + ' Celebrity rows UPDATED.'

UPDATE Album SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @AlbumRowCount nvarchar(10) = @@ROWCOUNT

UPDATE Song SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @SongRowCount nvarchar(10) = @@ROWCOUNT

PRINT @AlbumRowCount + ' Album rows UPDATED.'
PRINT @SongRowCount + ' Song rows UPDATED.'

/*
UPDATE TransferredMusicServiceCACache SET Organization = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @TransferredMSCA nvarchar(10) = @@ROWCOUNT
UPDATE SyndicatedPerformerCACache SET Organization = @DesiredOrg, SongPerformer = @DesiredOrgName WHERE Organization = @DeprecatedOrg
DECLARE @SyndPerfCA nvarchar(10) = @@ROWCOUNT

PRINT @TransferredMSCA + ' TransferredMusicServiceCACache rows UPDATED.'
PRINT @SyndPerfCA + ' SyndicatedPerformerCACache rows UPDATED.'

UPDATE OwnerLabelCache SET Organization = @DesiredOrg, Label = @DesiredOrg WHERE Organization = @DeprecatedOrg
DECLARE @OwnerLabel nvarchar(10) = @@ROWCOUNT

PRINT @OwnerLabel + ' OwnerLabelCache rows UPDATED.'*/

UPDATE Organization SET Active = 0 WHERE ID = @DesiredOrg
PRINT 'Organization ' + @DesiredOrgName + ' has been set to Inactive.'

--SELECT * from TransferredMusicServiceCACache where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from TransferredMusicServiceCACache where Organization = (select id from organization where name = 'Samuel French')
--SELECT * from SyndicatedPerformerCACache where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from ImportLog where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from OwnerLabelCache where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from OwnerLabelCache where Organization = (select id from organization where name = 'Samuel French')
--SELECT * from EarningTest where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from Album where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from Song where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from PayableStatement where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from Earning where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from Celebrity where Organization = (select id from organization where name = 'Samuel French, Inc.')
--SELECT * from Association where FromOrganization = (select id from organization where name = 'Samuel French, Inc.')

/*

select * from Celebrity where Organization = (select id from organization where name = 'samuel french, inc.')
select * from Celebrity where Organization = (select id from organization where name = 'samuel french')
select * from Celebrity where Name in (select Name from Celebrity where Organization = (select id from organization where name = 'samuel french, inc.'))


select Name 

DECLARE @Counter int = 1
DECLARE @DeprecatedCelebCount int 
SELECT @DeprecatedCelebCount = Count(*) from Celebrity where Organization = (select id from organization where name = 'samuel french, inc.')
WHILE @Counter <= @DeprecatedCelebCount
BEGIN
IF EXISTS (SELECT NULL FROM Celebrity WHERE 
*/

select * from albumcelebrity where album in (select id from album where organization = (select id from organization where name = 'samuel french, inc.'))

--FIND Celebs that are associated with SFI --> A
--FIND Celebs that are associated with SF --> B
--FIND Celebs that are associated with both SF and SFI --> C
--A + B do not need to be touched in albumCelebrity
--Celebrity rows from A need to have organization updated to SF
--AlbumCelebrity rows that contain celebs from C need to be updated to celebs from B

--Isolate Celebrities that are associated with SFI only
IF OBJECT_ID('tempdb.dbo.#SFI_Celebs') IS NOT NULL DROP TABLE #SFI_Celebs
CREATE TABLE #SFI_Celebs (Name nvarchar(260))
INSERT #SFI_Celebs
SELECT Name FROM Celebrity WHERE Organization = @DeprecatedOrg
EXCEPT 
SELECT Name FROM Celebrity WHERE Organization = @DesiredOrg

--Isolate Celebrities that are associated with SF only
IF OBJECT_ID('tempdb.dbo.#SF_Celebs') IS NOT NULL DROP TABLE #SF_Celebs
CREATE TABLE #SF_Celebs (Name nvarchar(260))
INSERT #SF_Celebs
SELECT Name FROM Celebrity WHERE Organization = @DesiredOrg
EXCEPT 
SELECT Name FROM Celebrity WHERE Organization = @DeprecatedOrg

--Isolate Celebrities that are associated with both SF and SFI
IF OBJECT_ID('tempdb.dbo.#Dup_Celebs') IS NOT NULL DROP TABLE #Dup_Celebs
CREATE TABLE #Dup_Celebs (Name nvarchar(260))
INSERT #Dup_Celebs
SELECT Name FROM Celebrity WHERE Organization = @DesiredOrg
INTERSECT
SELECT Name FROM Celebrity WHERE Organization = @DeprecatedOrg

UPDATE Celebrity SET Organization = @DesiredOrg 
FROM Celebrity 
INNER JOIN
tempdb.dbo.#SFI_Celebs sfi ON sfi.Name = Celebrity.Name
WHERE Celebrity.Organization = @DeprecatedOrg

UPDATE AlbumCelebrity SET Celebrity = 