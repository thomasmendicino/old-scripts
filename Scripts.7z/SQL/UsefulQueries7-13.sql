select * from daveusercontext where usercontext like '%437' or usercontext like '%806'

select * from musicservicedavepartner where davepartnercountryid = 806 or davepartnerid = 437

--update daveusercontext set active = 0 where id in (1268,1269,1270)
if not exists (select id from daveusercontext where usercontext = 'us_437' and active = 0)
begin
--update daveusercontext set active = 0 where usercontext = 'US_437'
end
--select * from daveusercontext where usercontext = 'US_437'

if exists (select id from daveusercontext where usercontext = 'US_437' and active = 1)
begin
--update daveusercontext set active = 0 where usercontext = 'US_437'
end


select * from musicservicedavepartner where musicservice = 351 davepartnername = '%musiwave%'
select * from musicservice where name like '%musiwave%'
select * from musicservicedavepartner where musicservice = 282

select * from syndicationorder where partnerid = 437

select * from musicservicecontractauthorityoverride where musicservice = 351
select * from arearestriction where musicservicecontractauthorityoverride = 31


select davepartnername, davepartnerid, count(*) from musicservicedavepartner
group by davepartnername, davepartnerid
having count(davepartnerid) > 1


select * from taskgraphitem where id in (select taskgraphitem from calendaritem where enabled = 1)
select * from task where id in (select task from taskgraphitem where id in (select taskgraphitem from calendaritem where enabled = 1))

select * from pendingimport where id = 73
select * from importlog where sourcedata = 'UMG Affiliates\2011\July\2011-07-11\1000000889293\Delivery_Messages\delivery_1000000889293.xml'
select * from importorder where importlog = (select id from importlog where sourcedata = 'UMG Affiliates\2011\July\2011-07-11\1000000889293\Delivery_Messages\delivery_1000000889293.xml')
select top 10 * from changerequestimportlogbatch where importlog = (select id from importlog where sourcedata = 'UMG Affiliates\2011\July\2011-07-11\1000000889293\Delivery_Messages\delivery_1000000889293.xml')


--delete from changerequestimportlogbatch where importlog = (select id from importlog where sourcedata = 'UMG Affiliates\2011\July\2011-07-11\1000000889293\Delivery_Messages\delivery_1000000889293.xml')
--delete from importorder where importlog = (select id from importlog where sourcedata = 'UMG Affiliates\2011\July\2011-07-11\1000000889293\Delivery_Messages\delivery_1000000889293.xml')
--delete from importlog where sourcedata = 'UMG Affiliates\2011\July\2011-07-11\1000000889293\Delivery_Messages\delivery_1000000889293.xml'
--update pendingimport set state = 1 where id = 73




select * from Job inner join JobParameter on Job.ID=JobParameter.Job where Job.Name Like 'HAL%'


select * from Parameter inner join JobParameter on Parameter.ID=JobParameter.Parameter inner join Job on Job.ID=JobParameter.Job where Job.Name Like 'HAL%billing%detail%'

select Parameter.Name AS ParameterName, Job.Name AS JobName from Parameter inner join JobParameter on Parameter.ID=JobParameter.Parameter inner join Job on Job.ID=JobParameter.Job where Job.Name Like 'HAL%'

select JobParameter.ID AS IDWeNeed, Parameter.Name AS ParameterName, Job.Name AS JobName from Parameter inner join JobParameter on Parameter.ID=JobParameter.Parameter inner join Job on Job.ID=JobParameter.Job where Job.Name Like 'HAL%Det%'

select * from jobparameter where id in (7047,7048,7049)

select * from job where id = 2224

select * from musicservice where name like '%rogers%'

select * from album where gtin = '00044003987388'

select * from JobParameterEnumerationSelection where JobParameter=7047

--delete from JobParameterEnumerationSelection where JobParameter=7047

select * from job where id = 2224 or id like '%1%' order by id

--begin tran
--commit
--rollback

--update job set at = null, indmauser = null, progress = 0, machine = null where id = 2224