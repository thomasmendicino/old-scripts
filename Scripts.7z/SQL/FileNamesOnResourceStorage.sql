USE AthenaComposite;
;with ScholasticTitles as 
(SELECT distinct p.Ordinal 
from 
	product p
		INNER JOIN  organizations o on o.OrganizationUid = p.OrganizationUid
		INNER JOIN  AthenaSecurity..OrgHierarchy('Scholastic Inc.') oh on oh.organizationUid = o.OrganizationUid
		INNER JOIN  asset a on a.ProductUid = p.ProductUid
		INNER JOIN  AssetOverride ao on ao.AssetUid = a.AssetUid
		INNER JOIN  AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NULL),
SingleMainTitle AS (
	SELECT DISTINCT
		p.Ordinal
		, replace(COALESCE(te.TitleText, te.TitlePrefix + ' ' + te.TitleWithoutPrefix),'"','''''') as Title
		, ROW_NUMBER() OVER (PARTITION BY p.Ordinal ORDER BY TitleElementLevel, isnull(te.TitleText,'z') DESC, te.TitleWithoutPrefix ASC) RowNum
	FROM
		Product p
		INNER JOIN  Asset a on a.ProductUid = p.ProductUid
		INNER JOIN  AssetOverride ao on ao.AssetUid = a.AssetUid
		INNER JOIN  AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		INNER JOIN  TitleDetails td on td.AssetVersionUid = av.AssetVersionUid
		INNER JOIN  TitleElements te ON te.TitleDetailId = td.TitleDetailId
		INNER JOIN  ScholasticTitles st ON st.Ordinal = p.Ordinal
	WHERE av.ValidUntilUtc is NULL)
select distinct
	p.Ordinal as ISBN, 
	o.OrganizationName as Imprint,
	mt.Title,
	r.Name RetailerSpecific,
	at.AssetTypeCode as AthenaAssetCode
	,at.AssetTypeText
	,rct.Name ResourceContentType
	,substring(rs.Path,52,len(rs.Path) - 52 - 36)	
FROM 
	AthenaProductCatalog..product p
		INNER JOIN  AthenaProductCatalog..asset a on a.ProductUid = p.ProductUid
		INNER JOIN  AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
		INNER JOIN  AthenaProductCatalog..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		INNER JOIN AthenaDistribution..Retailers r on r.RetailerUid = ao.RetailerUid
		INNER JOIN  AthenaSecurity..Organizations o on o.OrganizationUid = p.OrganizationUid
		INNER JOIN  ScholasticTitles st on st.Ordinal = p.Ordinal
		INNER JOIN TMResourceContentType rct on rct.ResourceContentType = a.ResourceContentType
		INNER JOIN refAssetType at on at.AssetTypeId = a.AssetType
		LEFT OUTER JOIN  SingleMainTitle mt on mt.Ordinal = p.Ordinal
		INNER JOIN Resources rs on rs.ResourceUid = av.ResourceUid
WHERE av.ValidUntilUtc is NULL
	AND mt.RowNum = 1
	AND r.Code = 'APC'
order by p.Ordinal, Imprint, mt.Title, AssetTypeText