select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Scholastic Regular ePub File Types Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Special File Types Notification'	union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Kobo Takedown Notification'	union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Kobo Scholastic Update Notification'	union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Scholastic Special File Types Notification'	union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Kobo Update Notification'	union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Baker and Taylor Takedown Notification'	union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Regular ePub File Types Notification'	union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Research And Education Association Regular ePub File Types Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'KDP Takedown Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Creative Homeowner Price Campaign Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'OverDrive Takedown Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'OverDrive Transfer Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Kobo Scholastic Takedown Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Scholastic Price Campaign Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Creative Homeowner Special File Types Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Dover Publications Regular ePub File Types Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Price Campaign Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Research And Education Association Price Campaign Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Baker and Taylor Scholastic Takedown Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Dover Publications Price Campaign Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'OverDrive Asset Update Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Kobo Scholastic New Product Notification'	union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Creative Homeowner Cover and Metadata Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Cover and Metadata Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Dover Publications Cover and Metadata Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'iBookstore Bibliographic Change Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Scholastic Cover and Metadata Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Kobo New Product Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Baker and Taylor Transfer Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Research And Education Association Cover and Metadata Notification'union
select ts.Name, tse.Name from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Baker and Taylor Scholastic Transfer Notification'



select ts.Name, tse.Name,* from athenaDistribution..TransferServiceEndpoints tse join athenadistribution..transferServices ts on ts.transferServiceUid = tse.transferServiceUid where tse.Name = 'Barnes And Noble Scholastic Special File Types Notification'

select * from athenadistribution..contracts
select * from athenaAssetProcessor..assetTypeCriterias
use athenacomposite;

select tat.name,p.Name,r.Name,* from athenacomposite..assetTypeConfigurations atc join contracts c on c.contractUid = atc.contractUid
join publishers p on p.publisherUid = c.publisherUid
join tmassettype tat on tat.id = atc.assetType
join retailers r on r.RetailerUid = c.RetailerUid
where p.name like '%scholastic%' and validUntilUtc is null
order by assettype

AssetTypeConfigurationUid
9BE4FDE1-16B4-41C2-881A-4F0E073898E2

select * from AssetTypeConfigurationValues where AssetTypeConfigurationUid = '9BE4FDE1-16B4-41C2-881A-4F0E073898E2' order by stringvalue
select * from distributionContracts
select * from distributionorderstructureGroupcontracts where contractUid = '16C28A14-A4FC-486A-8837-CB2FC2CA6D43' order by name

use AthenaComposite;
select tat.name [AssetType],p.Name [Publisher],r.Name Retailer, atc.AssetTypeConfigurationUid, atv.StringValue 
from assetTypeConfigurations atc 
join AssetTypeConfigurationValues atv on atv.assetTypeConfigurationUid = atc.assetTypeConfigurationUid
join contracts c on c.contractUid = atc.contractUid
join publishers p on p.publisherUid = c.publisherUid
join tmassettype tat on tat.id = atc.assetType
join retailers r on r.RetailerUid = c.RetailerUid
where p.name like '%scholastic%' and validUntilUtc is null
and tat.name = 'EMLSFTDM'

select * from DistributionOrderStructureGroupContracts dos
join contracts c on c.contractUid = dos.contractUid
join publishers p on p.publisherUid = c.publisherUid
join retailers r on r.RetailerUid = c.RetailerUid
where p.name like '%scholastic%'
and r.name like '%barnes%'
and dos.name like '%special%'
and c.ValidUntilUtc is null

select * from DistributionOrderStructureGroups order by distributionOrderUid

select * from contracts where contractUid in ('ADED3EDE-53CE-46D4-8589-E446602323EE',
'16C28A14-A4FC-486A-8837-CB2FC2CA6D43',
'54C8BAD0-78D8-4570-A132-85DD24C14E13',
'95A01617-405B-483F-8049-F8DC75009DA4')

select * from publishers where name like '%authentic%'

select * from Organizations where organizationUid in ('8F3A0B23-425D-4871-B2D2-0284EEC1F5B0','4BD075E4-AEEE-4870-8FF0-071CB0FDA1E1')
