use athenaproductcatalog;
select 
    case 
    when ret.Name is NULL then 'ECHO F | xcopy \\instor05\inscribe-master--1\ResourceStorage\' + r.Path + ' D:\temp\20160324\' + pub.Safename + '\' + cast(p.ordinal as nvarchar(13)) + '.onix' 
    when ret.Name is NOT NULL then 'ECHO F | xcopy \\instor05\inscribe-master--1\ResourceStorage\' + r.Path + ' D:\temp\20160324\' + pub.Safename + '\' + cast(p.ordinal as nvarchar(13)) + '_' + ret.Code + '.onix' 
    end as Commands
from product p
    join asset a on a.ProductUid = p.ProductUid
    join AssetOverride ao on ao.AssetUid = a.AssetUid
    join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
    join AthenaResourceStorage..Resources r on r.ResourceUid = av.ResourceUid
    join AthenaSecurity..organizations o on o.organizationUid = p.OrganizationUid
    join AthenaDistribution..publishers pub on pub.OrganizationUid = o.OrganizationUid
    left join AthenaDistribution..Retailers ret on ret.retailerUid = ao.retailerUid
where av.ValidUntilUtc is NULL 
    and assettype = 1003
    and ordinal in ( , )