use AthenaComposite;

select rtc.Name, p.name, po.OrganizationName parent, evv.Value Email from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
join AthenaSecurity..OrganizationEntities oe on oe.OrganizationUid = o.OrganizationUid
join AthenaSecurity..EavValueVarchars evv on evv.EntityId = oe.EavEntityId
join AthenaSecurity..EavAttributes ea on ea.EavAttributeId = evv.AttributeId
where rtp.enabled = 1
and rtc.enabled = 1
and ea.EavAttributeName = 'Email'
order by po.OrganizationName, o.organizationname

begin tran
update evv Set Value = Value + ', thomas@inscribedigital.com' from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
join AthenaSecurity..OrganizationEntities oe on oe.OrganizationUid = o.OrganizationUid
join AthenaSecurity..EavValueVarchars evv on evv.EntityId = oe.EavEntityId
join AthenaSecurity..EavAttributes ea on ea.EavAttributeId = evv.AttributeId
where rtp.enabled = 1
and rtc.enabled = 1
and ea.EavAttributeName = 'Email'


if object_id('tempdb..#EnabledParents') is not null
DROP TABLE #EnabledParents
GO

if object_id('tempdb..#EnabledChildren') is not null
DROP TABLE #EnabledChildren
GO
create table #EnabledParents (Name nvarchar(200), Report nvarchar(60))
create table #EnabledChildren (Name nvarchar(200), Report nvarchar(60))

insert #EnabledParents (Name, Report)
select o.OrganizationName, rtc.Name from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
where rtp.enabled = 1
and rtc.enabled = 1
and po.OrganizationName = 'INscribe Digital'

insert #EnabledChildren (Name, Report)
select o.OrganizationName, rtc.Name from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
where rtp.enabled = 1
and rtc.enabled = 1
and po.OrganizationName != 'INscribe Digital'

select * from #EnabledChildren

select * from #EnabledParents

--begin tran
update rtp set Enabled = 0 from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.organizationUid = p.OrganizationUid
join #EnabledParents ep on ep.Name = o.OrganizationName

--commit

--rollback
--begin tran
update rtp set Enabled = 1 from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.organizationUid = p.OrganizationUid
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
where 
rtc.Name in (--'Preorder Status',
'Content Validation Errors',
'Failed Ingestion',
'Distribution',
'Failed Distribution',
'Ingestion')
and o.organizationName in (
'Scholastic Inc.')

--rollback

select * from ReportTypeConfigurations order by name

select * from ReportTypePublishers

declare @DistributionReport uniqueidentifier
declare @EmailDistributionReport uniqueidentifier
declare @FailedIngestion uniqueidentifier
declare @EmailFailedIngestion uniqueidentifier
declare @ContentValidationError uniqueidentifier
declare @EmailContentValidationError uniqueidentifier
declare @FailedDistribution uniqueidentifier
declare @EmailFailedDistribution uniqueidentifier
declare @Ingestion uniqueidentifier
declare @EmailIngestion uniqueidentifier
declare @Preorder uniqueidentifier
declare @EmailPreorder uniqueidentifier

select @DistributionReport = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Distribution'
select @EmailDistributionReport = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Distribution Email'
select @FailedIngestion = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Failed Ingestion'
select @EmailFailedIngestion = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Failed Ingestion Email'
select @ContentValidationError = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Content Validation Errors'
select @EmailContentValidationError = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Content Validation Errors Email'
select @FailedDistribution = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Failed Distribution'
select @EmailFailedDistribution = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Failed Distribution Email'
select @Ingestion = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Ingestion'
select @EmailIngestion = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Ingestion Email'
select @Preorder = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Preorder Status'
select @EmailPreorder = reportTypeConfigurationUid from ReportTypeConfigurations where Name = 'Preorder Status Email'
begin tran
update RTP set ReportTypeConfigurationUId = @EmailContentValidationError from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
join AthenaSecurity..OrganizationEntities oe on oe.OrganizationUid = o.OrganizationUid
join AthenaSecurity..EavValueVarchars evv on evv.EntityId = oe.EavEntityId
join AthenaSecurity..EavAttributes ea on ea.EavAttributeId = evv.AttributeId
where rtp.enabled = 1
and rtc.enabled = 1
and ea.EavAttributeName = 'Email' and rtp.ReportTypeConfigurationUid = @ContentValidationError

update RTP set ReportTypeConfigurationUid = @EmailDistributionReport from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
join AthenaSecurity..OrganizationEntities oe on oe.OrganizationUid = o.OrganizationUid
join AthenaSecurity..EavValueVarchars evv on evv.EntityId = oe.EavEntityId
join AthenaSecurity..EavAttributes ea on ea.EavAttributeId = evv.AttributeId
where rtp.enabled = 1
and rtc.enabled = 1
and ea.EavAttributeName = 'Email' and  rtp.ReportTypeConfigurationUid = @DistributionReport

update RTP set ReportTypeConfigurationUid = @EmailFailedDistribution from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
join AthenaSecurity..OrganizationEntities oe on oe.OrganizationUid = o.OrganizationUid
join AthenaSecurity..EavValueVarchars evv on evv.EntityId = oe.EavEntityId
join AthenaSecurity..EavAttributes ea on ea.EavAttributeId = evv.AttributeId
where rtp.enabled = 1
and rtc.enabled = 1
and ea.EavAttributeName = 'Email' and rtp.ReportTypeConfigurationUid = @FailedDistribution

update RTP set ReportTypeConfigurationUid = @EmailFailedIngestion from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
join AthenaSecurity..OrganizationEntities oe on oe.OrganizationUid = o.OrganizationUid
join AthenaSecurity..EavValueVarchars evv on evv.EntityId = oe.EavEntityId
join AthenaSecurity..EavAttributes ea on ea.EavAttributeId = evv.AttributeId
where rtp.enabled = 1
and rtc.enabled = 1
and ea.EavAttributeName = 'Email' and rtp.ReportTypeConfigurationUid = @FailedIngestion

update RTP set ReportTypeConfigurationUid = @EmailIngestion from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
join AthenaSecurity..OrganizationEntities oe on oe.OrganizationUid = o.OrganizationUid
join AthenaSecurity..EavValueVarchars evv on evv.EntityId = oe.EavEntityId
join AthenaSecurity..EavAttributes ea on ea.EavAttributeId = evv.AttributeId
where rtp.enabled = 1
and rtc.enabled = 1
and ea.EavAttributeName = 'Email' and rtp.ReportTypeConfigurationUid = @Ingestion

update RTP set ReportTypeConfigurationUid = @EmailPreorder from AthenaReportCatalog..ReportTypePublishers rtp
join AthenaReportCatalog..ReportTypeConfigurations rtc on rtc.ReportTypeConfigurationUid = rtp.ReportTypeConfigurationUid
join AthenaDistribution..publishers p on p.PublisherUid = rtp.PublisherUid
join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..organizations po on po.OrganizationUid = o.ParentOrganizationUid
join AthenaSecurity..OrganizationEntities oe on oe.OrganizationUid = o.OrganizationUid
join AthenaSecurity..EavValueVarchars evv on evv.EntityId = oe.EavEntityId
join AthenaSecurity..EavAttributes ea on ea.EavAttributeId = evv.AttributeId
where rtp.enabled = 1
and rtc.enabled = 1
and ea.EavAttributeName = 'Email' and rtp.ReportTypeConfigurationUid = @Preorder

--rollback

--commit





declare @UploadsHostname nvarchar(100) = 'instor05'
declare @UploadsPath nvarchar(100) = 'inscribe-master--1\Uploads'
declare @ReportName nvarchar(100) = 'Content Validation Errors'
declare @IntervalDays int = '1'
declare @PublisherName nvarchar(100) = ''


declare @renderSettings table
(
	RenderFormat nvarchar(10),
	WriteMode nvarchar(20)
);

insert into @renderSettings values
('PDF', 'None'),
('Excel', 'None');

select
p.OrganizationUid			[Organization],
p.Name Publisher,
po.organizationname,
p.PublisherUid				[PublisherUid],
'\\' + @UploadsHostname + '\' + @UploadsPath + '\' + replace(replace(fp.PathFormat, '{UploadsPath}/', ''), '{PublisherSafeName}', p.SafeName) [Path],
replace(rtc.Name + '_' + SUBSTRING(replace(replace(replace(CONVERT(varchar,GETDATE(),120),'-',''),':',''),' ',''),0,11),' ','') as  [Filename],
rs.RenderFormat				[RenderFormat],
rs.WriteMode				[WriteMode],
GETDATE()-@IntervalDays		[DateRangeStart],
GETDATE()					[DateRangeEnd]

from
ImportFolderConfigurations i
inner join FolderProcessors fp on i.FolderProcessorId = fp.FolderProcessorId
inner join ReportTypePublishers rtp on i.PublisherUid = rtp.PublisherUid
inner join Publishers p on rtp.PublisherUid = p.PublisherUid 
inner join ReportTypeConfigurations rtc on rtp.ReportTypeConfigurationUid = rtc.ReportTypeConfigurationUid
join organizations o on o.organizationUid = p.organizationUId
join organizations po on po.organizationuid = o.parentOrganizationUid
cross join @renderSettings rs
where
fp.ImportSourceType = 2
and rtp.Enabled = 1
and rtc.Enabled = 1
and rtc.Name = @ReportName
group by
	p.Name,
	p.SafeName,
	p.OrganizationUid,
	p.PublisherUid,
	fp.PathFormat,
	rs.RenderFormat,
	rs.WriteMode,
	rtc.Name,
	o.organizationname,
	po.organizationname
HAVING  --Either the Publisher name is null and we want all publishers, or it is specific                                                   
	(@PublisherName IS NOT NULL AND p.Name = @PublisherName)
	OR @PublisherName=''

	System.Exception: Cannot find distribution contract for 'Amazon eBookBase' and '
Disney Publishing Worldwide, Inc.' used in Job '{ BatchRetailerName = Amazon eBo
okBase, BatchProductIsbn = 9781423146049 }'

select * from retailers where name = 'Amazon eBookBase'
select * from retailers where name = 'Barnes And Noble'
select * from retailers where name = 'Overdrive'
select * from publishers where name = 'Disney Publishing Worldwide, Inc.'
select * from Organizations where organizationuid = 'F3107F10-0E13-47BA-A75B-9E4B8E6C8DF2'
select * from contracts where retailerUid = '35C17122-2D6E-4A1A-BCF8-300303293F06' and publisherUId = 'F9BEDD69-6079-4372-B874-D792936582F7'
select * from product where ordinal = 9781423140276
select * from organizations where organizationuid = '5AEDFCAF-73EE-4E40-87EE-456EB0F361D7'

select dc.Name, dc.ValidFromUtc, c.ValidFromUtc, c.ValidUntilUtc, * from DistributionOrderStructureGroupContracts dc
join contracts c on c.contractUid = dc.contractUid
join publishers p on p.publisherUid = c.publisherUid
where --c.validUntilUtc is NULL
dc.name like '%histo%' 
and dc.name like '%overdr%'
order by dc.name

select dc.Name, dc.ValidFromUtc, c.ValidFromUtc, c.ValidUntilUtc, * from DistributionOrderStructureGroupContracts dc
join contracts c on c.contractUid = dc.contractUid
join publishers p on p.publisherUid = c.publisherUid
where --c.validUntilUtc is NULL
dc.name like '%histo%' 
and dc.name like '%barnes%' and p.name = 'inscribe digital'
order by dc.name


select dc.Name, dc.ValidFromUtc, c.ValidFromUtc, c.ValidUntilUtc, * from DistributionContracts dc
join contracts c on c.contractUid = dc.contractUid
join publishers p on p.publisherUid = c.publisherUid
where --c.validUntilUtc is NULL
dc.name like '%histo%' 
and dc.name like '%overdr%'
order by dc.name

select dc.Name, dc.ValidFromUtc, c.ValidFromUtc, c.ValidUntilUtc, * from DistributionContracts dc
join contracts c on c.contractUid = dc.contractUid
join publishers p on p.publisherUid = c.publisherUid
where --c.validUntilUtc is NULL
dc.name like '%histo%' 
and dc.name like '%barnes%' and p.name = 'inscribe digital'
order by dc.name



select * from DistributionOrderStructureContracts where DistributionOrderStructureGroupContractUid in ('B65E217D-EC81-4A93-A8D8-364527590954',
'4DDC584E-1B1A-4511-AE54-42146FCCD3CC',
'953D8EF0-8C77-466D-8F76-470A7E3C46AA',
'687B27C3-F94C-46AB-890C-532CC5E45DC1',
'D21690B8-EDFC-4622-B1AA-74B49CF2581E',
'2DDA4D93-C7B7-41ED-9000-8651B1725CBD',
'A6404D55-A9FB-4AD2-B73A-95ED7EDF3462',
'DF9AA02E-D6CF-489A-A03A-A3D5916D72A0',
'8A3021E5-A384-4F24-A919-A4E110726099',
'AA99EAEA-0F71-4041-8047-B5BDAFA0E8D3',
'D64AFE92-C1E0-48E6-806A-DD7E3210CA70',
'EDBCF7B1-0B93-42C9-83CD-DE31476D0B0D',
'12B3A67D-BE1B-4F82-877C-E15B59443B96') order by DistributionOrderStructureGroupContractUid



select * from DistributionOrderStructureGroupContracts where name like '%histo%' and name like '%over%'
--begin tran
--insert AthenaDistribution..DistributionOrderStructureGroupContracts (DistributionOrderStructureGroupContractUid, ContractUid, CreatedAtUtc, ValidFromUtc, ValidUntilUtc, Name, SafeName, Description, IsPartOfBatchAggregate)
select newid(), '115F3C76-9381-43D7-9D1F-C8AC49932589', GETUTCDATE(), '2009-01-01 00:00:00.000',NULL,'OverDrive Product History Ingestion', 'OverDriveProductHistoryIngestion', 'Product History Ingestion', 0

--begin tran
--insert athenadistribution..DistributionContracts (distributionContractuId, [Order], TolerableEventLevels, ContractUid, BatchServiceUid, TransferServiceEndpointUid, CreatedAtUtc, ValidFromUtc, ValidUntilUtc, Name, Safename, Description)
select newid(), 0, 3, '115F3C76-9381-43D7-9D1F-C8AC49932589','80F2760C-E2E1-4966-868F-23E0F28630C4', 'F2E57A10-3587-462F-A185-F7F4F906B16A',getutcdate(), '2009-01-01 00:00:00.000',NULL, 'OverDrive Product History Ingestion Contract','OverDriveProductHistoryIngestionContract', 'Product History Ingestion Contract'
--commit
select * from contracts c
join Retailers r on r.retailerUid = c.retailerUid
where r.name = 'overdrive' order by c.ValidFromUtc
/*
select * from rulesets where rulesetUId = '169A9720-58AA-49AC-8AB0-B1980207F7C5'
select * from contracts where contractUid = 'EBF7220C-E584-4083-9964-5A9B92376504'
select * from publishers where publisherUid = 'B2BD2716-7660-43BA-848A-C3453173D9B9'
select * from retailers where retailerUid = '35C17122-2D6E-4A1A-BCF8-300303293F06'
*/

select r.Name, cp.Name, o.OrganizationName, p.Ordinal, * from product p
left join AthenaDistribution..ProductRevisions pr on pr.ProductUid = p.ProductUid
join DistributionOrders do on do.productrevisionUid = pr.ProductRevisionUid
join Organizations o on o.organizationuid = p.organizationuid
join contracts c on c.contractUid = pr.ContractUid
join retailers r on r.retailerUId = c.retailerUId
join publishers cp on cp.publisherUId = c.publisherUid
--join DistributionContracts dc on dc.contractUid = c.contractUid
where o.organizationname like '%disney%'
and c.validUntilUtc is null
and ordinal = 9781423141013


select * from contracts c 
join publishers p on p.publisherUid = c.publisherUId
join retailers r on r.retailerUid = c.retailerUid
join distributioncontracts dc on dc.contractUId = c.contractUid
where c.contractUId in (
'C8A8EE2D-2D3E-48ED-990C-38DB0ADBEECC',
'D4734128-3E4F-411F-BEC2-790311E581BA',
'0DE39CCB-32D8-4774-AB88-A9542E17770D')

select * from product p
join asset a on a.productUid = p.ProductUid
join assetOverride ao on ao.assetUId = a.assetUid
join assetVersion av on av.AssetOverrideUid = ao.assetoverrideUid
join ProductForms pf on pf.assetVersionUid = av.AssetVersionUid
join ProductFormDetails pd on pd.assetversionUid = av.AssetVersionUid
where ordinal = 9781401388478

select * from TMProductFormType where productformtype = 49

select * from publishers where name like '%disney%'
select * from folderobjects where path like '%9781401388478%'

