/*

Finding Organization Emails - this is where reporting services emails will go

*/

select o.OrganizationName, po.OrganizationName, evv.Value Email,* from Organizations o
join OrganizationEntities oe on oe.OrganizationUid = o.OrganizationUid
join organizations po on po.OrganizationUid = o.ParentOrganizationUid
join EavValueVarchars evv on evv.EntityId = oe.EavEntityId
join EavAttributes ea on ea.EavAttributeId = evv.AttributeId
where ea.EavAttributeName = 'Email'


/*

Finding user emails - this is not used currently

*/


select au.UserName, o.OrganizationName Imprint, po.OrganizationName Parent, am.Email from aspnet_users au
join aspnet_Membership am on am.UserId = au.UserId
join Organizations o on o.OrganizationUid = au.PrimaryOrganizationUid
join organizations po on po.OrganizationUid = o.ParentOrganizationUid


/*

Finding transfer notification emails - this is where transfer notifications will go

*/

select p.Name Contract, r.Name Retailer, tse.[To] Email from TransferServiceEmailEndpoints tse
join DistributionContracts dc on dc.TransferServiceEndpointUid = tse.TransferServiceEndpointUid
join contracts c on c.contractUid = dc.ContractUid
join publishers p on p.PublisherUid = c.PublisherUid
join Retailers r on r.RetailerUid = c.RetailerUid
order by p.Name, r.Name