DECLARE @dt1 DATETIME
DECLARE @dt2 DATETIME

SET @dt1 = '2011-04-15 10:01:13.220'

SELECT
*
FROM
INgroovesLog.dbo.Log
WHERE
At BETWEEN DateAdd(minute, -8, @dt1) AND @dt1