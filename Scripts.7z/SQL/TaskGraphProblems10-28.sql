select s.syndicationlevel, * from syndicationorder so
join syndication s on so.syndication = s.id
where so.orderid in (1000000894902,1000000894899,1000000894894)

select * from musicservicedavepartner where davepartnerid = 182
select * from musicservice where id = 301
Copy Processing OrderBatchID 1000001056534 on Syndication Level 5364 to Media Net / UMG Owned
select * from syndicationorder where orderbatchid = 1000001055178
select * from syndicationorder where orderid = 1000000894902 

exec job_verify 'indma'

select t.description, * from taskgraphcondition tgc
join taskgraphitem tgi on tgi.id = tgc.taskgraphitem
join task t on tgi.task = t.id
where t.description like '%encode%bell%'

select t.description, * from taskgraphcondition tgc
join taskgraphitem tgi on tgi.id = tgc.taskgraphitem
join task t on tgi.task = t.id
where t.description like '%copy%medi%'

--delete from taskgraphcondition where id = 1190035

select * from job where name like '%copy%medi%ne%umg%'
select * from job where name like '%encode%bell%umg%'

select * from instruction

--update job set instruction = null, at = null, indmauser = null, machine = null where id = 1681
--update job set Machine = 'INDMA02' where ID = 978
--update job set Machine = 'INDMA04' where ID = 1942
--update job set Machine = 'INDMA03' where ID = 1915

select * from job where machine = 'indma14'


