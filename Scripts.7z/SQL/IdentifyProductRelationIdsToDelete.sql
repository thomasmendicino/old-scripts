;WITH DuplicateProductRelations AS
(
	SELECT pr.ProductIdentifierId 
	FROM ProductRelation pr
	GROUP BY 
        pr.ProductRelationType
        ,pr.ProductUid
        ,pr.ProductIdentifierId
	HAVING count(*) > 1
),
ProductIdsWithPprViolations AS
(
	SELECT dpr.ProductIdentifierId
	FROM DuplicateProductRelations dpr
	INNER JOIN ProductRelation pr 
        ON pr.ProductIdentifierId = dpr.ProductIdentifierId
	INNER JOIN PprViolations ppr 
        ON ppr.ProductRelationId = pr.ProductRelationId
),
Ranking AS
(
    SELECT
        ROW_NUMBER()
            OVER (PARTITION BY pr.ProductIdentifierId ORDER BY pr.ProductRelationId ASC) AS ProductRelationRank
        ,ProductRelationId
        ,pr.ProductIdentifierId
        ,pr.ProductUid
        ,pr.ProductRelationType
    FROM
        DuplicateProductRelations dpr
        INNER JOIN ProductRelation pr
            ON pr.ProductIdentifierId = dpr.ProductIdentifierId
)
SELECT PR.*
FROM Ranking
INNER JOIN ProductRelation PR
	ON PR.ProductRelationId = Ranking.ProductRelationId
LEFT OUTER JOIN ProductIdsWithPprViolations Ppr
	ON Ppr.ProductIdentifierId = Ranking.ProductIdentifierId
INNER JOIN Product P
    on p.ProductUid = 
ORDER BY 
    Ranking.ProductIdentifierId
    ,ProductRelationRank
    
********

use AthenaProductCatalog
;WITH DuplicateProductRelations AS
(
    SELECT pr.ProductUId 
    FROM ProductRelation pr
    GROUP BY 
       pr.ProductRelationType
       ,pr.ProductUid
       ,pr.ProductIdentifierId
    HAVING count(*) > 1
)
SELECT DISTINCT P.Ordinal
FROM Product P
INNER JOIN ProductRelation PR
   ON PR.ProductUid = P.ProductUid
INNER JOIN DuplicateProductRelations DPR
   ON DPR.ProductUid = PR.ProductUid
******