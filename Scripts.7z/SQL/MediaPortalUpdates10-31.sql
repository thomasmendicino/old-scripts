select syndicatortype, fields, * from musicservice where name like '%youtube%'

select * from syndicatortype where id = 316

select * from indmauser where name like '%chiquita%'
select * from 

c939677c33deb69a3186cd1731aa0285
a6befb6906135dae2b1d84face333eb6


--Old: 7B64A658917A8DB51DEF18437A248459
--begin tran
--commit
--rollback

--update INDMAUser set Password = '7B64A658917A8DB51DEF18437A248459' where id = 4056
select * from musicservice where name = 'Ingroovesmobilewav'

select * from album where gtin = '00044003133136'
select * from albumasset where album = 171494
select * from track where album = 171494
select * from song where id in (select song from track where album = 171494)
select * from song where id 
select * from songasset where song in (select song from track where album = 171494)
select * from assets where id in (196721,353666)
select * from songoverrides where song = 1143217
select * from media where id in (113281,113282)

/images/covers/HAS\2011\04\11\02\CoverArt_10FONIM10670_nZB6d.jpg

select defaultcountry, * from album where gtin = '00044003133136'
select * from albumoverrides where album = (select id from album where gtin = '00044003133136') and country = 34
select * from track where album = 171494
select * from trackoverrides where track in (select id from track where album = (select id from album where gtin = '00044003133136')) and country = 34
select * from trackoverrides where track in (select id from track where album = 171494) and country = 34
select * from song where id in (select song from track where album = 171494)
select * from song where id in (select song from track where album = 160387)
select * from songoverrides where song in (select song from track where album = 171494) and country = 34

select * from organization where id = 31914
--begin tran
--rollback
--commit
update song set 
--Organization = 31914, 
Mix = 'Music Video', 
Explicit = 1, 
--Performer = 'Pusha T',
 Genre = 11, 
 Cline = '(C) 2011 G.O.O.D. Music / Decon / Re-Up Gang', 
 OffsiteFile = 0, 
 MediaPortalIncomplete = 0 
 where ID in (2552039,2552040,2552041)
 update song set offsitefile = 0 where id = 2552042
--update song set /*Organization = 31914, */Mix = 'Behind The Scenes Video', Explicit = 1, /*Performer = 'Pusha T', */Genre = 11, Cline = '(C) 2011 G.O.O.D. Music / Decon / Re-Up Gang', OffsiteFile = 0, MediaPortalIncomplete = 0 where ID in (2552042)


--begin tran
--commit
--rollback
--update track set Fields = '<Document><String name="umgOwningTerritory" value="US" /><Integer name="umgAccountID" value="-1" /></Document>', DistributionSet = 110, UMGRightTypeCore = 3, UMGLabelCore = 9255, UMGLabelLocal = 366, UMGOwningTerritory = 'US' where ID in (2505085,2505086,2505087,2505088,2505089,2505090,2505091,2505092,2505093,2505094,2505095,2505096)
--update track set Fields = '<Document><String name="umgOwningTerritory" value="US" /><Integer name="umgAccountID" value="-1" /><Node name="associatedProducts" /><Node name="associatedTracks" /><String name="originalProgramming" value="" /><String name="liveStudio" value="" /><String name="videoCategory" value="Music Video" /></Document>', DistributionSet = 110, UMGRightTypeCore = 3, UMGLabelCore = 9255, UMGLabelLocal = 366, UMGOwningTerritory = 'US' where ID in (2527452,2527453,2527454)
--update track set Fields = '<Document><String name="umgOwningTerritory" value="US" /><Integer name="umgAccountID" value="-1" /><Node name="associatedProducts" /><Node name="associatedTracks" /><String name="originalProgramming" value="" /><String name="liveStudio" value="" /><String name="videoCategory" value="Behind the Scenes" /></Document>', AlbumOnly = 1, DistributionSet = 110, UMGRightTypeCore = 3, UMGLabelCore = 9255, UMGLabelLocal = 366, UMGOwningTerritory = 'US' where ID in (2527455)

--update album set Fields = '<Document><String name="exclusivityNotes" value="ITunes Exclusive" /><Integer name="umgAccountID" value="4" /><Boolean name="umgThirdParty" value="true" /><Boolean name="umgDeliverToYouTube" value="true" /><String name="umgOwningTerritory" value="US" /><Boolean name="iTunesSellPlusQuality" value="true" /></Document>', ReleaseDate = '2011-11-08 00:00:00.000', /*Organization = 31914, */CLine = '(C) 2011 G.O.O.D. Music / Decon / Re-Up Gang', PLine = '(P) 2011 G.O.O.D. Music / Decon / Re-Up Gang', SalesStartDate = '2011-11-08 00:00:00.000', UMGProductType = 62, UMGLabelCore = 9260, UMGLabelLocal = 366, UMGThirdParty = 1, UMGAccount = 4, UMGOwningTerritory = 'US' where gtin = '00850717002732'

declare @gtin nvarchar (14)
declare @AlbumCelebrity int
set @gtin = '00850717002732'
set @AlbumCelebrity = (select Celebrity from AlbumCelebrity where Album = (select id from Album where gtin = '00850717002732') and country = (select defaultcountry from album where gtin = @gtin))
insert AlbumCelebrity (Album, Celebrity, Role)
select (select ID from album where gtin = @gtin), @AlbumCelebrity, (select role from AlbumCelebrity where Album = (select id from album where gtin = @gtin) and country = (select defaultcountry from album where gtin = @gtin))

if not exists (select NULL from ALbumGenre where Album = (select id from album where gtin ='00850717002732') and genre = 655)
begin
insert AlbumGenre (Album, Genre, Sequence)
select (select ID from album where gtin = '00850717002732'), 655, 1
end





select * from song where id in (select song from track where album in (select id from album where gtin in ('00044003151727',
'00044003153837',
'00850717002442',
'00850717002732',
'00044003150621',
'00044003150676',
'00850717002657',
'00044003153264',
'00850717001834')))

select * from song where isrc = 'USZXT1060591'

select * from changerequest cr
join album a on a.id = cr.album
join changerequestbatch crb on cr.changerequestbatch = crb.id
join changerequestimportlogbatch crilb on crilb.changerequestbatch = crb.id
join importlog il on il.id = crilb.importlog
left join importlogentry ile on ile.importlog = il.id
where a.gtin = '00044003133136'

select 


select * from musicservice where distributionset = 1 and name like '%ing%'

select * from distributionsetitem where distributionset = 2822

select * from album where gtin = '881034922632'
select distributionset, * from track where album = 318512
select * from song where id = (select song from track where album = 318512)
select * from songcut where  song = (select song from track where album = 318512)


select * from changerequest cr
join album a on a.id = cr.album
left join changerequestimportlogbatch crilb on crilb.changerequestbatch = cr.id
left join importlog il on il.id = crilb.importlog
left join importlogentry ile on ile.importlog = il.id
where a.gtin like '%881034922632%'


select top 50 * from autosynclog where stagingpath like '%881034922632%'

select * from album where gtin = '881034922632'
select * from album where gtin = '881034753922'
select * from albumproducttype where album in (select ID from album where gtin in ('881034753922','881034922632'))

select * from importlogentry where destinationid = (select id from album where gtin = '881034922632')
select * from importlog where id in (select importlog from importlogentry where destinationid = (select id from album where gtin = '881034922632'))

select * from distributiontype

select count(*) from album where distributionset = 1

select id from song where resourcetype = 2

select * from track where album = 272293 --song = 887727 
select * from track where song in (select ID from song where resourcetype = 2 and path is not null) and track != 1 and fields is not null
select * from track where album = 305390
select * from song where id in (select song from track where album = 160387)
select * from media where id in (113281,113282)