USE [AthenaProductCatalog]
GO

/****** Object:  UserDefinedFunction [dbo].[CSVCountryList]    Script Date: 8/17/2015 1:30:17 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[CSVCountryList] 
(
	@CSUid nvarchar(100)
)
RETURNS NVARCHAR(1000)
AS
BEGIN

	DECLARE @counter int
	SELECT @counter = len(CountryList) from CountrySETs where CountrySETUid = @csUid
	SET @counter = @counter * 1.5
	DECLARE @iter int
	SET @iter = 0 
	DECLARE @list nvarchar(1000)
	DECLARE @string nvarchar(1000)
	SELECT @list = CountryList from CountrySets where CountrySETUid = @csUid
	
	while @iter < @counter - 3
	BEGIN
		SET @list = (SELECT stuff(@list,3+@iter,0,',') from CountrySETs where CountrySETUId = @csUid)
		SET @iter = @iter + 3
		IF (@iter >= @counter)
			BREAK
		ELSE
			CONTINUE
	END
	set @string = @list
RETURN @string
END


GO


