--RESTORE DATABASE INgrooves FROM DATABASE_SNAPSHOT = 'ingrooves_20110506_1530'

/*--Test to see if sales_snapshot0600 exists and if it 
-- does, delete it.
IF EXISTS (SELECT dbid FROM 
    WHERE NAME='ingrooves_20110507_1330')
    DROP DATABASE ingrooves_20110507_1330;
GO
-- Reverting Sales to sales_snapshot1200
USE master;
RESTORE DATABASE Ingrooves FROM DATABASE_SNAPSHOT = 'ingrooves_20110506_1530';
GO

USE master
GO
RESTORE DATABASE RegularDB
FROM DATABASE_SNAPSHOT = 'SnapshotDB';
GO
*/
DROP database [ingrooves_20110507_1330]