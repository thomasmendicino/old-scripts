--step1
USE AthenaQA02Security;
GO

SET NOCOUNT ON

IF object_ID('dbo.base64_encode') IS NOT NULL
DROP FUNCTION [dbo].[base64_encode]
GO

CREATE FUNCTION [dbo].[base64_encode] (@data VARBINARY(MAX))
RETURNS VARCHAR(MAX) WITH SCHEMABINDING,
	RETURNS NULL ON NULL INPUT 
	BEGIN 
		RETURN
			( SELECT [text()] = @data
			FOR XML PATH('') ) 
	END 

GO
----step 2
IF object_ID('dbo.CreateUser') IS NOT NULL
DROP PROCEDURE [dbo].[CreateUser]
GO

CREATE PROCEDURE [dbo].[CreateUser] 
  @UserName nvarchar(256)
, @ClearTextPassword nvarchar(128)
, @Email nvarchar(1000)
, @pUserId uniqueidentifier


AS

BEGIN

DECLARE @ApplicationName nvarchar(256)
DECLARE @PasswordFormat int
DECLARE @UnencodedSalt uniqueidentifier
DECLARE @Password nvarchar(128)
DECLARE @PasswordSalt nvarchar(128)
DECLARE @Now DATETIME
DECLARE @UniqueEmail int
DECLARE @UserId uniqueidentifier

SET @ApplicationName = '/' --Find in aspnet_Applications.ApplicationName 
SET @PasswordFormat = 1 
SET @UnencodedSalt = NEWID()
SET @PasswordSalt = dbo.base64_encode(@UnencodedSalt)
SET @Password = dbo.base64_encode(HASHBYTES('SHA1', 
   CAST(@UnencodedSalt as varbinary(MAX)) 
   + CAST(@ClearTextPassword AS varbinary(MAX)) )) 
SET @Now = getutcdate()
SET @UniqueEmail = 0
SET @UserId=@pUserId

--BEGIN TRANSACTION

--DECLARE @UserId uniqueidentifier

EXECUTE [dbo].[aspnet_Membership_CreateUser] 
   @ApplicationName
  ,@UserName
  ,@Password
  ,@PasswordSalt
  ,@Email
  ,NULL
  ,NULL
  ,1 -- IsApproved == true
  ,@Now
  ,@Now
  ,@UniqueEmail
  ,@PasswordFormat
  ,@UserId OUTPUT

--COMMIT  

END

GO   

--step 3
IF OBJECT_ID('tempdb.dbo.#TempUserInfo') IS NOT NULL
DROP TABLE #TempUserInfo
GO

CREATE TABLE #TempUserInfo (OrganizationName nvarchar(200), UserName nvarchar(100), ClearTextPassword nvarchar(100), Email nvarchar(1000), ErrorMessage nvarchar(1000),UserId uniqueidentifier)

BULK INSERT #TempUserInfo --(OrganizationName, UserName, ClearTextPassword, Email)
FROM 'C:\Tools\UserNames.csv'
WITH (FORMATFILE='C:\Tools\TestFormatFile.xml',
firstrow = 2)
  
--select * from #TempUserInfo

DECLARE @UserId uniqueidentifier
DECLARE @OrganizationName nvarchar(200)
DECLARE @UserName nvarchar(100)
DECLARE @ClearTextPassword nvarchar(100)
DECLARE @Email nvarchar(1000)
DECLARE @PrimaryOrganizationUid uniqueidentifier
DECLARE @Permissions table (ID int, Name nvarchar(100))
DECLARE @EavEntityId int
DECLARE @NewLine1 char(1) = CHAR(13)
DECLARE @NewLine2 char(1) = CHAR(10)

UPDATE #TempUserInfo
SET Email = REPLACE(REPLACE(Email, @NewLine1, ''),@NewLine2, '')

INSERT @Permissions (ID, Name)
VALUES('1','AssetApprove'),
('2','AssetReject'),
('14','FileDownloadCover'),
('15','FileDownloadEbook'),
('16','FileDownloadMetadata'),
('17','FileViewCoverart'),
('18','FileViewEbook'),
('19','FileViewMetadata'),
('20','ModuleCatalog'),
--('21','ModuleConfiguration'),
--('22','ModuleEventlog'),
('23','ModuleHelp'),
('24','ModuleIngestion'),
('25','ModuleReports'),
('26','ModuleUploads'),
--('27','ModuleUsermanagement'),
('28','ReportsDownloadConversion'),
('29','ReportsDownloadDistribution'),
('30','ReportsDownloadIngestion'),
('31','ReportsViewConversion'),
('32','ReportsViewDistribution'),
('33','ReportsViewIngestion'),
('34','StartConversion'),
('35','StartUpload'),
('36','UploadsViewConsole'),
('37','UploadsViewConversionhouse'),
('38','UploadsViewFtp'),
('39','UploadsViewReports'),
--('40','ModuleDistribution'),
('41','PacketApprove'),
('42','PacketSuppress'),
('43','RetryFailedIngestions'),
('44','DistributionStatus'),
('45','DownloadProductBulk'),
('46','ModuleAssetReview')


DECLARE UserCursor CURSOR LOCAL FOR
SELECT UserName, ClearTextPassword, Email, OrganizationName FROM #TempUserInfo

OPEN UserCursor
FETCH NEXT FROM UserCursor INTO @UserName, @ClearTextPassword, @Email, @OrganizationName

WHILE @@FETCH_STATUS = 0
BEGIN
	
	BEGIN TRY

	SET @UserId = NewId()
	
	SELECT @PrimaryOrganizationUid = OrganizationUid FROM Organizations WHERE OrganizationName = @OrganizationName
	
		PRINT 'Creating User ' + @UserName + ' for Primary Organization ' + @OrganizationName

		EXECUTE [dbo].[CreateUser] @UserName,@ClearTextPassword,@Email,@UserId
	
		INSERT INTO aspnet_UsersInRoles
			VALUES(
				(select roleID from [dbo].[aspnet_Roles] where RoleName='AthenaUsers'), 
				@UserId)
		INSERT INTO aspnet_UsersInRoles
			VALUES(
				(select roleID from [dbo].[aspnet_Roles] where RoleName='IdentityServerUsers'), 
				@UserId)
		INSERT INTO aspnet_UsersInRoles
			VALUES(
				(select roleID from [dbo].[aspnet_Roles] where RoleName='AthenaManagers'), 
				@UserId)

		/*
		Add Permissions
		*/
 
		INSERT INTO UserPermissions (UserUid, Permission)
		SELECT @UserId, ID FROM @Permissions

		/*
		Add associations to children of primary organization
		*/

		;WITH Children AS
			(SELECT po.OrganizationUid 
			FROM Organizations po
			WHERE OrganizationUid = @PrimaryOrganizationUid
			UNION ALL
			SELECT o.OrganizationUid
			FROM Organizations o
				INNER JOIN Children c on c.OrganizationUid = o.ParentOrganizationUid)
		INSERT INTO UserOrganizations (UserUid, OrganizationUid)
		SELECT @UserId, o.OrganizationUid
		FROM Children c
			INNER JOIN Organizations o on o.OrganizationUid = c.OrganizationUid

		/*
		Add UserEntities
		*/

		INSERT EavEntities DEFAULT VALUES;
		SET @EavEntityId = SCOPE_IDENTITY()

		INSERT UserEntities (UserUid, EavEntityId, EavAttributeSetId)
		select @UserId, @EavEntityId, 1 --User Profile
								
		UPDATE [dbo].[aspnet_Users]
		SET PrimaryOrganizationUid = @PrimaryOrganizationUid
		WHERE UserName = @UserName

		UPDATE #TempUserInfo 
		SET UserId = @UserId 
		WHERE UserName = @UserName
		
	END TRY
	
	BEGIN CATCH
	
		UPDATE #TempUserInfo
		SET ErrorMessage = ERROR_MESSAGE()
		WHERE UserName = @UserName
	
	END CATCH

FETCH NEXT FROM UserCursor INTO @UserName, @ClearTextPassword, @Email, @OrganizationName

END

CLOSE UserCursor
DEALLOCATE UserCursor