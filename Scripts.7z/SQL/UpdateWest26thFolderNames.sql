--begin tran
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyOneWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentyOneWest26thStreetPress' WHERE Name = 'Client Console: 21 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyOneWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentyOneWest26thStreetPress' WHERE Name = 'Conversion House: 21 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyOneWest26thStreetPress/FTP', SafeName = 'FtpTwentyOneWest26thStreetPress' WHERE Name = 'FTP: 21 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyOneWest26thStreetPress/Migration', SafeName = 'MigrationTwentyOneWest26thStreetPress' WHERE Name = 'Migration: 21 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyOneWest26thStreetPress/Reports', SafeName = 'ReportsTwentyOneWest26thStreetPress' WHERE Name = 'Reports: 21 West 26th Street Press'

update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyTwoWest26thStreetPress/ClientConsole', SafeName = 'ClientConsoleTwentyTwoWest26thStreetPress' WHERE Name = 'Client Console: 22 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyTwoWest26thStreetPress/ConversionHouse', SafeName = 'ConversionHouseTwentyTwoWest26thStreetPress' WHERE Name = 'Conversion House: 22 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyTwoWest26thStreetPress/FTP', SafeName = 'FtpTwentyTwoWest26thStreetPress' WHERE Name = 'FTP: 22 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyTwoWest26thStreetPress/Migration', SafeName = 'MigrationTwentyTwoWest26thStreetPress' WHERE Name = 'Migration: 22 West 26th Street Press'
update ImportFolderConfigurations SET Path = 'inscribe-master--1\Uploads/TwentyTwoWest26thStreetPress/Reports', SafeName = 'ReportsTwentyTwoWest26thStreetPress' WHERE Name = 'Reports: 22 West 26th Street Press'


--begin tran
update Publishers set SafeName = 'TwentyTwoWest26thStreetPress' WHERE Name = '22 West 26th Street Press'
update Publishers set SafeName = 'TwentyOneWest26thStreetPress' WHERE Name = '21 West 26th Street Press'