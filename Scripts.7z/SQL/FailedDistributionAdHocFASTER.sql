
USE AthenaComposite;
SET NOCOUNT ON 

DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @ISBNs table (ISBN bigint)
DECLARE @pacificTime int
DECLARE @DistributionTitles table (Title nvarchar(200), OrgUid uniqueidentifier, ISBN bigint, OnSaleDate datetime,    ProductUid uniqueidentifier,    RetailerUid uniqueidentifier,    Retailer nvarchar(50),    ProcessedAtUtc datetime,    distributionOrderUId uniqueidentifier)
DECLARE @DistributionDataSet table (FailedDate datetime, Code nvarchar(10), TheReason nvarchar(1000), DistributionOrderUId uniqueidentifier, [Rank] smallint)
DECLARE @Publisher nvarchar(200) = NULL
DECLARE @Retailer table (RetailerCode nvarchar(5))
DECLARE @ReasonString nvarchar(max) = NULL
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime

/*  ------
	Set the Start and End time range to gather failed distribution from
	-------
*/
SET @DateRangeStart = getutcdate()-10
SET @DateRangeEnd = getutcdate()

/*	------
	OPTIONAL: Set the Publisher name to be searched. Using the top level publisher will include imprints. Leave NULL to search all.
	------
*/
/*
SET @Publisher = ''

*/
/*	------
	OPTIONAL: Set the Retailers to check. Use retailer CODES, not names.
	------
*/

--INSERT @Retailer (RetailerCode)
--SELECT Code from dbo.Retailers WHERE Code NOT in ('INX')


/*	------
	OPTIONAL: Use a set of ISBNs to query. 
	------
*/
/*
INSERT @ISBNs (ISBN)
SELECT Ordinal from dbo.Product WHERE Ordinal in (
9781849460330,
9781849465045)
*/
/*	------
	OPTIONAL: Filter to a single failure reason string.
	Example: 'Transfer failed' or 'Physical price rules violation'
	------
*/

SET @ReasonString = NULL--'Acceptability%Overlapping price intervals found%'
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****/

DECLARE @ProductFormDetailFixed int = 5201
DECLARE @ProductFormDetailReflowable int = 5200
DECLARE @TitleTypeCodeDistinctiveTitle int = 1
DECLARE @TitleElementLevelCollection int = 2
DECLARE @LatestOrders TABLE 
    (Publisher nvarchar(100)
    , Title nvarchar(200)
    , OrgUid uniqueidentifier
    , ISBN bigint
    , OnSaleDate datetime
    , ProductUid uniqueidentifier
    , RetailerUid uniqueidentifier
    , Retailer nvarchar(100)
    , FailedDate datetime
    , DistributionOrderUid uniqueidentifier
    , Series nvarchar(200)
    , ContentType char(30)
    , ProductRevisionUid uniqueidentifier)

IF OBJECT_ID('tempdb..#Results') IS NOT NULL 
BEGIN
    DROP TABLE #Results
END

;WITH LatestProcessingTimestamp 
AS 
( 
    SELECT 
        MAX(ProcessedAtUtc) AS [MaxProcessedAtUTC]
        , pr.ProductUid
        , r.Name 
    FROM 
        DistributionOrderStatus dos
            INNER JOIN DistributionOrders do 
                ON do.distributionOrderUId = dos.DistributionOrderUId
            INNER JOIN ProductRevisions pr 
                ON pr.productRevisionUId = do.productRevisionUId
            INNER JOIN Contracts c 
                ON c.contractUid = pr.contractUId
            INNER JOIN Retailers r 
                ON r.retailerUId = c.retailerUid
            INNER JOIN Product p 
                ON p.ProductUid = pr.ProductUid
        WHERE
            ((SELECT TOP 1 1 from @ISBNs) IS NULL OR p.Ordinal in (SELECT ISBN from @ISBNs))
           	AND ((@Publisher IS NULL) OR p.OrganizationUid in (select organizationUId from OrgHierarchy(@Publisher)))
			AND ((SELECT TOP 1 1 from @Retailer) IS NULL OR r.Code in (SELECT RetailerCode from @Retailer))
            AND dos.ResultingEvent = 103 -- Distribution Order Created
        GROUP BY 
            pr.ProductUid, r.Name
        HAVING 
            MAX(ProcessedAtUtc) > ISNULL(@DateRangeStart,'1900-01-01')
)
, FailedOrders 
AS
(
    SELECT 
        do.DistributionOrderUid
        , dos.ProcessedAtUtc
    FROM 
        DistributionOrders do
            INNER JOIN DistributionOrderStatus dos 
                ON dos.distributionOrderUid = do.distributionOrderUId
            INNER JOIN productRevisions pr 
                ON pr.productRevisionUId = do.productRevisionUId
            INNER JOIN contracts c 
                ON c.contractUid = pr.contractUId
            INNER JOIN retailers r 
                ON r.retailerUId = c.retailerUid
            INNER JOIN LatestProcessingTimestamp m 
                ON m.ProductUid = pr.productUid 
                AND m.Name = r.Name 
                AND m.MaxProcessedAtUTC = dos.ProcessedAtUTC
    WHERE 
        dos.ResultingEvent = 103 -- Distribution Order Created
		AND EXISTS 
            (SELECT 1 
            FROM DistributionOrderStatus dos2 
            WHERE do.DistributionOrderUid = dos2.DistributionOrderUid
                AND dos2.ResultingEventLevel = 4) --ERROR Event Level
)
INSERT @LatestOrders 
    (ISBN
    ,ProductUid
    , Publisher
    , Retailer
    , RetailerUid
    , FailedDate
    , DistributionOrderUId)
SELECT DISTINCT
    p.Ordinal as ISBN,
    p.ProductUid,
    pub.Name Publisher,
    r.Name Retailer,
    r.RetailerUid,
    f.ProcessedAtUtc as FailedDate,
    F.distributionOrderUId
FROM
    DistributionOrderStatus dos
        INNER JOIN DistributionOrders do 
            ON do.DistributionOrderUid = dos.DistributionOrderUid
        INNER JOIN ProductRevisions pr 
            ON pr.ProductRevisionUid = do.ProductRevisionUid
        INNER JOIN Publishers pub 
            ON pub.PublisherUid = pr.PublisherUid
        INNER JOIN Contracts c 
            ON c.ContractUid = pr.ContractUid
        INNER JOIN Retailers r 
            ON r.RetailerUid = c.RetailerUid
        INNER JOIN Product p 
            ON p.ProductUid = pr.ProductUid
        INNER JOIN FailedOrders f 
            ON f.DistributionOrderUid = do.DistributionOrderUid
WHERE
    (@DateRangeStart is NULL OR dos.ProcessedAtUtc >= @DateRangeStart) -- Check the date range of the distribution
    AND (@DateRangeEnd is NULL OR dos.ProcessedAtUtc <= @DateRangeEnd)
	
;WITH AcceptabilityReasonsCte
AS 
(
    SELECT DISTINCT
        retdoa.Code ReasonCode,
        SUBSTRING(coalesce(doac.ResultingMessage, retdoa.Title), 0, 2045) 
            + CASE WHEN len(doac.ResultingMessage) > 2045 THEN '...' ELSE '' END
        as ReasonDetail,
        lo.DistributionOrderUid,
        2 as Significance, 
        CASE WHEN regdoa.Name = 'ExcludedByMetadata' THEN 'Excluded by Metadata' ELSE 'Distribution Failures' END as ReasonGroup,
        r.Path as Filename
    FROM @LatestOrders lo
    INNER JOIN DistributionOrderAcceptabilities doac on doac.DistributionOrderUid = lo.DistributionOrderUid
    LEFT JOIN ProductRevisionStructures prs on doac.ProductRevisionStructureId = prs.ProductRevisionStructureId
    LEFT JOIN Resources r on prs.ResourceUid = r.ResourceUid
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = doac.ResultingEvent
    LEFT JOIN refEventGroup regdoa ON retdoa.EventGroupId = regdoa.EventGroupId
    WHERE doac.ResultingEventLevel > 2
        AND retdoa.Code NOT IN ('DIDC')--, 'REM')
),
DistributionReasonsCTE -- latest distribution order structures dates per product
AS
(
    SELECT DISTINCT
        retdoa.Code ReasonCode,
        SUBSTRING(coalesce(dos.ResultingMessage, retdoa.Title), 0, 2045) 
            + CASE WHEN len(dos.ResultingMessage) > 2045 THEN '...' ELSE '' END
        as ReasonDetail,
        lo.DistributionOrderUid,
        1 as Significance,
        CASE WHEN regdoa.Name = 'ExcludedByMetadata' THEN 'Excluded by Metadata' ELSE 'Distribution Failures' END as ReasonGroup,
        null as Filename
    FROM @LatestOrders lo
    INNER JOIN DistributionOrderStatus dos on dos.DistributionOrderUid = lo.DistributionOrderUid
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = dos.ResultingEvent
    LEFT OUTER JOIN refEventGroup regdoa ON retdoa.EventGroupId = regdoa.EventGroupId
    WHERE dos.ResultingEventLevel = 4 -- Error
        AND retdoa.Code NOT IN ('DIDC')--, 'REM', 'DINA')   -- DIDC - Not distributed based on contract
),
ReasonsCte
AS
(
    select * from AcceptabilityReasonsCte
    union
    select * from DistributionReasonsCTE
),
MainReasonsCte
AS
(
    SELECT
        r.* 
    FROM 
        ReasonsCte r
    INNER JOIN 
        (
            SELECT DistributionOrderUid
                , MAX(Significance) Significance
            FROM ReasonsCte
            GROUP BY DistributionOrderUid
        ) ms ON ms.DistributionOrderUid = r.DistributionOrderUid and ms.Significance = r.Significance
)
SELECT
    Publisher
    , ISBN
    , COALESCE(cte.TitleText, ISNULL(cte.TitlePrefix + ' ', '') + cte.TitleWithoutPrefix, ctd.TitleStatement) AS Series
    , COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title
    , Filename  
    , CASE pfd.ProductFormDetailValue 
          WHEN @ProductFormDetailFixed THEN 'Fixed' 
          WHEN @ProductFormDetailReflowable THEN 'Reflowable'
          ELSE 'Not Specified' 
      END AS ContentType
    , coalesce(pd.Value, pdEmbargo.Value) AS OnSaleDate
    , Retailer
    , FailedDate
    , mr.ReasonCode
    , mr.ReasonDetail
    , mr.ReasonGroup
    , mr.DistributionOrderUid
INTO #Results
FROM MainReasonsCte mr WITH (NOLOCK)
    INNER JOIN  @LatestOrders lo 
        ON lo.DistributionOrderUid = mr.DistributionOrderUid
    INNER JOIN asset a 
        ON a.productUid = lo.productUid
    CROSS APPLY 
        (SELECT TOP 1 AssetOverrideUid
         FROM AssetOverride 
         WHERE AssetUid = a.AssetUid
         Order BY RetailerUid) ao
    INNER JOIN assetVersion av 
        ON av.assetOverrideUid = ao.assetOverrideUId
    INNER JOIN TitleDetails td 
        ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te 
        ON te.TitleDetailId = td.TitleDetailId
    LEFT OUTER JOIN Collections col 
        ON av.AssetVersionUid = col.AssetVersionUid
        AND col.CollectionId = 
            (
                SELECT TOP 1 CollectionId
                FROM Collections
                WHERE AssetVersionUid = av.AssetVersionUid
                ORDER BY CollectionId ASC
            )
    INNER JOIN productForms pf 
        ON pf.assetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN TitleDetails ctd 
        ON col.CollectionId = ctd.CollectionId
    LEFT OUTER JOIN TitleElements cte 
        ON ctd.TitleDetailId = cte.TitleDetailId
    LEFT OUTER JOIN PublishingDates pd 
        ON pd.AssetVersionUid = av.AssetVersionUid 
        AND pd.PublishingDateRole = 1  -- Main publishing date
    LEFT OUTER JOIN PublishingDates pdEmbargo 
        ON pdEmbargo.AssetVersionUid = av.AssetVersionUid 
        AND pdEmbargo.PublishingDateRole = 2 -- Embargo date
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (@ProductFormDetailFixed, @ProductFormDetailReflowable)
WHERE
    av.ValidUntilUtc is NULL
    AND coalesce(pd.Value, pdEmbargo.Value) is not null   -- Either PublicationDate or Embargo Date should be not null
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleElementLevel = 1                          -- Product Level 
    AND (ctd.TitleTypeCode = @TitleTypeCodeDistinctiveTitle OR ctd.TitleTypeCode IS NULL)   -- TitleTypeCode.DistinctiveTitle
    AND (cte.TitleElementLevel = @TitleElementLevelCollection OR cte.TitleElementLevel IS NULL) -- TitleElementLevelCode.Collection
    AND (@OnSaleDateRangeStart is NULL OR pd.Value >= @OnSaleDateRangeStart)  -- Check the On sale date range
    AND (@OnSaleDateRangeEnd is NULL OR pd.Value <= @OnSaleDateRangeEnd)
    AND pf.ProductFormTypeValue IN (49, 50, 51, 52, 59, 60, 61 )       -- Digital products: EA, EB, EC, ED, LA, LB, LC
    
SELECT DISTINCT 
    Publisher
    , ISBN
    , Series
    , Title
    , Filename
    , ContentType
    , OnSaleDate
    , Retailer
    , FailedDate
    , ReasonCode
    , REPLACE(REPLACE(ReasonDetail,CHAR(13),''),CHAR(10),'') ReasonDetail
    , ReasonGroup
FROM 
(
    -- Leave REM errors in the report but trim out any other validations per retailer per ISBN where an REM exists
    SELECT * FROM #Results where ReasonCode = 'REM' -- Include all REMs
    UNION 
    SELECT * FROM #Results where DistributionOrderUid NOT IN ( SELECT DistributionOrderUid FROM #Results where ReasonCode = 'REM' )
) r
WHERE
(@ReasonString is NULL OR ReasonDetail like '%' + @ReasonString + '%')
AND ReasonCode NOT IN ('EBM','MM','CIM','ITE','CIVF','PPR','EAVE','REM')
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC,
    ReasonCode
