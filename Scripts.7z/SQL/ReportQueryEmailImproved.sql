USE AthenaComposite;
if object_ID ('tempdb..#ReportResultsEM') is not null
drop table #ReportResultsEM
GO
if object_ID ('tempdb..#ErrFile') is not null
drop table #ErrFile
GO
--select * from #ReportresultsEM
declare @DeliveryExtension nvarchar(50) = 'Report Server Email'

create table #ReportResultsEM (ID int identity(1,1), Report nvarchar(100), Schedule nvarchar(100), SubscriptionUid uniqueidentifier, [To] nvarchar(2000), ReplyTo nvarchar(200), IncludeReport nvarchar(10), IncludeLink nvarchar(10), RenderFormat nvarchar(10), Subject nvarchar(500), Priority nvarchar(15), Organization uniqueidentifier, PublisherUid uniqueidentifier, Filename nvarchar(100), DateRangeStart datetime, DateRangeEnd datetime, Comment nvarchar(max), ContentTypes nvarchar(max), RetailerName nvarchar(max))
CREATE TABLE #ErrFile (ExecError INT)
declare @cmds table (command nvarchar(max), report nvarchar(200), Schedule nvarchar(200), SubscriptionID uniqueidentifier)
declare @cmd nvarchar(max), @ExecError INT
declare @IdStart int
declare @IdEnd int
declare @report nvarchar(100) = ''
declare @SubscriptionId uniqueidentifier
declare @schedule nvarchar(100) = ''
declare @queryToRun table (SubscriptionId uniqueidentifier, Query nvarchar(max))
insert @cmds (command, report, Schedule, SubscriptionID)
select substring(cast(DataSettings as nvarchar(max)),(charindex('<CommandText>',cast(DataSettings as nvarchar(max))) + 13),(charindex('</CommandText>',cast(DataSettings as nvarchar(max))) - charindex('<CommandText>',cast(DataSettings as nvarchar(max))) - 13)) command,
	c.Name Report
	, sc.Name Schedule
	, s.SubscriptionID
from ReportServer..Subscriptions s
	join ReportServer..reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
	join ReportServer..Schedule sc on sc.scheduleId = rs.ScheduleId
	join ReportServer..Catalog c on c.ItemId = s.Report_OID
where DeliveryExtension = @DeliveryExtension
	AND (@schedule = '' OR sc.Name = @schedule)
	AND (@report = '' OR c.Name = @report)
	AND s.DataSettings IS NOT NULL
	AND c.Name <> 'New Publishers Email'
	
declare query_cursor cursor local for
select command, report, schedule, SubscriptionID from @cmds

open query_cursor
FETCH next from query_cursor into @cmd, @report, @schedule, @subscriptionId
while @@fetch_status=0
begin
select @cmd = replace(replace(replace(@cmd,'replace(rtc.Name + ''_'' + SUBSTRING(replace(replace(replace(CONVERT(varchar,GETDATE(),120),''-'',''''),'':'',''''),'' '',''''),0,11),'' '','''') as  [Filename],','/*replace(rtc.Name + ''_'' + SUBSTRING(replace(replace(replace(CONVERT(varchar,GETDATE(),120),''-'',''''),'':'',''''),'' '',''''),0,11),'' '','''') as  [Filename],*/'),'&gt;','>'),'&lt;','<')

if @report in ('Preorder Status')
	begin
		select @IdStart = isnull(max(ID),0) + 1 from #ReportResultsEM
		insert #ReportResultsEM ([To], ReplyTo, IncludeReport, IncludeLink, RenderFormat, Subject, Priority, Organization, PublisherUid, DateRangeStart, DateRangeEnd)
		exec (@cmd)
		set @IdEnd = SCOPE_IDENTITY()
		set @ExecError = (SELECT * FROM #ErrFile)
		update #ReportResultsEM set Report = @report, Schedule = @schedule, SubscriptionUid = @SubscriptionId where ID BETWEEN @IdStart and @IdEnd
	END
else if @report = 'New Publishers Email'
	BEGIN
		select @IdStart = isnull(max(ID),0) + 1 from #ReportResultsEM
		insert #ReportResultsEM ([To], ReplyTo, IncludeReport, IncludeLink, RenderFormat, Subject, Priority, DateRangeStart, DateRangeEnd, Comment, RetailerName)
		exec (@cmd)
		set @IdEnd = SCOPE_IDENTITY()
		set @ExecError = (SELECT * FROM #ErrFile)
		update #ReportResultsEM set Report = @report, Schedule = @schedule, SubscriptionUid = @SubscriptionId where ID BETWEEN @IdStart and @IdEnd
	END
else if @report = 'APC Ready-Review Changes'
	BEGIN
		--select @IdStart = isnull(max(ID),0) + 1 from #ReportResultsEM
		--insert #ReportResultsEM ([To], ReplyTo, IncludeReport, IncludeLink, RenderFormat, Subject, Priority, DateRangeStart, DateRangeEnd, Comment, RetailerName)
		--exec (@cmd)
		--set @IdEnd = SCOPE_IDENTITY()
		--set @ExecError = (SELECT * FROM #ErrFile)
		--update #ReportResultsEM set Report = @report, Schedule = @schedule, SubscriptionUid = @SubscriptionId where ID BETWEEN @IdStart and @IdEnd
		print 'apc ready-review'
	END
ELSE
	begin 
		select @IdStart = isnull(max(ID),0) + 1 from #ReportResultsEM
		insert #ReportResultsEM ([To], ReplyTo, IncludeReport, IncludeLink, RenderFormat, Subject, Priority, Organization, PublisherUid, DateRangeStart, DateRangeEnd, Comment, ContentTypes)
		exec (@cmd)
		set @IdEnd = SCOPE_IDENTITY()
		set @ExecError = (SELECT * FROM #ErrFile)
		update #ReportResultsEM set Report = @report, Schedule = @schedule, SubscriptionUid = @SubscriptionId where ID BETWEEN @IdStart and @IdEnd
	end

delete from #ErrFile

fetch next from query_cursor into @cmd, @report, @schedule, @subscriptionId
end

select 
	p.Name Publisher, po.OrganizationName Parent, c.Name Report, sc.Name Schedule, replace(SUBSTRING(s.DataSettings,CHARINDEX('@IntervalDays INT = ',cast(s.DataSettings as NVARCHAR(MAX))) + 21,2),'''','') as IntervalDays, s.Description, s.LastRunTime, LastStatus, [To] Recipient, ReplyTo, em.ContentTypes
from #ReportResultsEM em
	join ReportServer..Subscriptions s on s.subscriptionId = em.SubscriptionUid
	join ReportServer..reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
	join ReportServer..Schedule sc on sc.scheduleId = rs.ScheduleId
	join ReportServer..Catalog c on c.ItemId = s.Report_OID
	left join AthenaComposite..publishers p on p.publisherUid = em.PublisherUid
	left join AthenaComposite..organizations o on o.organizationUid = p.OrganizationUid
	left join AthenaComposite..organizations po on po.OrganizationUid = o.ParentOrganizationUid
ORDER by p.Name, c.Name
--commit

CLOSE query_cursor 
   DEALLOCATE query_cursor 

