declare @OverdriveUid uniqueidentifier 
select @OverdriveUid = RetailerUid from Retailers where Name = 'overdrive'
declare @productChangeTypes table(Name varchar(50), Value int)
insert into @productChangeTypes values ('NewProduct', 1)
insert into @productChangeTypes values ('AssetUpdate', 2)
insert into @productChangeTypes values ('MetadataUpdate', 4)
insert into @productChangeTypes values ('Takedown', 8)
insert into @productChangeTypes values ('PartialTakedown', 16)
insert into @productChangeTypes values ('Preorder', 32)
insert into @productChangeTypes values ('Embargo', 64)
insert into @productChangeTypes values ('PriceCampaign', 128)
insert into @productChangeTypes values ('IBookstoreBibliographicChange', 256)
insert into @productChangeTypes values ('ManualReviewRequired', 512)
insert into @productChangeTypes values ('ManualReviewApproved', 1024)
insert into @productChangeTypes values ('ManualReviewRejected', 2048)

;with OverdriveDelivered as (
select distinct p.Ordinal from product p 
join productRevisions pr on pr.productUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join DistributionOrderStructureGroups dsg on dsg.distributionOrderUid = do.DistributionOrderUid
join DistributionOrderStructureGroupBatches dsb on dsb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join DistributionOrderStatus dos on dos.distributionOrderUid = do.DistributionOrderUid
join contracts c on c.ContractUid = pr.contractUid
join DistributionContracts dc on dc.DistributionContractUid = dsg.DistributionContractUid
where c.RetailerUid = @OverdriveUid
and dos.ResultingEvent = 110)
--select * from OverdriveDelivered
,LatestWasTakedown as (
select distinct p.ordinal from product p
join OverdriveDelivered od on od.Ordinal = p.Ordinal
join productRevisions pr on pr.productUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join (select p2.ordinal, max(do.CreatedAtUtc) At
from product p2
join productRevisions pr on pr.productUid = p2.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join OverdriveDelivered od on od.ordinal = p2.ordinal
left join productRevisionStructures prs on prs.ProductRevisionUid = pr.ProductRevisionUid
cross join @productChangeTypes ct
where 
pr.ChangeType & ct.Value <> 0
group by p2.Ordinal) a on a.Ordinal = p.ordinal and a.At = do.CreatedAtUtc
where pr.ChangeType = 8)

select av.AssetVersionUid as AssetVersionsToBeRefreshed, p.Ordinal as ProductsToGetNewProductRevisionCreatedForOVD from product p
join asset a on a.productUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join OverdriveDelivered od on od.ordinal = p.ordinal
WHERE av.ValidUntilUtc is NULL and a.ResourceContentType = 100
AND p.Ordinal not in (select Ordinal from LatestWasTakedown)
AND (ao.RetailerUid = @OverdriveUid or (ao.RetailerUid is null and not exists(select 1 from AssetOverride ao where ao.RetailerUid = @OverdriveUid and ao.assetUid = a.assetUid)))