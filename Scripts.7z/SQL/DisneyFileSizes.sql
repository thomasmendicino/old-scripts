use AthenaComposite;

declare @Disney table (orgUid uniqueidentifier)

declare @organizationName nvarchar(100)
select @organizationname = 'disney publishing worldwide, inc.'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @Disney
select organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select '00000000-0000-0000-0000-000000000001'

;with ProductTitles as (
select distinct Ordinal, 
COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title
from Product p
join Asset a on a.ProductUid = p.ProductUid
join AssetOverride ao ON ao.AssetUid = a.AssetUid
	and ao.AssetOverrideUid = 
	(
		SELECT TOP 1 AssetOverrideUid
		FROM AssetOverride
		WHERE AssetUid = a.AssetUid 
		ORDER BY RetailerUid -- it puts the NULL retailer override on the top
	)
join AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
join TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
join TitleElements te ON te.TitleDetailId = td.TitleDetailId and te.TitleElementId = (select top 1 TitleElementId from TitleElements where TitleDetailId = td.TitleDetailId order by len(TitleText) desc)
join @Disney d on d.orgUid = p.OrganizationUid
where av.ValidUntilUtc is NULL
and te.TitleElementLevel = 1
)
select p.Ordinal ISBN, o.OrganizationName Imprint, pt.Title, tat.AssetTypeText AssetType, rc.Name ContentType, 
case when ao.RetailerUid is NULL then 'N'
else 'Y' end as RetailerSpecificAsset,
isnull(ret.Name ,'') as Retailer, 
case 
when len(r.Length) between 4 and 6 then cast(cast(r.Length / 1024.00 as decimal(18,2)) as nvarchar(max)) + ' KB'
when len(r.Length) between 7 and 9 then cast(cast(r.Length / (1024.00 * 1024) as decimal(18,2)) as nvarchar(max)) + ' MB'
when len(r.Length) between 10 and 12 then cast(cast(r.Length / (1024.00 * 1024 * 1024) as decimal(18,2)) as nvarchar(max)) + ' GB'
else cast(cast(r.Length as decimal(18,2)) as nvarchar(max)) + ' B'
end as FileSize, 
cast(cast(r.Length / 1024.00 as decimal(18,2)) as nvarchar(max)) as SizeInKB,
cast(cast(r.Length / (1024.00 * 1024) as decimal(18,2)) as nvarchar(max)) as SizeInMB,
r.Length as SizeInBytes
from product p
join asset a on a.ProductUid = p.ProductUid
join assetOverride ao on ao.assetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join resources r on r.resourceUid = av.ResourceUid
join refassetType tat on tat.AssetTypeId = a.AssetType
join @Disney d on d.orgUid = p.OrganizationUid
join TMResourceContentType rc on rc.ResourceContentType = a.ResourceContentType
join ProductTitles pt on pt.Ordinal = p.Ordinal
left join retailers ret on ret.RetailerUid = ao.RetailerUid
join Organizations o on o.organizationUid = p.OrganizationUid
where av.ValidUntilUtc is NULL
and rc.Name in ('FullContent','SampleContent')
and (tat.AssetTypeText like '%EPUB%' or tat.AssetTypeText like '%EPIB%')
order by p.ordinal, ret.Name, rc.Name, tat.AssetTypeText


--2795
/*
--select * from @Disney
*/

select * from TitleDetails where AssetVersionUid = '80BE2B19-E73A-47A4-8797-BED1D663638A'

'73AC6CD5-0E11-4D76-A43B-8BD50FBA2569'
'B4AD2013-E2DC-4FCD-9C06-F348133B7C95'
/*
select fo.* from ImportFolderConfigurations ic
join @Disney d on d.orgUid = ic.OrganizationUid
join folderobjects fo on fo.ImportFolderConfigurationUid = ic.ImportFolderConfigurationUid
where fo.path like '%sample%'
and fo.Path not like '%_SampleContent%'
--and fo.path like '%9781484717530%'
--and 
--fo.path like '%9781423181361%'
--20150129.8\--_sample_epib.epub
/*
select * from product p
join asset a on a.ProductUid = p.ProductUid
join assetOverride ao on ao.assetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join resources r on r.resourceUid = av.ResourceUid
where ordinal = 9781484717530
*/
--20150331.2\9781423176763_sample.epub --> Needs sample file and full content file reingested
--20150331.2\9781423176718_sample.epub --> Sample file needs reingested
--20150313.2\9781484742860_SampleConten_sample_epib.epub --> No action required
--20150331.2\9781423176725_sample.epub --> Sample file needs reingested

1. Identify all Disney files that were uploaded with '%sample%' in the name, but NOT '_SampleContent'
2. Those are mostly epibs. There are 4 titles that need manual attention, and may possibly have the wrong file as full content. I will address those, but I think there shouldnt be others
3. Look up all files that were fulfilled to BNO with Sample in the name. If the most recent sampleContent had an upper case S, that will need redistributed. If the most recent was a lower case s then we should be good


select * from AthenaAssetProcessor..folderobjects where path like '%9781423176763%'
*/

select 2078948
select 2078948 / 1024
select cast(2078948 / 1024 / 1024 as float(2))
select 2078948 / (1024.00)
select cast(2078948 / (1024.00 * 1024) as decimal(18,2))
select 2078948 / (1024.00 * 1024 * 1024)



