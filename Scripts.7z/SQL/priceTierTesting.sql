select * from priceTierMappingType where name = 'ebookWholesalePrice'

select * from priceTier order by id desc

select * from priceTier where name like '%ebookWholes%'

select top 1500 * from priceCampaign order by id desc

select * from priceTier where id =1122

select * from album where id = 555028

9781780782096

select a.bigintgtin, pt.ID, pt.Name, pmt.Name, c.Name, pv.AlbumPrice, pc.* from priceTier pt
join priceTierMapping pm on pm.priceTier = pt.id
join priceTierMappingValue pv on pv.id= pm.PriceTierMappingValue
join priceTierMappingType pmt on pmt.id = pv.PriceTierMappingType
join priceCampaign pc on pc.StartPriceTier = pt.id
join album a on a.id = pc.album
join currency c on c.id = pv.Currency
where a.id in (555034,
391266,
391266,
391266,
391266,
485287) order by a.bigintgtin, c.Name

select * from athenaImport order by id desc
where filePath like '%9781599793016%'

select * from importLogEntry where Sourceid = '9781599793016'

select a.bigintgtin, pt.ID, pt.Name, pmt.Name, c.Name, pv.AlbumPrice, cn.A2, pc.* from priceTier pt
join priceTierMapping pm on pm.priceTier = pt.id
join priceTierMappingValue pv on pv.id= pm.PriceTierMappingValue
join priceTierMappingType pmt on pmt.id = pv.PriceTierMappingType
join priceCampaign pc on pc.StartPriceTier = pt.id
join album a on a.id = pc.album
join currency c on c.id = pv.Currency
join country cn on cn.id = pc.country
where a.gtin = '9780486151861'-- and country is null
and c.Name = 'United States Dollars'
order by a.bigintgtin, A2, c.Name
9780486797281.onix
9780486151861.onix
9780486121598.onix
select * from album where gtin = '9780810980105'

6,284,613
243 
2,147,483,647
   13,574,613
30,000
select * from priceCampaign where album = 555036
select top 5 * from trendTransaction order by id desc
select * from priceTier where id in (1043,
1047,
1340,
1045)

select * from taskType
select * from taskQueueItem
select * from taskNode where id = 6392882
select * from task where id = 6396700
select * from taskType where id = 49
--update taskType set EnableStart = 1 where id = 49

