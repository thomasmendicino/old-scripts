--begin tran
;with oldAsset as
(select min(aa.Asset) [AssetId] from albumAsset aa
join album a on a.id = aa.album
join assets at on at.id = aa.asset
where isPrimary=1
 and AssetType = (select id from AssetType where Name='Syndication Album Art')
 AND (aa.MusicService IS NULL AND aa.Country IS NULL)
 group by 
 album
having count(asset) > 1)
--update aa set isPrimary = 0 from albumAsset aa
join oldAsset oa on oa.AssetId = aa.Asset
--commit


select a.GTIN, ae.[FileName], ae.Description, at.*, ae.* from album a 
join albumasset at on at.album = a.id
join assets ae on ae.id = at.asset
where a.id in (429370)
and at.isPrimary = 1
order by a.gtin, ae.Id asc

select
 album
 , count(distinct asset)
from AlbumAsset aa
 inner join Assets ast on aa.Asset=ast.ID
where isPrimary=1
 and AssetType = (select id from AssetType where Name='Syndication Album Art')
 AND (aa.MusicService IS NULL AND aa.Country IS NULL)
group by 
 album
having count(asset) > 1


select *from syndicationorder where orderstate in (11,12,15) and partnername like '%rdio%'

select * from trendstatement order by At desc