
IF OBJECT_ID('tempdb.dbo.#AthenaMigratedOrgs') is not null DROP TABLE #AthenaMigratedOrgs
CREATE TABLE #AthenaMigratedOrgs (Org int, MigratedAt datetime)


INSERT #AthenaMigratedOrgs (Org, MigratedAt)
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Charisma House'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Publicaciones Casa'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Christian Life'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Realms'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Siloam'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Casa Creaci�n'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Creation House'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Excel Books'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Frontline'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Passio'
UNION
SELECT ID, '2013-08-13 00:00:00.000' from Organization WHERE Name = 'Charisma Media'
UNION
SELECT ID, '2013-08-19 00:00:00.000' from Organization WHERE Name = 'Courier'
UNION
SELECT ID, '2013-08-19 00:00:00.000' from Organization WHERE Name = 'Dover Publications'
UNION
SELECT ID, '2013-08-19 00:00:00.000' from Organization WHERE Name = 'Research & Education Association'
UNION
SELECT ID, '2013-08-19 00:00:00.000' from Organization WHERE Name = 'Creative Homeowner'