select a.GTIN, ct1.Name [Video Category], ct2.Name [Asset Category], vt.Name [VidType], ay.Name [AssetType], rt.Name [AssetResource] from album A
join track t on t.album = a.id
join song s on t.song = s.id
join albumAsset aa on aa.album = a.id
join categoryType ct1 on ct1.id = s.categoryType
join assets at on at.id = aa.asset
join categoryType ct2 on ct2.id = at.CategoryType
join VideoType vt on vt.id = s.videoType
join AssetType ay on ay.id = at.assetType
join resourceType rt on rt.id = at.ResourceType
where vt.Name = 'Concert film' order by a.GTIN

/*

And orders that have concert films



select ob.* from [order] o
join ordercountry oc on oc.[order] = o.id
join orderalbum oa on oa.ordercountry = oc.id
join orderitem oi on oi.orderalbum = oa.id
join orderbatch ob on ob.id = oi.orderbatch
join album a on a.id = oa.album
where a.gtin in (select a.GTIN from album A
join track t on t.album = a.id
join song s on t.song = s.id
join albumAsset aa on aa.album = a.id
join categoryType ct1 on ct1.id = s.categoryType
join assets at on at.id = aa.asset
join categoryType ct2 on ct2.id = at.CategoryType
join VideoType vt on vt.id = s.videoType
join AssetType ay on ay.id = at.assetType
join resourceType rt on rt.id = at.ResourceType
where vt.Name = 'Concert film') and o.id > 1000002000000
order by ob.insertedAt desc


*/