select a.Name [Title], rtrim(GTIN) [ISBN], c.Name [Author], o.Name [Publisher/Imprint] from album a 
inner join AthenaImport AI on a.gtin = reverse(substring(reverse(FilePath),6,13))
inner join organization o on o.id = a.organization
inner join AlbumCelebrity ac on ac.album = a.id
inner join Celebrity c on c.id = ac.Celebrity
inner join Role r on r.id = ac.Role
where r.Name = 'Main Artist'
and AI.InitialImportAt > getdate()-7