declare @OverdriveUid uniqueidentifier 
select @OverdriveUid = RetailerUid from Retailers where Name = 'overdrive'
;with OverdriveDelivered as (
select distinct p.Ordinal, max(dos.ProcessedAtUtc) LatestDelivered from product p 
join productRevisions pr on pr.productUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join DistributionOrderStructureGroups dsg on dsg.distributionOrderUid = do.DistributionOrderUid
join DistributionOrderStructureGroupBatches dsb on dsb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join DistributionOrderStatus dos on dos.distributionOrderUid = do.DistributionOrderUid
join contracts c on c.ContractUid = pr.contractUid
join DistributionContracts dc on dc.DistributionContractUid = dsg.DistributionContractUid
where c.RetailerUid = @OverdriveUid
and dos.ResultingEvent = 110
group by Ordinal)

select * from product p
join OverdriveDelivered od on od.ordinal = p.ordinal
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join assetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
where av.ValidUntilUtc is NULL
and av.validFromUtc between '2015-06-03' and '2015-07-24'
and a.ResourceContentType = 100
AND (ao.RetailerUid = @OverdriveUid or (ao.RetailerUid is null and not exists(select 1 from AssetOverride ao2 where ao2.RetailerUid = @OverdriveUid and ao2.assetUid = a.assetUid)))