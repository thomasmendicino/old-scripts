select * from album where gtin = '00888072303904'
select * from changerequest where album = 72391
select * from changerequestbatch where id in (select changerequestbatch from changerequest where album = 72391)
select * from changerequestimportlogbatch where changerequestbatch in (select id from changerequestbatch where id in (select changerequestbatch from changerequest where album = 72391))
select * from importlog where id in (43918,82404,94651,282084)
select * from importlogentry where importlog in (43918,82404,94651,282084)
select * from album where gtin = '00888072308114'
select * from album where gtin = '00888072303911'

select * from track where album = (select id from album where gtin = '00888072303911')
select * from importlogentry where importitemtype = 2 and destinationid = 2315912

select * from track where album = 72391
select * from song where id in (select song from track where album = 72406)
select * from track where album = 72406
select * from song where isrc in ('USFI89500119','USFI87000105')
select * from song where isrc = 'USFI86900025'
select isrc, * from song where id in (2315912,2315913,632038,632033) order by name
select * from process
select top 100 * from changerequest where album = 72391 and processedat between '2011-07-15 16:50:02.090' and '2011-07-15 16:59:02.090'
select top 500 * from ingroovesaudit.dbo.form where at between '2011-07-15' and '2011-07-16'
select top 500 * from ingroovesaudit.dbo.transfer

select * from track where album = 72391
select * from album where id = 72391
select * from song where isrc = 'USFI87000105'
select * from song where isrc = 'USFI87000193'
select * from song where isrc = 'USFI86900025'
select * from track where song in (632038,2315912)
select * from syndicationorder where orderbatchid = 1000001012612
select * from syndicationordereventlog where syndicationorder = 84682
Missing master path for element. Album 00888072303911, Track USFI87000105

--begin tran
--commit
--rollback
/*
delete from pricecampaign where track in (select id from track where album = 72406 and song in (select id from song where isrc in ('USFI89500119','USFI87000105') and path is null))
delete from track where album = 72406 and song in (select id from song where isrc in ('USFI89500119','USFI87000105') and path is null)
delete from songcelebrity where song in (select id from song where isrc in ('USFI89500119','USFI87000105') and path is null)
delete from credit where song in (select id from song where isrc in ('USFI89500119','USFI87000105') and path is null)
delete from song where isrc in ('USFI89500119','USFI87000105') and path is null

*/
select * from song where isrc in ('USFI89500119','USFI87000105') and path is null
select * from track where album = 72406 and song in (select id from song where isrc in ('USFI89500119','USFI87000105') and path is null)
select top 50 * from pricecampaign where track in (select id from track where album = 72406 and song in (select id from song where isrc in ('USFI89500119','USFI87000105') and path is null))
select * from songcelebrity where song in (select id from song where isrc in ('USFI89500119','USFI87000105') and path is null)
select * from credit where song in (select id from song where isrc in ('USFI89500119','USFI87000105') and path is null)

select * from song where isrc in ('USFI89500119','USFI87000105')

select * from track where id in (2292554,2292555)

select * from tracksyndication where track in (2292554,2292555)
select * from song where id in (select song from track where album = 72391)
select * from syndication where id in (select syndication from tracksyndication where track = 2329522)
select * from song where isrc in ('USFI80700546')

select * from albumproducttype
select * from producttype

select * from musicserviceproducttype
select * from syndicatortype where name like '%r2%'

select * from musicservice where syndicatortype = 234
select * from autosynclog where stagingpath like '%00888072303904%'
select * from autosynclog where id = 76782
select top 50 * from importlog where
select top 50 * from 

