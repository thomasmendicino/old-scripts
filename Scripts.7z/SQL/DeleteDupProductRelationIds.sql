--BEGIN TRAN
--ROLLBACK
--COMMIT
USE AthenaProductCatalog;
;WITH DuplicateProductRelations AS
(
	SELECT pr.ProductIdentifierId 
	FROM ProductRelation pr
	GROUP BY 
        pr.ProductRelationType
        ,pr.ProductUid
        ,pr.ProductIdentifierId
	HAVING count(*) > 1
),
ProductRelationIdsWithPprViolations AS
(
	SELECT ppr.ProductRelationId
	FROM DuplicateProductRelations dpr
	INNER JOIN ProductRelation pr 
        ON pr.ProductIdentifierId = dpr.ProductIdentifierId
	INNER JOIN PprViolations ppr 
        ON ppr.ProductRelationId = pr.ProductRelationId
),
Ranking AS
(
    SELECT
        ROW_NUMBER()
            OVER (PARTITION BY pr.ProductIdentifierId ORDER BY pr.ProductRelationId ASC) AS ProductRelationRank
        ,ProductRelationId
        ,pr.ProductIdentifierId
        ,pr.ProductUid
        ,pr.ProductRelationType
    FROM
        DuplicateProductRelations dpr
        INNER JOIN ProductRelation pr
            ON pr.ProductIdentifierId = dpr.ProductIdentifierId
)
DELETE PR
FROM Ranking
INNER JOIN ProductRelation PR
	ON PR.ProductRelationId = Ranking.ProductRelationId
LEFT OUTER JOIN ProductRelationIdsWithPprViolations Ppr
	ON Ppr.ProductRelationId = Ranking.ProductRelationId
WHERE Ppr.ProductRelationId IS NULL
AND Ranking.ProductRelationRank > 1
--ORDER BY 
--    Ranking.ProductIdentifierId
--    ,ProductRelationRank