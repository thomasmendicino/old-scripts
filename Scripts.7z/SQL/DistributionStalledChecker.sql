
SET NOCOUNT ON
DECLARE @Times table (FolderObject datetime, DOSat datetime, BatchAt datetime)
;with MostRecentFolderObjectAt as (
select top 1 dateadd(hh,-7,fo.CreatedAtUtc) FolderObjectAt from folderobjects fo
join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
where ic.name not like '%report%' and ic.Name not like '%migrat%'
and fo.CreatedAtUtc between getUTCdate()-4 and GETUTCDATE()
order by CreatedAtUtc desc),
MostRecentDistributionOrderStatusAt as (
select top 1 dateadd(hh,-7,CreatedAtUtc) DOSAt
from DistributionOrderStatus 
where CreatedAtUtc between GETUTCDATE()-4 and GETUTCDATE()
order by CreatedAtUtc desc),
MostRecentBatchStatusAt as (select top 1 dateadd(hh,-7,CreatedAtUtc) BatchStatusAt 
from BatchStatus 
where CreatedAtUtc between GETUTCDATE()-4 and GETUTCDATE()
order by CreatedAtUtc desc)
insert @Times (FolderObject, DOSat, BatchAt)
select (select FolderObjectAt from MostRecentFolderOBjectAt), (select DOSAt from MostRecentDistributionOrderStatusAt), (select BatchStatusAt from MostRecentBatchStatusAt)
--select * from @Times
IF (select datediff(minute,DOSat, FolderObject) as timediff from @Times) > 30
begin 
IF (select datediff(minute,BatchAt, FolderObject) as timediff from @Times) > 30
BEGIN
RAISERROR ('Distribution is STALLED!',16,1)
END
END
