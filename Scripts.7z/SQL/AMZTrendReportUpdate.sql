
select * from TrendTransaction where TrendStatement = 22029
--delete from TrendTransaction where TrendStatement = 22030
--delete from TrendStatement where id = 22030
select * from TrendStatement order by id desc

select * from TrendTransaction where TrendStatement = 22030
select * from TrendTransaction where TrendStatement = 22025

select * from TrendFileConfiguration c
join TrendFileHeader h on h.TrendFileConfiguration = c.id
where c.name like '%amazon%gb%'

--begin tran
--update c set PreHeaderSize = 1 from TrendFileConfiguration c
--join TrendFileHeader h on h.TrendFileConfiguration = c.id
--where c.name = 'Amazon eBookBase Daily US'

--update c set HeaderSize = 7 from TrendFileConfiguration c
--join TrendFileHeader h on h.TrendFileConfiguration = c.id
--where c.name = 'Amazon eBookBase Daily US'

--ROLLBACK
--commit
--begin tran
--update h set Position = Position + 1
--from TrendFileConfiguration c
--join TrendFileHeader h on h.TrendFileConfiguration = c.id
--where c.name = 'Amazon eBookBase Daily US'
--and Position > 8 

--insert TrendFileHeader (TrendFileConfiguration, [Column], Map, Position)
--select 17, 'Currency','Currency',9




select * from TrendFileConfiguration c
join TrendFileHeader h on h.TrendFileConfiguration = c.id
where c.name = 'Amazon eBookBase Daily US'

select * from Transformer
/*
update c set ReplaceChar = '$' from TrendFileConfiguration c
join TrendFileHeader h on h.TrendFileConfiguration = c.id
where c.name = 'Amazon eBookBase Daily US'
*/


UPDATE TrendFileConfiguration SET HeaderSize = 7 WHERE Name = 'Amazon eBookBase Daily US'

IF NOT EXISTS (SELECT 1 FROM TrendFileHeader
	INNER JOIN TrendFileConfiguration
		ON TrendFileConfiguration.ID = TrendFileHeader.TrendFileConfiguration
WHERE TrendFileConfiguration.Name = 'Amazon eBookBase Daily US'
	AND [Column] = 'Currency')
BEGIN
	UPDATE TrendFileHeader 
		SET Position = Position + 1 
	FROM TrendFileHeader
		INNER JOIN TrendFileConfiguration
			ON TrendFileConfiguration.ID = TrendFileHeader.TrendFileConfiguration
	WHERE TrendFileConfiguration.Name = 'Amazon eBookBase Daily US'
		AND Position > 8
	
	IF NOT EXISTS (SELECT 1 FROM TrendFileHeader
		INNER JOIN TrendFileConfiguration
			ON TrendFileConfiguration.ID = TrendFileHeader.TrendFileConfiguration
	WHERE TrendFileConfiguration.Name = 'Amazon eBookBase Daily US'
		AND Position = 9)
	BEGIN
		INSERT TrendFileHeader (TrendFileConfiguration, [Column], Map, Position)
		SELECT ID, 'Currency', 'Currency', 9 
		FROM TrendFileConfiguration
		WHERE Name = 'Amazon eBookBase Daily US'
	END
END


/*

Time for Amazon GB
*/

DECLARE @TrendFileConfigurationName NVARCHAR(200)
SET @TrendFileConfigurationName = 'Amazon eBookBase Daily GB'

--Update header names and mappings
UPDATE [TrendFileHeader]
	SET	[Column] = 'ASIN',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 1
UPDATE [TrendFileHeader]
	SET	[Column] = 'ASIN name',
		[Map] = 'Album'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 2
UPDATE [TrendFileHeader]
	SET	[Column] = 'ID type',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 3
UPDATE [TrendFileHeader]
	SET	[Column] = 'External ID',
		[Map] = 'GTIN'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 4
UPDATE [TrendFileHeader]
	SET	[Column] = 'Product group',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 5
UPDATE [TrendFileHeader]
	SET	[Column] = 'Release date',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 6
UPDATE [TrendFileHeader]
	SET	[Column] = 'Customer Orders',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 7
UPDATE [TrendFileHeader]
	SET	[Column] = 'Units shipped',
		[Map] = 'Quantity'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 8
UPDATE [TrendFileHeader]
	SET	[Column] = 'Shipped COGS',
		[Map] = 'Revenue'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 9
UPDATE [TrendFileHeader]
	SET	[Column] = 'Units returned by customers',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 10
UPDATE [TrendFileHeader]
	SET	[Column] = 'Category',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 11
UPDATE [TrendFileHeader]
	SET	[Column] = 'Sub-category',
		[Map] = ''
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 12
UPDATE [TrendFileHeader]
	SET	[Column] = 'Author/Artist/Actor',
		[Map] = 'Artist'
	FROM [TrendFileConfiguration]
	INNER JOIN [TrendFileHeader]
		ON [TrendFileHeader].[TrendFileConfiguration] = [TrendFileConfiguration].[ID]
	WHERE [TrendFileConfiguration].[Name] = @TrendFileConfigurationName
		AND [TrendFileHeader].[Position] = 13

UPDATE TrendFileConfiguration SET HeaderSize = 7 WHERE Name = 'Amazon eBookBase Daily GB'

IF EXISTS (SELECT 1 FROM TrendFileHeader
	INNER JOIN TrendFileConfiguration
		ON TrendFileConfiguration.ID = TrendFileHeader.TrendFileConfiguration
	WHERE TrendFileConfiguration.Name = 'Amazon eBookBase Daily GB'
		AND Position > 13)
BEGIN
	DELETE TrendFileHeader FROM TrendFileHeader 
		INNER JOIN TrendFileConfiguration
			ON TrendFileConfiguration.ID = TrendFileHeader.TrendFileConfiguration
	WHERE TrendFileConfiguration.Name = 'Amazon eBookBase Daily GB'
		AND Position > 13
END

UPDATE TrendFileHeader SET 