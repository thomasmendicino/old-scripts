declare	@Interval int = 5

	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED	


DECLARE @DateRangeStart DATETIME 
DECLARE @DateRangeEnd DATETIME 
DECLARE @NewLineChar AS CHAR(2) = CHAR(13) + CHAR(10)

SET @DateRangeStart = Dateadd(dd, -@Interval, Getutcdate()) 
SET @DateRangeEnd = Getutcdate(); 

WITH distributiontitles 
     AS (SELECT pr.productuid, 
                p.ordinal               AS ISBN, 
                r.NAME                  AS Retailer, 
                r.retaileruid, 
                Max(dos.processedatutc) AS ProcessedAtUtc 
         FROM   Athenacomposite..distributionorderstatus dos 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.distributionorderuid = dos.distributionorderuid 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productrevisionuid = do.productrevisionuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                INNER JOIN Athenacomposite..retailers r 
                        ON r.retaileruid = c.retaileruid 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = pr.productuid 
                INNER JOIN Athenacomposite..asset a 
                        ON a.productuid = p.productuid 
                CROSS apply (SELECT TOP 1 assetoverrideuid 
                             FROM   Athenacomposite..assetoverride 
                             WHERE  a.assetuid = assetuid 
                             ORDER  BY retaileruid ASC) ao 
                INNER JOIN Athenacomposite..assetversion av 
                        ON av.assetoverrideuid = ao.assetoverrideuid 
                INNER JOIN Athenacomposite..productforms pf 
                        ON pf.assetversionuid = av.assetversionuid 
         WHERE  pf.productformtypevalue IN ( 49, 50, 51, 52 ) 
		 AND p.Ordinal in (
		 9781613720127,
9781613720813,
9781613726594,
9781613728055,
9781613728215,
9781613728451,
9781613728468,
9781613728628,
9781613728901,
9781613729144,
9781613729359,
9781613729373,
9781613729533,
9781615812899,
9781615812905,
9781615813049,
9781615813254,
9781615813278,
9781615813384,
9781615814169,
9781615814466,
9781615814473,
9781615814565,
9781615815555,
9781615819317,
9781623800031,
9781623801090,
9781623801861,
9781623802189,
9781623803032,
9781623803049,
9781623803537,
9781623803544,
9781623803728,
9781623803742,
9781623803810,
9781623804350,
9781623804794,
9781623805289,
9781623805388,
9781623805395,
9781623805425,
9781623805494,
9781623805500,
9781623805524,
9781623805685,
9781623805692,
9781623805753,
9781623806804,
9781623807474,
9781623807528,
9781623807603,
9781623807627,
9781623807634,
9781623807726,
9781623808907,
9781623809584,
9781627980753,
9781627981194,
9781627981439,
9781627982702,
9781627984690,
9781627985611,
9781627985628,
9781627986106,
9781627986113,
9781627986243,
9781627987660,
9781627987769,
9781627987776,
9781627987783,
9781627987790,
9781627988612,
9781627988629,
9781627988995,
9781627989695,
9781627989701,
9781627989718,
9781627989725,
9781627989787,
9781627989794,
9781627989848,
9781627989862,
9781627989893,
9781632160256,
9781632160263,
9781632163172,
9781632163257,
9781632163264,
9781632163271,
9781632163288,
9781632163295,
9781632163301,
9781632163318,
9781632163325,
9781632163332,
9781632163349,
9781632163356,
9781632163363,
9781632163370,
9781632163387,
9781632163394,
9781632163400,
9781632163417,
9781632163424,
9781632163431,
9781632163448,
9781632163455,
9781632163462,
9781632163479,
9781632163486,
9781632163493,
9781632163509,
9781632163516,
9781632163523,
9781632163530,
9781632163547,
9781632164353,
9781632164391,
9781632164407,
9781632164414,
9781632164421,
9781632164438,
9781632164445,
9781632164452,
9781632164469,
9781632164599,
9781632165657,
9781632165978,
9781632165992,
9781632166456,
9781632166463,
9781632166661,
9781632166678,
9781632166845,
9781632166852,
9781632166869,
9781632166876,
9781632167873,
9781632167880,
9781632167897,
9781632167903,
9781632167910,
9781632167927,
9781632167934,
9781632167941,
9781632167958,
9781632167965,
9781632167972,
9781632167989,
9781632167996,
9781632168009,
9781632168054,
9781632168788,
9781632168795,
9781632168801,
9781632168818,
9781632169457,
9781632169495,
9781632169501,
9781632169518,
9781632169525,
9781632169532,
9781632169549,
9781632169556,
9781632169587,
9781632169754,
9781632169761,
9781634760164,
9781634760171,
9781634760331,
9781634760348,
9781634760461,
9781634760492,
9781634760508,
9781634760539,
9781634760584,
9781634760591,
9781634760607,
9781634760621,
9781634760638,
9781634761062,
9781634761079,
9781634761086,
9781634761093,
9781634761109,
9781634761116,
9781634761130,
9781634761192,
9781634761208,
9781634761215,
9781634761222,
9781634761536,
9781634761574,
9781634761581,
9781634761598,
9781634761604,
9781634761611,
9781634761628,
9781634761635,
9781634761659,
9781634761666,
9781634761673,
9781634761680,
9781634761697,
9781634761703,
9781634761710,
9781634761727,
9781634761734,
9781634761741,
9781634761901,
9781634761918,
9781634761925,
9781634761932,
9781634763271,
9781634763318,
9781634763325,
9781634763424,
9781634763431,
9781634763448,
9781634763455,
9781634763462,
9781634763479,
9781634763509,
9781634763516,
9781634763530,
9781634763547,
9781634763554,
9781634763592,
9781634763622,
9781634763639,
9781634763646,
9781634763653,
9781634763660,
9781634763813,
9781634763905,
9781634763929,
9781634763981,
9781634764407,
9781634764414,
9781634764476,
9781634764599,
9781634764605,
9781634764612,
9781634764629,
9781634764636,
9781634764643,
9781634764650,
9781634764667,
9781634764810,
9781634764827,
9781634764841,
9781634765459,
9781634765473,
9781634765480,
9781634765497,
9781634765503,
9781634765510,
9781634765565,
9781634765572,
9781634765701,
9781634765718,
9781634765725,
9781634765732,
9781634766456,
9781634766524,
9781634766531,
9781634767170,
9781634767200,
9781634767705,
9781634767866,
9781634767903,
9781634767910,
9781634767958,
9781634767965,
9781634767972,
9781634767989,
9781634768245,
9781634768252,
9781634768269,
9781634768276,
9781634768290,
9781634768306,
9781634768733,
9781634768740,
9781634768818,
9781634768825,
9781634768832,
9781634768900,
9781634768917,
9781634769679,
9781634769709,
9781634769938,
9781634769945,
9781634770323,
9781634770330,
9781634770491,
9781634770507,
9781634770514,
9781634770828,
9781634771191,
9781634771474,
9781634771481,
9781634771498,
9781634771504,
9781634771948,
9781634772020,
9781634772105,
9781634772112,
9781634772167,
9781634772174,
9781634772235,
9781634772242,
9781634772259,
9781634772266,
9781634772273,
9781634772334,
9781634772341,
9781634772372,
9781634772389,
9781634772433,
9781634772440,
9781634772457,
9781634772624,
9781634772631,
9781634772761,
9781634772778,
9781634772785,
9781634772792,
9781634772808,
9781634772860,
9781634772976,
9781634773072,
9781634773164,
9781634773201,
9781634773218,
9781634773225,
9781634773232,
9781634773256,
9781634773430,
9781634773447,
9781634773805,
9781634773881,
9781634774420,
9781634775540,
9781634775557,
9781634775588,
9781634775601,
9781634776110,
9781634776264,
9781634776288,
9781634776554,
9781634776561,
9781634776639,
9781634776646,
9781634777384,
9781634777391)
         GROUP  BY pr.productuid, 
                   p.ordinal, 
                   r.NAME, 
                   r.retaileruid 
         HAVING Max(dos.processedatutc) BETWEEN 
                @DateRangeStart AND @DateRangeEnd), 
     distributiondataset 
     AS (SELECT DISTINCT isbn, 
                         dt.retailer 
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
         WHERE  ret.code = 'DITC'),
	 invaliddistributiondataset1 
	 as (SELECT DISTINCT isbn, 
                         dt.retailer,
						 do.DistributionOrderUid 
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
         WHERE  dos.resultingeventlevel = 4
                AND (ret.code IN ( 'DIDC','DINA')
				OR (ret.code = 'DIMF' 
				AND (substring(dos.ResultingMessage, 161, 29) IN ('Product does not have any sup','Source metadata contains conf','There are no supported assets'))
				OR substring(dos.ResultingMessage, 0,29) = 'One or more tokens have been')
				OR substring(dos.ResultingMessage, charindex('Package Summary', dos.ResultingMessage)+34,43) = 'were not uploaded because they had problems'
				OR substring(dos.ResultingMessage, 93,26) in ('Cover image not acceptable',@NewLineChar + 'Cover image not acceptab')))
					 ,
	 invaliddistributiondataset2
	 as (SELECT DISTINCT isbn, 
                         dt.retailer,
						 do.DistributionOrderUid
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
				INNER JOIN AthenaComposite..DistributionOrderAcceptabilities doa
						ON doa.DistributionOrderUid = do.DistributionOrderUid
         WHERE dos.resultingeventlevel = 4
                AND ret.code = 'DIMF'
				AND DOA.ResultingEvent IN (10,47,13,131)
				),
     faileddistributiondataset 
     AS (SELECT DISTINCT isbn, 
                         dt.retailer 
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
         WHERE  dos.resultingeventlevel > 2 
                AND ret.code = 'DIMF'
				AND do.distributionOrderUid NOT IN (select DistributionOrderUid from invaliddistributiondataset1
				UNION ALL
				select DistributionOrderUid from invaliddistributiondataset2)
						)
						, 
     successcount 
     AS (SELECT retailer AS Retailer, 
                Count(*) [Titles Distributed] 
         FROM   distributiondataset dt 
         GROUP  BY retailer), 
	 invalidcount1
	 AS (SELECT retailer AS Retailer,
				count(*) [Titles Failing Validation]
		 FROM	invaliddistributiondataset1 id1
		 GROUP	BY retailer
		 ),
     invalidcount2
	 AS (SELECT retailer AS Retailer,
				count(*) [Titles Failing Validation]
		 FROM	invaliddistributiondataset2 id2
		 GROUP	BY retailer
		 ),
     failurecount
     AS (SELECT retailer AS Retailer, 
                Count(*) [Titles Failed] 
         FROM   faileddistributiondataset dt 
         GROUP  BY retailer) 

SELECT DISTINCT CASE 
                  WHEN NAME = 'Amazon EbookBase' THEN 'Amazon' 
                  WHEN NAME = 'Baker and Taylor' THEN 'Baker & Taylor' 
                  WHEN NAME = 'Barnes And Noble' THEN 'Barnes & Noble' 
                  WHEN NAME = 'Scholastic PCD Feed' THEN 'PCD' 
                  WHEN NAME = 'Google Books' THEN 'Google' 
				  WHEN Len(Name) > 10 THEN Code
                  ELSE NAME 
                END                               AS Retailer, 
                Isnull(d.[titles distributed], 0) [Titles Distributed], 
                Isnull(f.[titles failed], 0)      [Titles Failed - System Issue],
				ISNULL(i1.[Titles Failing Validation],0) + ISNULL(i2.[Titles Failing Validation],0)	[Titles Failing Acceptability Validations]
FROM   Athenacomposite..retailers r 
       INNER JOIN Athenacomposite..contracts c 
               ON c.retaileruid = r.retaileruid 
       LEFT OUTER JOIN successcount d 
                    ON d.retailer = r.NAME 
       LEFT OUTER JOIN failurecount f 
                    ON f.retailer = d.retailer 
	   LEFT OUTER JOIN invalidcount1 i1
					on i1.retailer = r.Name
	   LEFT OUTER JOIN invalidcount2 i2
					ON i2.retailer = r.Name
WHERE  c.validuntilutc IS NULL 
ORDER  BY retailer ASC