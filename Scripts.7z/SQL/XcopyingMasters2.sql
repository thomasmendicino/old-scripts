select 
    case 
    when at.AssetTypeCode like '%jpg%' then 'ECHO F | xcopy \\instor05\inscribe-master--1\ResourceStorage\' + r.Path + ' D:\temp\20160503\' + pub.Safename + '\' + cast(p.ordinal as nvarchar(13)) + '.jpg'
	when at.AssetTypeCode like '%pdf%' then 'ECHO F | xcopy \\instor05\inscribe-master--1\ResourceStorage\' + r.Path + ' D:\temp\20160503\' + pub.Safename + '\' + cast(p.ordinal as nvarchar(13)) + '.pdf'
    when at.AssetTypeCode not like '%jpg%' and at.AssetTypeCode not like '%pdf%' then 'ECHO F | xcopy \\instor05\inscribe-master--1\ResourceStorage\' + r.Path + ' D:\temp\20160503\' + pub.Safename + '\' + cast(p.ordinal as nvarchar(13)) + '.' + left(right(r.Path,41),4)
    end as Commands
from product p
    join asset a on a.ProductUid = p.ProductUid
    join AssetOverride ao on ao.AssetUid = a.AssetUid
    join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
    join AthenaResourceStorage..Resources r on r.ResourceUid = av.ResourceUid
    join AthenaSecurity..organizations o on o.organizationUid = p.OrganizationUid
    join AthenaDistribution..publishers pub on pub.OrganizationUid = o.OrganizationUid
    left join AthenaDistribution..Retailers ret on ret.retailerUid = ao.retailerUid
	join refAssetType at on at.AssetTypeId = a.AssetType
where av.ValidUntilUtc is NULL 
    and ordinal in ( 9781632161376,
9781632168115,
9781632169167,
9781634769778,
9781634770231,
9781623809423,
9781634764865,
9781632164223,
9781634771313,
9781632169624,
9781632167071,
9781615817139,
9781634763264,
9781613720882,
9781613727041,
9781623800932,
9781623800154)

