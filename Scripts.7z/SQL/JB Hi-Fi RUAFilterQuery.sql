/*Can you have someone look into writing this report early next week? I told Tony we'd get it to him by Wednseday.
tony.cates@umgtemp.com
It's basically:
--1. take all released umg P&D albums (non-mobile)
--2. intersect the album's territories & the album's UMG contract's territories
--3. take all umg P&D retailers & their effective umg contract authority countries
--4. intersect the albums from step 2 umg contract's allowable retailers with all umg p&d retailers
--5. intersect step 3 & 4 to get a list of where every umg p&d album could have gone based on contract & area restrictions alone (album*country*retailer -- big list)
--6. build list of album * retailer * all countries sent under umg affils 
--   - need union of all countrysets for each album per retailer to handle territory additions over time
--7. except the set in step 6 from the set in step 5 to find albums that weren't sent for some reason
--probably takes half a day to write. 

--intersect means grab it if its in either
*/

---------------------------------------------------------------------------------------------
create table #releasedalbums (aid int, countryID int,msid int)
create table #contractcountries (aid int, countryID int,msid int)
create table #results1 (aid int, countryID int, msid int)
create table #musicservices (aid int, countryID int, msid int)
create table #results2 (aid int, countryID int, msid int)
create table #results3 (aid int, countryid int, msid int) 
create table #final (aid int, countryid int, msid int)
create table #services			(musicservice int, countryset int)
create table #musicservicecountries (contractauthority int, musicservice int, country int)
create table #results	(musicservice int, Album int, contract int, country int)
---------------------------------------------------------------------------------------------
--all released P&D albums and allowed countries/musicservice at the album level 
insert into #releasedalbums
select distinct a.id, country.id, ms.id
from album a
join contractalbumview cav on cav.album = a.id
join albumproducttype apt on apt.album = a.id
join countrysetcountry csc on csc.countryset = a.countryset
join country on country.id = csc.country
join contractserviceview csv on csv.contract = cav.contract
join musicservice ms on ms.id = csv.musicservice
where apt.producttype =(select id from producttype where name ='Audio_Album')
and a.process = (select id from process where name ='released')
and ms.name = 'JB Hi-Fi'
and cav.contractauthority in (1,3)
---------------------------------------------------------------------------------------------
--all release P&D albums and allowed countries at the contract level 
insert into #contractcountries
select distinct a.id, country.id, ms.id
from album a
join contractalbumview cav on cav.album = a.id
join contract con on con.id = cav.contract
join contractauthority ca on ca.id = cav.contractauthority
join albumproducttype apt on apt.album = a.id
join countrysetcountry csc on csc.countryset = con.countryset
join country on country.id = csc.country
join contractserviceview csv on csv.contract = cav.contract
join musicservice ms on ms.id = csv.musicservice
where apt.producttype =(select id from producttype where name ='Audio_Album')
and a.process = (select id from process where name ='released')
and ms.name = 'JB Hi-Fi'
and cav.contractauthority in (1,3)
---------------------------------------------------------------------------------------------
--all P&D released albums and where they are allowed to go per musicservice per territory 
insert into #results1
select aid, countryID, msid from #releasedalbums
intersect
select aid, countryid, msid from #contractcountries
---------------------------------------------------------------------------------------------




--declare @contractauthority	int 
--declare @producttype		int
---------------------------------
--set @contractauthority		=(select id from contractauthority where folderprefix='UMGAffiliates')
--set @producttype			=(select id from producttype where name='audio_album')
----------------------------------------------------------------------------------------------------------
-- Filter the set of musicservice we are working with to those which accept UMG Affiliates contract authority
-- And accept a Audio_Album for their product type.
----------------------------------------------------------------------------------------------------------

insert into #services			(musicservice, countryset)
select distinct ms.ID, ms.CountrySet from MusicServiceContractAuthorityView msca
	inner join MusicService ms on msca.MusicService=ms.ID
	inner join MusicServiceProductType mspt on msca.MusicService=mspt.MusicService
		and mspt.ProductType=3		
	where msca.ContractAuthority in (1,3)
	and ms.name = 'JB Hi-Fi'
----------------------------------------------------------------------------------------------------------
-- Create a table which is the same as MusicServiceContractAuthorityCountryView except it is filtered by 
-- additional input (musicservices and contractauthorities) to improve performance for this query.
----------------------------------------------------------------------------------------------------------

insert into #musicservicecountries (contractauthority, musicservice, country)
select ca.ID as ContractAuthority,ms.musicservice,csc.country
from ContractAuthority ca
	cross join #services ms
    left outer join MusicServiceContractAuthorityOverride msca on ms.musicservice = msca.MusicService 
		and msca.ContractAuthority in (1,3)
		and msca.OverrideAreaRestriction = 1
    inner join CountrySetCountry csc on coalesce(msca.CountrySet, ms.CountrySet) = csc.CountrySet
		where ca.id in (1,3)
		
----------------------------------------------------------------------------------------------------------
-- Join musicservicecountries onto a query that gets the album countries filtered by the same criteria.
-- This is your result set.
----------------------------------------------------------------------------------------------------------
	
insert into		#results	(musicservice, Album, contract, country)
select distinct csv.musicservice, cav.Album, c.ID, csc.country 
from #services s
	inner join ContractServiceView csv on s.musicservice=csv.MusicService
	inner join Contract c on csv.Contract=c.id
		and c.ContractAuthority in (1,3)
	inner join ContractAlbumViewActive cav on c.id=cav.Contract
	inner join AlbumProductType apt on cav.Album=apt.Album
		and apt.ProductType=3			
	inner join countrysetcountry csc on c.countryset=csc.countryset
	inner join #musicservicecountries msc on msc.contractauthority in (1,3)
		and s.musicservice=msc.musicservice
		and csc.Country=msc.country

---------------------------------------------------------------------------------------------
--Everywhere P&D content can go, retailers, contract, album restrictions taken into account
insert into #results2--currently running 
select album, country, musicservice from #results
intersect
select aid, countryid, msid from #results1
---------------------------------------------------------------------------------------------
--everywhere P&D content has been syndicated
insert into #results3
select distinct a.id, country.id, ms.id
from #results1
join album a on a.id = #results1.aid
join track t on t.album = a.id
join tracksyndicationmusicservicecontractauthorityview tscav on tscav.track = t.id
join countrysetcountry csc on csc.countryset = tscav.countryset 
join country on country.id = csc.country
join musicservice ms on ms.id = tscav.musicservice 
where tscav.contractauthority in (1,3)
and ms.name = 'JB Hi-Fi'
---------------------------------------------------------------------------------------------
--everywhere content can go less everywhere content has gone
insert into #final
select aid, countryid, msid from #results2
except 
select aid, countryid, msid from #results3
---------------------------------------------------------------------------------------------
--final report adding columns and names to make it easy to read
select distinct a.gtin as GTIN/*, a.name as AlbumName, country.name as Country, ms.name as MusicService, mst.statusname,o.name as Label, isnull(o2.name,'') as ParentLabel*/
from #final
join album a on a.id = #final.aid
join musicservice ms on ms.id = #final.msid
join country on country.id = #final.countryid
join organization o on o.id = a.organization
left outer join organization o2 on o2.id = o.parent
join musicservicestatus mst on mst.id = ms.musicservicestatus
where ms.name = 'JB Hi-Fi'
/*not in (
'INgroovesAAC',                                      
'INgroovesAACADIF',                                  
'INgroovesAACMP4',                                   
'INgroovesAACPlus',                                  
'INgroovesAACPlusMP4',                               
'INgroovesFLAC',                                     
'INgroovesMP3HiHiFi',                                
'INgroovesMP3MedFi',                                 
'INgroovesMP3MedHiFi',                               
'INgroovesWAV',
'Nielsen SoundScan',
'UMG Standard Test'
) */                                     
--and musicservicestatus  = 1
order by a.gtin





--drop table #releasedalbums
--drop table #contractcountries
--drop table #results1 
--drop table #musicservices 
--drop table #results2
--drop table #results3
--drop table #final
--drop table #services
--drop table #musicservicecountries
--drop table #results
