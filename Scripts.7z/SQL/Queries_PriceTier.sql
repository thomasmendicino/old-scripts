select * from encodingprofile

select * from encodingstructure

select * from encodingstructureconfiguration

select description, count(*) from encodingconfiguration
group by description

select esc.encodingconfiguration, ec.description, count(*) from encodingstructureconfiguration esc
inner join encodingconfiguration ec on esc.encodingconfiguration = ec.id
group by esc.encodingconfiguration, ec.description
order by count(*) desc
10
select * from musicservicedavepartner where davepartnername like '%jason%'

select * from autosynclog where stagingpath like '%\\NAS4\WamNet-Staging\2011\07\18\01\276814-372397%'


select * from syndicationorder where partnername like '%systems%'

select top 10 * from album
select top 10 * from musicservice

select * from musicservice where name like '%24%7%'
select * from pricetiermappingtype where id = 10
select * from pricetiermapping where pricetiermappingtype = 10
select * from pricetier where id in (12,13,14)
select PriceTierMappingType, InheritAlbumPriceTierForTrack, UseAlbumPriceTier, UseTrackPriceTier, * from musicservice where id = 243
select * from pricetiermapping where pricetiermappingtype = 8
select * from pricetiermapping where albumtiername is not null
select * from conversion
select * from currency where code = 'gbp' or code = 'eur'


select * from musicservicecontractauthority where musicservice = 9
select * from musicservicecontractauthorityoverride where musicservice = 9
select * from encodingstructure where id = 205
select encodingstructure, * from musicservicecontractauthorityoverride where musicservice = 242

select * from pricetier where descriptionkey like '%24%'

select * from pricetiermappingtype where id = 8
select * from pricetiermapping where pricetiermappingtype = 8
select * from pricetier where id in (select pricetier from pricetiermapping where pricetiermappingtype in (8,11,9,2,10,1,12,8))
11,12,13,14,1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1109,1110)

select * from contractauthoritypricetier where contractauthority = 9
select * from musicservicecontractauthority where musicservice = (select id from musicservice where name like '%24%7%')

select PriceTierMappingType, InheritAlbumPriceTierForTrack, UseAlbumPriceTier, UseTrackPriceTier, * from musicservice where id = 243

select * from pricecampaign where musicservice = 7
select * from pricetier where id = 12
8
11
9
2
10
1
12
8


MTV Networks
Shanachie Entertainment
VP Records
VP Music Group, Inc
ESL Music, Inc.
K-Tel
Fat Possum Records
Rostrum Records
Stingray Music (Karaoke)
Hopeless Records, Inc.

select * from organization
select 