begin tran
​
declare @FolderProcessors table 
(
	FolderProcessorId int, 
	SafeName nvarchar(200), 
	Name nvarchar(128)
)
INSERT INTO @FolderProcessors
	VALUES (1, 'ConversionHouse', 'Conversion House: '),
	(2, 'Reports', 'Reports: '),
	(3, 'Ftp', 'FTP: '),
	(4, 'ClientConsole', 'Client Console: '),
	(5, 'Migration', 'Migration: '),
	(6, 'ConversionHouse', 'Conversion House: '),
	(7, 'Ftp', 'FTP: '),
	(8, 'ClientConsole', 'Client Console: '),
	(9, 'Migration', 'Migration: '),
	(10, 'ConversionHouse', 'Conversion House: '),
	(11, 'Ftp', 'FTP: '),
	(12, 'ClientConsole', 'Client Console: '),
	(13, 'Migration', 'Migration: ')
UPDATE ic
SET	ic.Name = rfp.Name + p.Name,
	ic.SafeName = rfp.SafeName + p.SafeName
FROM AthenaUATAssetProcessor..ImportFolderConfigurations ic
INNER JOIN AthenaUATAssetProcessor..FolderProcessors fp
	ON fp.FolderProcessorId = ic.FolderProcessorId
INNER JOIN AthenaUATDistribution..Publishers p
	ON p.publisherUid = ic.PublisherUid
INNER JOIN @FolderProcessors rfp
	ON rfp.FolderProcessorId = fp.FolderProcessorId
WHERE ic.SafeName <> rfp.SafeName + p.SafeName
OR ic.Name <> rfp.Name + p.Name
​
SELECT
	p.Name AS Publisher,
	ic.Name AS CurrentName,
	ic.SafeName AS CurrentSafeName,
	rfp.Name + p.Name AS IdealName,
	rfp.SafeName + p.SafeName AS IdealSafeName
FROM AthenaUATAssetProcessor..ImportFolderConfigurations ic
INNER JOIN AthenaUATAssetProcessor..FolderProcessors fp
	ON fp.FolderProcessorId = ic.FolderProcessorId
INNER JOIN AthenaUATDistribution..Publishers p
	ON p.publisherUid = ic.PublisherUid
INNER JOIN @FolderProcessors rfp
	ON rfp.FolderProcessorId = fp.FolderProcessorId
WHERE ic.SafeName <> rfp.SafeName + p.SafeName
OR ic.Name <> rfp.Name + p.Name
​
rollback
--commit