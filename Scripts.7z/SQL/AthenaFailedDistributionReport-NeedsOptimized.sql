USE AthenaUATComposite;
--*******
--******* Default paramters for running query outside report
--*******
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @eISBNList NVARCHAR(MAX)
DECLARE @OrganizationUidList NVARCHAR(MAX)

--SELECT top 1 @OrganizationUidList = o.OrganizationUid from Organizations o where o.OrganizationName = 'Disney Publishing Worldwide, Inc.'
SET @DateRangeStart = GETUTCDATE()-6
SET @DateRangeEnd = GETUTCDATE()
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

SET @eISBNs = NULL
SET @eISBNList = NULL

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

IF OBJECT_ID('tempdb..#ErrorMessages') IS NOT NULL
    DROP TABLE #ErrorMessages
--*/

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

SELECT
    pub.Name AS Publisher,
    cast(p.Ordinal as varchar(20)) AS ISBN,
    p.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	DistributionOrderStatus dos
	INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN Product p ON p.ProductUid = pr.ProductUid
	INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
WHERE
    pub.OrganizationUid IN (SELECT OrganizationUId from Organizations WHERE OrganizationName like '%Disney%')                           -- Part of the selected publisher hierarchy
    AND (@eISBNs IS NULL OR cast(p.Ordinal as varchar(20)) IN (@eISBNList)) -- In the List of supplied ISBNs
    AND r.retailerUid IN (N'75e44d5f-2433-4d1c-ab29-084521c4bc0a',N'b3ead8f5-81c9-49ec-ad16-0fa7cf994c1a',N'67c9f971-dc9b-436a-9733-114f59ce4a81',N'533d4c81-9c20-438b-b0b4-1408fdead3b7',N'0b948035-959a-45c7-b5b9-15f4b9a6382e',N'bd6736cd-9508-4ac1-aaaa-20240b250061',N'b7a7bad6-d313-4ee7-a668-20fc575dfe58',N'99bc2940-9ebe-4efa-b785-2a50ee785b03',N'e8d53639-6898-4f39-a5e8-2b53259a8dfa',N'35c17122-2d6e-4a1a-bcf8-300303293f06',N'd70186c9-e40a-45d1-a111-407cb54c84c2',N'd8f1c7f6-27f8-416e-9830-48905d8f101a',N'0269f3d8-0cd6-47f7-bb1b-65fa4859d628',N'01449e94-31df-4caf-a9bf-71070dee7a60',N'0ea57251-cefc-487a-8c98-79b5cee90ffb',N'70ebbae4-a83b-4795-8985-84bf69b7287c',N'b906c9e4-1cff-4551-b978-88dc0363e119',N'0b642884-4587-4cec-a06e-9067e48d4fb4',N'4c280345-df74-43bb-91b2-96397bd26979',N'dddd4034-cfc2-41ba-8203-a093811cd5c4',N'0aa49437-ef56-4ae5-945c-c31d6ce314ef',N'd4584d23-47ac-4ac6-8607-d45796d286d0',N'9515425b-cdb9-4ea8-971a-d525b7aa8aad',N'd3f6c33a-e8d9-46e0-bf31-ec9c51dcadc9',N'05d88e2d-7331-4de2-b796-f59e4b002310',N'68756233-60b1-46d0-bd12-f68bd0ffbdc6',N'1337b51b-e267-492f-820f-f71b62f2f0ec')
GROUP BY
	pub.Name,
    p.ProductUid,
    p.Ordinal,
    r.Name,
    r.RetailerUid
HAVING                                                                      -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
	do.DistributionOrderUid
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos ON
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
    CROSS APPLY 
        (SELECT 
             TOP 1 ResultingEvent
         FROM	
		     DistributionOrderAcceptabilities 
		 WHERE
	         DistributionOrderUid = do.DistributionOrderUid
	     ORDER BY  
	         CreatedAtUtc DESC) doa
    INNER JOIN refEventType retdoa ON retdoa.EventTypeId = doa.ResultingEvent
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    dos.ResultingEventLevel > 2
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleElementLevel = 1                          -- Product Level
    AND CASE pfd.ProductFormDetailValue 
            WHEN 190 THEN 'Fixed' 
            WHEN 189 THEN 'Reflowable'
            ELSE 'Not Specified' END IN (N'Fixed',N'Reflowable',N'Not Specified')
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))

SELECT DISTINCT
	ds2.DistributionOrderUid,
	stuff((
		SELECT CHAR(10) + CHAR(10) + SUBSTRING(ds1.ResultingMessage, 0, 2048)
			+ CASE WHEN len(ds1.ResultingMessage) > 2048 THEN '...' ELSE '' END
		FROM DistributionOrderStatus ds1
		WHERE ds1.DistributionOrderUid = ds2.DistributionOrderUid AND ds1.ResultingEventLevel > 2
		FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS ErrorMessage
INTO
	#ErrorMessages
FROM
	DistributionOrderStatus ds2
	INNER JOIN #DistributionDataset dd on dd.DistributionOrderUid = ds2.DistributionOrderUid
WHERE
	ds2.ResultingEventLevel > 2
 
SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    Title,
    ContentType,
    OnSaleDate,
    Retailer,
    FailedDate,
    ReasonCode,
    em.ErrorMessage as ReasonDetail
FROM
    #DistributionDataset dd
	INNER JOIN #ErrorMessages em ON em.DistributionOrderUid = dd.DistributionOrderUid
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC,
    ReasonCode