;with ebookprices as (select p.Ordinal, pr.Amount,
ROW_NUMBER() OVER (PARTITION BY p.Ordinal order by PriceType asc, pr.Qualifier asc, pr.IsTaxIncluded asc) AS ROWNum
 from product p
join asset a on a.ProductUid = p.ProductUid
cross apply (
	select top 1 AssetOverrideUid
	from AssetOverride
	where AssetOverride.AssetUid = a.AssetUid
	order by RetailerUid asc) ao
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join TerritorySupplyDetails td on td.TerritorySupplyId = ts.TerritorySupplyId
join CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
--join refCountryCode rc on rc.CountryCode = cs.
join Prices pr on pr.TerritorySupplyDetailId = td.TerritorySupplyDetailId
where av.ValidUntilUtc is null
AND pr.Currency = 174
AND pr.PriceCode is null
AND CountryList like '%us%'
AND CHARINDEX('US',CountryList) % 2 != 0
AND pr.EffectiveToUtc is NULL),

BISACPivoter AS (
select p.Ordinal, 
ROW_NUMBER() OVER (PARTITION BY p.Ordinal order by s.IsMainSubject desc, s.SubjectId desc) as SequenceNum,
rbs.BISACCode from product p
join asset a on a.ProductUid = p.ProductUid
cross apply (
	select top 1 AssetOverrideUid
	from AssetOverride
	where AssetOverride.AssetUid = a.AssetUid
	order by RetailerUid asc) ao
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join Subjects s on s.AssetVersionUid = av.AssetVersionUid
join refBISACCode rbs on rbs.BISACCode = s.SubjectCode
where av.ValidUntilUtc is null),
SubjectPivoter AS 
(
select p.Ordinal, 
ROW_NUMBER() OVER (PARTITION BY p.Ordinal order by s.IsMainSubject desc, SubjectId asc) as SequenceNum2,
rbs.BISACText from product p
join asset a on a.ProductUid = p.ProductUid
cross apply (
	select top 1 AssetOverrideUid
	from AssetOverride
	where AssetOverride.AssetUid = a.AssetUid
	order by RetailerUid asc) ao
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join Subjects s on s.AssetVersionUid = av.AssetVersionUid
join refBISACCode rbs on rbs.BISACCode = s.SubjectCode
where av.ValidUntilUtc is null)


--select * from BISACPivoter

--select Ordinal from ebookprices 
--where RowNum = 1
--96232
/*
select o.OrganizationName Imprint, po.OrganizationName Parent, p.Ordinal, ep.Amount, 
case 
WHEN SequenceNum = 1 then 'PrimaryBISAC'
WHEN SequenceNum = 2 then 'SecondBISAC'
WHEN SequenceNum = 3 then 'ThirdBISAC'
WHEN SequenceNum = 4 then 'FourthBISAC'
end as
SequenceNum, b.BISACCode, 
case 
when SequenceNum2 = 1 then 'PrimarySubjectDescription'
when SequenceNum2 = 2 then 'SecondSubjectDescription'
when SequenceNum2 = 3 then 'ThirdSubjectDescription'
when SequenceNum2 = 4 then 'FourthSubjectDescription'
end as SequenceNum2, s.BISACText from Product p
join Organizations o on o.OrganizationUid = p.OrganizationUid
join Organizations po on po.OrganizationUid = o.ParentOrganizationUid
join ebookprices ep on ep.Ordinal = p.Ordinal
join BISACPivoter b on b.Ordinal = p.Ordinal
join SubjectPivoter s on s.Ordinal = p.Ordinal
where ep.RowNum = 1*/

/*
select p.Ordinal, ep.*, b.*, s.* from Product p
join ebookPrices ep on ep.Ordinal = p.Ordinal
join BISACPivoter b on b.Ordinal = p.Ordinal
join SubjectPivoter s on s.Ordinal = p.Ordinal
*/


select Imprint, Parent, Ordinal, Amount, PrimaryBISAC, SecondBISAC, ThirdBISAC, FourthBISAC, PrimarySubjectDescription, SecondSubjectDescription, ThirdSubjectDescription, FourthSubjectDescription
from
(select o.OrganizationName Imprint, po.OrganizationName Parent, p.Ordinal, ep.Amount, 
case 
WHEN SequenceNum = 1 then 'PrimaryBISAC'
WHEN SequenceNum = 2 then 'SecondBISAC'
WHEN SequenceNum = 3 then 'ThirdBISAC'
WHEN SequenceNum = 4 then 'FourthBISAC'
end as
BISACSequence, b.BISACCode, 
case 
when SequenceNum2 = 1 then 'PrimarySubjectDescription'
when SequenceNum2 = 2 then 'SecondSubjectDescription'
when SequenceNum2 = 3 then 'ThirdSubjectDescription'
when SequenceNum2 = 4 then 'FourthSubjectDescription'
end as SubjectSequence, s.BISACText from Product p
join Organizations o on o.OrganizationUid = p.OrganizationUid
join Organizations po on po.OrganizationUid = o.ParentOrganizationUid
join ebookprices ep on ep.Ordinal = p.Ordinal
join BISACPivoter b on b.Ordinal = p.Ordinal
join SubjectPivoter s on s.Ordinal = p.Ordinal
where ep.RowNum = 1) as SourceQuery
pivot
(max(BISACCode) for BISACSequence
in ([PrimaryBISAC],[SecondBISAC],[ThirdBISAC], [FourthBISAC])) as pvt1
pivot
(max(BISACText) for SubjectSequence
in ([PrimarySubjectDescription],[SecondSubjectDescription],[ThirdSubjectDescription],[FourthSubjectDescription])) as pvt2
--00:19, 95989 rows




BISACs AS (
	select p.Ordinal, 
	ROW_NUMBER() OVER (PARTITION BY p.Ordinal order by s.IsMainSubject desc, s.SubjectId desc) as SequenceNum,
	rbs.BISACCode from product p
	join asset a on a.ProductUid = p.ProductUid
	cross apply (
		select top 1 AssetOverrideUid
		from AssetOverride
		where AssetOverride.AssetUid = a.AssetUid
		order by RetailerUid asc) ao
	join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	join Subjects s on s.AssetVersionUid = av.AssetVersionUid
	join refBISACCode rbs on rbs.BISACCode = s.SubjectCode
	where av.ValidUntilUtc is null),
BISACPivoter AS (
	select Ordinal,
	case 
	WHEN SequenceNum = 1 then 'PrimaryBISAC'
	WHEN SequenceNum = 2 then 'SecondBISAC'
	WHEN SequenceNum = 3 then 'ThirdBISAC'
	WHEN SequenceNum = 4 then 'FourthBISAC'
	end as BISACSequence,
	BISACCode from BISACs),
SubjectDescription AS (
	select p.Ordinal, 
	ROW_NUMBER() OVER (PARTITION BY p.Ordinal order by s.IsMainSubject desc, SubjectId asc) as SequenceNum2,
	rbs.BISACText from product p
	join asset a on a.ProductUid = p.ProductUid
	cross apply (
		select top 1 AssetOverrideUid
		from AssetOverride
		where AssetOverride.AssetUid = a.AssetUid
		order by RetailerUid asc) ao
	join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	join Subjects s on s.AssetVersionUid = av.AssetVersionUid
	join refBISACCode rbs on rbs.BISACCode = s.SubjectCode
	where av.ValidUntilUtc is null),
SubjectPivoter AS (
	select Ordinal,
	case 
	when SequenceNum2 = 1 then 'PrimarySubjectDescription'
	when SequenceNum2 = 2 then 'SecondSubjectDescription'
	when SequenceNum2 = 3 then 'ThirdSubjectDescription'
	when SequenceNum2 = 4 then 'FourthSubjectDescription'
	end as SequenceNum2,
	BISACText
	from SubjectDescription)



select Imprint, Parent, Ordinal, Amount, PrimaryBISAC, SecondBISAC, ThirdBISAC, FourthBISAC, PrimarySubjectDescription, SecondSubjectDescription, ThirdSubjectDescription, FourthSubjectDescription
from
(select o.OrganizationName Imprint, po.OrganizationName Parent, p.Ordinal, ep.Amount, 
BISACSequence, b.BISACCode, 
SequenceNum2, s.BISACText from Product p
join Organizations o on o.OrganizationUid = p.OrganizationUid
join Organizations po on po.OrganizationUid = o.ParentOrganizationUid
join ebookprices ep on ep.Ordinal = p.Ordinal
join BISACPivoter b on b.Ordinal = p.Ordinal
join SubjectPivoter s on s.Ordinal = p.Ordinal
where ep.RowNum = 1) as SourceQuery
pivot
(max(BISACCode) for BISACSequence
in ([PrimaryBISAC],[SecondBISAC],[ThirdBISAC], [FourthBISAC])) as pvt1
pivot
(max(BISACText) for SequenceNum2
in ([PrimarySubjectDescription],[SecondSubjectDescription],[ThirdSubjectDescription],[FourthSubjectDescription])) as pvt2


--00:14 95989