use AthenaProductCatalog;
declare @organizationName nvarchar(100)
select @organizationname = 'scholastic inc.'
;with org as (
select o.organizationName, o.ParentOrganizationUid from athenasecurity..organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from athenasecurity..organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from athenasecurity..organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from athenasecurity..organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
--select * into #Scholastic from child
--select * from org
--union all
--select * from child

select distinct s.OrganizationName OwningImprint, p.Ordinal ISBN, tat.Name AssetType from product p
inner join asset a on a.ProductUid = p.ProductUid
inner join AssetOverride ao on ao.assetUid = a.AssetUid
inner join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
inner join TMAssetType tat on tat.id = a.AssetType
inner join child s on s.OrganizationUId = p.OrganizationUid
where a.ResourceContentType = 28
and av.ValidUntilUtc is NULL
and tat.Name in ('EPUB2R','EPUB2RE')
order by s.OrganizationName, Ordinal
