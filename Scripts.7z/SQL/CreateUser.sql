USE AthenaSecurity;

declare @UserName nvarchar(50)
declare @LoweredUserName nvarchar(50)
declare @OrganizationName nvarchar(200)
declare @EntityID int

SET @UserName = ''
SET @LoweredUserName = ''
SET @OrganizationName = ''


--CREATE USER
insert into AthenaSecurity.dbo.aspnet_Users
(ApplicationId,UserName,LoweredUserName,MobileAlias,IsAnonymous,LastActivityDate,PrimaryOrganizationUid)
select 
	a.ApplicationId,
	@UserName,
	@LoweredUserName,
	NULL,
	0,
	GetDate(),
	(select top 1 OrganizationUid from AthenaSecurity.dbo.Organizations where OrganizationName = @OrganizationName)
from AthenaSecurity.dbo.aspnet_Applications a
where a.ApplicationName = '/'

--ASSIGN USER ROLES
insert into athenasecurity.dbo.aspnet_UsersInRoles
(RoleId, UserId)
select
	r.RoleId,
	(select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName)
from athenasecurity.dbo.aspnet_Roles r
where r.RoleName in ('AthenaUsers','AthenaManagers','IdentityServerUsers')


--MEMBERSHIP FOR USER
insert into athenasecurity.dbo.aspnet_Membership
(	UserId,
	ApplicationId,
	Password,
	PasswordFormat,
	PasswordSalt,
	MobilePIN,
	Email,
	LoweredEmail,
	PasswordQuestion,
	PasswordAnswer,
	IsApproved,
	IsLockedOut,
	CreateDate,
	LastLoginDate,
	LastPasswordChangedDate,
	LastLockoutDate,
	FailedPasswordAttemptCount,
	FailedPasswordAttemptWindowStart,
	FailedPasswordAnswerAttemptCount,
	FailedPasswordAnswerAttemptWindowStart,
	Comment
)
values
(
	(select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName),
	(select ApplicationId from athenasecurity.dbo.aspnet_Applications where ApplicationName = '/'),
	'N54WCnc0ZkNSGoxDrZf9C3BJiTA=',
	1,
	'GwP0d4Pd3tovgwe2g04C3Q==',
	NULL,
	'kbeehler@inscribedigital.com',
	'kbeehler@inscribedigital.com',
	NULL,
	NULL,
	1,
	0,
	GetDate(),
	GetDate(),
	GetDate(),
	'1754-01-01 00:00:00.000',
	0,
	'1754-01-01 00:00:00.000',
	0,
	'1754-01-01 00:00:00.000',
	NULL
)

--ENTITIES FOR USER

INSERT EAVEntities
DEFAULT VALUES
set @EntityID = SCOPE_IDENTITY()

--INSERT USERENTITIES

INSERT UserEntities (UserUid, EavEntityId, EavAttributeSetId)
select UserId,
@EntityId, 
1 from athenasecurity.dbo.aspnet_Users where UserName=@UserName

--INSERT USERORGANIZATIONS (Adds all children of the organization to be visible to the user)

;with child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
INSERT UserOrganizations (UserUid, OrganizationUid)
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), OrganizationUid from child

--INSERT UserPermissions

INSERT UserPermissions (UserUid, Permission)
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 1 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 2 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 14 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 15 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 16 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 17 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 18 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 19 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 20 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 23 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 24 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 25 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 26 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 28 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 29 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 30 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 31 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 32 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 33 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 34 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 35 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 36 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 37 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 38 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 39 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 40 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 41 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 42 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 43 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 44 UNION
SELECT (select UserId from athenasecurity.dbo.aspnet_Users where UserName=@UserName), 45

