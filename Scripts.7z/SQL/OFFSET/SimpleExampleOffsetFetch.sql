select * from assetVersion av
order by av.AssetVersionId
OFFSET 12 ROWS
FETCH NEXT 50 ROWS ONLY