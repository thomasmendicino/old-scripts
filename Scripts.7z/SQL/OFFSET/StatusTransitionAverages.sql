SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
declare @StatusOrder table (StatusTransition nvarchar(30), Ordering int)
INSERT @StatusOrder (StatusTransition, Ordering)
VALUES 
('DICR -> DIAD',1)
,('DICR -> DINA',2)
,('DICR -> DIMF',3)
,('DICR -> DIDC',4)
,('DIAD -> DIRB',5)
,('DIRB -> DIBC',6)
,('DIBC -> DIMF',7)
,('DIBC -> DITP',8)
,('DITP -> DITP',9)
,('DITP -> DITC',10)
,('DITP -> DIMF',11)
,('DITC -> DIMF',12)
,('DITC -> DITC',13)
,('DITC -> DITP',14)


declare @StartWindow datetime = '2016-03-18'
declare @EndWindow datetime = '2016-03-19'

;with status1 as (
	select dos.DistributionOrderUid, dos.ProcessedAtUtc, et.Code, pr.ContractUid, ROW_NUMBER() OVER (PARTITION BY do.DistributionOrderUid ORDER BY dos.DistributionOrderStatusId asc) as RowNum from DistributionOrderStatus dos
	join distributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
	join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
	join product p on p.ProductUid = pr.ProductUid
	join refEventType et on et.EventTypeId = dos.ResultingEvent
	where do.CreatedAtUtc between @StartWindow and @EndWindow
		AND ISNULL(dos.ResultingMessage,'') NOT LIKE 'Transfer for%'
		),
diff as (select s1.DistributionOrderUid, s1.ProcessedAtUtc as status1ProcessedTime, s2.ProcessedAtUtc as status2ProcessedTime, s1.Code as Code1, s2.Code as Code2, s2.ContractUid , s1.RowNum as Num1, s2.RowNum as Num2
	from status1 s1
	join status1 s2 on s1.DistributionOrderUid = s2.DistributionOrderUid AND s2.RowNum = s1.RowNum + 1),
averages as (
	select 
		datediff(second, status1ProcessedTime, status2ProcessedTime) TimeInSeconds
		, cast(Code1 as varchar(100)) + ' -> ' + cast(code2 as varchar(100)) as StatusTransition
		, ContractUid
	from diff 
	group by ContractUid, datediff(second, status1ProcessedTime, status2ProcessedTime), cast(Code1 as varchar(100)) + ' -> ' + cast(code2 as varchar(100)))

SELECT MAX(TimeInSeconds) as [MaxDuration (s)], MIN(TimeInSeconds) as [MinDuration (s)], AVG(TimeInSeconds) as [AverageDuration (s)], a.StatusTransition, count(*) as CountOfInstances
FROM averages a
	left outer join @StatusOrder so on so.StatusTransition = a.StatusTransition
GROUP BY a.StatusTransition,ISNULL(so.Ordering,100)
ORDER BY ISNULL(so.Ordering,100) ASC
