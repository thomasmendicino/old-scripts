/*

EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
GO

EXEC master.dbo.sp_configure 'xp_cmdshell', 1
RECONFIGURE WITH OVERRIDE
GO

*/
/*

EXEC master.dbo.sp_configure 'xp_cmdshell', 0
RECONFIGURE WITH OVERRIDE
GO

EXEC master.dbo.sp_configure 'show advanced options', 0
RECONFIGURE WITH OVERRIDE
GO

*/

IF OBJECT_ID('tempdb..##tmp' , 'U') IS NOT NULL
   drop TABLE ##tmp
GO
declare @length nvarchar(3)
create table ##tmp (results nvarchar(max))
declare @start int = 1
declare @run int
declare @pubs table ([Row] int, OrganizationName nvarchar(200))
DECLARE @OutputFile NVARCHAR(100) ,    @FilePath NVARCHAR(100) ,    @bcpCommand NVARCHAR(1000)
DECLARE @NewLineChar AS CHAR(2) = CHAR(13) + CHAR(10)
;with OnixPubs as (
select p.OrganizationUid, p.Name from publishers p 
join ImportFolderConfigurations ic on ic.PublisherUid = p.PublisherUid
join folderobjects fo on fo.ImportFolderConfigurationUid = ic.ImportFolderConfigurationUid
where fo.path like '%xml%'),
orgs as (
select distinct o.OrganizationName from product p
join organizations o on o.OrganizationUid = p.OrganizationUid
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
where 
av.ValidFromUtc < '2014-11-01'
and o.OrganizationUid not in (select organizationUid from OnixPubs)
and o.ParentOrganizationUid not in (select organizationUid from OnixPubs)
and pf.ProductFormTypeValue > 35)
insert @pubs 
select ROW_NUMBER() OVER (Order BY OrganizationName) [Row], OrganizationName from orgs

select @run = count(*) from @pubs

while @start <= @run
BEGIN
insert ##tmp
SELECT distinct '--action
	ExecuteMigratorJobsForPublishers

--allow-parallel-jobs
	true

--system-name
	Athena
	
// comment out to include all publishers
--publisher-names' + STUFF((select ' ' + @NewLineChar + char(9) + OrganizationName from @pubs where [Row] between @start and @start + 4 for xml path (''),type).value('.', 'nvarchar(max)'),1,2,'') + '
	
--job-names
	Athena Maintenance: Lock all ImportFolderConfigurations for the publisher
	Athena Maintenance: Import Onix resources
	Athena Maintenance: Update Onix resources
	Athena Maintenance: Export Onix resources
	Athena Maintenance: Upload the complete file in target folders
	Athena Maintenance: Unlock all ImportFolderConfigurations for the publisher

--job-parameters
	// New parameter SelectionLogic, optional. Valid values are None, ProductAvailabilityUpdate
	// By default all resources are imported (None)
	// OnixResourcesImport.SelectionLogic = ProductAvailabilityUpdate
	
	// update availability SQL/xQuery scripts (in the order)
	OnixResourcesUpdate.PathToSqlScript = "C:\Octopus\Applications\Athena\IN.Athena.Migrator\1.0.101817.481\Scripts\Insert Retailers OptIn Sales Restriction.sql"

	OnixResourcesExport.TargetPath = \\instor05\inscribe-master--1\Uploads
    OnixResourcesExport.TargetFolder = Migration
    
	UploadFoldersComplete.TargetPath = \\instor05\inscribe-master--1\Uploads
    UploadFoldersComplete.TargetFolder = Migration' as listp from @pubs where [Row] between @start and @start + 4

	
	SET @bcpCommand = 'bcp "SELECT * FROM tempdb..##tmp " queryout '
	--select * from ##tmp
	SET @FilePath = 'D:\temp\MigratorCommands'
	SET @length = rtrim(cast(@start as NVARCHAR(3)))
	SET @OutputFile = 'Results' + @length + '.txt'
	--PRINT @bcpCommand + @FilePath + @OutputFile + ' -c -t -T -S '+ @@servername
	SET	@bcpCommand = @bcpCommand + @FilePath + @OutputFile + ' -c -t -T -S '+ @@servername
	--PRINT @bcpCommand
	exec master..xp_cmdshell @bcpCommand
	delete from ##tmp

set @start = @start + 5
END

