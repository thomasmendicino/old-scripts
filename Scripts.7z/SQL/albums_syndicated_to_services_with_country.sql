
select DISTINCT a.Name [Album Name], a.GTIN, ms.Name, syn.Syndicationlevel, syn.TransferredAt, c.A2 [Territory] from Syndication syn
inner join musicservice ms ON ms.ID = syn.Musicservice
inner join TrackSyndication ts on ts.Syndication = syn.ID
inner join track t on t.ID = ts.track
inner join song s on s.ID = t.Song
inner join album a on a.id = t.Album
inner join albumcountryview acv ON acv.Album = a.ID
inner join Country c ON c.ID = acv.Country
WHERE A.Gtin IN ('00823674731021', '00823674731328', '00823674445836', '00843930001606', '00843930001521')
Order by a.Gtin, ms.Name, syn.SyndicationLevel