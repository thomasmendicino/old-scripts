Create Database Ingrooves_20110408_1330  on 
(NAME = Ingrooves_Data, FILENAME = 'D:\Databases\Snapshots\INgrooves_data_20110408_1330.ss'),
(NAME = Primary_file2, FILENAME = 'D:\Databases\Snapshots\INgrooves_primary2_20110408_1330.ss'),
(NAME = Primary_file3, FILENAME = 'D:\Databases\Snapshots\INgrooves_primary3_20110408_1330.ss'),
(NAME = IndexGroup_file1, FILENAME = 'D:\Databases\Snapshots\INgrooves_index1_20110408_1330.ss'), 
(NAME = IndexGroup_file2, FILENAME = 'D:\Databases\Snapshots\INgrooves_index2_20110408_1330.ss'), 
(NAME = IndexGroup_file3, FILENAME = 'D:\Databases\Snapshots\INgrooves_index3_20110408_1330.ss'),
(NAME = CacheGRoup_file1, FILENAME = 'D:\Databases\Snapshots\INgrooves_cache1_20110408_1330.ss'), 
(NAME = CacheGRoup_file2, FILENAME = 'D:\Databases\Snapshots\INgrooves_cache2_20110408_1330.ss'), 
(NAME = CacheGRoup_file3, FILENAME = 'D:\Databases\Snapshots\INgrooves_cache3_20110408_1330.ss') 
as snapshot of INgrooves
GO