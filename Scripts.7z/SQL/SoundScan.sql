--SOUNDSCAN REPORT QUERY
--
USE INgrooves ;
GO
IF OBJECT_ID ('dbo.MS162', 'V') IS NOT NULL
    DROP VIEW dbo.MS162 ;
GO
CREATE VIEW dbo.MS162 as
	select *
	from musicserviceorganizationcode
	where musicservice=162;
GO
-- add parent organization name
select porg.name as 'Parent Organization Name', org_name_q.Org_name as 'Organization Name', org_name_q.parent_a2 as 'Parent 2 dig Code', 
org_name_q.a2 as '2 dig Code', org_name_q.a3 as '3 dig Code'
from
    -- add organization name
	(select parent_q.*, org.name as ORG_NAME
	from
        -- add parent a2 column
		(select parent_org_q.*, dbo.MS162.a2 as parent_a2
		from
            -- select necessary existing columns and add parent organization column
			(select	musicservice as MS, organization as ORG, a2 as A2, a3 as A3, (select Top 1 organization
					from dbo.get_parent_organizations(organization) ORDER BY Distance DESC) as parent_org
			from dbo.MS162) as parent_org_q
			left outer join dbo.MS162 on parent_org_q.parent_org=dbo.MS162.organization) as parent_q
			left outer join organization as org on org.id=parent_q.ORG)	as org_name_q
			left outer join organization as porg on porg.id=org_name_q.parent_org
			where org_name_q.Org_name in (select name from organization where organization.createdat between getdate()-7 and getdate())
order by parent_a2
DROP VIEW dbo.MS162 ;