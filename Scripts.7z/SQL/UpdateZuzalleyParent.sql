--begin tran
--rollback
--commit
--Edits the organization Zuzalley Enterprises, LLC to have no parent. See Sysaid# 17419
declare @OrganizationUid uniqueidentifier
declare @NewParentOrganizationUid uniqueidentifier
declare @OldParentOrganizationUid uniqueidentifier

select @organizationUid = organizationUid from AthenaSecurity..Organizations where OrganizationName = 'Zuzalley Enterprises, LLC'
select @OldParentOrganizationUid = ParentOrganizationUid from AthenaSecurity..Organizations where OrganizationUid = @organizationUid
select @NewParentOrganizationUid = OrganizationUid from AthenaSecurity..Organizations where OrganizationName = 'INscribe Digital'

IF @NewParentOrganizationUid != @OldParentOrganizationUid
BEGIN

UPDATE AthenaSecurity..Organizations set ParentOrganizationUid = @NewParentOrganizationUid where OrganizationUid = @OrganizationUid

END