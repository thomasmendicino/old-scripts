;with ProductOrders AS
(select DateAdd(minute, 15 * (DateDiff(minute, '20000101', dos.CreatedAtUtc) / 15), '20000101') As OrderCreationTime,
Ordinal as ISBN
From product p
join ProductRevisions pr on pr.ProductUid = p.ProductUid
join DistributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join DistributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
where dos.ResultingEvent = 110
and dos.CreatedAtUtc > GETUTCDATE()-7)
Select OrderCreationTime, count(ISBN) As NumProducts
From ProductOrders
Group By OrderCreationTime
order by OrderCreationTime;