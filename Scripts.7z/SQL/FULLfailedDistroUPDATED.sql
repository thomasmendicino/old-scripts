--***** Failed Distribution... Last 2 hours

DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
--DECLARE @FailedOrders table (DistributionOrderUid uniqueidentifier)

SET @DateRangeStart = dateadd(hh,-1,getUTCdate())
SET @DateRangeEnd = getUTCdate()
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

--SET @eISBNs = 9780545317931

;with MaxAt as (select max(ProcessedAtUtc) [MaxProcessedAtUTC], pr.ProductUid, r.Name from AthenaUATDistribution..distributionOrderStatus dos
join AthenaUATDistribution..distributionOrders do on do.distributionORderUId = dos.DistributionOrderUId
join AthenaUATDistribution..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaUATDistribution..contracts c on c.contractUid = pr.contractUId
join AthenaUATDistribution..retailers r on r.retailerUId = c.retailerUid
group by pr.productUid, r.Name
having max(ProcessedAtUtc) > @DateRangeStart),
--insert @FailedOrders (DistributionOrderUId)
FailedOrders as (
select do.DistributionOrderUid from AthenaUATDistribution..DistributionOrders do
join AthenaUATDistribution..DistributionOrderStatus dos on dos.distributionOrderUid = do.distributionORderUId
join AthenaUATDistribution..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaUATDistribution..contracts c on c.contractUid = pr.contractUId
join AthenaUATDistribution..retailers r on r.retailerUId = c.retailerUid
join MaxAt m on m.ProductUid = pr.productUid and m.Name = r.Name and m.MaxProcessedAtUTC = dos.ProcessedAtUTC
where dos.ResultingEventLevel = 4),
#DistributionTitles as(
SELECT DISTINCT
    pub.Name AS Publisher,
    [pi].Value AS ISBN,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    dos.ProcessedAtUtc AS ProcessedAtUtc,
    F.distributionOrderUId
FROM
	AthenaUATDistribution..DistributionOrderStatus dos
	INNER JOIN AthenaUATDistribution..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaUATDistribution..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaUATDistribution..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaUATDistribution..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaUATDistribution..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaUATProductCatalog..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN AthenaUATProductCatalog..ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
	INNER JOIN AthenaUATProductCatalog..Asset a on a.productUid = p.productUid
	INNER JOIN AthenaUATProductCatalog..assetOverride ao on ao.assetUid = a.assetUid
	INNER JOIN AthenaUATProductCatalog..assetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	INNER JOIN ProductForms pf on pf.AssetVersionUid = av.AssetVersionUid
    INNER JOIN FailedOrders f on f.DistributionOrderUid = do.DistributionOrderUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
	AND pf.ProductFormTypeValue IN (49,50,51,52)
	AND AV.ValidUntilUtc is NULL
	and a.ResourceContentType in (100,101,104)
	--AND [pi].value = '9780545317931'
GROUP BY
	pub.Name,
    pr.ProductUid,
    [pi].Value,
    r.Name,
    r.RetailerUid,
    dos.ProcessedAtUtc,
    F.DistributionOrderUid
HAVING                                                     -- Check the date range of the distribution
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NOT NULL 
	AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
	OR
	(@DateRangeStart IS NULL 
	AND @DateRangeEnd IS NOT NULL
	AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	OR
	(@DateRangeStart IS NOT NULL 
	AND @DateRangeEnd IS NULL
	AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	OR
	(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)),

	#DistributionDataSet as (    
SELECT DISTINCT
    Publisher,
    ISBN,
    coalesce(td.TitleStatement, te.TitleText) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS FailedDate,
    ret.Code AS ReasonCode,
    rtrim(rtrim(replace(replace(ResultingMessage, CHAR(10), ' '), CHAR(13), ' '))) AS ReasonDetail,
    dt.DistributionORderUId
FROM
	#DistributionTitles dt
    INNER JOIN AthenaUATDistribution..ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN AthenaUATDistribution..Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN AthenaUATDistribution..DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN AthenaUATDistribution..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaUATProductCatalog..Product p ON p.ProductUid = dt.ProductUid
    INNER JOIN AthenaUATProductCatalog..Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AthenaUATProductCatalog..AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AthenaUATProductCatalog..AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN AthenaUATProductCatalog..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN AthenaUATProductCatalog..ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190)
    INNER JOIN AthenaUATEventLog..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
	INNER JOIN AthenaUATProductCatalog..TitleDetails td ON td.AssetVersionUid = av.AssetVersionUid
    INNER JOIN AthenaUATProductCatalog..TitleElements te ON te.TitleDetailId = td.TitleDetailId
WHERE
    dos.ResultingEventLevel > 2
	AND av.ValidUntilUtc is null
    AND ret.Code NOT IN ('DIDC')                          -- Not distributed based on contract
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleText IS NOT NULL                          -- Only displayt the title elements with TitleText
    and rtrim(dos.ResultingMessage) <> 'Distribution Order is not acceptable for distribution:   '
    )
SELECT DISTINCT
	ISBN,
case 
when po.OrganizationName = 'INscribe Digital' then o.OrganizationName
when ppo.OrganizationName = 'INscribe Digital' then po.OrganizationName
when pppo.OrganizationName = 'INscribe Digital' then ppo.OrganizationName
when ppppo.OrganizationName = 'INscribe Digital' then pppo.OrganizationName
when po.OrganizationName is NULL then o.OrganizationName
end as [TopLevelParent],
	Publisher [Imprint],
    dt.Title,
    ContentType,
    OnSaleDate,
    Retailer,
    max(FailedDate) as FailedDate,
    ReasonCode,
	case when doa.ResultingMessage is NULL
	then 
	ISNULL(left(stuff((select replace(', ' + ReasonDetail,CHAR(13),'') from #DistributionDataset dt
	where dt.ISBN = p.Ordinal and dt.Publisher = pub.Name and dt.Retailer = r.Name for xml path ('')),1,1,''),1000) --as [Reason1],
	+ stuff((select distinct '; '+ ret.Title + '' from AthenaUATEventLog..refEventType ret join AthenaUATdistribution..distributionORderAcceptabilities doa on doa.ResultingEvent = ret.EventTypeID where doa.ResultingEvent = ret.EventTypeId and doa.distributionOrderUid = dt.distributionOrderUId and doa.ResultingEventLevel > 2 for xml path ('')),1,1,''),
	left(stuff((select replace(', ' + ReasonDetail + ';',CHAR(13),'') from #DistributionDataset dt
	where dt.ISBN = p.Ordinal and dt.Publisher = pub.Name and dt.Retailer = r.Name for xml path ('')),1,1,''),1000) )
	else 
	stuff((select distinct '; '+ ret.Title + '' from AthenaUATEventLog..refEventType ret join AthenaUATdistribution..distributionORderAcceptabilities doa on doa.ResultingEvent = ret.EventTypeID where doa.ResultingEvent = ret.EventTypeId and doa.distributionOrderUid = dt.distributionOrderUId and doa.ResultingEventLevel > 2 for xml path ('')),1,1,'')
	end
	as [ReasonDetail]

FROM
    #DistributionDataset dt
    join AthenaUATDistribution..Publishers pub on pub.Name = dt.Publisher
    join AthenaUATSecurity..Organizations o on o.organizationUId = pub.organizationUId
    LEFT OUTER JOIN AthenaUATSecurity..Organizations po on po.organizationUid = o.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations ppo on ppo.organizationUid = po.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations pppo on pppo.organizationUid = ppo.ParentOrganizationUid
	LEFT OUTER JOIN AthenaUATSecurity..Organizations ppppo on ppppo.organizationUid = pppo.ParentOrganizationUid
	join AthenaUATDistribution..retailers r on r.Name = dt.Retailer
	join AthenaUATProductCatalog..product p on p.Ordinal = dt.ISBN
    LEFT OUTER JOIN AthenaUATDistribution..DistributionORders do on do.distributionOrderUid = dt.distributionOrderUid
    LEFT OUTER JOIN AthenaUATDistribution..DistributionOrderAcceptabilities doa on doa.distributionORderUId = do.distributionORderUid and doa.ResultingEventLevel = 4
    LEFT OUTER JOIN AthenaUATEventLog..refEventType ret on ret.EventTypeId = doa.ResultingEvent
	group by ISBN,o.organizationname, po.organizationname,ppo.organizationname,pppo.organizationname,ppppo.organizationName, dt.Publisher,dt.Title,ContentType,OnSaleDate,Retailer,ReasonCode,p.Ordinal, pub.Name, r.Name, doa.ResultingEventLevel, ret.EventLevelId, ret.Title,ret.EventTypeId,doa.ResultingEvent, dt.DistributionORderUid, doa.ResultingMessage
ORDER BY
	ISBN,
    OnSaleDate DESC,
    dt.Title ASC,
    ReasonCode

	/*

	SELECT
             --TOP 1 ProductTitleId
			te.*, '',td.*
         FROM
             AthenaUATProductCatalog..TitleElements te
			 join titleDetails td on td.TitleDetailId = te.TitleDetailId

			 select * from athenaUATProductCatalog..TitleDetails where assetVersionUid is not null
         
		
	    
	    

		https://jira.ingrooves.com/browse/ATHENA-1871

		select * from athenauatproductcatalog..ProductForms where productFormTypeValue <> 52
		select top 50 * from assetVersion
		select top 50 * from assetOverride
		

		*/