-- ALL ORDERS COUNT
select count(*) from syndicationorder so
inner join syndicationorderstate sos on sos.id = so.orderstate
where submissiondate > getdate()-1 

-- COMPLETED STATS
select sos.name, so.orderstatemessage, count(*) from syndicationorder so
inner join syndicationorderstate sos on sos.id = so.orderstate
where submissiondate > getdate()-1 and completed=1
group by sos.name, so.orderstatemessage
order by sos.name

-- NOT COMPLETED STATS
select sos.name, so.orderstatemessage, count(*) from syndicationorder so
inner join syndicationorderstate sos on sos.id = so.orderstate
where submissiondate > getdate()-1 and completed=0
group by sos.name, so.orderstatemessage
order by sos.name