select * from musicservice where name like '%cricket%'
select * from musicservice where name like '%myxer%' SAO = 0, STAO = 0, STUR = 1, UR = 1

select * from musicservicecontractauthority where musicservice = 596

select top 5 * from royalty
select * from track t 
join tracksyndication ts on ts.track = t.id
join syndication s on ts.syndication = s.id
where t.userringtone = 0
and s.musicservice = (select ID from musicservice where name = 'myxer')

select * from royalty r
join song s on r.song = s.id
join track t on t.song = s.id
join tracksyndication ts on ts.track = t.id
join syndication sy on ts.syndication = sy.id
where sy.musicservice = (select ID from musicservice where name = 'myxer')
and r.mobile = 0

select distinct o.name, r.mobile, sy.syndicatedat from royalty r
join organization o on r.organization = o.id
join album a on a.organization = o.id
join track t on a.id = t.album
join tracksyndication ts on ts.track = t.id
join syndication sy on ts.syndication = sy.id
join earning e on e.royalty = r.id
where sy.musicservice = (select ID from musicservice where name = 'myxer')
and r.mobile = 0
and e.contractauthority = 1
order by syndicatedat desc

order by sy.syndicatedat desc

select top 5 * from tracksyndication
select top 5 * from track
select top 5 * from albumsyndicationview

select * from syndication

select * from contractauthorityroyaltyidentity where musicservice = 

select * from syndicationorder where orderbatchid = 1000001065536
select * from syndication where id = 289297
select * from syndicationordereventlog where syndicationorder = 134619
--begin tran
--update syndicationorder set orderstate = 2 where orderbatchid = 1000001065536
--commit
--rollback
select * from musicservice where name like '%cricket%'
select * from distributiontype
select * from album where gtin = '00602527428123'
select s.syndicationlevel, * from syndicationorder so
join syndication s on so.syndication = s.id
where orderbatchid in (1000001006856, 
1000001006857, 
1000001006858, 
1000001006917, 
1000001006918, 
1000001007539, 
1000001007540, 
1000001007541, 
1000001007542, 
1000001007544, 
1000001007545, 
1000001007546, 
1000001007602, 
1000001007603, 
1000001007604, 
1000001007607,
1000001007610, 
1000001007611, 
1000001007615, 
1000001007616, 
1000001007619, 
1000001007620, 
1000001007621, 
1000001007623, 
1000001007624, 
1000001007627, 
1000001007628, 
1000001007630, 
1000001007631, 
1000001007633, 
1000001007861, 
1000001008066, 
1000001008067, 
1000001008068, 
1000001008070, 
1000001008071, 
1000001008072, 
1000001008074, 
1000001008075, 
1000001008076, 
1000001008077, 
1000001008078, 
1000001008079, 
1000001008080, 
1000001008081, 
1000001008082, 
1000001008136, 
1000001008137, 
1000001008142, 
1000001008143, 
1000001008144, 
1000001008145, 
1000001008146, 
1000001008147, 
1000001008148, 
1000001008158, 
1000001008159, 
1000001008160, 
1000001008161, 
1000001008253, 
1000001008261, 
1000001008281, 
1000001008333, 
1000001008383) order by s.syndicationlevel





select * from musicservicedavepartner where davepartnername like '%INGrooves_WDR%'


