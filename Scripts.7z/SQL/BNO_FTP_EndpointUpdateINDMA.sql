--begin tran
--commit
--rollback
select ts.* from musicservice ms
join musicservicetransfersettings ts on ts.musicservice = ms.id
where ms.name = 'barnes and noble' and contractAuthority = 28

declare @BNO int
select @BNO = ID from MusicService where name = 'Barnes And Noble'

update MusicServiceTransferSettings set [Server] = 'sftp-pub.barnesandnoble.com', Port = 22, UserName = 'D0763', Password = 'nY9hYgGou', TransferProtocol = 2, UploadRoot = '' WHERE MusicService = @BNO and FilterExpression = '.*\.xml$|.*\.jpg$' and ProductType = 22 and ContractAuthority = 28

update MusicServiceTransferSettings set [Server] = 'sftp-pub.barnesandnoble.com', Port = 22, UserName = 'A0187', Password = 'rBlH8Kkdgd', TransferProtocol = 2, UploadRoot = '/' WHERE MusicService = @BNO and FilterExpression = '.*\.xml$|.*\.jpg$' and ProductType = 23 and ContractAuthority = 28

update MusicServiceTransferSettings set [Server] = 'sftp-pub.barnesandnoble.com', Port = 22, UserName = 'A0187', Password = 'rBlH8Kkdgd', TransferProtocol = 2, UploadRoot = '/' WHERE MusicService = @BNO and FilterExpression = '.*\.xml$|.*\.jpg$' and ProductType = 24 and ContractAuthority = 28

select ts.* from musicservice ms
join musicservicetransfersettings ts on ts.musicservice = ms.id
where ms.name = 'barnes and noble' and contractAuthority = 28
