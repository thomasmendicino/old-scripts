IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[reset_jobs_and_sessions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[reset_jobs_and_sessions]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- This stored procedure will reset transient
-- data related to Jobs and Sessions. The second
-- parameter default value is null, otherwise
-- you can specify either 'Jobs' or 'Sessions'
-- to reset one of them individually.
--
-- For example, executing with parameter 'Jobs'
-- is useful when the grid needs to be reset
-- (delete from the Object and JobFunction tables
-- when restarting INgroovesJob/Function.
-- =============================================
CREATE PROCEDURE [dbo].[reset_jobs_and_sessions]
	@DatabaseServer	nvarchar(max),			-- string must = @@SERVERNAME	
	@Instruction	nvarchar(max) = null	-- 'Jobs' or 'Sessions', or omit altogether to reset both
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE	@DBServerMessage nvarchar(max)
	SET		@DBServerMessage = 'Your first parameter must be the name of the database server.'

	IF @DatabaseServer != CAST(@@SERVERNAME as nvarchar(max))
		BEGIN
			RAISERROR (@DBServerMessage, 18, 1)
			RETURN -1
		END
	
	DECLARE @InstructionMessage nvarchar(max)
	SET		@InstructionMessage = 'If you choose to specify the second parameter, you must select either ''Jobs'' or ''Sessions''. Omit the parameter to reset both.'
	
	IF @Instruction not in ('Jobs','Sessions')
		BEGIN
			RAISERROR (@InstructionMessage, 18, 1)
			RETURN -1
		END
	
	IF @Instruction = 'Jobs'
	OR @Instruction is null
		BEGIN
			DELETE FROM JobFunction
			DELETE FROM Object
		END
	
	IF @Instruction = 'Sessions'
	OR @Instruction is null
		BEGIN
			DELETE FROM Lock
			DELETE FROM [tempdb].[dbo].[ASPStateTempApplications]
			DELETE FROM [tempdb].[dbo].[ASPStateTempSessions]
			DELETE FROM [tempdb].[dbo].[INgroovesTempAPI]
			DELETE FROM [tempdb].[dbo].[INgroovesTempSessionAddition]
			DELETE FROM [tempdb].[dbo].[INgroovesTempSessions]
			DELETE FROM [tempdb].[dbo].[INgroovesTempViewState]
		END
	
	IF @Instruction = 'Jobs' and @@ERROR = 0
		BEGIN
			PRINT 'You have successfully reset job data (JobFunction, Object tables) in database '+CAST(DB_Name() as nvarchar(max))+'.'
		END

	IF @Instruction = 'Sessions' and @@ERROR = 0
		BEGIN
			PRINT 'You have successfully reset session data (Lock table and tempdb session tables) in database '+CAST(DB_Name() as nvarchar(max))+'.'
		END

	IF @Instruction is null and @@ERROR = 0
		BEGIN
			PRINT 'You have successfully reset job and session data (JobFunction, Object, Lock and tempdb session tables) in database '+CAST(DB_Name() as nvarchar(max))+'.'
		END
END


GO