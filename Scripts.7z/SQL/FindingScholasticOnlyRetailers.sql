select distinct rs.Name RuleSet, r.Name Retailer, p.Name Publisher from contracts c
join retailers r on r.RetailerUid = c.RetailerUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
join publishers p on p.PublisherUid = c.PublisherUid
where c.ValidUntilUtc is NULL
and rs.Name not in (
'Distribution Prohibited',
'Onix Feed rules')
and p.Name = 'Scholastic Inc.'
order by r.Name