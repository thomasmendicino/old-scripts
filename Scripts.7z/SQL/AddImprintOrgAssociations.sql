/*

Adds user associations to the OperationsAdmin user for all organizations
select * from AthenaSecurity..aspnet_Users where UserName like '%browngi%'
*/
use AthenaSecurity;
begin tran
--rollback
--commit

declare @TopParent uniqueidentifier
declare @ExistingAssociations table (organizationUid uniqueidentifier)
declare @UserId uniqueidentifier
declare @OrgId uniqueidentifier
declare @OrgName nvarchar(200)

select @TopParent = '00000000-0000-0000-0000-000000000001'
select @UserId = UserId from AthenaSecurity..aspnet_Users where UserName = 'BrownGirlsPublishing'
select @OrgId = PrimaryOrganizationUid from AthenaSecurity..aspnet_Users where UserId = @UserId
select @OrgName = OrganizationName from AthenaSecurity..Organizations where OrganizationUid = @OrgId

insert @ExistingAssociations (organizationUid)
select uo.OrganizationUid from AthenaSecurity..aspnet_Users asu
inner join AthenaSecurity..UserOrganizations uo on uo.UserUid = asu.UserId
where asu.UserId = @UserId

insert AthenaSecurity..UserOrganizations (UserUid, OrganizationUid)
select @UserId, OrganizationUid from AthenaSecurity..Organizations
WHERE organizationUid not in (
select OrganizationUid from @ExistingAssociations
UNION
select @TopParent)
and OrganizationUid in (select organizationUid from dbo.OrgHierarchy(@OrgName))

commit