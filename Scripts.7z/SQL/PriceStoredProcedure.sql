USE [AthenaProductCatalog]
GO

/****** Object:  StoredProcedure [dbo].[Price]    Script Date: 7/22/2015 11:29:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[Price]
	@ISBN			bigint = ''

	AS
BEGIN
	SET NOCOUNT ON;


select cs.CountryList, av.ValidFromUtc, av.ValidUntilUtc, av.AssetVersionUid,
case
when PriceType = 14 then 'Agency'
when PriceType = 1 then 'Wholesale'
else cast(PriceType as nvarchar(10))
end as PriceType, pr.Amount, pr.Currency, pr.EffectiveFromUtc, pr.EffectiveToUtc,
pr.*, r.Path,* from AthenaProductCatalog..product p
join AthenaProductCatalog..asset a on a.ProductUid = p.ProductUid
join AthenaProductCatalog..AssetOverride ao on ao.AssetUid = a.AssetUid
join AthenaProductCatalog..AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join AthenaProductCatalog..TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
join AthenaProductCatalog..TerritorySupplyDetails td on td.TerritorySupplyId= ts.TerritorySupplyId
join AthenaProductCatalog..prices pr on pr.TerritorySupplyDetailId = td.TerritorySupplyDetailId
join AthenaResourceStorage..resources r on r.ResourceUid = av.ResourceUid
join AthenaProductCatalog..CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
where ordinal = @ISBN
and pr.PriceCodeTypeName is null
order by av.ValidFromUtc, cs.CountryList


	END


GO


