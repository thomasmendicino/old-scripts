
create table #perms (perm nvarchar(50), id int)
insert #perms (perm, id)
       select 'AssetApprove', 1 UNION
        select 'AssetReject', 2 UNION
        select 'FileDownloadCover', 14 UNION
        select 'FileDownloadEbook', 15 UNION
        select 'FileDownloadMetadata', 16 UNION
        select 'FileViewCoverart', 17 UNION
        select 'FileViewEbook', 18 UNION
        select 'FileViewMetadata', 19 UNION
        select 'ModuleCatalog', 20 UNION
        select 'ModuleConfiguration', 21 UNION
        select 'ModuleEventlog', 22 UNION
        select 'ModuleHelp', 23 UNION
        select 'ModuleIngestion', 24 UNION
        select 'ModuleReports', 25 UNION
        select 'ModuleUploads', 26 UNION
        select 'ModuleUsermanagement', 27 UNION
        select 'ReportsDownloadConversion', 28 UNION
        select 'ReportsDownloadDistribution', 29 UNION
        select 'ReportsDownloadIngestion', 30 UNION
        select 'ReportsViewConversion', 31 UNION
        select 'ReportsViewDistribution', 32 UNION
        select 'ReportsViewIngestion', 33 UNION
        select 'StartConversion', 34 UNION
        select 'StartUpload', 35 UNION
        select 'UploadsViewConsole', 36 UNION
        select 'UploadsViewConversionhouse', 37 UNION
        select 'UploadsViewFtp', 38 UNION
        select 'UploadsViewReports', 39 UNION
        select 'ModuleDistribution', 40 UNION
        select 'PacketApprove', 41 UNION
        select 'PacketSuppress', 42 UNION
        select 'RetryFailedIngestions', 43 UNION
        select 'DistributionStatus', 44 UNION
        select 'DownloadProductBulk', 45
		
select au.UserName, p.perm from userPermissions up
join #perms p on p.id = up.Permission
join aspnet_users au on au.UserId = up.UserUid
where p.perm like '%distribution%statu%'
order by username
