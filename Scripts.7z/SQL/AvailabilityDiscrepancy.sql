select distinct Ordinal from publishingdates pd
join assetVersion av on av.assetVersionUId = pd.assetVersionUid
join assetOverride ao on ao.assetOverrideUid = av.assetOverrideUid
join asset a on a.assetUId = ao.assetUId
join product p on p.productUid = a.productUid
join publishingStatus ps on ps.AssetVersionUid = av.assetVersionUId
join refPublishingStatusType rp on rp.publishingStatusTypeId = ps.PublishingStatusType
join productForms pf on pf.assetVersionUid = av.assetVersionUId
where rp.Name = 'Forthcoming' and Value <= getDate()
and pf.ProductFormTypeValue in (52)	
order by Ordinal

