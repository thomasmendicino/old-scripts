
select * from syndicationorder so
 join country c on c.a2 = so.partnerterritory
 join musicservicedavepartner msdp on so.partnerid = msdp.davepartnerid and msdp.country = c.id
 join daveusercontext uc on uc.usercontext = (c.a2 + '_' + cast(msdp.davepartnerid as nvarchar(3)))
 where so.id = 13
 