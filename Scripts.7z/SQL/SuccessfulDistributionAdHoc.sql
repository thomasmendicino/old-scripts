--patch set 2. Original - ProcessedAtUtc 2921 rows, 59s | 1m,38s 7301
--Updated to use CreatedAtUtc instead: 2921 rows, 1m,37s | 37s, 7301
--Updated to use DistroStatusId instead: 2921 rows, 1m,47s | 6s, 7301
/***/
--Updated to use DistroStatusId with (FORCESCAN) + CROSS APPLY TitleElement 6s, 10578 rows for Courier - OVD,INX. | with apple 8s, 13746
--ProcessedAtUtc = 28s, 10578rows | with apple 27s 13746
--18955 29s
DECLARE @DateRangeStart datetime = NULL
DECLARE @DateRangeEnd datetime = NULL
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)

SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL

SET @eISBNs = NULL

--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset



DECLARE @ProductFormDetailFixed int = 5201
DECLARE @ProductFormDetailReflowable int = 5200

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')


;WITH DistributionTitlesCTE 
AS 
(
    SELECT
        pub.Name AS Publisher,
        [pi].Value AS ISBN,
        pr.ProductUid,
        r.RetailerUid,
        r.Name AS Retailer,
--        MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
		MAX(dos.DistributionOrderStatusId) AS DistributionOrderStatusId
    FROM
        DistributionOrderStatus dos
        INNER JOIN DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
        INNER JOIN ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
        INNER JOIN Publishers pub ON pub.PublisherUid = pr.PublisherUid
        INNER JOIN Contracts c ON c.ContractUid = pr.ContractUid
        INNER JOIN Retailers r ON r.RetailerUid = c.RetailerUid
        INNER JOIN Product p ON p.ProductUid = pr.ProductUid
        INNER JOIN ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
    WHERE
        [pi].ProductIdentifierType = 15                       -- ISBN-13
        AND pub.OrganizationUid IN (select organizationUid from OrgHierarchy('Bloomsbury Publishing'))     -- Part of the selected publisher hierarchy
		--AND p.Ordinal = 9780486147710
        --AND (@eISBNs IS NULL OR [pi].Value IN (@eISBNList))   -- In the List of supplied ISBNs
        --AND r.Code in ('OVD','INX','APC','GOO')
    GROUP BY
        pub.Name,
        pr.ProductUid,
        [pi].Value,
        r.Name,
        r.RetailerUid
    HAVING                                                     -- Check the date range of the distribution
        (@DateRangeStart IS NOT NULL 
        AND @DateRangeEnd IS NOT NULL 
        AND MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd)
        OR
        (@DateRangeStart IS NULL 
        AND @DateRangeEnd IS NOT NULL
        AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
        OR
        (@DateRangeStart IS NOT NULL 
        AND @DateRangeEnd IS NULL
        AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
        OR
        (@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
)
--select * from DistributionTitlesCTE --35106954 from IDs. 2016-06-30 10:32:44.077 from timestamps
SELECT DISTINCT
    Publisher,
    ISBN,    
    dt.Retailer,
    dos.ProcessedAtUtc AS DistributionDate
INTO
    #DistributionDataset
FROM
	DistributionTitlesCTE dt
    INNER JOIN ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN DistributionOrderStatus dos WITH (FORCESCAN) 
		ON dos.DistributionOrderUid = do.DistributionOrderUid
    --AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	AND dos.DistributionOrderStatusId = dt.DistributionOrderStatusId
    INNER JOIN refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
	ret.Code = 'DITC'

SELECT
    Publisher,
    ISBN,
    'Not Implemented' AS Series,
    COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN @ProductFormDetailFixed THEN 'Fixed' 
        WHEN @ProductFormDetailReflowable THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    Retailer,
    DistributionDate
FROM
    #DistributionDataset ds
    INNER JOIN Product p ON p.Ordinal = ds.ISBN
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
	CROSS APPLY 
		(SELECT
			TOP 1 TitleText, TitlePrefix, TitleWithoutPrefix
		 FROM
			TitleElements
		 WHERE TitleDetailId = td.TitleDetailId
			AND TitleElementLevel = 1						-- TitleElementLevelCode.Product
		 ORDER BY 
			TitleElementId) te
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (@ProductFormDetailReflowable, @ProductFormDetailFixed) 
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
    av.ValidUntilUtc IS NULL                        -- Most recent version
    AND pd.PublishingDateRole = 1                       -- Main publishing date
	AND td.TitleTypeCode = 1							-- TitleTypeCode.DistinctiveTitle
    AND pd.DateLevel = 1                                -- Product publishing date
    AND                                                   -- Check the On sale date range
	((@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL 
		AND pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NULL 
		AND @OnSaleDateRangeEnd IS NOT NULL
		AND pd.Value <= @OnSaleDateRangeEnd)
		OR
		(@OnSaleDateRangeStart IS NOT NULL 
		AND @OnSaleDateRangeEnd IS NULL
		AND pd.Value >= @OnSaleDateRangeStart)
		OR
		(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL))
ORDER BY
    OnSaleDate DESC,
    Series ASC,
    Title ASC
--	9780486812625

/*

	select * from #DistributionDataset ds
	INNER JOIN Product p ON p.Ordinal = ds.ISBN
    INNER JOIN Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN TitleDetails td ON av.AssetVersionUid = td.AssetVersionUid
    INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
    INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
WHERE
    av.ValidUntilUtc IS NULL                        -- Most recent version
    AND pd.PublishingDateRole = 1                       -- Main publishing date
	AND td.TitleTypeCode = 1							-- TitleTypeCode.DistinctiveTitle
	AND te.TitleElementLevel = 1						-- TitleElementLevelCode.Product
    AND pd.DateLevel = 1                                -- Product publishing date
	AND isbn = 9780486812625*/

	--max ID is failure or success, but max timestamp is opposite.
	/*
with IDs as(select DistributionOrderUid, max(DistributionOrderStatusId) ID from DistributionOrderStatus
	group by distributionOrderUid),
timestamps as(select DistributionOrderUid, max(ProcessedAtUtc) At from DistributionOrderStatus
	group by distributionOrderUid)

select dos.distributionOrderUid, dos.ProcessedAtUtc, dos.DistributionOrderStatusId, IDs.ID, t.At from DistributionOrderStatus dos
left join IDs on IDs.DistributionOrderUid = dos.DistributionOrderUid AND IDs.ID = dos.DistributionOrderStatusId
left join timestamps t on t.DistributionOrderUid = dos.DistributionOrderUid AND t.At = dos.ProcessedAtUtc
order by dos.DistributionOrderUid, dos.ProcessedAtUtc

select * from distributionOrders do
join ProductRevisions pr on pr.productRevisionUid = do.productRevisionUid
join Product p on p.ProductUid = pr.ProductUid
join organizations o on o.OrganizationUid = p.OrganizationUid
where distributionOrderUid = '87AA69B4-469B-4505-9612-9E2B0E043C22'

exec distro 9781423165439, 'APC'

select * from product where productUid = 'D73764AB-6C0C-4C2A-9E69-A0F520C6FD30'
select * from organizations where OrganizationUid = 'C04F72D6-D385-4713-8EA3-7D62F32096CB'
9781507128466
DECLARE @uid uniqueidentifier 
--set @uid = '223C0522-AB8A-45FC-A079-15CD05524FFA'
--set @uid = 'D1B81A04-1BF0-4032-989F-5AB07BC50CA0'
--set @uid = 'EED7A421-9CB8-4BFE-97A8-BF7F378CF342'
--set @uid = 'C05F0C19-63E3-4338-94E2-DCF2CDF29EA4'
--set @uid = '11CB3188-361A-48C3-A784-C7B43CB33D61'
--set @uid = '87AA69B4-469B-4505-9612-9E2B0E043C22'


set @uid = 'F797122B-B640-4E99-9F23-19BB13D19620'
--set @uid = '1398EA45-DD9E-4CD7-9E52-1A202F59C547'
--set @uid = 'F39928EB-1FB7-4EEB-A91F-2081F564276D'
--set @uid = '1621D56A-0B75-4235-A31D-2212AE04BA3C'
--set @uid = 'CE281230-CF9B-4D3F-A2EE-2D6159348F5F'
--set @uid = '586181BF-4DA7-40B9-B9AA-2FD7AB5B556B'

select * from DistributionOrderStatus where DistributionOrderUid = @Uid 
order by DistributionOrderStatusId


;with times as 
	(select DistributionOrderUid, max(ProcessedAtUtc) At from DistributionOrderStatus
		group by distributionOrderUid),
maxId as 
	(select dos.DistributionOrderUid, max(DistributionOrderStatusId) maxId from DistributionOrderStatus dos
		group by distributionOrderUid),
maxIdTimes as 
	(select dos.DistributionOrderUid, dos.ProcessedAtUtc from DistributionOrderStatus dos
		join maxId md on md.DistributionOrderUid = dos.DistributionOrderUid AND dos.DistributionOrderStatusId = md.maxId)
select mt.DistributionOrderUid from maxIDTimes mt
	join times t on t.DistributionOrderUId = mt.DistributionOrderUid
	left join DistributionOrderStatus dos1 on dos1.DistributionOrderUid = mt.DistributionOrderUid AND dos1.ProcessedAtUtc = mt.ProcessedAtUtc
	left join DistributionOrderStatus dos2 on dos2.DistributionOrderUid = t.DistributionOrderUid AND dos2.ProcessedAtUtc = t.At
WHERE t.At > mt.ProcessedAtUtc
	AND dos1.ResultingEvent <> dos2.ResultingEvent
	*/