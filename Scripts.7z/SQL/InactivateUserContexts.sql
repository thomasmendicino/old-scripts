select * from musicservicedavepartner where davepartnername in ('Masterbeat_MP3', 'YouTube_UGC', 'YouTube_Audio_UGC', 'Video_YouTube Back Catalog')
select * from musicservicedavepartner where davepartnerid in (375,413,353,234)
select * from daveusercontext where usercontext like '%375'
select * from daveusercontext where usercontext like '%353'
select * from daveusercontext where usercontext like '%413'
select * from daveusercontext where usercontext like '%234'


select * from musicservice where id in (select musicservice from musicservicedavepartner where davepartnername in ('Masterbeat_MP3', 'YouTube_UGC', 'YouTube_Audio_UGC', 'Video_YouTube Back Catalog'))

select * from daveusercontext where usercontext like ('%' + (select davepartnerid from musicservicedavepartner where davepartnername = 'masterbeat_mp3'))

declare DAVeID

--update daveusercontext set active = 0 where id = (select id from daveusercontext where usercontext = ('us_' + '375'))
--update daveusercontext set active = 0 where id = (select id from daveusercontext where usercontext = ('ca_' + '375'))
--update daveusercontext set active = 0 where id = (select id from daveusercontext where usercontext = ('us_' + '353'))
--update daveusercontext set active = 0 where id = (select id from daveusercontext where usercontext = ('us_' + '413'))
--update daveusercontext set active = 0 where id = (select id from daveusercontext where usercontext = ('us_' + '234'))


select * from musicservicedavepartner where davepartnerid in (375,413,353,234)
select * from daveusercontext where usercontext = ('us_' + '375')
select * from daveusercontext where usercontext = ('ca_' + '375')
select * from daveusercontext where usercontext = ('us_' + '353')
select * from daveusercontext where usercontext = ('us_' + '413')
select * from daveusercontext where usercontext = ('us_' + '234')
