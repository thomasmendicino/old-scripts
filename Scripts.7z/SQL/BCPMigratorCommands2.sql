/*

EXEC master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
GO

EXEC master.dbo.sp_configure 'xp_cmdshell', 1
RECONFIGURE WITH OVERRIDE
GO

*/
/*

EXEC master.dbo.sp_configure 'xp_cmdshell', 0
RECONFIGURE WITH OVERRIDE
GO

EXEC master.dbo.sp_configure 'show advanced options', 0
RECONFIGURE WITH OVERRIDE
GO

*/

IF OBJECT_ID('tempdb..##tmp' , 'U') IS NOT NULL
   drop TABLE ##tmp
GO
declare @length nvarchar(3)
create table ##tmp (results nvarchar(max))
declare @start int = 1
declare @run int
declare @pubs table ([Row] int, Name nvarchar(200))
DECLARE @OutputFile NVARCHAR(100) ,    @FilePath NVARCHAR(100) ,    @bcpCommand NVARCHAR(1000)
DECLARE @NewLineChar AS CHAR(2) = CHAR(13) + CHAR(10)
insert @pubs 
select ROW_NUMBER() OVER (Order BY Name) [Row], Name from Organization where Name in ('* Demo E',
'* Demo Parent',
'344 Design, LLC',
'4R Inc.',
'5150 Media Publishing',
'AARP',
'Abydos Enterprises',
'Allen O''Shea Literary Agency',
'Arcadian Lifestyle Publishing',
'Arcana Comics',
'Arcana Studio',
'Armory New Media',
'AudioGO Limited',
'AudioGO',
'Avoiding Medical Errors Media & Publishing',
'Balance Edutainment, LLC',
'Beach View Publishing',
'Benshima Ltd.',
'Big Scratch Publishing',
--'Blackstone Audio',
--'Bloomsbury USA Academic and Professional',
'Blue Hand Books',
'BooGoo Press',
'BooksBNimble',
'Capital Resource Design',
'CartoonLink',
'Catalyst Books, LLC',
'Charlotte Raymond Literary Agent',
'Clarus Press',
'Cloud Publishing, Inc.',
'Contented Hearts',
'Continuum',
'Copenhagen Publishing House Aps',
'Cordia Product Realisatie BV',
'CPAExcel',
'Createspace',
'Creative Management Partners, LLC',
'CRN Publishing LLC',
'Crosslink Publishing',
'Croton River Publishers',
'David Black Agency',
'Dawn Horse Press',
'Day Dream Publishing',
'Donald Treichler',
'Dr. Alan Lazar',
'Dr. Dean Russell',
'E-Magine Publishing',
'Earle Levenstein',
'Earth Dog Inc.',
'ebooks Patagonia',
'Ed Wright',
'Efficient Learning Systems, Inc',
'EMPOWERMENT  LLC',
'Ense�a Chile',
'Escargot-Books',
'Executive Suite Press, Inc.',
'FiGi Publishing',
'Folio Literary Management, LLC',
'Frederator Books, LLC',
'Full Steam Press',
'Gaby Press',
'Geraldine Evans',
'Geraldine Nagle',
'Giggle Goods, LLC',
'Go-Getter''s Guides',
'Hallinan Consulting LLC',
'Hangzhou Jiwen Digital Technology Co. Ltd.',
'Hap Klopp',
'Honeycomb Valley PTY LTD',
'Horse Fly Studios',
'Hudson Valley Authors',
'Institute for Finance and Entrepreneurship LLC',
'Irion Books, LLC',
'James Howard Kunstler',
'James Peter & Associates',
'Jaynie Smith',
'Joyeuse Press',
'JPA Publishing',
'JTE Multimedia Global Partners',
'Karen Dionne',
'Kate Jerome',
'Killeena Publishing',
'Killer Machine',
'KNI Publishing',
'L&G (2002 Studios Media Ltd)',
'Lady Nairna',
'Lazlo Borsai',
'Legacy Publications',
'Les �ditions du Vaisseau D''Or',
'Lightning Path Press, LTD.',
'Louis R. Kief',
'Madeline Fresco',
'Manly Publishers',
'Mark D. Kupris',
'Marpex, Inc.',
'Matt Bell',
'Maureen Millea Smith',
'Mira Publishing House',
'MLA Members for Scholar''s Rights',
'Mouse Prints Press',
'Movable Type Literary Group',
'Mud Luscious Press',
'NACHA - The Electronic Payments Association',
'Naes Publishing',
'National Magazine Company',
'Natmag-Rodale',
'New Field Consulting',
'New Harbor Press',
'Nick Akerman',
--'Oberon Books Ltd.',
'One Wish Publishing Inc.',
'Painted Daisy Books',
'Patagonia',
'Pedipress Inc.',
'Permanent Tourist Books',
'Piker''s Press',
'PK Books',
'Power City Press',
'PressBooks Flat Fee',
'Qantati Literario',
--'Red Hot Publishing',
'Residual Publishing, LLC',
'RIL Editores',
'Riptide Publishing, LLC',
'RLR Associates Ltd.',
'Robin Conner''s Pixel Painting',
'Rolling Olive Press',
'Ruckus Media Group',
'Russ Heinl',
'S.K. Epperson',
'Sallie Williams-Tyrrell',
'Sedona Editions',
'Silvermine International Books',
'Simple Truths, LLC',
'Small Wonder Books',
'Spellbinder Press',
'Stanton-Burns Publishing',
'Star Root Press',
'STM Publication',
'Stockholm Text Publishing AB',
'Straw Hat',
'Stu Heinecke',
'Susan E. Briggs',
'Take It To The Limit Publications',
'The National Magazine Company Limited',
'Today College Tour, Inc.',
'UMG Books',
'Universal Music Germany',
'Vecker Press',
'W.H. Publishing',
--'Wayne State University Press',
'WebFirst, Inc.',
'Wei-Tzen Doris Huang',
'Xenophon Press LLC',
'Zen Organizer Press')

select @run = count(*) from @pubs

while @start <= @run
BEGIN
insert ##tmp
SELECT distinct '--action
	ExecuteMigratorJobsForPublishers

--allow-parallel-jobs
	true

--system-name
	INDMA
	
// comment out to include all publishers
--publisher-names' + STUFF((select ' ' + @NewLineChar + char(9) + Name from @pubs where [Row] between @start and @start + 4 for xml path (''),type).value('.', 'nvarchar(max)'),1,2,'') + '

--job-names
	INDMA Migration: Publishers' as listp from @pubs where [Row] between @start and @start + 4

	
	SET @bcpCommand = 'bcp "SELECT * FROM ##tmp " queryout '
	--select * from ##tmp
	SET @FilePath = 'C:\Users\thomas.INGROOVES\Desktop\Temp\Inactive\Publishers\'
	SET @length = rtrim(cast(((@start-1)/5) as NVARCHAR(3)))
	SET @OutputFile = 'Results' + @length + '.txt'
	--PRINT @bcpCommand + @FilePath + @OutputFile + ' -c -t -T -S '+ @@servername
	SET	@bcpCommand = @bcpCommand + @FilePath + @OutputFile + ' -c -t -T -S '+ @@servername
	--PRINT @bcpCommand
	exec master..xp_cmdshell @bcpCommand
	delete from ##tmp

set @start = @start + 5
END

