--begin tran
--commit
--rollback
IF OBJECT_ID('tempdb.dbo.#Changes') IS NOT NULL
DROP TABLE #Changes
GO
CREATE TABLE #Changes (Album int, oldAlbumOrg int, oldSongOrg int, oldCelebOrg int, newOrg int, At datetime)

IF object_ID('tempdb.dbo.#TMerror') IS NOT NULL 
DROP TABLE #TMerror
GO
CREATE TABLE #TMerror (Album int, Song int, NewOrganization int, ErrorNumber nvarchar(max), ErrorProcedure nvarchar(max), ErrorLine nvarchar(max), ErrorState nvarchar(max), ErrorMessage nvarchar(max))

BEGIN TRY

DECLARE @DesiredOrgName nvarchar(50) = 'Bloomsbury USA'
DECLARE @DeprecatedOrgName nvarchar(50) = 'Bloomsbury USA Children''s Books'
DECLARE @DesiredOrg int
SELECT @DesiredOrg = ID FROM Organization WHERE Name = @DesiredOrgName
DECLARE @DeprecatedOrg int
SELECT @DeprecatedOrg = ID FROM Organization WHERE Name = @DeprecatedOrgName
DECLARE @Album table (Album int)
--select @DesiredOrgname
--select @DeprecatedOrgName
INSERT INTO @Album
SELECT DISTINCT ID FROM Album WHERE Organization = @DeprecatedOrg AND GTIN IN ('9780802721990',
'9780802722294',
'9780802722447',
'9780802722539',
'9780802722591',
'9780802723017',
'9780802723192',
'9780802723239',
'9780802733955',
'9780802735010',
'9780802735188',
'9780802735195',
'9780802735348',
'9780802735584',
'9780802735614',
'9780802736284',
'9780802736758',
'9780802736772',
'9780802736949',
'9780802737359',
'9780802737670',
'9780802737717',
'9780802738103',
'9780802738141',
'9781599903996',
'9781599904078',
'9781599906140',
'9781599906324',
'9781599906386',
'9781599906751',
'9781599907093',
'9781599907468',
'9781599907864',
'9781599908052',
'9781599908663',
'9781599909356',
'9781599909486',
'9781599909899',
'9781619630208',
'9781619630406',
'9781619630468',
'9781619630567',
'9781619630819',
'9781619630840',
'9781619631007',
'9781619631137',
'9781619631168',
'9781619631342',
'9781619631397',
'9781619631410',
'9781619631458',
'9781619632073',
'9781619632110',
'9781619632202',
'9781619632325',
'9781619632509',
'9781619632622',
'9781619632752',
'9781619633001',
'9781619633360',
'9781619633384',
'9781619633476',
'9781619633551',
'9781619633605',
'9781619633759',
'9781619633995',
'9781619634152',
'9781619634251',
'9781619634329',
'9781619634411',
'9781619634435',
'9781619634459',
'9781619634589',
'9781619634602',
'9781619634695',
'9781619634770',
'9781619634831',
'9781619634862',
'9781619635098',
'9781619635111',
'9781619635142',
'9781619635296',
'9781619635746',
'9781619636316',
'9781619636705',
'9781619636804',
'9781619636835',
'9781619637450',
'9781619637801',
'9781619637818',
'9781619637849')

--select * from @Album
DECLARE @AlbumId int

DECLARE Album_Cursor CURSOR LOCAL FOR
SELECT Album FROM @Album


OPEN Album_Cursor
FETCH NEXT FROM album_cursor INTO @AlbumId

WHILE @@fetch_status= 0 
BEGIN

DECLARE @newOrg int = @DesiredOrg
DECLARE @oldAlbumOrg int = (SELECT DISTINCT Organization FROM Album WHERE ID = @AlbumId)
DECLARE @oldSongOrg int = (SELECT DISTINCT S.Organization FROM Album A
INNER JOIN Track T on T.Album = A.ID
INNER JOIN Song S on T.Song = S.ID
WHERE A.ID = @AlbumId AND S.Organization <> @DesiredOrg)
DECLARE @oldCelebOrg int = (SELECT DISTINCT C.Organization FROM Album A
INNER JOIN AlbumCelebrity AC on AC.Album = A.ID
INNER JOIN Celebrity C on C.ID = AC.Celebrity
WHERE A.ID = @AlbumID)

EXEC change_album_owner @AlbumID, @newOrg

INSERT #Changes (Album, oldAlbumOrg, oldSongOrg, oldCelebOrg, newOrg, At)
SELECT @AlbumId, @oldAlbumOrg, @oldSongOrg, @oldCelebOrg, @newOrg, getdate()


FETCH NEXT FROM Album_Cursor INTO @AlbumId
WAITFOR DELAY '00:00:00.500'
END

 CLOSE Album_Cursor
   DEALLOCATE Album_Cursor
   
  END TRY
  
BEGIN CATCH

INSERT #TMerror (Album, NewOrganization, ErrorNumber, ErrorProcedure, ErrorLine, ErrorState, ErrorMessage)
VALUES(@AlbumId, @NewOrg, ERROR_NUMBER(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_STATE(), ERROR_MESSAGE())

END CATCH


SELECT * FROM #TMerror
SELECT * FROM #Changes


SELECT A.ID [Album], A.GTIN [ISBN], S.ID [Song], Cel.Name [Celebrity], R.Name [Role], OOA.Name [Old Album Organization], OOS.Name [Old Song Organization], OOC.Name [Old Celebrity Organization],
NOA.Name [New Album Organization], NOS.Name [New Song Organization], NOC.Name [New Celebrity Organization] FROM 
#Changes C
INNER JOIN Album A ON A.ID = C.Album
LEFT OUTER JOIN Organization OOS on OOS.ID = C.oldSongOrg
INNER JOIN Organization OOA on OOA.ID = C.oldAlbumOrg
INNER JOIN Organization OOC on OOC.ID = C.oldCelebOrg
INNER JOIN AlbumCelebrity AC on AC.Album = A.ID
INNER JOIN Celebrity Cel on Cel.ID = AC.Celebrity
INNER JOIN Organization NOA on NOA.ID = A.Organization
LEFT OUTER JOIN Track T on T.Album = A.ID
LEFT OUTER JOIN Song S on T.Song = S.ID
LEFT OUTER JOIN Organization NOS on NOS.ID = S.Organization
INNER JOIN Organization NOC on NOC.ID = Cel.Organization
INNER JOIN [Role] R on R.ID = AC.[Role]