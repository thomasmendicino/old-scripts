select * from album where gtin = '00044003142381'
select * from album where gtin = '00044003150317'
select * from album where gtin = '00879645001020'

--select * from track where album = (select id from album where gtin = '00044003142381')
select * from track where album = (select id from album where gtin = '00044003150317')
--select * from track where album = (select id from album where gtin = '00879645001020')
--select * from song where id in (select song from track where album = (select id from album where gtin = '00044003142381'))
select * from song where id in (select song from track where album = (select id from album where gtin = '00044003150317'))
--select * from song where id in (select song from track where album = (select id from album where gtin = '00879645001020'))
select * from process
select syndication from tracksyndication where track in (select id from track where album = (select id from album where gtin = '00044003142381'))

select * from syndication where id in (select syndication from tracksyndication where track in (select id from track where album = (select id from album where gtin = '00044003142381')))

select top 50 * from autosynclog where WNPackageID = '276814-388732'
select top 50 * from autosynclog where WNPackageID = '276814-391712'
select top 1000 * from autosynclog order by processed desc-- where WNPackageID = '276814-391712'

select * from autosyncstate

select * from 
\\INDMASTOR01\WamNet-Staging\2011\09\27\10\276814-392648\00602527849386


select * from album where gtin = '00044003150317'

select top 50 * from pendingimport where deliverypath like '%00044003150317%'

select * from process
362299

select * from song where id in (2448798,2456864)

select * from album where gtin = '00879645001020'
select * from encodingstructure where name like '%ingro%'

--need to find the metadata import. order came in on autosync. we imported it. 

select * from pendingimport where date between '2011-09-16' and '2011-09-17' 

UMG INgrooves CA\2011\September\2011-09-14\1000001013946\Delivery_Messages\delivery_1000001013946.xml

select * from '1000001016774'
'1000001016773'
'1000001016775'

select * from importlog where 

UMG Loudtrax\2011\September\2011-09-16\1000001016773\Delivery_Messages\delivery_1000001016773.xml

USZXT1123646

select * from assets where r2isrc = 'USMEM0601001'

select * from syndicationorder where orderbatchid = 1000001025167
select * from album where gtin = '00602527855684'
select * from track where album = (select id from album where gtin = '00602527855684')
select * from song where id in (select song from track where album = (select id from album where gtin = '00602527855684'))

select * from syndicatortype where name like '%ddex%'