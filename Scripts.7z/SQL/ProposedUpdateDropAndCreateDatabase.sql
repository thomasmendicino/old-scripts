﻿DECLARE @Directory nvarchar(max)
DECLARE @LogDirectory nvarchar(max);
SELECT @Directory = LEFT(physical_name, LEN(physical_name)-CHARINDEX('\', REVERSE(physical_name))+1) FROM sys.master_files where name = 'ReportServer' 
SELECT @LogDirectory = LEFT(physical_name, LEN(physical_name)-CHARINDEX('\', REVERSE(physical_name))+1) FROM sys.master_files where name = 'ReportServer_log'

IF NOT EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = @DestinationContextCatalog)
begin
EXECUTE( '
CREATE DATABASE ' + @DestinationContextCatalog + ' ON  PRIMARY 
( NAME = N''' + @DestinationContextCatalog + ''', FILENAME = N''' + @Directory + @DestinationContextCatalog + '.mdf'' , SIZE = '+ @MdfFileInitialSizeMB +'MB , MAXSIZE = UNLIMITED, FILEGROWTH = 128MB )
 LOG ON 
( NAME = N''' + @DestinationContextCatalog + '_log'', FILENAME = N''' + @LogDirectory + @DestinationContextCatalog + '_log.LDF'' , SIZE = '+ @LogFileInitialSizeMB +'MB , MAXSIZE = UNLIMITED , FILEGROWTH = 256MB)')
end