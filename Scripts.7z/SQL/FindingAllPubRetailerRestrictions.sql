/*
what to do:

display a report of publishers that have at least one retailer restriction
Show the publisher, the prohibited retailer, and allowed retailers


temp table with publisherUId, restrictedRetailerUid
temp table with publisherUId, allowedRetailerUid
report with publisher name, string of allowed + string or restricted.
*/

IF OBJECT_ID('tempdb..#RestrictedRetailers') IS NOT NULL DROP TABLE #RestrictedRetailers
GO
IF OBJECT_ID('tempdb..#AllowedRetailers') IS NOT NULL DROP TABLE #AllowedRetailers
GO
IF OBJECT_ID('tempdb..#IgnoredPublishers') IS NOT NULL DROP TABLE #IgnoredPublishers
GO
IF OBJECT_ID('tempdb..#ScholasticContracts') IS NOT NULL DROP TABLE #ScholasticContracts
GO
IF OBJECT_ID('tempdb..#RestRetailers') IS NOT NULL DROP TABLE #RestRetailers
GO
IF OBJECT_ID('tempdb..#AllRetailers') IS NOT NULL DROP TABLE #AllRetailers
GO

DECLARE @ProhibitedPublisher NVARCHAR(MAX)
SET @ProhibitedPublisher = 'Scholastic Inc.'
DECLARE @ProhibitedPublisherUid uniqueidentifier = (select organizationUid from Organizations where organizationName = @ProhibitedPublisher)
DECLARE @ProhibitedPublisher2 NVARCHAR(MAX)
SET @ProhibitedPublisher2 = 'Bloomsbury Publishing'
DECLARE @ProhibitedPublisherUid2 uniqueidentifier = (select organizationUid from Organizations where organizationName = @ProhibitedPublisher2)

create table #IgnoredPublishers (PublisherName nvarchar(max))
;with Organization as
(
    select child.OrganizationUid, child.OrganizationName, child.ParentOrganizationUid, parent.OrganizationName ParentOrganizationName, 0 as Level
    from Organizations child
         left outer join Organizations parent on child.ParentOrganizationUid = parent.OrganizationUid
    where child.OrganizationUid = @ProhibitedPublisherUid

    union all

    select child.OrganizationUid, child.OrganizationName, child.ParentOrganizationUid, parent.OrganizationName ParentOrganizationName, r.Level + 1 as Level
    from Organization r
         inner join Organizations parent on parent.OrganizationUid = r.OrganizationUid
         inner join Organizations child on parent.OrganizationUid = child.ParentOrganizationUid
),
Organization2 as
(
    select child.OrganizationUid, child.OrganizationName, child.ParentOrganizationUid, parent.OrganizationName ParentOrganizationName, 0 as Level
    from Organizations child
         left outer join Organizations parent on child.ParentOrganizationUid = parent.OrganizationUid
    where child.OrganizationUid = @ProhibitedPublisherUid2

    union all

    select child.OrganizationUid, child.OrganizationName, child.ParentOrganizationUid, parent.OrganizationName ParentOrganizationName, r.Level + 1 as Level
    from Organization2 r
         inner join Organizations parent on parent.OrganizationUid = r.OrganizationUid
         inner join Organizations child on parent.OrganizationUid = child.ParentOrganizationUid
)

insert #IgnoredPublishers (PublisherName)
select
     Organization.OrganizationName
from Organization
UNION
select
     Organization2.OrganizationName
from Organization2


create table #ScholasticContracts (contractUId uniqueidentifier)
insert #ScholasticContracts (contractUId)

select c.ContractUid from contracts c 
join distributionContracts dc on dc.ContractUid = c.ContractUid
where c.ValidUntilUtc is NULL and
dc.ValidUntilUtc is NULL and
dc.Name not like '%scholastic%' and
dc.Name not like '%bloomsbury%' and
dc.Name not like '%product%history%ingestion%'

create table #RestrictedRetailers (organizationUid uniqueidentifier, AffectedChild uniqueidentifier, AffectedGrandchild uniqueidentifier, RetailerName nvarchar(100), IsInheritable bit)
insert #RestrictedRetailers (organizationUid/*, AffectedChild, AffectedGrandchild*/, RetailerName, IsInheritable)

select o.organizationUid /*, co.organizationUid, cco.organizationUid*/, r.Name, c.IsInheritable from publishers p
join organizations o on o.OrganizationUid = p.OrganizationUid
join contracts c on c.PublisherUid = p.PublisherUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
join retailers r on r.RetailerUid = c.RetailerUid
where c.ValidUntilUtc is NULL
and rs.Name = 'Distribution Prohibited'
and c.contractUid not in (select contractUid from #ScholasticContracts)
and o.organizationName not like '%scholastic%'
and o.organizationName not like '%blooms%'
order by r.Name

create table #AllowedRetailers (Name nvarchar(50), organizationName nvarchar(200))
insert #AllowedRetailers (Name, organizationName)

select r.Name, p.Name [OrganizationName] from distributionContracts dc
join contracts c on c.ContractUid = dc.ContractUid 
join retailers r on r.retailerUid = c.retailerUid
join publishers p on p.publisherUid = c.publisherUid
join organizations o on o.organizationUid = p.organizationUId
left join organizations co on co.ParentOrganizationUid = o.organizationUid
left join organizations cco on cco.ParentOrganizationUId = co.organizationUid
left join organizations ccco on ccco.ParentOrganizationUid = cco.OrganizationUid
left join Organizations cccco on cccco.ParentOrganizationUid = ccco.OrganizationUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where dc.validUntilUtc is null 
and c.ValidUntilUtc is null
and p.Name not like '%Scholastic%'
and co.OrganizationName not like '%scholastic%'
and p.Name not like '%bloomsbury%'
and co.OrganizationName not like '%bloomsbury%'
and p.Name is not null
UNION
select r.Name, co.OrganizationName from distributionContracts dc
join contracts c on c.ContractUid = dc.ContractUid 
join retailers r on r.retailerUid = c.retailerUid
join publishers p on p.publisherUid = c.publisherUid
join organizations o on o.organizationUid = p.organizationUId
left join organizations co on co.ParentOrganizationUid = o.organizationUid
left join organizations cco on cco.ParentOrganizationUId = co.organizationUid
left join organizations ccco on ccco.ParentOrganizationUid = cco.OrganizationUid
left join Organizations cccco on cccco.ParentOrganizationUid = ccco.OrganizationUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where dc.validUntilUtc is null 
and c.ValidUntilUtc is null
and p.Name not like '%Scholastic%'
and co.OrganizationName not like '%scholastic%'
and p.Name not like '%bloomsbury%'
and co.OrganizationName not like '%bloomsbury%'
and co.OrganizationName is not null
UNION
select r.Name, cco.OrganizationName from distributionContracts dc
join contracts c on c.ContractUid = dc.ContractUid 
join retailers r on r.retailerUid = c.retailerUid
join publishers p on p.publisherUid = c.publisherUid
join organizations o on o.organizationUid = p.organizationUId
left join organizations co on co.ParentOrganizationUid = o.organizationUid
left join organizations cco on cco.ParentOrganizationUId = co.organizationUid
left join organizations ccco on ccco.ParentOrganizationUid = cco.OrganizationUid
left join Organizations cccco on cccco.ParentOrganizationUid = ccco.OrganizationUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where dc.validUntilUtc is null 
and c.ValidUntilUtc is null
and p.Name not like '%Scholastic%'
and co.OrganizationName not like '%scholastic%'
and p.Name not like '%bloomsbury%'
and co.OrganizationName not like '%bloomsbury%'
and cco.OrganizationName is not null
UNION
select r.Name, ccco.OrganizationName from distributionContracts dc
join contracts c on c.ContractUid = dc.ContractUid 
join retailers r on r.retailerUid = c.retailerUid
join publishers p on p.publisherUid = c.publisherUid
join organizations o on o.organizationUid = p.organizationUId
left join organizations co on co.ParentOrganizationUid = o.organizationUid
left join organizations cco on cco.ParentOrganizationUId = co.organizationUid
left join organizations ccco on ccco.ParentOrganizationUid = cco.OrganizationUid
left join Organizations cccco on cccco.ParentOrganizationUid = ccco.OrganizationUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where dc.validUntilUtc is null 
and c.ValidUntilUtc is null
and p.Name not like '%Scholastic%'
and co.OrganizationName not like '%scholastic%'
and p.Name not like '%bloomsbury%'
and co.OrganizationName not like '%bloomsbury%'
and ccco.OrganizationName is not null
UNION
select r.Name, cccco.OrganizationName from distributionContracts dc
join contracts c on c.ContractUid = dc.ContractUid 
join retailers r on r.retailerUid = c.retailerUid
join publishers p on p.publisherUid = c.publisherUid
join organizations o on o.organizationUid = p.organizationUId
left join organizations co on co.ParentOrganizationUid = o.organizationUid
left join organizations cco on cco.ParentOrganizationUId = co.organizationUid
left join organizations ccco on ccco.ParentOrganizationUid = cco.OrganizationUid
left join Organizations cccco on cccco.ParentOrganizationUid = ccco.OrganizationUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where dc.validUntilUtc is null 
and c.ValidUntilUtc is null
and p.Name not like '%Scholastic%'
and co.OrganizationName not like '%scholastic%'
and p.Name not like '%bloomsbury%'
and co.OrganizationName not like '%bloomsbury%'
and cccco.OrganizationName is not null
order by r.Name

create table #RestRetailers (Name nvarchar(50), organizationName nvarchar(200))
insert #RestRetailers (Name, organizationName)
select r.Name, o.OrganizationName from #RestrictedRetailers rr
join retailers r on rr.retailerName = r.Name
join organizations o on o.OrganizationUid = rr.organizationUid
where organizationName not like '%scholastic%'
and organizationName not like '%bloomsbury%'
UNION
select r.name, co.OrganizationName from #RestrictedRetailers rr
join retailers r on rr.retailerName = r.Name
join organizations o on o.OrganizationUid = rr.organizationUid
join organizations co on o.OrganizationUid = co.ParentOrganizationUid
where rr.IsInheritable = 1
and co.organizationName not like '%scholastic%'
and co.organizationName not like '%bloomsbury%'
UNION
select r.name, cco.OrganizationName from #RestrictedRetailers rr
join retailers r on rr.retailerName = r.Name
join organizations o on o.OrganizationUid = rr.organizationUid
join organizations co on o.OrganizationUid = co.ParentOrganizationUid
join organizations cco on co.OrganizationUid = cco.OrganizationUid
where rr.IsInheritable = 1
and cco.organizationName not like '%scholastic%'
and cco.organizationName not like '%bloomsbury%'
UNION
select r.name, cco.OrganizationName from #RestrictedRetailers rr
join retailers r on rr.retailerName = r.Name
join organizations o on o.OrganizationUid = rr.organizationUid
join organizations co on o.OrganizationUid = co.ParentOrganizationUid
join organizations cco on co.OrganizationUid = cco.OrganizationUid
join organizations ccco on cco.OrganizationUid = ccco.OrganizationUid
where rr.IsInheritable = 1
and ccco.organizationName not like '%scholastic%'
and ccco.organizationName not like '%bloomsbury%'
UNION
select r.name, cco.OrganizationName from #RestrictedRetailers rr
join retailers r on rr.retailerName = r.Name
join organizations o on o.OrganizationUid = rr.organizationUid
join organizations co on o.OrganizationUid = co.ParentOrganizationUid
join organizations cco on co.OrganizationUid = cco.OrganizationUid
join organizations ccco on cco.OrganizationUid = ccco.OrganizationUid
join organizations cccco on ccco.OrganizationUid = cccco.OrganizationUid
where rr.IsInheritable = 1
and cccco.organizationName not like '%scholastic%'
and cccco.organizationName not like '%bloomsbury%'

create table #AllRetailers (Name nvarchar(50), organizationName nvarchar(200))
insert #AllRetailers (Name, organizationName)
select * from #AllowedRetailers
except
select * from #RestRetailers

;with pivoter (Retailer, Org, [Allowed]) as 
(select ar.Name Retailer, organizationName Org, 'Allowed' as Allowed
FROM #AllRetailers ar
UNION
Select rr.Name Retailer, organizationName Org, 'X' as Allowed
FROM #RestRetailers rr)
select Imprint, Parent, [3M], [Amazon eBookBase], [Baker And Taylor], [Barnes And Noble], [Google Books], [iBookStore], [KDP], 
[Kobo], [OverDrive], [Follett], [Chegg], [Gardners]
from 
(
SELECT o.OrganizationName [Imprint],
case when po.OrganizationName = 'INscribe Digital' then ''
else po.OrganizationName end as [Parent], p.Allowed, p.Retailer FROM 
organizations o 
inner join pivoter p on p.Org = o.organizationName
left join organizations po on po.organizationUId = o.parentOrganizationUId
where o.organizationName <> 'INscribe Digital'
) as SourceQuery
pivot
(
Max(Allowed)
For Retailer
IN ([Amazon eBookBase], [iBookStore], [Barnes And Noble],[Kobo], [KDP], [OverDrive], [Google Books], [3M], [Baker And Taylor], [Follett], [Chegg], [Gardners])) as pvt
order by Imprint

