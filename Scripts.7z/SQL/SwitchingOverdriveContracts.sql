
select * from DistributionOrderStructureGroupContracts dsgc
join contracts c on c.contractUid = dsgc.ContractUid
join DistributionOrderStructureContracts dsc on dsc.DistributionOrderStructureGroupContractUid = dsgc.DistributionOrderStructureGroupContractUid
where name like '%overdrive%'
and c.ValidUntilUtc is null
and dsc.ResourceContentType not in (1,28)
order by dsgc.name, dsc.PathFormat

select * from DistributionOrderStructureGroupContracts dsgc
join contracts c on c.contractUid = dsgc.ContractUid
join DistributionOrderStructureContracts dsc on dsc.DistributionOrderStructureGroupContractUid = dsgc.DistributionOrderStructureGroupContractUid
where name like '%overdrive%'
and c.ValidFromUtc = '2015-01-29 08:03:18.903'
and dsc.ResourceContentType not in (1,28)
order by dsgc.name, dsc.PathFormat



select do.CreatedAtUtc,* from AthenaDistribution..ProductRevisions pr 
join product p on p.ProductUid = pr.ProductUid
join distributionorders do on do.ProductRevisionUid = pr.ProductRevisionUid
join contracts c on c.contractUid = pr.ContractUid
join Retailers r on r.retailerUid = c.RetailerUid
where --ContractUid = 'E6A94A98-FCB4-4C36-B0FA-485800B2C451'
ordinal = 9780978730291
and r.code = 'ovd'

and do.CreatedAtUtc between '2015-01-29' and '2015-02-7'


--begin tran
--update pr set ContractUid = '0D35CF04-80BB-4969-AEE7-2FFE85E62CCD'
from AthenaDistribution..ProductRevisions pr 
join product p on p.ProductUid = pr.ProductUid
join distributionorders do on do.ProductRevisionUid = pr.ProductRevisionUid
where ContractUid = 'E6A94A98-FCB4-4C36-B0FA-485800B2C451'
and ordinal = 9780978730291
and do.CreatedAtUtc between '2015-01-29' and '2015-02-7'

--update pr set ContractUid = 'A3007F68-E82D-48D9-8061-2ED5B7EB74E4'
from AthenaDistribution..ProductRevisions pr 
join product p on p.ProductUid = pr.ProductUid
join distributionorders do on do.ProductRevisionUid = pr.ProductRevisionUid
where ContractUid = '5B94B4DD-CAD4-4897-A722-4B75BE0A477C'
and ordinal = 9780978730291
and do.CreatedAtUtc between '2015-01-29' and '2015-02-7'

--update pr set ContractUid = 'DEC32C61-7546-448B-BD70-2C48921E7348'
from AthenaDistribution..ProductRevisions pr 
join product p on p.ProductUid = pr.ProductUid
join distributionorders do on do.ProductRevisionUid = pr.ProductRevisionUid
where ContractUid = 'E989BDC6-7CC7-44C1-A688-03C4462535F2'
and ordinal = 9780978730291
and do.CreatedAtUtc between '2015-01-29' and '2015-02-7'


--rollback
select * from folderobjects where path like '%9781629560564%'
--commit



------------------------


--begin tran
--update pr set ContractUid = '0D35CF04-80BB-4969-AEE7-2FFE85E62CCD'
from AthenaDistribution..ProductRevisions pr 
join product p on p.ProductUid = pr.ProductUid
join distributionorders do on do.ProductRevisionUid = pr.ProductRevisionUid
where ContractUid = 'E6A94A98-FCB4-4C36-B0FA-485800B2C451'
and do.CreatedAtUtc between '2015-01-28' and '2015-02-13'

--update pr set ContractUid = 'A3007F68-E82D-48D9-8061-2ED5B7EB74E4'
from AthenaDistribution..ProductRevisions pr 
join product p on p.ProductUid = pr.ProductUid
join distributionorders do on do.ProductRevisionUid = pr.ProductRevisionUid
where ContractUid = '5B94B4DD-CAD4-4897-A722-4B75BE0A477C'
and do.CreatedAtUtc between '2015-01-28' and '2015-02-13'

--update pr set ContractUid = 'DEC32C61-7546-448B-BD70-2C48921E7348'
from AthenaDistribution..ProductRevisions pr 
join product p on p.ProductUid = pr.ProductUid
join distributionorders do on do.ProductRevisionUid = pr.ProductRevisionUid
where ContractUid = 'E989BDC6-7CC7-44C1-A688-03C4462535F2'
and do.CreatedAtUtc between '2015-01-28' and '2015-02-13'
