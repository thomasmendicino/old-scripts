exec job_verify 'indmaxfer2'

--exec job_stop_and_restart 'indmaxfer2', stop, 'indmadb'
--begin tran
--commit
/*
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3249, Machine='INDMAXFER2' where ID =1628
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=2470, Machine='INDMAXFER2' where ID =368
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3671, Machine='INDMAXFER2' where ID =342
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3249, Machine='INDMAXFER2' where ID =442
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=2470, Machine='INDMAXFER2' where ID =135
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3671, Machine='INDMAXFER2' where ID =692
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3671, Machine='INDMAXFER2' where ID =1312
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3249, Machine='INDMAXFER2' where ID =1338
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3671, Machine='INDMAXFER2' where ID =272
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3249, Machine='INDMAXFER2' where ID =1219
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3697, Machine='INDMAXFER2' where ID =282
UPDATE Job set Instruction = 1, At = GetDate(), INDMAUser=3697, Machine='INDMAXFER2' where ID =287
*/

select * from job where id in (282,287,1219,272,1338,1312,692,135,442,342,368,1628)

--rollback

select * from condition