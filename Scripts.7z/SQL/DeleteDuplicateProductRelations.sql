begin tran
;with 
multipleRelations as (
select ProductUid  from AthenaUATProductCatalog..ProductRelation group by ProductUid, ProductRelationType, ProductIdentifierId having count(*) > 1),
productRelationIdsToKeep as (
select pr.ProductRelationId from Product P
join multipleRelations mr on mr.productUid = p.ProductUid
cross apply (
select min(productRelationId) as productRelationId from ProductRelation pr
where pr.productUid = p.ProductUid) pr
)
delete pr from ProductRelation pr
join multipleRelations mr on mr.productUid = pr.ProductUid
where pr.ProductRelationId not in (select productRelationId from productRelationIdsToKeep)