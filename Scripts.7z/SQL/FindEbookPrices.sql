--Find ebook titles with default prices

select distinct rtrim(o.Name) [Imprint], a.BigIntGTIN [ISBN], ptv.AlbumPrice, c.Code [Currency], pt.Name [PriceTier], coalesce(rtrim(ms.Name), NULL) as MusicService from album a
join albumProductType apt on apt.album = a.id
join priceCampaign pc on pc.album = a.id
join priceTier pt on pt.id = pc.startPriceTier
join priceTierMapping ptm on ptm.priceTier = pt.id
join priceTierMappingValue ptv on ptv.ID = ptm.priceTierMappingValue
join currency c on c.id = ptv.currency
join organization o on o.id = a.organization
left outer join musicservice ms on ms.id = pc.musicservice
where apt.productType in (22,23,24)
and a.process in (5,1)
and c.Code = 'USD'
and pc.EndDate is NULL
order by ptv.AlbumPrice desc, a.BigIntGTIN