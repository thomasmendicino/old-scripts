WITH
ProductsEverDistributedSucessfullyToKBO
as
(
select distinct p.Ordinal,  av.AssetVersionUid, rSpecific.Code
from AssetVersion av
inner join AssetOverride ao ON av.AssetOverrideUid = ao.AssetOverrideUid
inner join Asset a ON ao.AssetUid = a.AssetUid
inner join Product p ON a.ProductUid = p.ProductUid
inner join ProductRevisions pr ON p.ProductUid = pr.ProductUid
inner join ProductRevisionStructures prs ON pr.ProductRevisionUid = prs.ProductRevisionUid
inner join DistributionOrders do ON pr.ProductRevisionUid = do.ProductRevisionUid
inner join DistributionOrderStatus dos ON do.DistributionOrderUid = dos.DistributionOrderUid
inner join refEventType ret ON ret.EventTypeId = dos.ResultingEvent
inner join Contracts c ON pr.ContractUid = c.ContractUid
inner join Retailers r ON c.RetailerUid = r.RetailerUid
left join Retailers rSpecific ON ao.RetailerUid = rSpecific.RetailerUid
WHERE
    ret.Code IN ('DITC')
    and r.Code = 'KBO'
	and (rSpecific.Code IS null or rSpecific.Code = 'KBO')
    and av.ValidUntilUtc is null
    and a.ResourceContentType=100
),
DrmProtected 
as 
(
    select distinct p.Ordinal, etp.EpubTechnicalProtectionType
    from ProductsEverDistributedSucessfullyToKBO p
    join EpubTechnicalProtections etp on etp.AssetVersionUid = p.AssetVersionUid
    WHERE
    etp.EpubTechnicalProtectionType > 1
)
select distinct p.Ordinal ISBN, isnull(p.code, '') RetailerSpecific, o.OrganizationName Imprint, case when po.OrganizationName = 'Inscribe Digital' then '' else po.OrganizationName end as Parent from ProductsEverDistributedSucessfullyToKBO p
join product pd on pd.Ordinal = p.Ordinal
join organizations o on o.OrganizationUid = pd.OrganizationUid
join organizations po on po.OrganizationUid = o.ParentOrganizationUid
where p.Ordinal not in 
(
    select Ordinal from DrmProtected
)
order by p.Ordinal

--16243 products delivered that are DRM-Free
--10647 products delivered that are DRM-Free

use AthenaComposite;
select 
o.OrganizationName Imprint
, po.OrganizationName Parent
from organizations o
join organizations po on po.OrganizationUid = o.ParentOrganizationUid
where o.OrganizationName = 'Glenmere Press'


select p.Ordinal EbookISBN, p2.Ordinal PbookISBN
from product p
join ProductRelation pr on pr.ProductUid = p.ProductUid
join ProductIdentifier pd on pd.ProductIdentifierId = pr.ProductIdentifierId
join product p2 on p2.ProductUid = pd.ProductUid
where p2.Ordinal = <pbook>

select * from productRevisionStructures