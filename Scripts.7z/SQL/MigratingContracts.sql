begin try 
   declare @NewContract int
   declare @Contract  int 
   
   -- double check that this cursor is not in use
   
   declare ContractCursor cursor local for
   select Contract from @AlbumContracts        
   
   open ContractCursor
   fetch next from ContractCursor into @Contract    
   
   while @@fetch_status=0
   begin

    declare @ContractServices table(MusicService int)
    insert into @ContractServices(MusicService)
    select distinct MusicService from ContractServiceView where Contract = @Contract
    
    -- find a matching contract under the new organizations contract holder
    set @NewContract =  
      ( select distinct c.ID
       from Contract c
       where c.ContractAuthority = (select ContractAuthority from Contract where ID = @Contract)
        and c.CountrySet = (select ContractAuthority from Contract where ID = @Contract)
        and getdate() >= c.Starts and (c.Ends is null or getdate() <= c.Ends)
        and c.Organization = @ContractOrganization
       intersect
        select Contract 
        from ContractServiceView
        where MusicService in (select MusicService from @ContractServices)
        group by Contract
        having Count(MusicService)=(select Count(*) from @ContractServices)
      )
      
    -- if a contract cannot be found copy the albums contracts under the new owner
    if @NewContract is NULL
    begin      
     exec dbo.copy_contract_with_new_payee @Contract, @ContractOrganization, @NewContract out
    end

    insert into ContractMedia(Contract, Album)
    values(@NewContract, @Album)
    
    fetch next from ContractCursor into @Contract
   end
   
   close ContractCursor
   deallocate ContractCursor
  end try

  begin catch
   insert into xxx_AK_VP_Reconciliation_Error(Album, Song, NewOrganization, ErrorMessage)
   values(@Album, @Song, @NewOrganization, ERROR_MESSAGE())
   
   fetch next from SongCursor into @Album, @Song, @NewOrganization 
   continue
  end catch