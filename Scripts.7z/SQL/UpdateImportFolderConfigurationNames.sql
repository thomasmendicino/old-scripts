declare @FolderProcessors table (FolderProcessorId int, SafeNameFormat nvarchar(200))
insert @FolderProcessors (FolderProcessorId, SafeNameFormat) VALUES
(1, 'ConversionHouse'),
(2, 'Reports'),
(3, 'Ftp'),
(4, 'ClientConsole'),
(5, 'Migration'),
(6, 'ConversionHouse'),
(7, 'Ftp'),
(8, 'ClientConsole'),
(9, 'Migration'),
(10, 'ConversionHouse'),
(11, 'Ftp'),
(12, 'ClientConsole'),
(13, 'Migration')

declare @ToUpdate table (PublisherUid uniqueidentifier)
;with duplicateImportFolders as (
select Name, count(*) as num from AthenaAssetProcessor..importFolderConfigurations 
group by Name
having count(*) > 1)

insert @ToUpdate (PublisherUid)
select ic.PublisherUid
from AthenaAssetProcessor..ImportFolderConfigurations ic
join duplicateImportFolders df on df.Name = ic.Name
order by ic.OrganizationUid, ic.FolderProcessorId

update ic set ic.Name = 'Conversion House: ' + p.Name, ic.SafeName = 'ConversionHouse' + p.SafeName
--select distinct 'Conversion House: ' + p.Name as Name, 'ConversionHouse' + p.SafeName as SafeName, *
from AthenaAssetProcessor..ImportFolderConfigurations ic
	inner join @ToUpdate t on t.PublisherUid = ic.PublisherUid
	inner join AthenaDistribution..Publishers p on p.publisherUid = ic.PublisherUid
	inner join AthenaAssetProcessor..FolderProcessors fp on fp.FolderProcessorId = ic.FolderProcessorId
	inner join @FolderProcessors rfp on rfp.FolderProcessorId = fp.FolderProcessorId
where rfp.SafeNameFormat = 'ConversionHouse'

update ic set ic.Name = 'Client Console: ' + p.Name, ic.SafeName = 'ClientConsole' + p.SafeName
--select distinct 'Client Console: ' + p.Name as Name, 'ClientConsole' + p.SafeName as SafeName, *
from AthenaAssetProcessor..ImportFolderConfigurations ic
	inner join @ToUpdate t on t.PublisherUid = ic.PublisherUid
	inner join AthenaDistribution..Publishers p on p.publisherUid = ic.PublisherUid
	inner join AthenaAssetProcessor..FolderProcessors fp on fp.FolderProcessorId = ic.FolderProcessorId
	inner join @FolderProcessors rfp on rfp.FolderProcessorId = fp.FolderProcessorId
where rfp.SafeNameFormat = 'ClientConsole'

update ic set ic.Name = 'FTP: ' + p.Name, ic.SafeName = 'Ftp' + p.SafeName
--select distinct 'FTP: ' + p.Name as Name, 'Ftp' + p.SafeName as SafeName, *
from AthenaAssetProcessor..ImportFolderConfigurations ic
	inner join @ToUpdate t on t.PublisherUid = ic.PublisherUid
	inner join AthenaDistribution..Publishers p on p.publisherUid = ic.PublisherUid
	inner join AthenaAssetProcessor..FolderProcessors fp on fp.FolderProcessorId = ic.FolderProcessorId
	inner join @FolderProcessors rfp on rfp.FolderProcessorId = fp.FolderProcessorId
where rfp.SafeNameFormat = 'Ftp'

update ic set ic.Name = 'Reports: ' + p.Name, ic.SafeName = 'Reports' + p.SafeName
--select distinct 'Reports: ' + p.Name as Name, 'Reports' + p.SafeName as SafeName, *
from AthenaAssetProcessor..ImportFolderConfigurations ic
	inner join @ToUpdate t on t.PublisherUid = ic.PublisherUid
	inner join AthenaDistribution..Publishers p on p.publisherUid = ic.PublisherUid
	inner join AthenaAssetProcessor..FolderProcessors fp on fp.FolderProcessorId = ic.FolderProcessorId
	inner join @FolderProcessors rfp on rfp.FolderProcessorId = fp.FolderProcessorId
where rfp.SafeNameFormat = 'Reports'

update ic set ic.Name = 'Migration: ' + p.Name, ic.SafeName = 'Migration' + p.SafeName
--select distinct 'Migration: ' + p.Name as Name, 'Migration' + p.SafeName as SafeName, *
from AthenaAssetProcessor..ImportFolderConfigurations ic
	inner join @ToUpdate t on t.PublisherUid = ic.PublisherUid
	inner join AthenaDistribution..Publishers p on p.publisherUid = ic.PublisherUid
	inner join AthenaAssetProcessor..FolderProcessors fp on fp.FolderProcessorId = ic.FolderProcessorId
	inner join @FolderProcessors rfp on rfp.FolderProcessorId = fp.FolderProcessorId
where rfp.SafeNameFormat = 'Migration'