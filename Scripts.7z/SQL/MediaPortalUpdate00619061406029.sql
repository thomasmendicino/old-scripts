--begin tran
--commit
--update album set ReleaseDate = (select ReleaseDate from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
Fields = (select Fields from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
Organization = (select Organization from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
Name = (select Name from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
Mix = (select Mix from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
CLine = (select CLine from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
PLine = (select PLine from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
SalesStartDate = (select SalesStartDate from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
UMGproducttype = (select umgproducttype from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
UMGlabelcore = (select umglabelcore from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
UMGlabellocal = (select umglabellocal from AlbumOverrides where album = (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')),
process = 1, umgincomplete = 0, UMGAccount = 3, UMGOwningTerritory = 'CA' where gtin = '00619061406029'

--00619061406029--00601091070653--

--begin tran
--rollback
--commit
--update track set Fields = ((select top 1 Fields from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')))),
DistributionSet = ((select top 1 DistributionSet from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')))),
UMGRightTypeCore = ((select top 1 UMGRightTypeCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')))),
UMGLabelCore = ((select top 1 UMGLabelCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')))),
UMGLabelLocal = ((select top 1 UMGLabelLocal from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061406029') and Country = (select DefaultCountry from Album where gtin = '00619061406029')))),
UMGOwningTerritory = 'CA' where album = (select ID from album where gtin = '00619061406029')

--begin tran
--rollback
--commit

--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061406029'))),
Performer = (select top 1 Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061406029'))),
Genre = (select top 1 Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061406029'))),
PLine = (select top 1 PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061406029'))),
Process = 1, MediaPortalIncomplete = 0 where ID in (select Song from Track where Album = (select ID from album where gtin = '00619061406029'))
--13 rows
--begin tran
--commit

/*
--begin tran
--rollback
insert SongCelebrity (Song, Celebrity, Role)
select 2514055, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514056, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514057, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514058, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514059, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514060, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514061, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514062, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514063, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514064, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514065, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514066, 208916, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2514067, 208916, 1
*/


select Celebrity from AlbumCelebrity where Album = (select id from Album where gtin = '00619061406029')

select * from albumoverrides where album = 314162
select * from albumcelebrity where album = 314162
select * from albumgenre where album = 314162
--begin tran
--commit
declare @gtin nvarchar (14)
declare @AlbumCelebrity int
set @gtin = '00619061406029'
set @AlbumCelebrity = (select Celebrity from AlbumCelebrity where Album = (select id from Album where gtin = @gtin) and country = (select defaultcountry from album where gtin = @gtin))
insert AlbumCelebrity (Album, Celebrity, Role)
select (select ID from album where gtin = @gtin), @AlbumCelebrity, (select role from AlbumCelebrity where Album = (select id from album where gtin = @gtin) and country = (select defaultcountry from album where gtin = @gtin))

--insert AlbumGenre (Album, Genre, Sequence)
select (select ID from album where gtin = '00619061406029'), 19, 1



select * from celebrity where id = 54235
select * from celebrity where id = 252210

select * from albumgenre where album = 314162
select * from album where gtin = '00619061406029'
select * from albumoverrides where album = 314162 and country = (select defaultcountry from album where id = 314162)
select * from process
select genre, * from song where id in (select song from track where album in (select id from album where gtin in ('00619061406029')))
select * from songoverrides where song in (select song from track where album in (select id from album where gtin in ('00619061406029'))) and country = (select defaultcountry from album where id = 314162) order by name
select * from track where album = (select id from album where gtin = '00619061406029')
select * from trackoverrides where track in (select id from track where album = (select id from album where gtin = '00619061406029')) and country = (select defaultcountry from album where id = 314162)
select * from songcelebrity where song in (select song from track where album = 314162) and (country = 248 or country is null)

select * from album where mix is not null