use [AthenaAssetProcessor]

begin tran

delete atc
---SELECT TOP 1000 atc.*, fp.FolderProcessorAlias
FROM [dbo].[AssetTypeCriterias] atc
inner join [dbo].[FolderProcessors] fp on fp.FolderProcessorId = atc.FolderProcessorId
where atc.FileExtension like '%_drp%' AND fp.FolderProcessorAlias like '%Scholastic%'

  --commit
  rollback