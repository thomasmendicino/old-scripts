
;with #latestTransfer as
(select max(b.TransferCompletedAtUTC) latest, p.Ordinal, r.SafeName from AthenaDistributionWorkflow.dbo.Batch b
join AthenaDistributionWorkflow.dbo.BatchPacketSyndication bps on bps.batchId = b.BatchId
join AthenaDistributionWorkflow.dbo.PacketSyndication pks on pks.PacketSyndicationUid = bps.PacketSyndicationUid
join AthenaDistributionWorkflow.dbo.Packet pk on pk.PacketUid = pks.PacketUid
join AthenaDistributionWorkflow.dbo.DistributionOrder do on do.DistributionOrderUid = pk.DistributionOrderUid
join AthenaProductCatalog..product p on p.productUid = do.ProductUid 
join AthenaWorkflowConfiguration..Retailer r on r.RetailerUid = do.RetailerUid and r.retailerUid = b.retailerUid
where b.TransferCompletedAtUTC is not null
group by r.SafeName, p.Ordinal)

select distinct p.Ordinal [ISBN], te.TitleText [Title], te.Subtitle, r.Name [Retailer], dateadd(hh,-7, b.TransferCompletedAtUtc) [Transferred At], o.OrganizationName [Publisher], tp.name from AthenaDistributionWorkflow.dbo.Batch b
join AthenaDistributionWorkflow.dbo.BatchPacketSyndication bps on bps.batchId = b.BatchId
join AthenaDistributionWorkflow.dbo.PacketSyndication pks on pks.PacketSyndicationUid = bps.PacketSyndicationUid
join AthenaDistributionWorkflow.dbo.Packet pk on pk.PacketUid = pks.PacketUid
join AthenaDistributionWorkflow.dbo.DistributionOrder do on do.DistributionOrderUid = pk.DistributionOrderUid
join AthenaProductCatalog..product p on p.productUid = do.ProductUid 
join AthenaWorkflowConfiguration..Retailer r on r.RetailerUid = do.RetailerUid and r.retailerUid = b.retailerUid
join AthenaProductCatalog..productTitles pt on pt.productUid = p.productUid
join AthenaProductCatalog..TitleDetails td on td.ProductTitleId = pt.ProductTitleId
join AthenaProductCatalog..TitleElements te on te.TitleDetailId = td.TitleDetailId
join AthenaProductCatalog..TMProductFormType tp on tp.productFormType = p.ProductFormType
join AthenaSecurity..Organizations o on o.organizationUid = p.OrganizationUid
join #latestTransfer lt on lt.latest = b.TransferCompletedAtUtc
where tp.Name = 'DigitalDownload' and 
b.TransferCompletedAtUtc is not null and te.TitleText is not null
--and lt.latest > getUTCdate()-7
order by o.OrganizationName, r.Name, p.Ordinal