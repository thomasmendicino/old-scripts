--(@OrganizationUid nvarchar(36),@ReportStartDate datetime,@ReportEndDate nvarchar(4000),@eISBNs nvarchar(4000),@eISBNList nvarchar(4000),@RetailerUidList nvarchar(36))-- Uncomment next 2 lines for debugging in ssms

declare @OrgUids table (orgUid uniqueidentifier)

declare @organizationName nvarchar(100)
select @organizationname = 'Bloomsbury Publishing'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @OrgUids
select organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select '00000000-0000-0000-0000-000000000001'

--select * from @Disney


DECLARE @ReportStartDate as date = '2015-02-13'
DECLARE @ReportEndDate as date = null

DECLARE @DigitalProductFormTypes table
(
	ProductFormTypeValue int NOT NULL PRIMARY KEY,
	Name varchar(2)
);

INSERT INTO @DigitalProductFormTypes
	VALUES (49, 'EA'),
	(50, 'EB'),
	(51,'EC'), 
	(52,'ED'), 
	(59,'LA'), 
	(60,'LB'), 
	(61, 'LC')

DECLARE @CollectionTypeCode int = 10
DECLARE @ContributorRoleTypeCode int = 1
DECLARE @MetadataResourceContentType int = 100
DECLARE @WholesalePriceType int = 1
DECLARE @AgencyPriceType int = 14

IF OBJECT_ID('tempdb..#CountrySetCountries') IS NOT NULL 
	DROP TABLE #CountrySetCountries
SELECT r.Country, r.CountrySetUid, r.CountryList
INTO #CountrySetCountries
FROM
(
	SELECT 
		substring(cs.CountryList, v.number+1, 2) as Country
		,v.number as RowNumber
		,cs.CountrySetUid, cs.CountryList
	FROM CountrySets cs
		JOIN MASTER..spt_values v on v.number < len(cs.CountryList)
	WHERE v.type = 'P'
) r
WHERE (RowNumber % 2) = 0
--47s


--select * from #CountrySetCountries

--select * from #ValidMetadata
IF OBJECT_ID('tempdb..#ValidMetaData') IS NOT NULL DROP TABLE #ValidMetaData 
SELECT
    av.AssetVersionUid,
	p.ProductUid,
	pub.OrganizationUid,
	pub.OrganizationName,
	p.Ordinal,
	r.Code,
	av.ValidFromUtc
INTO #ValidMetaData
FROM 
	AssetOverride ao
    INNER JOIN Asset a on ao.AssetUid = a.AssetUid
    INNER JOIN Product p on a.ProductUid = p.ProductUid
    Left JOIN Retailers r on ao.RetailerUid = r.RetailerUid
    INNER JOIN AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
    INNER JOIN Organizations pub on p.OrganizationUid = pub.OrganizationUid
	INNER JOIN ProductForms pf ON av.AssetVersionUid = pf.AssetVersionUid
	INNER JOIN @DigitalProductFormTypes dpft ON pf.ProductFormTypeValue = dpft.ProductFormTypeValue
WHERE
	a.ResourceContentType = @MetadataResourceContentType
	AND av.ValidUntilUtc IS NULL
-- comment next 3 lines for debugging in ssms
	--AND (@eISBNs IS NULL OR p.Ordinal IN (@eISBNList))   -- In the List of supplied ISBNs
	--AND (ao.RetailerUid IS NULL OR r.retailerUid IN (@RetailerUidList)) -- In the List of supplied retailers
	AND pub.OrganizationUid in (select orgUid from @OrgUids)

IF OBJECT_ID('tempdb..#Title') IS NOT NULL
	DROP TABLE #Title
select av.AssetVersionUid, te.TitleText as Title INTO #Title 
from assetVersion av
	join TitleDetails td on td.AssetVersionUid = av.AssetVersionUid
	join TitleElements te on te.TitleDetailId = td.TitleDetailId
	join #ValidMetadata m on m.AssetVersionuid = av.AssetVersionUid
	where av.validUntilUtc is NULL
	and te.TitleText is not null
	
	
/*
IF OBJECT_ID('tempdb..#Subtitle') IS NOT NULL
	DROP TABLE #Subtitle
SELECT
	m.AssetVersionUid,
	(SELECT top 1 ISNULL(te.Subtitle,'')
		FROM
			TitleDetails td
			INNER JOIN TitleElements te ON te.TitleDetailId = td.TitleDetailId
		WHERE
			td.TitleTypeCode = 1				-- TitleTypeCode.DistinctiveTitle
			AND te.TitleElementLevel = 1		-- TitleElementLevelCode.Product
			AND (td.CollectionId is null)
			AND m.AssetVersionUid = td.AssetVersionUid) Title
INTO #Subtitle
FROM
	#ValidMetadata m
    
IF OBJECT_ID('tempdb..#CollectionTitle') IS NOT NULL
    DROP TABLE #CollectionTitle     
SELECT
	m.AssetVersionUid,
	(SELECT TOP 1
		COALESCE(te.TitleText, ISNULL(te.TitlePrefix + ' ', '') + te.TitleWithoutPrefix, td.TitleStatement) AS Title
	FROM
	    Collections c
	    INNER JOIN TitleDetails td ON c.CollectionId = td.CollectionId
        INNER JOIN TitleElements te ON td.TitleDetailId = te.TitleDetailId
    WHERE
    	c.CollectionTypeCode = @CollectionTypeCode
		AND td.TitleTypeCode = 1			-- TitleTypeCode.DistinctiveTitle
		AND te.TitleElementLevel = 1		-- TitleElementLevelCode.Product
	    AND td.CollectionId IS NOT NULL
	    AND m.AssetVersionUid = c.AssetVersionUid) Title
INTO #CollectionTitle
FROM
    #ValidMetadata m

IF OBJECT_ID('tempdb..#Authors') IS NOT NULL
    DROP TABLE #Authors
SELECT
    m.AssetVersionUid,
    STUFF((
        SELECT ', ' + REPLACE(REPLACE(REPLACE(PersonName, CHAR(9), ''), CHAR(10), ''), CHAR(13), '')
        FROM Contributors c
        INNER JOIN ContributorRoles cr ON c.ContributorId = cr.ContributorId
        AND cr.ContributorRoleType = @ContributorRoleTypeCode
        WHERE c.AssetVersionUid = m.AssetVersionUid
        FOR XML PATH('')), 1, 2, '') Authors
INTO #Authors
FROM
    #ValidMetadata m
*/
IF OBJECT_ID('tempdb..#WholesalePrices') IS NOT NULL DROP TABLE #WholesalePrices
SELECT m.AssetVersionUid, ts.CountrySetUid, pt.TierName WholesalePrice
INTO #WholesalePrices
		FROM #ValidMetadata m
			join TerritorySupplies ts on ts.AssetVersionUid = m.AssetVersionUid
			join TerritorySupplyDetails tsd on tsd.TerritorySupplyId = ts.TerritorySupplyId
			left outer join prices pr on pr.TerritorySupplyDetailId = tsd.TerritorySupplyDetailId
			left outer join refCurrencyCode cc on pr.Currency = cc.CurrencyCodeId
			left JOIN refPriceTierLookup pt on cc.CurrencyCode = pt.CurrencyCode
		WHERE 
			(pr.PriceType is null or pr.priceType = @WholesalePriceType)
			AND pr.EffectiveFromUtc is null -- non campaign price
			AND pr.EffectiveToUtc is null -- non campaign price
			AND (pr.Amount is NULL or pr.Amount > pt.StartExclusive)
			AND (pr.Amount is NULL or pr.Amount <= pt.EndInclusive)
			AND pr.TerritorySupplyDetailId is not null
			and pr.Currency is not null


IF OBJECT_ID('tempdb..#AgencyPrices') IS NOT NULL DROP TABLE #AgencyPrices
SELECT m.AssetVersionUid, ts.CountrySetUid, pt.TierName AgencyPrice
INTO #AgencyPrices
		FROM #ValidMetadata m
			join TerritorySupplies ts on ts.AssetVersionUid = m.AssetVersionUid
			join TerritorySupplyDetails tsd on tsd.TerritorySupplyId = ts.TerritorySupplyId
			left outer join prices pr on pr.TerritorySupplyDetailId = tsd.TerritorySupplyDetailId
			left outer join refCurrencyCode cc on pr.Currency = cc.CurrencyCodeId
			left JOIN refPriceTierLookup pt on cc.CurrencyCode = pt.CurrencyCode
		WHERE 
			(pr.PriceType is null or pr.priceType = @AgencyPriceType)
			AND pr.EffectiveFromUtc is null -- non campaign price
			AND pr.EffectiveToUtc is null -- non campaign price
			AND (pr.Amount is NULL or pr.Amount > pt.StartExclusive)
			AND (pr.Amount is NULL or pr.Amount <= pt.EndInclusive)
			AND pr.TerritorySupplyDetailId is not null
			and pr.Currency is not null

IF OBJECT_ID('tempdb..#ValidPriceCampaignsTempDuplicates') IS NOT NULL 
	DROP TABLE #ValidPriceCampaignsTempDuplicates
;WITH 
AllPromoPrices
as(
select 
		ts2.AssetVersionUid
		,ts2.CountrySetUid
		,pr2.PriceType
		,pr2.EffectiveFromUtc
		,pr2.EffectiveToUtc	
		,pr2.Currency
		,pr2.Amount
FROM
	#ValidMetaData m
	INNER JOIN TerritorySupplies ts2 on m.AssetVersionUid = ts2.AssetVersionUid
	INNER JOIN TerritorySupplyDetails tsd2 ON ts2.TerritorySupplyId = tsd2.TerritorySupplyId
	INNER JOIN Prices pr2 ON tsd2.TerritorySupplyDetailId = pr2.TerritorySupplyDetailId
WHERE
	pr2.EffectiveFromUtc is not null -- price campaign
	OR pr2.EffectiveToUtc is not null   -- price campaign
),
PromoPricesInsideDateRange
AS
(
    SELECT  pt.TierName
		,app.AssetVersionUid
		,app.CountrySetUid
		,app.PriceType
		,app.EffectiveFromUtc
		,app.EffectiveToUtc		
		FROM AllPromoPrices app
			INNER JOIN refCurrencyCode cc on app.Currency = cc.CurrencyCodeId
			INNER JOIN refPriceTierLookup pt on cc.CurrencyCode = pt.CurrencyCode
		WHERE app.Amount > pt.StartExclusive
			AND app.Amount <= pt.EndInclusive
)
SELECT
	allPP.AssetVersionUid
	,allPP.EffectiveFromUtc
	,allPP.EffectiveToUtc
	,cs.CountryList as Territories
	,cs.CountrySetUid as CountrySetUid
	,ISNULL((SELECT TOP 1 pp.TierName
		FROM PromoPricesInsideDateRange pp
			INNER JOIN #AgencyPrices ap on 
				(pp.AssetVersionUid = ap.AssetVersionUid AND pp.CountrySetUid = ap.CountrySetUid)
		WHERE pp.PriceType = @AgencyPriceType
			AND pp.AssetVersionUid = allPP.AssetVersionUid
			AND pp.CountrySetUid = allPP.CountrySetUid
			AND pp.TierName <> ap.AgencyPrice
			AND ((pp.EffectiveFromUtc is null and allPP.EffectiveFromUtc is null) or pp.EffectiveFromUtc = allPP.EffectiveFromUtc)
			AND ((pp.EffectiveToUtc is null and allPP.EffectiveToUtc is null) or pp.EffectiveToUtc = allPP.EffectiveToUtc)),'') [AgencyPromoPrice]
	,ISNULL((SELECT TOP 1 pp.TierName
		FROM PromoPricesInsideDateRange pp
			INNER JOIN #WholesalePrices wp on 
				(pp.AssetVersionUid = wp.AssetVersionUid AND pp.CountrySetUid = wp.CountrySetUid)
		WHERE pp.PriceType = @WholesalePriceType
			AND pp.AssetVersionUid = allPP.AssetVersionUid
			AND pp.CountrySetUid = allPP.CountrySetUid
			AND pp.TierName <> wp.WholesalePrice
			AND ((pp.EffectiveFromUtc is null and allPP.EffectiveFromUtc is null) or pp.EffectiveFromUtc = allPP.EffectiveFromUtc)
			AND ((pp.EffectiveToUtc is null and allPP.EffectiveToUtc is null) or pp.EffectiveToUtc = allPP.EffectiveToUtc)),'') [WholesalePromoPrice]
INTO #ValidPriceCampaignsTempDuplicates
FROM
	AllPromoPrices allPP
	INNER JOIN CountrySets cs on allPP.CountrySetUid = cs.CountrySetUid
WHERE
	(@ReportStartDate is null or allPP.EffectiveFromUtc >= @ReportStartDate)
	AND (@ReportEndDate is null or allPP.EffectiveToUtc < dateadd(day, 1, @ReportEndDate))
	
IF OBJECT_ID('tempdb..#ValidPriceCampaignsTemp') IS NOT NULL 
	DROP TABLE #ValidPriceCampaignsTemp
SELECT 
	AssetVersionUid
    ,EffectiveFromUtc
	,EffectiveToUtc
	,Territories
	,CountrySetUid
	,AgencyPromoPrice
	,WholesalePromoPrice
INTO #ValidPriceCampaignsTemp
FROM (
    SELECT 
		AssetVersionUid
		,EffectiveFromUtc
		,EffectiveToUtc
		,Territories
		,CountrySetUid
		,AgencyPromoPrice
		,WholesalePromoPrice
        ,ROW_NUMBER() OVER(PARTITION BY 
								AssetVersionUid
								, AgencyPromoPrice
								, WholesalePromoPrice
								, Territories
								, EffectiveFromUtc
								,EffectiveToUtc 
							ORDER BY AssetVersionUid, AgencyPromoPrice, WholesalePromoPrice, Territories) Number
    FROM #ValidPriceCampaignsTempDuplicates
) t
WHERE Number = 1
	AND NOT (AgencyPromoPrice = '' AND WholesalePromoPrice = '')

IF OBJECT_ID('tempdb..#ValidPriceCampaignsByCountryList') IS NOT NULL 
	DROP TABLE #ValidPriceCampaignsByCountryList
SELECT 
		a.AssetVersionUid
		,a.EffectiveFromUtc
		,a.EffectiveToUtc
		,a.WholesalePromoPrice
		,a.AgencyPromoPrice
		,a.CountrySetUid
		,Country
INTO #ValidPriceCampaignsByCountryList
FROM 
	#ValidPriceCampaignsTemp a
	JOIN #CountrySetCountries csc on csc.CountryList = a.Territories
ORDER BY a.AssetVersionUid, Country

IF OBJECT_ID('tempdb..#ValidPriceCampaigns') IS NOT NULL 
	DROP TABLE #ValidPriceCampaigns
select
	pcl.AssetVersionUid,
	EffectiveFromUtc,
	EffectiveToUtc,
	wp.WholesalePrice,
	WholesalePromoPrice,
	ap.AgencyPrice,
	AgencyPromoPrice,
	Territories =
		stuff(
			(select ' ' + Country
			 from #ValidPriceCampaignsByCountryList pc2
			 where pcl.AssetVersionUid = pc2.AssetVersionUid and
				   ((pcl.EffectiveFromUtc is null and pc2.EffectiveFromUtc is null) or pcl.EffectiveFromUtc = pc2.EffectiveFromUtc) and
				   ((pcl.EffectiveToUtc is null and pc2.EffectiveToUtc is null) or pcl.EffectiveToUtc = pc2.EffectiveToUtc) and
				   pcl.WholesalePromoPrice = pc2.WholesalePromoPrice and
				   pcl.AgencyPromoPrice = pc2.AgencyPromoPrice
			 order by Country
			 for xml path('')),
			1, 1, '')
into #ValidPriceCampaigns
from #ValidPriceCampaignsByCountryList pcl
	INNER JOIN #AgencyPrices ap ON 
		(pcl.AssetVersionUid = ap.AssetVersionUid AND pcl.CountrySetUid = ap.CountrySetUid)
    INNER JOIN #WholesalePrices wp ON 
		(pcl.AssetVersionUid = wp.AssetVersionUid AND pcl.CountrySetUid = wp.CountrySetUid)
group by
	pcl.AssetVersionUid,
	EffectiveFromUtc,
	EffectiveToUtc,
	wp.WholesalePrice,
	WholesalePromoPrice,
	ap.AgencyPrice,
	AgencyPromoPrice

IF OBJECT_ID('tempdb..#ValidPriceCampaignsByRetailer') IS NOT NULL DROP TABLE #ValidPriceCampaignsByRetailer
SELECT
    m.OrganizationUid
    ,m.OrganizationName [PublisherName]
    ,m.Ordinal [ISBN]
    ,vpc.WholesalePrice [WholesalePriceTier]
    ,vpc.WholesalePromoPrice [WholesalePromoPriceTier]
    ,vpc.AgencyPrice [AgencyPriceTier]
    ,vpc.AgencyPromoPrice [AgencyPromoPriceTier]
    ,t.Title [Title]
    --,st.Title [Subtitle]
    --,ct.Title [Series]
    --,a.Authors
    ,vpc.Territories
	,m.Code
    ,vpc.EffectiveFromUtc [BeginDateUtc]
    ,vpc.EffectiveToUtc [EndDateUtc]
INTO #ValidPriceCampaignsByRetailer
FROM #ValidMetaData m
	INNER JOIN #Title t ON m.AssetVersionUid = t.AssetVersionUid
    --INNER JOIN #CollectionTitle ct ON m.AssetVersionUid = ct.AssetVersionUid
    --INNER JOIN #Subtitle st ON m.AssetVersionUid = st.AssetVersionUid
    --INNER JOIN #Authors a ON m.AssetVersionUid = a.AssetVersionUid
    INNER JOIN #ValidPriceCampaigns vpc ON m.AssetVersionUid = vpc.AssetVersionUid
ORDER BY m.Ordinal, m.Code

--select * from #ValidPriceCampaignsByRetailer
--select * from #ValidPriceCampaigns

/*
--(92 row(s) affected)

(7 row(s) affected)

(72303 row(s) affected)

(7995 row(s) affected)
The statement has been terminated.
Query was cancelled by user.
*/



IF OBJECT_ID('tempdb..#ValidPriceCampaignsByRetailerListDuplicates') IS NOT NULL 
	DROP TABLE #ValidPriceCampaignsByRetailerListDuplicates
SELECT 
	OrganizationUid
    ,PublisherName
    ,ISBN
    ,WholesalePriceTier
    ,WholesalePromoPriceTier
    ,AgencyPriceTier
    ,AgencyPromoPriceTier
    ,Title
    --,Subtitle
    --,Series
    --,Authors
    ,Territories
	,STUFF((
        SELECT ' ' + Code
        FROM #ValidPriceCampaignsByRetailer vpcr2
        WHERE vpcr2.ISBN = vpcr1.ISBN
			AND (vpcr2.BeginDateUtc = vpcr1.BeginDateUtc
				OR (vpcr2.BeginDateUtc is null AND vpcr1.BeginDateUtc is null))
			AND (vpcr2.EndDateUtc = vpcr1.EndDateUtc 
				OR (vpcr2.EndDateUtc is null AND vpcr1.EndDateUtc is null))
			AND vpcr2.Territories = vpcr1.Territories
			AND vpcr2.WholesalePromoPriceTier = vpcr1.WholesalePromoPriceTier
			AND vpcr2.AgencyPromoPriceTier = vpcr1.AgencyPromoPriceTier
			AND (vpcr2.Code is not null AND vpcr1.Code is not null)
        FOR XML PATH('')), 1, 1, '') AS RetailerCode
    ,BeginDateUtc
    ,EndDateUtc
INTO #ValidPriceCampaignsByRetailerListDuplicates
FROM #ValidPriceCampaignsByRetailer vpcr1

SELECT 
	OrganizationUid
    ,PublisherName
    ,ISBN
    ,WholesalePriceTier
    ,WholesalePromoPriceTier
    ,AgencyPriceTier
    ,AgencyPromoPriceTier
    ,Title
    --,Subtitle
    --,ISNULL( Series, '') [Series]
    --,Authors
    ,Territories
	,RetailerCode
    ,BeginDateUtc
    ,EndDateUtc
FROM (
    SELECT 
		OrganizationUid
		,PublisherName
		,ISBN
		,WholesalePriceTier
		,WholesalePromoPriceTier
		,AgencyPriceTier
		,AgencyPromoPriceTier
		,Title
--		,Subtitle
		--,Series
		--,Authors
		,Territories
	    ,ISNULL(RetailerCode,'') as RetailerCode
		,BeginDateUtc
		,EndDateUtc
        ,ROW_NUMBER() OVER
			(PARTITION BY 
				ISBN
				,RetailerCode
				,BeginDateUtc
				,EndDateUtc
				,Territories
				,WholesalePromoPriceTier
				,AgencyPromoPriceTier
				,BeginDateUtc
				,EndDateUtc
			ORDER BY ISBN, RetailerCode) Number
    FROM #ValidPriceCampaignsByRetailerListDuplicates
) t
WHERE Number = 1
ORDER BY PublisherName asc, ISBN asc , BeginDateUtc asc, EndDateUtc asc

