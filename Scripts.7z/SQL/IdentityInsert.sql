SET IDENTITY_INSERT zeusBeta.dbo.orderSet OFF
SET IDENTITY_INSERT zeusBeta.dbo.[order] OFF
SET IDENTITY_INSERT zeusBeta.dbo.orderBatch OFF
declare @orderSet bigint
declare @ord bigint
select @orderSet = 1000002100000
select @ord = 1000002100000
begin tran
--INSERT orderSet (ID, orderSetType, INDMAUser, InsertedAt, IgnoreHoldDate)
--SELECT 1000002100000,1,1, getdate(), 0

--INSERT [order] (ID, orderSet, musicservice, orderstate, orderpriority, insertedat, billable, ignorebundling, redeliver, ignorewatermark)
--SELECT 1000002100000, @orderSet, 1, 4, 1, getdate(), 0, 0, 0, 1

--select * from orderstate


INSERT orderBatch (ID, [order], orderFulfillmentsystem, orderbatchstate, insertedat)
SELECT 1000002200000, 1000002100000, 1, 7, getdate()


--commit
--rollback
--SET IDENTITY_INSERT zeusBeta.dbo.orderSet OFF


SET IDENTITY_INSERT zeusBeta.dbo.[order] ON
begin tran
INSERT [order] (ID)
SELECT 1000002100000
--commit
--rollback
SET IDENTITY_INSERT zeusBeta.dbo.orderSet OFF
SET IDENTITY_INSERT zeusBeta.dbo.[order] OFF
SET IDENTITY_INSERT zeusBeta.dbo.orderBatch OFF

select top 500 * from [order] order by id desc
select top 5 * from orderbatch order by id desc
select top 5 * from orderset order by id desc

select top 5000 * from ingrooveslog.dbo.log

select * from email where person = 2
select top 500 * from ingrooveslog.dbo.log where machinename like '%beta%' and (message like '%syndicationprocessor%error%initializing%data%' or message like '%incoming%tabular%')
select top 500 * from ingrooveslog.dbo.log where machinename like '%beta%' and message like '%incoming%tabular%'

select * from person
SyndicationProcessorJob OrderBatch ID 1000002000106: Error initializing data provider: AlbumProvider using method: Boolean initialize(IOrderBatchProvider) 
select * from orderbatch where id = 1000002000106
select * from orderbatch where [order] = 1000001079238
select * from [order] where id = 1000001079238
select * from ordercountry oc
join [order] o on o.id = oc.[order]
join orderalbum oa on oa.ordercountry = oc.id
where o.id = 1000001079238

select * from orderbatch where id in (1000002000047,1000002000106)

select * from [order] o 
join ordercountry oc on oc.[order] = o.id
join orderalbum oa on oa.ordercountry = oc.id
where o.id = 1000001079238


select * 