/*
This report is only a report of NEW titles imported into Athena
*/
 ;with #SingleMainArtist as
                                                            (select ac.Album, min(ac.ID) [AlbCelId]
                                                            from AlbumCelebrity ac
                                                            join Album a on a.id = ac.album
                                                            join AthenaAlbum aa on aa.album = a.id
                                                            where ac.Role = 1
                                                            group by ac.Album)
                                                        select distinct a.Name [Title], rtrim(GTIN) [ISBN], c.Name [Author], o.Name [Imprint] from album a 
                                                            inner join AthenaAlbum AA on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            inner join AlbumCelebrity ac on ac.album = a.id
                                                            inner join Celebrity c on c.id = ac.Celebrity
                                                            inner join Role r on r.id = ac.Role
                                                            inner join #SingleMainArtist sma on sma.AlbCelId = ac.ID
                                                            where r.Name = 'Main Artist'
                                                            and A.CreatedAt > '2013-08-12 15:30:00.00'
                                                            order by o.Name, a.Name
													
/*****************************************************************/
/* 
This report includes retailer distribution information for titles that went out as New Releases from Athena. Change requests are not included, and titles that went 
out to retailers in INDMA from orgs that previously lived in INDMA are not included.
*/
declare @lastRunAt datetime
set @lastRunAt = '2013-08-26 10:20:00.00'
;with #SingleMainArtist as
                                                            (select ac.Album, min(ac.ID) [AlbCelId]
                                                            from AlbumCelebrity ac
                                                            join Album a on a.id = ac.album
                                                            join AthenaAlbum aa on aa.album = a.id
                                                            where ac.Role = 1
                                                            group by ac.Album),
#NewSyndications as (select a.GTIN ISBN, o.Name Imprint, rtrim(ms.Name) Retailer from album a
															inner join athenaAlbum aa on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            left outer join AlbumSyndicationView asv on asv.Album = a.id
                                                            left outer join MusicService ms on ms.id = asv.musicservice
                                                            where AI.UpdatedAt > @lastRunAt
                                                            except
                                                            select a.GTIN ISBN, o.Name Imprint, rtrim(ms.Name) Retailer from album a
															inner join athenaAlbum aa on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            left outer join AlbumSyndicationView asv on asv.Album = a.id
                                                            left outer join MusicService ms on ms.id = asv.musicservice
                                                            where AI.UpdatedAt <= @lastRunAt),
#INDMASyndications as (select distinct a.GTIN ISBN, o.Name Imprint, rtrim(ms.Name) Retailer from album a
                                                            inner join organization o on o.id = a.organization
                                                            inner join xxx_AthenaMigratedOrgs amo on amo.org = o.id
                                                            inner join albumSyndicationView asv on asv.album = a.id
                                                            inner join musicService ms on ms.id = asv.musicservice
                                                            where asv.SyndicatedAt < amo.MigratedAt)
select distinct a.Name [Title], rtrim(GTIN) [ISBN], c.Name [Author], o.Name [Imprint], rtrim(ms.Name) [Retailer] from album a 
                                                            inner join AthenaAlbum AA on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            inner join AlbumCelebrity ac on ac.album = a.id
                                                            inner join Celebrity c on c.id = ac.Celebrity
                                                            inner join Role r on r.id = ac.Role
                                                            inner join #SingleMainArtist sma on sma.AlbCelId = ac.ID
                                                            inner join AlbumSyndicationView asv on asv.Album = a.id
                                                            inner join MusicService ms on ms.id = asv.musicservice
                                                            inner join #NewSyndications ns on ns.ISBN = a.GTIN and ns.Imprint = o.Name and ns.Retailer = rtrim(ms.Name)
                                                            where r.Name = 'Main Artist'
                                                            UNION
                                                            select distinct a.Name [Title], rtrim(GTIN) [ISBN], c.Name [Author], o.Name [Imprint], rtrim(ms.Name) [Retailer] from album a 
                                                            inner join AthenaAlbum AA on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            inner join AlbumCelebrity ac on ac.album = a.id
                                                            inner join Celebrity c on c.id = ac.Celebrity
                                                            inner join Role r on r.id = ac.Role
                                                            inner join #SingleMainArtist sma on sma.AlbCelId = ac.ID
                                                            left outer join AlbumSyndicationView asv on asv.album = a.id
                                                            left outer join MusicService ms on ms.id = asv.musicservice
                                                            where asv.SyndicatedAt is NULL
                                                            and a.CreatedAt > @lastRunAt
                                                            EXCEPT
                                                            select distinct a.Name [Title], rtrim(GTIN) [ISBN], c.Name [Author], o.Name [Imprint], rtrim(ms.Name) [Retailer] from album a 
                                                            inner join organization o on o.id = a.organization
                                                            inner join albumCelebrity ac on ac.album = a.id
                                                            inner join celebrity c on c.id = ac.celebrity
                                                            inner join albumSyndicationView asv on asv.album = a.id
                                                            inner join musicservice ms on ms.id = asv.musicservice
                                                            inner join #INDMASyndications ins on ins.ISBN = a.GTIN and ins.Imprint = o.Name and ins.Retailer = rtrim(ms.name)
                                                            order by o.Name, a.Name
