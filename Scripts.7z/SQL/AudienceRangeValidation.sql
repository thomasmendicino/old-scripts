begin transaction;
use AthenaUATDistribution;
IF NOT EXISTS (
select 1 FROM RuleSetRuleServices rsrs
inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
where rs.SafeName = 'AudienceRangeValidation')
begin
    declare @RuleSetUid uniqueidentifier;
    declare @RuleServiceUid uniqueidentifier;
    
    -- fix iBookstoreValidationRules
    
    select @RuleSetUid = RuleSetUid from RuleSets where SafeName = 'iBookstoreValidationRules'
    select @RuleServiceUid = RuleServiceUid from RuleServices where SafeName = 'AudienceRangeValidation'
    
    insert into RuleSetRuleServices (RuleSetUid, RuleServiceUid, [Order])
    values (@RuleSetUid, @RuleServiceUid, 0)
    update rsrs set [Order] = 0
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'ProductAcceptabilityRule'
    update rsrs set [Order] = 1
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'PacketAssetsValidation'
    update rsrs set [Order] = 2
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'AssetVersionChangeDetector'
    update rsrs set [Order] = 3
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'MetadataChangeDetector'
    update rsrs set [Order] = 4
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'IBookstoreBibliographicChangeDetector'
    update rsrs set [Order] = 5
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'iTMSTransporterValidation'
    update rsrs set [Order] = 6
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'LanguageValidationRule'
    update rsrs set [Order] = 7
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'RetailerProductTypeValidation'
    update rsrs set [Order] = 8
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'PhysicalPricingValidation'
	update rsrs set [Order] = 9
    from RuleSetRuleServices rsrs
    inner join RuleServices rs on rs.RuleServiceUid = rsrs.RuleServiceUid
    where RuleSetUid = @RuleSetUid and rs.SafeName = 'AudienceRangeValidation'
end
commit;