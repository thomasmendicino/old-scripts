select distinct Ordinal, 'call iTMSTransporter -m status -u digitalpublishing@ingrooves.com -p APC55#digipub -vendor_id ' + cast(ordinal as nvarchar(13)) + ' -v off -outputformat xml -WONoPause True >> D:\temp\ITMS\status.xml TIMEOUT 1'
--, c.*, cs.*, td.*, te.* 
from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join Collections c on c.AssetVersionUid = av.AssetVersionUid
join CollectionSequences cs on cs.CollectionId = c.CollectionId
join TitleDetails td on td.AssetVersionUid = av.AssetVersionUid
join TitleElements te on te.TitleDetailId = td.TitleDetailId
where av.ValidUntilUtc is null