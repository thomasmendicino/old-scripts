
begin tran
delete from AthenaSecurity..UserOrganizations where organizationUId = 'C5352CB6-05F2-439F-ACBA-E9CB56F15196'
delete from AthenaDistribution..publishers where OrganizationUid = 'C5352CB6-05F2-439F-ACBA-E9CB56F15196'
delete from athenaSecurity..organizations where organizationUid = 'C5352CB6-05F2-439F-ACBA-E9CB56F15196'