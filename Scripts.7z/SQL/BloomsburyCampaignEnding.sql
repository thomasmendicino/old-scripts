SET NOCOUNT ON
/*
Would you be able to write a script to email a weekly report that lists bloomsbury ISBNs that had agency promo 
price campaigns that ended within that week, only when the agency promo price doesn't match the wholesale promo price?
*/
USE AthenaComposite;
DECLARE @StartDate datetime
DECLARE @EndDate datetime
DECLARE @WholesalePriceType int = 1
DECLARE @AgencyPriceType int = 14
DECLARE @EndingThisWeek TABLE (Ordinal bigint, aPriceid bigint, aCountryList nvarchar(max), aEffectiveFromUtc datetime, aEffectiveToUtc datetime, aIsTaxIncluded bit, aPriceType int, aQualifier int, aAmount decimal(18,2), aCurrency int, aTerritorySupplyDetailId bigint, wPriceid bigint, wCountryList nvarchar(max), wEffectiveFromUtc datetime, wEffectiveToUtc datetime, wIsTaxIncluded bit, wPriceType int, wQualifier int, wAmount decimal(18,2), wCurrency int, wTerritorySupplyDetailId bigint)
SET @StartDate = DATEADD(DAY, -7, GETUTCDATE())
SET @EndDate = GETUTCDATE()

;with BloomsburyTitles AS 
	(SELECT 
		p.Ordinal
	FROM Product P
		INNER JOIN AthenaSecurity..OrgHierarchy('Bloomsbury Publishing') oh on oh.organizationUId = p.OrganizationUid),
AgencyCampaignsEndingThisWeek AS (
	SELECT 
		p.Ordinal, 
		pr.PriceId,
		cs.CountryList,
		pr.EffectiveFromUtc,
		pr.EffectiveToUtc,
		pr.IsTaxIncluded,
		pr.PriceType,
		pr.Qualifier,
		pr.Amount,
		pr.Currency,
		td.TerritorySupplyDetailId
	FROM Product P
		INNER JOIN Asset a on a.ProductUid = p.ProductUid
		INNER JOIN AssetOverride ao on ao.AssetUid = a.AssetUid
		INNER JOIN AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		INNER JOIN TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
		INNER JOIN TerritorySupplyDetails td on td.TerritorySupplyId = ts.TerritorySupplyId
		INNER JOIN CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
		INNER JOIN Prices pr on pr.TerritorySupplyDetailId = td.TerritorySupplyDetailId
		INNER JOIN BloomsburyTitles b on b.ordinal = p.Ordinal
	WHERE
		av.ValidUntilUtc is NULL
		AND pr.EffectiveToUtc BETWEEN @StartDate AND @EndDate
		AND pr.PriceType = @AgencyPriceType),
WholesaleCampaignsEndingThisWeek AS (
	SELECT 
		p.Ordinal, 
		pr.PriceId,
		cs.CountryList,
		pr.EffectiveFromUtc,
		pr.EffectiveToUtc,
		pr.IsTaxIncluded,
		pr.PriceType,
		pr.Qualifier,
		pr.Amount,
		pr.Currency,
		td.TerritorySupplyDetailId
	FROM Product P
		INNER JOIN Asset a on a.ProductUid = p.ProductUid
		INNER JOIN AssetOverride ao on ao.AssetUid = a.AssetUid
		INNER JOIN AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		INNER JOIN TerritorySupplies ts on ts.AssetVersionUid = av.AssetVersionUid
		INNER JOIN TerritorySupplyDetails td on td.TerritorySupplyId = ts.TerritorySupplyId
		INNER JOIN CountrySets cs on cs.CountrySetUid = ts.CountrySetUid
		INNER JOIN Prices pr on pr.TerritorySupplyDetailId = td.TerritorySupplyDetailId
		INNER JOIN BloomsburyTitles b on b.ordinal = p.Ordinal
	WHERE
		av.ValidUntilUtc is NULL
		AND pr.EffectiveToUtc BETWEEN @StartDate AND @EndDate
		AND pr.PriceType = @WholesalePriceType)
INSERT @EndingThisWeek (Ordinal, aPriceid, aCountryList, aEffectiveFromUtc, aEffectiveToUtc, aPriceType, aQualifier, aAmount, aCurrency, aTerritorySupplyDetailId, wPriceid, wCountryList, wEffectiveFromUtc, wEffectiveToUtc, wPriceType, wQualifier, wAmount, wCurrency, wTerritorySupplyDetailId)
	SELECT atw.Ordinal
		, atw.PriceId
		, atw.CountryList
		, atw.EffectiveFromUtc
		, atw.EffectiveToUtc
		, atw.PriceType
		, atw.Qualifier
		, atw.Amount
		, atw.Currency
		, atw.TerritorySupplyDetailId
		, wtw.Priceid
		, wtw.CountryList
		, wtw.EffectiveFromUtc
		, wtw.EffectiveToUtc
		, wtw.PriceType
		, wtw.Qualifier
		, wtw.Amount
		, wtw.Currency
		, wtw.TerritorySupplyDetailId 
	FROM AgencyCampaignsEndingThisWeek atw
		INNER JOIN WholesalecampaignsEndingThisWeek wtw ON wtw.Ordinal = atw.Ordinal 
	WHERE wtw.CountryList = atw.CountryList
			AND wtw.Currency = atw.Currency
			AND wtw.IsTaxIncluded = atw.IsTaxIncluded

;WITH SingleMainTitle AS (
	SELECT DISTINCT
		p.Ordinal
		, replace(COALESCE(te.TitleText, te.TitlePrefix + ' ' + te.TitleWithoutPrefix),'"','''''') as Title
		, ROW_NUMBER() OVER (PARTITION BY p.Ordinal ORDER BY TitleElementLevel, isnull(te.TitleText,'z') DESC, te.TitleWithoutPrefix ASC) RowNum
	FROM
		Product p
	INNER JOIN Asset a
		on a.ProductUid = p.ProductUid
	INNER JOIN AssetOverride ao
		on ao.AssetUid = a.AssetUid
	INNER JOIN AssetVersion av
		on av.AssetOverrideUid = ao.AssetOverrideUid
	INNER JOIN TitleDetails td
		on td.AssetVersionUid = av.AssetVersionUid
	INNER JOIN TitleElements te
		ON te.TitleDetailId = td.TitleDetailId
	WHERE av.ValidUntilUtc is NULL)
SELECT
	e.Ordinal as ISBN 
	, s.Title
	, CASE
        WHEN o.ParentOrganizationUid = '00000000-0000-0000-0000-000000000001' then ''
        ELSE o.OrganizationName
      END AS Imprint
	, CASE 
		WHEN po.OrganizationName = 'Inscribe Digital' then o.OrganizationName
		ELSE po.OrganizationName
	  END AS Publisher
	, e.aAmount as AgencyPromoPrice
	, rca.CurrencyCode as AgencyCurrency
	, e.wCountryList as Territories
	, e.wAmount as WholesalePromoPrice
	, rcw.CurrencyCode as WholesaleCurrency
	, e.aEffectiveFromUtc as PriceCampaignStart
	, e.aEffectiveToUtc as PriceCampaignEnd
FROM 
	@EndingThisWeek e
	INNER JOIN Product p on p.Ordinal = e.Ordinal
	INNER JOIN Organizations o on o.OrganizationUid = p.OrganizationUid
	INNER JOIN Organizations po on po.OrganizationUid = o.ParentOrganizationUid
	INNER JOIN refCurrencyCode rca on rca.CurrencyCodeId = e.aCurrency
	INNER JOIN refCurrencyCode rcw on rcw.CurrencyCodeId = e.wCurrency
	INNER JOIN SingleMainTitle s on s.ordinal = e.ordinal
WHERE 
	e.aAmount <> e.wAmount
	AND s.RowNum = 1
ORDER BY e.Ordinal, AgencyCurrency