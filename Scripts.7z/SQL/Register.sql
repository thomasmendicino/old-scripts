use ingrooves
go


-- The following script needs to be applied to the database after a
-- fresh restore, and after a build of INDMA. It registers (and
-- copies) the assemblies of the INDMA build into the sql server so
-- that they may be referenced and executed by sql queries.  For
-- production and beta, it will register Release versions. Otherwise
-- (on a developer's machine) it will register the debug versions.
-- Contrary to popular belief, the following authorization code can be
-- left uncommented (Serge confirms this) and this script only needs
-- to be run once, after the SQLModule and MediaFields dlls are
-- rebuilt.

alter authorization on database::ingrooves to sa
go
alter database ingrooves set trustworthy on
go
sp_configure 'clr enabled', 1
go
reconfigure
go

--
-- remove dependencies on sqlmodule objects
--

-- (none so far)

--
-- remove sqlmodule objects
--

use ingrooves

if object_id('dbo.mf_xml_query') is not null drop function dbo.mf_xml_query
go
if object_id('dbo.mf_text_query') is not null drop function dbo.mf_text_query
go
if object_id('dbo.mf_get_xml_query_text') is not null drop function dbo.mf_get_xml_query_text
go
if object_id('dbo.mf_get_text_query_text') is not null drop function dbo.mf_get_text_query_text
go
if object_id('dbo.mf_validate') is not null drop function dbo.mf_validate
go
if object_id('dbo.mf_validate_and_shred') is not null drop procedure dbo.mf_validate_and_shred
go
if object_id('dbo.mf_reload_schemas') is not null drop procedure dbo.mf_reload_schemas
go
if object_id('dbo.mf_alter_schema') is not null drop procedure dbo.mf_alter_schema
go
if object_id('dbo.mf_create_mediatype') is not null drop procedure dbo.mf_create_mediatype
go
if object_id('dbo.concatenate') is not null drop aggregate dbo.concatenate  -- Deprecated 2008-10-10
go
if object_id('dbo.sc_jarowinkler') is not null drop function dbo.sc_jarowinkler
go

--
-- recreate assembly
--
if exists (select null from sys.assemblies where name = 'INSQL')
    drop assembly INSQL

if exists (select null from sys.assemblies where name = 'MediaFields.XmlSerializers')
    drop assembly [MediaFields.XmlSerializers]

declare @pos int 
declare @server nvarchar(20)

select @pos = charindex('\', @@servername)

select @server = (case when @pos = 0 then @@servername else substring(@@servername, 1, @pos - 1) end)

if @server = 'BETADB' or @server = 'INDMADB' or @server = 'YAMDB' or @server = 'STAGEDB'
begin
    create assembly INSQL from 'C:\Source\INgrooves\SQLModule\bin\Release\SQLModule.dll' with permission_set = unsafe
    create assembly [MediaFields.XmlSerializers] from 'C:\Source\INgrooves\MediaFields\bin\Release\MediaFields.XmlSerializers.dll' with permission_set = unsafe
end
else
begin
    create assembly INSQL from 'C:\Source\INgrooves\SQLModule\bin\Debug\SQLModule.dll' with permission_set = unsafe
	alter assembly  INSQL add file from 'C:\Source\INgrooves\SQLModule\bin\Debug\SQLModule.pdb'
	alter assembly  MediaFields add file from 'C:\Source\INgrooves\SQLModule\bin\Debug\MediaFields.pdb'
    create assembly [MediaFields.XmlSerializers] from 'C:\Source\INgrooves\MediaFields\bin\Debug\MediaFields.XmlSerializers.dll' with permission_set = unsafe
end
go

--
-- create sqlmodule objects
--

-- MediaFields objects

create procedure dbo.mf_validate_and_shred (@MediaType int, @MediaId int, @xml xml, @validationErrors nvarchar(max) out) 
as external name INSQL.[INgrooves.SQLModule.MediaFields].ValidateAndShred
go

create function dbo.mf_xml_query (@mediaType int, @queryXml xml) 
returns table (ID int)
as external name INSQL.[INgrooves.SQLModule.MediaFields].XmlQuery
go

create function dbo.mf_text_query (@mediaType int, @text nvarchar(4000)) 
returns table (ID int)
as external name INSQL.[INgrooves.SQLModule.MediaFields].TextQuery
go

create function dbo.mf_get_xml_query_text (@mediaType int, @queryXml xml)
returns nvarchar(max)
as external name INSQL.[INgrooves.SQLModule.MediaFields].GetXmlQueryText
go

create function dbo.mf_get_text_query_text (@mediaType int, @text nvarchar(4000))
returns nvarchar(max)
as external name INSQL.[INgrooves.SQLModule.MediaFields].GetTextQueryText
go

create function dbo.mf_validate (@mediaType int, @fieldsXml xml)
returns nvarchar(max)
as external name INSQL.[INgrooves.SQLModule.MediaFields].Validate
go

create procedure dbo.mf_reload_schemas
as external name INSQL.[INgrooves.SQLModule.MediaFields].ResetLoadedSchemas
go

create procedure dbo.mf_alter_schema (@schemaFileLocation nvarchar(260))
as external name INSQL.[INgrooves.SQLModule.MediaFields].AlterSchema
go

create procedure dbo.mf_create_mediatype (@schemaFileLocation nvarchar(260))
as external name INSQL.[INgrooves.SQLModule.MediaFields].CreateMediaType
go

CREATE FUNCTION dbo.sc_jarowinkler(@firstword NVARCHAR(255),@secondword NVARCHAR(255))
RETURNS float
as EXTERNAL NAME INSQL.[INgrooves.SQLModule.StringComparisons].JaroWinkler
GO

--
-- restore deleted dependencies
--

-- (none so far)

