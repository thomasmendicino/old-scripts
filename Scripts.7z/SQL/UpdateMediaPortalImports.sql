select * from album where gtin = '00619061399628'


--select top 50 * from autosynclog where stagingpath like '%619061399628%'
--select * from album where gtin = '00619061399628'
--select * from album where gtin = '00619061406029'
select derivedgenre, * from album where gtin = '00044003152595'
select * from songcelebrity where song in (select song from track where album = (select id from album where gtin = '00044003152595'))
select * from albumcelebrity
select * from song where id in (select song from track where album = (select ID from album where gtin = '00044003152595'))
select * from songoverrides where song in (select song from track where album = (select ID from album where gtin = '00044003152595'))
--select * from pricecampaign where album = (select ID from album where gtin = '00044003152595')
--or track in (select ID from Track where Album = (select ID from album where gtin = '00044003152595'))
--select * from pricecampaign where album = 37522
select * from organization where name like '%umg%'
select top 500 * from album --where organization = 3214 coverart like '%has%'
select * from pricecampaign where album = 37505
--select * from album where gtin = '00601091070653'
select process, * from album where gtin in ('00044003102323','00044003103115','00044003152595')
select * from track where album in (select id from album where gtin in ('00044003102323','00044003103115','00044003152595'))
select * from trackoverrides where track in (select id from track where album in (select id from album where gtin in ('00044003102323','00044003103115','00044003152595'))) and country = 248
update album set coverart = '/images/Covers/HAS/2011/10/10/19/CoverArt_11FONIM01743_gcSTu' where id = 251462
select genre, * from song where id in (select song from track where album in (select id from album where gtin in ('00044003102323','00044003103115','00044003152595')))
select * from genre
select * from mastergenre
select * from organization where id = 3425

select * from songoverrides where song in (select song from track where album = (select ID from album where gtin = '00044003152595')) and country = 248
select * from syndicationorder where placername like '%test%'order by submissiondate desc
--begin tran
--rollback
--commit
--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Remix 1' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Process = 5 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00044003152595')) and Name = 'I Love You - Remix 1')

--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Original' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Process = 5 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00044003152595')) and Name = 'I Love You - (Original)')

--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00044003152595')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Process = 5 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00044003152595')) and Name = 'I Love You - (Urban AC)')

--begin tran
--rollback
--commit
--update track set Fields = ((select top 1 Fields from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')))),
UMGRightTypeCore = ((select top 1 UMGRightTypeCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')))),
UMGLabelCore = ((select top 1 UMGLabelCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')))),
UMGLabelLocal = ((select top 1 UMGLabelLocal from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')))),
UMGOwningTerritory = 'US' where album = (select ID from album where gtin = '00044003152595')

select * from albumoverrides where album = 251462
select * from albumcelebrity where album = 251462
declare @gtin nvarchar (14)
declare @AlbumCelebrity int
set @gtin = '00044003152595'
set @AlbumCelebrity = (select Celebrity from AlbumCelebrity where Album = (select id from Album where gtin = @gtin) and country = (select defaultcountry from album where gtin = @gtin))
insert AlbumCelebrity (Album, Celebrity, Role)
select (select ID from album where gtin = @gtin), @AlbumCelebrity, (select 

select * from assets where r2isrc = '11FONIM04712'
select * from countrysetcountry where countryset = 32019
HAS\2011\10\10\19\CoverArt_11FONIM01743_gcSTu.tif
--begin tran
--commit
--update album set ReleaseDate = (select ReleaseDate from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Fields = (select Fields from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
Organization = (select Organization from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
CLine = (select CLine from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
PLine = (select PLine from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
SalesStartDate = (select SalesStartDate from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
UMGproducttype = (select umgproducttype from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
UMGlabelcore = (select umglabelcore from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
UMGlabellocal = (select umglabellocal from AlbumOverrides where album = (select id from album where gtin = '00044003152595') and Country = (select DefaultCountry from Album where gtin = '00044003152595')),
process = 5, umgincomplete = 0 where gtin = '00044003152595'
--update album set CoverArt = '/images/Covers/HAS/2011/10/10/19/CoverArt_11FONIM01743_gcSTu' where gtin = '00044003152595'
select * from celebrity where id = 54235
select * from celebrity where id = 252210

select * from autosynclog where stagingpath like '%00044003152595%'
select * from importlog where receivedat between '2011-10-21' and '2011-10-22' 

select * from 