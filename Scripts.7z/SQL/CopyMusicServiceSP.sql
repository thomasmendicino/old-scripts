DECLARE @RC int
DECLARE @SourceMusicServiceName varchar(100)
DECLARE @NewMusicServiceName varchar(100)
DECLARE @Return int
 
EXECUTE @RC = [dbo].[copy_MusicService] 
   @SourceMusicServiceName = 'Chegg'
  ,@NewMusicServiceName = 'Total Boox'
  ,@Return=@Return OUTPUT
GO
