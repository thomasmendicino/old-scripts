select distinct a.gtin "Album UPC", song.isrc "Song ISRC", song.name "Song Title", count(c.name) "Quantity",c.name "Download/Stream", sum(et.grossnet) GrossNet, ms.name "Retailer" from earningtest et
inner join statement s on s.id = et.statement
inner join format f on s.format = f.id
left outer join consumption c on f.consumption = c.id
inner join musicservice ms on f.musicservice = ms.id
inner join song on et.song = song.id
inner join album a on et.relatedalbum = a.id
where et.song in (select id from song where isrc in ('USQY51024027',
'USQY51024028',
'USQY51024029',
'USQY51024030',
'USQY51024031',
'USQY51024032',
'USQY51024033',
'USQY51024034',
'USQY51024035',
'USQY51024036',
'USQY51024037',
'USQY51024038')
)
group by a.gtin, song.isrc, song.name, c.name, ms.name
order by song.isrc

--sum grossnet = .687 (earningtest)
--sum grossnet = .512 (earning)

