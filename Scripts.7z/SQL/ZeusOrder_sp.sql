USE [Zeus]
GO

/****** Object:  StoredProcedure [dbo].[Order_Info]    Script Date: 04/05/2012 20:34:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Order_Info]
@orderId bigint = NULL
AS
BEGIN
SET NOCOUNT ON
IF @OrderId IS NULL
BEGIN
select o.id [OrderID], ms.name [Business Partner], orst.name [Order State], coalesce(ec.[Description],cec.[description]) as [Encoding Configuration], coalesce(ec.UMGOwnedFormatCode,cec.UMGOwnedFormatCode) as [UMGOFormatCode], a.id [Album ID], a.gtin [Album GTIN], c.name [Order Country], c2.name [Destination], ob.id [Batch ID], orbst.name [Batch State], ob.TicketPath, ob.MergedMetadataPath from [order] o
inner join orderset os on os.id = o.orderset  
inner join ordersettype ost on ost.id = os.ordersettype 
inner join ordercountry oc on oc.[order] = o.id 
inner join country c on c.id = oc.country  
left outer join country c2 on c2.id = oc.destinationcountry 
inner join orderalbum oa on oa.ordercountry = oc.id
inner join album a on a.id = oa.album 
left outer join orderencoding oe on oe.orderencodingset = o.orderencodingset 
left outer join encodingconfiguration ec on ec.id = oe.encodingconfiguration 
left outer join orderencoding oce on oce.orderencodingset = oc.orderencodingset
left outer join encodingconfiguration cec on cec.id = oce.encodingconfiguration
inner join musicservice ms on ms.id = o.musicservice 
inner join orderstate orst on orst.id = o.orderstate 
left outer join orderbatch ob on ob.[order] = o.id 
left outer join orderbatchstate orbst on orbst.id = ob.orderbatchstate
ORDER BY o.id asc, ob.id asc
END
ELSE
BEGIN
select o.id [OrderID], ms.name [Business Partner], orst.name [Order State], coalesce(ec.[Description],cec.[description]) as [Encoding Configuration], coalesce(ec.UMGOwnedFormatCode,cec.UMGOwnedFormatCode) as [UMGOFormatCode], a.id [Album ID], a.gtin [Album GTIN], c.name [Order Country], c2.name [Destination], ob.id [Batch ID], orbst.name [Batch State], ob.TicketPath, ob.MergedMetadataPath from [order] o
inner join orderset os on os.id = o.orderset  
inner join ordersettype ost on ost.id = os.ordersettype 
inner join ordercountry oc on oc.[order] = o.id 
inner join country c on c.id = oc.country  
left outer join country c2 on c2.id = oc.destinationcountry 
inner join orderalbum oa on oa.ordercountry = oc.id
inner join album a on a.id = oa.album 
left outer join orderencoding oe on oe.orderencodingset = o.orderencodingset 
left outer join encodingconfiguration ec on ec.id = oe.encodingconfiguration 
left outer join orderencoding oce on oce.orderencodingset = oc.orderencodingset
left outer join encodingconfiguration cec on cec.id = oce.encodingconfiguration
inner join musicservice ms on ms.id = o.musicservice 
inner join orderstate orst on orst.id = o.orderstate 
left outer join orderbatch ob on ob.[order] = o.id 
left outer join orderbatchstate orbst on orbst.id = ob.orderbatchstate
WHERE o.id = @OrderId
ORDER BY ob.id asc
END
END

GO


