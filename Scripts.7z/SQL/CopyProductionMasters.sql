use AthenaComposite;
SELECT 
DISTINCT 'ECHO F | xcopy \\instor05\inscribe-master--1\ResourceStorage\' + r.Path + ' D:\temp\20160120\' + cast(p.Ordinal as char(13)) + '.onix' as commands
FROM
	product p
	join asset a on a.productUid = p.ProductUid
	join AssetOverride ao on ao.AssetUid = a.AssetUid
	join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	join resources r on r.ResourceUid = av.ResourceUid
WHERE ao.RetailerUid is NULL
	and r.path like '%onix%'
	and av.ValidUntilUtc is NULL
	and p.Ordinal in (
	9781614237600,
9781625845696,
9781625845696,
9781625855695)
	order by commands
	/*use athenaComposite;
	select * from folderobjects where path like '%9781439610008%'

	select top 5000 * from folderObjects fo
	join ImportFolderConfigurations ic on ic.ImportFolderConfigurationUid = fo.ImportFolderConfigurationUid
	order by fo.Size desc

	--select * from Retailers where name like'%scr%'
	*/