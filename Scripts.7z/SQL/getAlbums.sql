/*

Album	Performer
113522	Hobo Junction
250530	Redd Volkaert
253400	Big Sandy & His Fly-Rite Boys

*/
if object_id('tempdb.dbo.#albumCel') is not null drop table #albumCel
Declare @variousArtists     nvarchar(max)
    Declare @noTracks           nvarchar(max)
create table #albumCel (gtin bigint)
insert #albumCel
select '00012928050128' union
select '000000042321'   


;with #perf as (
select Contributor.Album,
                 (case count(distinct Performer)
                  when 0 then @noTracks
                  when 1 then min(Contributor.Performer)
                  else @variousArtists end) as Performer
          from (select AlbumOrganizationPerformer.Album, AlbumOrganizationPerformer.Performer
                from AlbumOrganizationPerformer with (NOEXPAND)
                join album a on a.id =AlbumOrganizationPerformer.Album
                where a.id in (select id from album where gtin in (select gtin from #albumCel))
    
                union
    
                select AlbumPersonPerformer.Album, AlbumPersonPerformer.Performer
                from AlbumPersonPerformer with (NOEXPAND)
                join album a on a.id =AlbumPersonPerformer.Album
                where a.id in (select id from album where gtin in (select gtin from #albumCel))
    
                union
    
                select AlbumPseudonymPerformer.Album, AlbumPseudonymPerformer.Performer
                from AlbumPseudonymPerformer with (NOEXPAND)
                join album a on a.id =AlbumPseudonymPerformer.Album
                where a.id in (select id from album where gtin in (select gtin from #albumCel))
                ) Contributor
          group by Contributor.Album

          union

          select Album.ID, @noTracks
          from Album
              left outer join Track on Album.ID = Track.Album
          where Track.ID is null
          and album.id in (select id from album where gtin in (select gtin from #albumCel)))
          select a.gtin, p.Performer from #perf p
          join album a on a.id = p.album
          order by a.gtin
