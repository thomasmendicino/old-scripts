USE [AthenaDistribution]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [dbo].[SP_SuccessToFailure]
		@Interval int
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED	


DECLARE @DateRangeStart DATETIME 
DECLARE @DateRangeEnd DATETIME 
DECLARE @NewLineChar AS CHAR(2) = CHAR(13) + CHAR(10)

SET @DateRangeStart = Dateadd(dd, -@Interval, Getutcdate()) 
SET @DateRangeEnd = Getutcdate(); 

WITH distributiontitles 
     AS (SELECT pr.productuid, 
                p.ordinal               AS ISBN, 
                r.NAME                  AS Retailer, 
                r.retaileruid, 
                Max(dos.processedatutc) AS ProcessedAtUtc 
         FROM   Athenacomposite..distributionorderstatus dos 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.distributionorderuid = dos.distributionorderuid 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productrevisionuid = do.productrevisionuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                INNER JOIN Athenacomposite..retailers r 
                        ON r.retaileruid = c.retaileruid 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = pr.productuid 
                INNER JOIN Athenacomposite..asset a 
                        ON a.productuid = p.productuid 
                CROSS apply (SELECT TOP 1 assetoverrideuid 
                             FROM   Athenacomposite..assetoverride 
                             WHERE  a.assetuid = assetuid 
                             ORDER  BY retaileruid ASC) ao 
                INNER JOIN Athenacomposite..assetversion av 
                        ON av.assetoverrideuid = ao.assetoverrideuid 
                INNER JOIN Athenacomposite..productforms pf 
                        ON pf.assetversionuid = av.assetversionuid 
         WHERE  pf.productformtypevalue IN ( 49, 50, 51, 52 ) 
         GROUP  BY pr.productuid, 
                   p.ordinal, 
                   r.NAME, 
                   r.retaileruid 
         HAVING Max(dos.processedatutc) BETWEEN 
                @DateRangeStart AND @DateRangeEnd), 
     distributiondataset 
     AS (SELECT DISTINCT isbn, 
                         dt.retailer 
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
         WHERE  ret.code = 'DITC'),
	 invaliddistributiondataset1 
	 as (SELECT DISTINCT isbn, 
                         dt.retailer,
						 do.DistributionOrderUid 
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
         WHERE  dos.resultingeventlevel = 4
                AND (ret.code IN ( 'DIDC','DINA')
				OR (ret.code = 'DIMF' 
				AND (substring(dos.ResultingMessage, 161, 29) IN ('Product does not have any sup','Source metadata contains conf','There are no supported assets'))
				OR substring(dos.ResultingMessage, 0,29) = 'One or more tokens have been')
				OR substring(dos.ResultingMessage, charindex('Package Summary', dos.ResultingMessage)+34,43) = 'were not uploaded because they had problems'
				OR substring(dos.ResultingMessage, 93,26) in ('Cover image not acceptable',@NewLineChar + 'Cover image not acceptab')))
					 ,
	 invaliddistributiondataset2
	 as (SELECT DISTINCT isbn, 
                         dt.retailer,
						 do.DistributionOrderUid
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
				INNER JOIN AthenaComposite..DistributionOrderAcceptabilities doa
						ON doa.DistributionOrderUid = do.DistributionOrderUid
         WHERE dos.resultingeventlevel = 4
                AND ret.code = 'DIMF'
				AND DOA.ResultingEvent IN (10,47,13,131)
				),
     faileddistributiondataset 
     AS (SELECT DISTINCT isbn, 
                         dt.retailer 
         FROM   distributiontitles dt 
                INNER JOIN Athenacomposite..productrevisions pr 
                        ON pr.productuid = dt.productuid 
                INNER JOIN Athenacomposite..contracts c 
                        ON c.contractuid = pr.contractuid 
                           AND c.retaileruid = dt.retaileruid 
                INNER JOIN Athenacomposite..distributionorders do 
                        ON do.productrevisionuid = pr.productrevisionuid 
                INNER JOIN Athenacomposite..distributionorderstatus dos 
                        ON dos.distributionorderuid = do.distributionorderuid 
                           AND dos.processedatutc = dt.processedatutc 
                INNER JOIN Athenacomposite..product p 
                        ON p.productuid = dt.productuid 
                INNER JOIN Athenacomposite..refeventtype ret 
                        ON ret.eventtypeid = dos.resultingevent 
         WHERE  dos.resultingeventlevel > 2 
                AND ret.code = 'DIMF'
				AND do.distributionOrderUid NOT IN (select DistributionOrderUid from invaliddistributiondataset1
				UNION ALL
				select DistributionOrderUid from invaliddistributiondataset2)
						)
						, 
     successcount 
     AS (SELECT retailer AS Retailer, 
                Count(*) [Titles Distributed] 
         FROM   distributiondataset dt 
         GROUP  BY retailer), 
	 invalidcount1
	 AS (SELECT retailer AS Retailer,
				count(*) [Titles Failing Validation]
		 FROM	invaliddistributiondataset1 id1
		 GROUP	BY retailer
		 ),
     invalidcount2
	 AS (SELECT retailer AS Retailer,
				count(*) [Titles Failing Validation]
		 FROM	invaliddistributiondataset2 id2
		 GROUP	BY retailer
		 ),
     failurecount
     AS (SELECT retailer AS Retailer, 
                Count(*) [Titles Failed] 
         FROM   faileddistributiondataset dt 
         GROUP  BY retailer) 

SELECT DISTINCT CASE 
                  WHEN NAME = 'Amazon EbookBase' THEN 'Amazon' 
                  WHEN NAME = 'Baker and Taylor' THEN 'Baker & Taylor' 
                  WHEN NAME = 'Barnes And Noble' THEN 'Barnes & Noble' 
                  WHEN NAME = 'Scholastic PCD Feed' THEN 'PCD' 
                  WHEN NAME = 'Google Books' THEN 'Google' 
				  WHEN Len(Name) > 10 THEN Code
                  ELSE NAME 
                END                               AS Retailer, 
                Isnull(d.[titles distributed], 0) [Titles Distributed], 
                Isnull(f.[titles failed], 0)      [Titles Failed - System Issue],
				ISNULL(i1.[Titles Failing Validation],0) + ISNULL(i2.[Titles Failing Validation],0)	[Titles Failing Acceptability Validations]
FROM   Athenacomposite..retailers r 
       INNER JOIN Athenacomposite..contracts c 
               ON c.retaileruid = r.retaileruid 
       LEFT OUTER JOIN successcount d 
                    ON d.retailer = r.NAME 
       LEFT OUTER JOIN failurecount f 
                    ON f.retailer = d.retailer 
	   LEFT OUTER JOIN invalidcount1 i1
					on i1.retailer = r.Name
	   LEFT OUTER JOIN invalidcount2 i2
					ON i2.retailer = r.Name
WHERE  c.validuntilutc IS NULL 
ORDER  BY retailer ASC

END





GO


