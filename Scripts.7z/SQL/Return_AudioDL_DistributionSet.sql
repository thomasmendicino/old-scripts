use INgrooves
go

/* get a distribution set for the given distribution types */
declare		@distribution_type		table(DistributionType int)
declare		@distributionset_count	int

insert into @distribution_type(DistributionType)
	select distinct
		ID	[DistributionType]
	from DistributionType 
	where Name in	(	  'Audio Download'
					)
---------------------------------------------------------------					
	select 
		@distributionset_count	=	COUNT(DistributionType)
	from @distribution_type

;with not_in_set as
(
	select 
		DistributionSet
	from DistributionSetItem dsi
		inner join DistributionType dt on dsi.DistributionType=dt.ID
	where dt.ID not in		(	select
									DistributionType
								from @distribution_type
							)
		
)
select distinct 
	  dsi.DistributionSet				[DistributionSet]
	, COUNT(dt.ID)						[DistributionSet_Count]
From DistributionSet ds
	inner join DistributionSetItem dsi on ds.ID=dsi.DistributionSet
	inner join DistributionType dt on dsi.DistributionType=dt.ID
	inner join @distribution_type dt2 on dt.ID	=	dt2.DistributionType
group by 
	dsi.DistributionSet	
having 
	COUNT(dt.ID)	=	@distributionset_count
except 
	select distinct 
		  DistributionSet				[DistributionSet]
		, @distributionset_count		[DistributionSet_Count]
	from not_in_set 
	

