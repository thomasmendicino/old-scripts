with #MostRecentContracts as (
select max(ValidUntilUtc) ValidUntilUtc, r.Name Retailer, p.Name Publisher, c.CountrySetUid, rs.SafeName RuleSet
from contracts c 
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where c.ValidUntilUtc is not null
group by r.Name, p.Name, c.CountrySetUid, rs.SafeName)

select p.Name Publisher, r.Name Retailer, c.CountrySetUid, rs.SafeName RuleSet from contracts c 
join publishers p on p.PublisherUid = c.PublisherUid
join retailers r on r.RetailerUid = c.RetailerUid
join ruleSets rs on rs.RuleSetUid = c.RuleSetUid
where c.ValidUntilUtc is NULL
EXCEPT
select Publisher, Retailer, CountrySetUid, RuleSet from #MostRecentContracts
