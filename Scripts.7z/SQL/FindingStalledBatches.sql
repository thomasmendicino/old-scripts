/*
select * from product p
join productRevisions pr on pr.ProductUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join contracts c on c.ContractUid = pr.ContractUid
join Retailers r on r.RetailerUid = c.RetailerUid
join distributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join DistributionOrderStructureGroupBatches db on db.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join Batches b on b.BatchUid = db.BatchUid
join BatchStatus bs on bs.BatchUid = b.BatchUid
where ordinal = 9780486145709
and r.name = 'overdrive'
order by dos.CreatedAtUtc
*/
;with MaxAt as (select max(ProcessedAtUtc) [MaxProcessedAtUTC], pr.ProductUid, r.Name from AthenaComposite..distributionOrderStatus dos
join AthenaComposite..distributionOrders do on do.distributionORderUId = dos.DistributionOrderUId
join AthenaComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaComposite..contracts c on c.contractUid = pr.contractUId
join AthenaComposite..retailers r on r.retailerUId = c.retailerUid
where r.Code = 'OVD'
group by pr.productUid, r.Name),
Orders as (
select do.DistributionOrderUid from AthenaComposite..DistributionOrders do
join AthenaComposite..DistributionOrderStatus dos on dos.distributionOrderUid = do.distributionORderUId
join AthenaComposite..productRevisions pr on pr.productRevisionUId = do.productRevisionUId
join AthenaComposite..contracts c on c.contractUid = pr.contractUId
join AthenaComposite..retailers r on r.retailerUId = c.retailerUid
join MaxAt m on m.ProductUid = pr.productUid and m.Name = r.Name and m.MaxProcessedAtUTC = dos.ProcessedAtUTC)
,
transferred as (select ordinal, BatchOrdinal from product p
join productRevisions pr on pr.ProductUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join contracts c on c.ContractUid = pr.ContractUid
join Retailers r on r.RetailerUid = c.RetailerUid
join distributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join DistributionOrderStructureGroupBatches db on db.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join Batches b on b.BatchUid = db.BatchUid
join BatchStatus bs on bs.BatchUid = b.BatchUid
where r.name = 'overdrive'
and bs.ResultingEvent = 90
and dos.ResultingEvent = 110),
errored as (select ordinal, BatchOrdinal from product p
join productRevisions pr on pr.ProductUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join contracts c on c.ContractUid = pr.ContractUid
join Retailers r on r.RetailerUid = c.RetailerUid
join distributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join DistributionOrderStructureGroupBatches db on db.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join Batches b on b.BatchUid = db.BatchUid
join BatchStatus bs on bs.BatchUid = b.BatchUid
where r.name = 'overdrive'
and bs.ResultingEventLevel = 4
and dos.ResultingEventLevel = 4),
batched as (
select ordinal, BatchOrdinal from product p
join productRevisions pr on pr.ProductUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join distributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join contracts c on c.ContractUid = pr.ContractUid
join Retailers r on r.RetailerUid = c.RetailerUid
join distributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join DistributionOrderStructureGroupBatches db on db.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
join Batches b on b.BatchUid = db.BatchUid
join BatchStatus bs on bs.BatchUid = b.BatchUid
join Orders o on o.DistributionORderUid = dos.DistributionOrderUid
where r.name = 'overdrive'
and bs.ResultingEvent = 116
and dos.ResultingEvent = 106)
select * from batched
except
select * from transferred
except
select * from errored
