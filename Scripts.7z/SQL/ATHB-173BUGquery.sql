;with batchs as (
select distinct b.BatchOrdinal, b.CreatedAtUtc from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
inner join AthenaDistribution..DistributionContracts dc on dc.contractUid = c.contractUid
inner join AthenaDistribution..DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
inner join AthenaDistribution..DistributionOrderStructureGroupBatches dsgb on dsgb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
inner join AthenaDistribution..batches b on b.batchUid = dsgb.batchUid
where 
r.code in ('FOL', 'AMZ', 'KNB', 'BNO', 'BSH', 'BOW', 'EDL', 'INR' /*INgram metadata updates only. NRs contain the batch*/, 'KBO', 'MKN', 'GDN', 'FLK', 'CHG')
and 
b.CreatedAtUtc > '2014-03-05'
and b.CreatedAtUtc not in (select CreatedAtUtc from batches where datepart(hh,CreatedAtUtc) = '0' and datepart(mi,CreatedAtUtc) = '0' and datepart(ss,CreatedAtUtc) = '0')
),
DupTimestamps as (
select CreatedAtUtc from batchs 
group by CreatedAtUtc
having Count(*) > 1),
narrowingdown as (
select r.Name, b.CreatedAtUtc
from batches b
join contracts c on c.contractUId = b.ContractUid
join retailers r on r.retailerUId = c.retailerUid
inner join DupTimestamps dt on dt.CreatedAtUtc = b.CreatedAtUtc
group by r.Name, b.CreatedAtUtc
having count(*) > 1
)
select distinct r.Name [Retailer],b.batchOrdinal,dateadd(hh,(datediff(hh,getdate(),getUTCdate())),b.CreatedAtUtc) as BatchCreatedAt--,p.Ordinal
from AthenaProductCatalog..product p
inner join AthenaDistribution..productRevisions pr on pr.productUid = p.productUId
inner join AthenaDistribution..DistributionOrders do on do.productRevisionUid = pr.productRevisionUid
inner join AthenaDistribution..Publishers pub on pub.publisherUid = pr.publisherUid
inner join AthenaDistribution..Contracts c on c.contractUid = pr.ContractUid
inner join AthenaDistribution..Retailers r on r.retailerUid = c.retailerUid
inner join AthenaDistribution..DistributionContracts dc on dc.contractUid = c.contractUid
inner join AthenaDistribution..DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
inner join AthenaDistribution..DistributionOrderStructureGroupBatches dsgb on dsgb.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
inner join AthenaDistribution..batches b on b.batchUid = dsgb.batchUid
inner join narrowingDown n on n.Name = r.Name and n.CreatedAtUtc = b.CreatedAtUtc
--where b.CreatedAtUtc > DATEADD(HH,-72,GETUTCDATE())
order by BatchCreatedAt, r.Name


