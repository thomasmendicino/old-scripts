USE [INgrooves]
GO

/****** Object:  Table [dbo].[Address]    Script Date: 11/2/2015 10:10:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Address](
	[ID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[Location] [int] NOT NULL,
	[Street1] [nvarchar](50) NULL,
	[Street2] [nvarchar](50) NULL,
	[City] [nvarchar](50) NULL,
	[StateOrProvince] [nvarchar](50) NULL,
	[USState] [int] NULL,
	[CAProvince] [int] NULL,
	[Country] [int] NULL,
	[PostalCode] [nvarchar](50) NULL,
	[Person] [int] NULL,
	[Organization] [int] NULL,
	[ByPerson] [int] NULL,
	[At] [datetime] NULL,
 CONSTRAINT [PK_Address] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_CAProvince] FOREIGN KEY([CAProvince])
REFERENCES [dbo].[CAProvince] ([ID])
GO

ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_CAProvince]
GO

ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_Country] FOREIGN KEY([Country])
REFERENCES [dbo].[Country] ([ID])
GO

ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_Country]
GO

ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_Location] FOREIGN KEY([Location])
REFERENCES [dbo].[Location] ([ID])
GO

ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_Location]
GO

ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_Organization] FOREIGN KEY([Organization])
REFERENCES [dbo].[Organization] ([ID])
GO

ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_Organization]
GO

ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_Person] FOREIGN KEY([Person])
REFERENCES [dbo].[Person] ([ID])
GO

ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_Person]
GO

ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_Person1] FOREIGN KEY([ByPerson])
REFERENCES [dbo].[Person] ([ID])
GO

ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_Person1]
GO

ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [FK_Address_USState] FOREIGN KEY([USState])
REFERENCES [dbo].[USState] ([ID])
GO

ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_USState]
GO

ALTER TABLE [dbo].[Address]  WITH CHECK ADD  CONSTRAINT [CK_Address] CHECK  ((NOT [person] IS NULL OR NOT [organization] IS NULL))
GO

ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [CK_Address]
GO


