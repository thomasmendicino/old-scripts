USE AthenaSecurity
GO
DBCC SHRINKFILE (AthenaSecurity_log, 5);
GO

USE AthenaResourceStorage
GO
DBCC SHRINKFILE (AthenaResourceStorage_log, 5);
GO

USE AthenaReportCatalog
GO
DBCC SHRINKFILE (AthenaReportCatalog_log, 5);
GO

USE AthenaProductCatalog
GO
DBCC SHRINKFILE (AthenaProductCatalog_log, 5);
GO

USE AthenaAssetProcessor
GO
DBCC SHRINKFILE (AthenaAssetProcessor_log, 5);
GO

USE AthenaEventLog
GO
DBCC SHRINKFILE (AthenaEventLog_log, 5);
GO

USE AthenaDistribution
GO
DBCC SHRINKFILE (AthenaDistribution_log, 5);
GO

USE AthenaMigrator
GO
DBCC SHRINKFILE (AthenaMigrator_log, 5);
GO

USE AthenaComposite
GO
DBCC SHRINKFILE (AthenaComposite_log, 5);
GO