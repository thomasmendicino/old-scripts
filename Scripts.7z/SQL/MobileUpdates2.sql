--begin tran
--rollback

declare @MobileAudioDS int

-- DistributionType for UMG Mobile importer Album.DistributionSet (MST/RBT products)
declare @audio_download_mobile int
select @audio_download_mobile = ID from DistributionType where Name = 'Audio Download'

if object_ID('tempdb.dbo.#MatchDistributions') is not null drop table #MatchDistributions
create table #MatchDistributions (DistributionType int, Allow bit)

insert into #MatchDistributions (DistributionType,Allow)
values (@audio_download_mobile,1)

exec get_distribution_set_id @MobileAudioDS out

 select @MobileAudioDS
/*
update Album set DistributionSet = @MobileAudioDS from Album
join AlbumProductType on AlbumProductType.Album = Album.ID
join ProductType on ProductType.ID = AlbumProductType.ProductType
join ImportLogEntry on ImportLogEntry.DestinationID = Album.ID and ImportLogEntry.ImportItemType = 1
join ImportLog on ImportLog.ID = ImportLogEntry.ImportLog
join ImportSourceType on ImportSourceType.ID = ImportLog.ImportSourceType
where Album.CreatedAt > '2011-10-18 00:00:00.000' -- the day before the RC38 push that caused this problem
and ProductType.Name in ('MST','RBT') and Album.DistributionSet = 1
and Album.UMGIncomplete = 0 and ImportSourceType.Name = 'UMG Affiliates Mobile'


select * from album 
join AlbumProductType on AlbumProductType.Album = Album.ID
join ProductType on ProductType.ID = AlbumProductType.ProductType
join ImportLogEntry on ImportLogEntry.DestinationID = Album.ID and ImportLogEntry.ImportItemType = 1
join ImportLog on ImportLog.ID = ImportLogEntry.ImportLog
join ImportSourceType on ImportSourceType.ID = ImportLog.ImportSourceType
where Album.CreatedAt > '2011-10-18 00:00:00.000' -- the day before the RC38 push that caused this problem and
ProductType.Name in ('MST','RBT') and Album.DistributionSet = 1
and Album.UMGIncomplete = 0 and ImportSourceType.Name = 'UMG Affiliates Mobile'*/