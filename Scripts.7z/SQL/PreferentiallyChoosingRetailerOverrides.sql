
select p.Ordinal, av.AssetVersionUid, ao.RetailerUid from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
left join retailers r on r.retailerUid = ao.RetailerUid
where 
p.ordinal in (9780830876617,9780830864959,9781599795652)
and av.ValidUntilUtc is NULL and a.ResourceContentType = 100
and (ao.RetailerUid = '533D4C81-9C20-438B-B0B4-1408FDEAD3B7' or (ao.RetailerUid is null and not exists(select 1 from AssetOverride ao where ao.RetailerUid = '533D4C81-9C20-438B-B0B4-1408FDEAD3B7' and ao.assetUid = a.assetUid)))
