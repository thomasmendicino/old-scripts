--Creating austindevvm_ss as snapshot of the
--austindevvm database:
CREATE 
DATABASE thomasdev_ss_11_11
ON
(	NAME = INgrooves_Data, FILENAME = 
	'F:\TM_20130911\ing_0911\INgrooves.MDF'),
(	NAME = Primary_File2, FILENAME = 
	'F:\TM_20130911\ing_0911\Primary_File2.NDF'),
(	NAME = Primary_File3, FILENAME = 
	'F:\TM_20130911\ing_0911\Primary_File3.NDF'),
(	NAME = IndexGroup_File1, FILENAME = 
	'F:\TM_20130911\ing_0911\IndexGroup_File1.NDF'),
(	NAME = IndexGroup_File2, FILENAME = 
	'F:\TM_20130911\ing_0911\IndexGroup_File2.NDF'),
(	NAME = IndexGroup_File3, FILENAME = 
	'F:\TM_20130911\ing_0911\IndexGroup_File3.NDF'),
(	NAME = CacheGroup_File1, FILENAME = 
	'F:\TM_20130911\ing_0911\CacheGroup_File1.NDF'),	
(	NAME = CacheGroup_File2, FILENAME = 
	'F:\TM_20130911\ing_0911\CacheGroup_File2.NDF'),
(	NAME = CacheGroup_File3, FILENAME = 
	'F:\TM_20130911\ing_0911\CacheGroup_File3.NDF')
AS SNAPSHOT OF TM_20130911
GO
---------------------------------------------------------------


DECLARE @DatabaseName nvarchar(50)
DECLARE @SPId int
DECLARE @SQL nvarchar(100)

SET @DatabaseName = 'TM_20130911'
DECLARE my_cursor CURSOR FAST_FORWARD FOR
SELECT SPId FROM MASTER..SysProcesses
WHERE DBId = DB_ID(@DatabaseName) AND SPId <> @@SPId

OPEN my_cursor

FETCH NEXT FROM my_cursor INTO @SPId

WHILE @@FETCH_STATUS = 0
BEGIN
 SET @SQL = 'KILL ' + CAST(@SPId as nvarchar(10))
 print @SQL
 EXEC sp_executeSQL @SQL
 --KILL @SPId -- Causing Incorrect syntax near '@spid'.

 FETCH NEXT FROM my_cursor INTO @SPId
END

CLOSE my_cursor
DEALLOCATE my_cursor

USE master;
-- Reverting austindevvm to austindevvm_ss
RESTORE 
DATABASE TM_20130911
from 
DATABASE_SNAPSHOT = 'thomasdev_ss_11_11';
GO


