
use AthenaProductCatalog;
;with reflow as (
select p.Ordinal from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join TMAssetType at on at.id = a.AssetType
where av.ValidUntilUtc is NULL
and at.Name in ('EPUB2R','EPUB3R','EPUB3RE','EPUB2RE')
),
fixed as (select p.Ordinal from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join TMAssetType at on at.id = a.AssetType
where av.ValidUntilUtc is NULL
and at.Name in (
'EPUB2FF','EPUB3FF','EPUB2FFE','EPUB3FFE'
))

select distinct p.Ordinal/*, at.Description*/ from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join TMAssetType at on at.id = a.AssetType
where av.ValidUntilUtc is NULL
and ordinal in 
(select ordinal from reflow 
intersect
select ordinal from fixed)
order by p.ordinal

258 titles have both an active Reflowable epub and an active Fixed Format epub
1671 titles have both an active Reflowable epub and a PDF


;with reflow as (
select p.Ordinal from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join TMAssetType at on at.id = a.AssetType
where av.ValidUntilUtc is NULL
and at.Name in ('EPUB2R','EPUB3R','EPUB3RE','EPUB2RE')
),
pdf as (select p.Ordinal from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join TMAssetType at on at.id = a.AssetType
where av.ValidUntilUtc is NULL
and at.Name in (
'DOCPDF'
))

select distinct p.Ordinal/*, at.Description*/ from product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join TMAssetType at on at.id = a.AssetType
where av.ValidUntilUtc is NULL
and ordinal in 
(select ordinal from reflow 
intersect
select ordinal from pdf)
order by p.ordinal