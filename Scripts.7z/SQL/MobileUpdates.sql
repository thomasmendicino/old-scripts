
select * from album 
join AlbumProductType on AlbumProductType.Album = Album.ID
join ProductType on ProductType.ID = AlbumProductType.ProductType
where Album.CreatedAt > '2011-10-18 00:00:00.000' -- the day before the RC38 push that caused this problem
 and ProductType.Name in ('MST','RBT') and Album.DistributionSet = 1
and Album.UMGIncomplete = 0 --and ImportSourceType.Name = 'UMG Affiliates Mobile'


select top 50 * from autosynclog
select top 50 * from importlogentry
select * from importlog

select * from musicservice where name like '%virgin%'

select * from musicservicedavepartner where musicservice = 285


