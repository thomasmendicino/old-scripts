use athenaProductCatalog;

declare @organizationUIdList table (orgUid uniqueidentifier)
declare @organizationName nvarchar(100)
select @organizationname = 'Wayne State University Press'
;with org as (
select o.organizationName, o.ParentOrganizationUid from AthenaSecurity..organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from AthenaSecurity..organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid as ParentOrganizationUId from AthenaSecurity..organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId as ParentOrganizationUId from AthenaSecurity..organizations o
join child c on c.parentorganizationUid = o.parentOrganizationUid)
insert @organizationUIdList (orgUid)
select ParentOrganizationUId as orgUid from org
union all
select ParentOrganizationUid as orgUId from child
except
select NULL
except
select '00000000-0000-0000-0000-000000000001'

select Ordinal as ISBN from AthenaProductCatalog..Product p
INNER join AthenaSecurity..organizations o on o.OrganizationUid = p.OrganizationUid
inner join @organizationUIdList ol on ol.orgUid = o.OrganizationUid
inner join asset a on a.productUid = p.ProductUid
inner join AssetOverride ao on ao.assetUid = a.AssetUid
inner join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
inner join ProductForms pf on pf.AssetVersionUid = av.AssetVersionUid
where av.ValidUntilUtc is NULL and
pf.ProductFormTypeValue = 52
