DECLARE @ReportName NVARCHAR(100) = 'Failed Distribution Email'
DECLARE @PublisherSafeName NVARCHAR(100) = ''
DECLARE @IntervalDays INT = '1'
DECLARE @EmailMessage NVARCHAR(MAX) = 'Dear INscriber,
Your files did not pass all retailer validations. Please address the errors in the attached report and upload corrected file(s) as needed. Then place a Sysaid ticket under Upload Notification along with the file path. If you have any questions on this report, reply-all to this email.
If you would like to take advantage of our file repair services, place a ticket under Converting or Revising eBook > Request for Quote.
Helpful links:
ONIX: http://www.editeur.org/83/Overview/
EPUB: http://idpf.org/epub
KindleGen: http://www.amazon.com/gp/feature.html?ie=UTF8&docId=1000765211
Kindle Publishing Guidelines: http://kindlegen.s3.amazonaws.com/AmazonKindlePublishingGuidelines.pdf
Thank you!
Team INscribe'

DECLARE @EmailAttribute NVARCHAR(100) = 'Email'
DECLARE @EmailSettings TABLE
(
	SendTO			NVARCHAR(MAX),
	PublisherUid	uniqueidentifier,
	OrganizationUid uniqueidentifier
);

INSERT @EmailSettings
	SELECT
		eValue.Value AS SendTO,
		p.PublisherUid AS PublisherUid,
		p.OrganizationUid AS OrganizationUid
	FROM EavValueVarchars AS eValue
	INNER JOIN EavAttributes AS ea
		ON ea.EavAttributeId = eValue.AttributeId
	LEFT OUTER JOIN (EavEntities AS entity
	CROSS JOIN OrganizationEntities AS oe
	INNER JOIN Organizations AS o
		ON o.OrganizationUid = oe.OrganizationUid)
		ON (entity.EavEntityId = eValue.EntityId)
		AND (oe.EavEntityId = entity.EavEntityId)
	INNER JOIN Publishers AS p
		ON p.OrganizationUid = o.OrganizationUid
	WHERE ea.EavAttributeName = @EmailAttribute
	AND	((@PublisherSafeName IS NOT NULL AND p.SafeName = @PublisherSafeName) OR @PublisherSafeName='');

;WITH ActivePubs AS (
SELECT 
	p.PublisherUid, p.PublisherUid as ParentPubUid
FROM
	ProductRevisions pr
INNER JOIN DistributionOrders do
	ON do.ProductRevisionUid = pr.ProductRevisionUid
INNER JOIN DistributionOrderStatus dos
	ON dos.DistributionOrderUid = do.DistributionOrderUid
INNER JOIN Contracts c
	ON c.ContractUid = pr.ContractUid
INNER JOIN Publishers p
	ON p.PublisherUid = c.PublisherUid
WHERE
	dos.CreatedAtUtc > 	GETUTCDATE() - @IntervalDays
UNION ALL
SELECT 
	p.PublisherUid, pp.PublisherUid as ParentPubUid
FROM
	ProductRevisions pr
INNER JOIN DistributionOrders do
	ON do.ProductRevisionUid = pr.ProductRevisionUid
INNER JOIN DistributionOrderStatus dos
	ON dos.DistributionOrderUid = do.DistributionOrderUid
INNER JOIN Publishers p
	ON p.PublisherUid = pr.PublisherUid
INNER JOIN Organizations o
	ON o.OrganizationUid = p.OrganizationUid
INNER JOIN Organizations po
	ON po.OrganizationUid = o.ParentOrganizationUid
INNER JOIN Publishers pp
	ON pp.OrganizationUid = po.OrganizationUid
WHERE
	dos.CreatedAtUtc > 	GETUTCDATE() - @IntervalDays
	)

SELECT DISTINCT
	es.SendTO [TO],
	'noreply@inscribedigital.com' [ReplyTo],
	'True' [IncludeReport],
	'False' [IncludeLink],
	'EXCEL' [RenderFormat],
	'[REPORT] @ReportName @ExecutionTime' [Subject],
	'NORMAL' [Priority],
	es.OrganizationUid [Organization],
	es.PublisherUid [PublisherUid],
	GETUTCDATE() - @IntervalDays [DateRangeStart],
	GETUTCDATE() [DateRangeEnd],
	@EmailMessage [Comment]
FROM ReportTypePublishers rtp
INNER JOIN ReportTypeConfigurations rtc
	ON rtp.ReportTypeConfigurationUid = rtc.ReportTypeConfigurationUid
INNER JOIN @EmailSettings es
	ON rtp.PublisherUid = es.PublisherUid
INNER JOIN ActivePubs ap 
	ON ap.PublisherUid = es.PublisherUid
	OR ap.ParentPubUid = es.PublisherUid
WHERE rtp.Enabled = 1
AND rtc.Enabled = 1
AND rtc.Name = @ReportName;

