use AthenaComposite;
IF OBJECT_ID('tempdb..#versions' , 'U') IS NOT NULL
   drop TABLE #versions
GO
IF OBJECT_ID('tempdb..#pages' , 'U') IS NOT NULL
   drop TABLE #pages
GO
--drop table #pages
create table #versions (ID int identity(1,1), DistributionOrderUid uniqueidentifier, CreatedAtUtc datetime, Retailer nvarchar(3), ISBN bigint)

declare @productChangeTypes table(Name varchar(50), Value int)
insert into @productChangeTypes values ('NewProduct', 1)
insert into @productChangeTypes values ('AssetUpdate', 2)
insert into @productChangeTypes values ('MetadataUpdate', 4)
insert into @productChangeTypes values ('Takedown', 8)
insert into @productChangeTypes values ('PartialTakedown', 16)
insert into @productChangeTypes values ('Preorder', 32)
insert into @productChangeTypes values ('Embargo', 64)
insert into @productChangeTypes values ('PriceCampaign', 128)
insert into @productChangeTypes values ('IBookstoreBibliographicChange', 256)
insert into @productChangeTypes values ('ManualReviewRequired', 512)
insert into @productChangeTypes values ('ManualReviewApproved', 1024)
insert into @productChangeTypes values ('ManualReviewRejected', 2048)
;with mostrecentorders as (
select Ordinal,r.Code, max(do.CreatedAtUtc) CreatedAtUtc
from product p
join productRevisions pr on pr.ProductUid = p.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
where do.CreatedAtUtc > GETDATE()-2
group by Ordinal, r.code),
mostrecentstatus as (
select dos.distributionOrderUid, max(dos.CreatedAtUtc) CreatedAtUtc, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostrecentorders m on m.Ordinal = p.Ordinal and m.CreatedAtUtc = do.CreatedAtUtc and r.code = m.Code
where dos.CreatedAtUtc > getdate()-2
group by dos.DistributionOrderUid, r.code),
mostrecentisbatch as (
select dos.DistributionOrderUid, dos.CreatedAtUtc, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostrecentstatus m on m.DistributionOrderUid = dos.DistributionOrderUid and m.CreatedAtUtc = dos.CreatedAtUtc and r.code = m.Retailer
where dos.ResultingEvent = 108
and dos.CreatedAtUtc < GETUTCDATE())-- -1) -- this is just to ignore batches in the last day that may not have had fulfillment attempted yet.
--, versions as 
insert #versions
select distinct m.DistributionOrderUid, m.CreatedAtUtc, m.Retailer, p.Ordinal as ISBN from mostrecentisbatch m
join DistributionOrders do on do.DistributionOrderUid = m.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.productUid
--and pr.ProductUid = (select productUid from product where ordinal = 9780486151755)
--select * from distributionOrderStructureGroupContracts where distributionOrderStructureGroupcontractUid =  '37BB86DC-2C6F-4C88-A541-2A7A5A78120A'
--select * from #versions
/*
select p.Ordinal as ISBN, r.Name as Retailer, do.distributionOrderUId,dsg.*, dost.* from #versions v
join AssetVersion av on av.AssetVersionUid = v.assetVersionUid
join AssetOverride ao on ao.AssetOverrideUid = av.AssetOverrideUid
join asset a on a.AssetUid = ao.AssetUid
join product p on p.ProductUid = a.ProductUid
join distributionOrders do on do.DistributionOrderUid = v.DistributionOrderUid
join ProductRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p2 on p2.ProductUid = pr.ProductUid
join contracts c on c.ContractUid = pr.ContractUid
join Retailers r on r.RetailerUid = c.RetailerUid
join distributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join distributionOrderStructures dost on dost.DistributionOrderStructureGroupUid = dsg.DistributionOrderStructureGroupUid
order by p.Ordinal, r.Name, do.DistributionOrderUid*/

create table #pages (ID int identity(1,1), name char(2))

declare @results table (Commands nvarchar(max), Retailer char(3))
declare @position1 int
declare @position2 int
declare @rowcount int = 100
insert #pages (name)
select top 26 1 from organizations;

declare pageCursor cursor local for
select ID from #pages
open pagecursor
fetch next from pageCursor into @position1
while @@fetch_status=0
begin
set @position1 = @position1 * @rowcount
set @position2 = @position1 + @rowcount
insert @results (Commands, Retailer)
select distinct 
'Distribution.Launcher.exe -a CreateAndProcessDistributionOrders --product-list ' + STUFF((select ','+ cast(p2.Ordinal as nvarchar(100)) from product p2
join #versions v2 on v2.ISBN = p2.Ordinal
where v2.Retailer = v.Retailer
and v2.ID between @position1 and @position2
for xml path ('')),1,1,'')  
+ ' --retailer-list ' + v.Retailer as Commands, 
 v.Retailer 
from product p
 join #versions v on v.ISBN = p.Ordinal
where v.ID between @position1 and @position2 

fetch next from pageCursor into @position1
end
select * from @results
close pageCursor
deallocate pageCursor
