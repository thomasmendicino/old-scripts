IF OBJECT_ID('tempdb..#TitleCounts') is not null
	DROP TABLE #TitleCounts
GO
CREATE TABLE #TitleCounts (ParentPublisher nvarchar(200), eBookTitleCount int, PhysicalBookTitleCount int)

DECLARE @INscribeDigital uniqueidentifier
DECLARE @OrgName nvarchar(200)
DECLARE @ParentOrganizations TABLE (OrganizationName nvarchar(200))
DECLARE TitleCountCursor CURSOR LOCAL FOR
	SELECT OrganizationName From @ParentOrganizations

SELECT @INscribeDigital = OrganizationUid from Organizations WHERE OrganizationName = 'INscribe Digital'

INSERT @ParentOrganizations (OrganizationName)
	SELECT OrganizationName 
	FROM Organizations
	WHERE ParentOrganizationUid = @INscribeDigital

OPEN TitleCountCursor
FETCH NEXT FROM TitleCountCursor INTO @OrgName

	WHILE @@fetch_status = 0
	BEGIN 

	--First find all children for the parent publisher

		DECLARE @Hierarchy table (OrganizationName nvarchar(200), eBookCount int, PBookCount int)
		INSERT @Hierarchy (OrganizationName)
		SELECT o.OrganizationName
		FROM Organizations O 
			INNER JOIN AthenaSecurity..OrgHierarchy(@OrgName) oh on oh.organizationUid = o.OrganizationUid


	--Then update the temp table with the counts
		;WITH eCounts AS (
			SELECT 
				o.OrganizationName
				,count(*) as eBookTitleCount
			FROM Product p
				INNER JOIN organizations o on o.organizationUid = p.OrganizationUid
				INNER JOIN asset a on a.ProductUid = p.ProductUid
				CROSS APPLY
					(select top 1 AssetOverrideUid 
					from AssetOverride 
					where AssetOverride.assetUid = a.AssetUid
					order by retailerUid) ao
				INNER JOIN AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
				INNER JOIN ProductForms pf on pf.AssetVersionUid = av.AssetVersionUid
				INNER JOIN @Hierarchy h on h.OrganizationName = o.OrganizationName
			WHERE
				av.ValidUntilUtc is NULL
				AND pf.ProductFormTypeValue IN (49, 52)
			GROUP BY
				o.OrganizationName)
		UPDATE H SET eBookCount = eBookTitleCount from @Hierarchy h
			INNER JOIN eCounts e on e.OrganizationName = h.OrganizationName
		
		;WITH PhysicalBookCounts AS (
			SELECT 
				o.OrganizationName
				,count(*) as PhysicalBookTitleCount
			FROM Product p
				INNER JOIN organizations o on o.organizationUid = p.OrganizationUid
				INNER JOIN asset a on a.ProductUid = p.ProductUid
				CROSS APPLY
					(select top 1 AssetOverrideUid 
					from AssetOverride 
					where AssetOverride.assetUid = a.AssetUid
					order by retailerUid) ao
				INNER JOIN AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
				INNER JOIN ProductForms pf on pf.AssetVersionUid = av.AssetVersionUid
				INNER JOIN @Hierarchy h on h.OrganizationName = o.OrganizationName
			WHERE
				av.ValidUntilUtc is NULL
				AND pf.ProductFormTypeValue NOT IN (49, 52)
			GROUP BY
				o.OrganizationName)
		UPDATE H SET PBookCount = PhysicalBookTitleCount from @Hierarchy h
			INNER JOIN PhysicalBookCounts p on p.OrganizationName = h.OrganizationName

		--Then insert the counts into the master temp table
		INSERT #TitleCounts (ParentPublisher, eBookTitleCount, PhysicalBookTitleCount)
		SELECT @OrgName, SUM(eBookCount), SUM(PBookCount)
		FROM @Hierarchy

		delete @Hierarchy
			

		FETCH NEXT FROM TitleCountCursor INTO @OrgName
	END

CLOSE TitleCountCursor
DEALLOCATE TitleCountCursor

select ParentPublisher, isnull(eBookTitleCount,0) eBookTitleCount, isnull(PhysicalBookTitleCount,0) PhysicalBookTitleCount from #TitleCounts