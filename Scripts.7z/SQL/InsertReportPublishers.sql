
declare @reportNames table (reportname nvarchar(70))
declare @reportName nvarchar(70)
declare @staged table (publisherUid uniqueidentifier, reporttypeconfigurationUid uniqueidentifier, [Enabled] bit)
declare @reportUid uniqueidentifier
insert @reportNames (reportname)
select Name from ReportTypeConfigurations
declare report_cursor cursor local for
select reportname from @reportNames

open report_cursor
fetch next from report_cursor into @reportName
while @@fetch_status=0
begin 
select @reportUid = ReportTypeConfigurationUid from ReportTypeConfigurations where Name = @ReportName
insert @staged (PublisherUid, ReportTypeConfigurationUid, [Enabled])
select PublisherUid, @reportUid as ReportTypeConfigurationUid, 1 as [Enabled] from Publishers p
where not exists (select 1 from ReportTypePublishers rp
join publishers p2 on p.PublisherUid = rp.PublisherUid and p2.PublisherUid = p.PublisherUid
where rp.ReportTypeConfigurationUid = @reportUid)

fetch next from report_cursor into @reportName
end

 CLOSE report_Cursor
   DEALLOCATE report_Cursor
   
select * from @staged s
join publishers p on p.PublisherUid = s.publisherUid
join ReportTypeConfigurations rc on rc.ReportTypeConfigurationUid = s.reporttypeconfigurationUid
order by p.Name, rc.Name
begin tran
insert AthenaReportCatalog..ReportTypePublishers (PublisherUid, ReportTypeConfigurationUid, [Enabled])
select PublisherUid, ReportTypeConfigurationUid, [Enabled] from @staged