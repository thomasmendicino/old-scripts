select * from musicservice where name like '%real%'
select * from syndicatortype where id = 315
select * from syndicatortype where name like '%ddex%'

select * from track where album = (select id from album where gtin = '881034445490')
select * from album where gtin = '881034445490'

select * from song where id = 742822
select top 1000 * from ingrooveslog.dbo.log
select top 50 * from ingrooveslog.dbo.log where message like '%create%dfm%'
select * from encodingstructure where name like '%real%'
/*insert into encodingstructureconfigurationproducttype (encodingstructureconfiguration, producttype)
values (1787,1)
insert into encodingstructureconfigurationproducttype (encodingstructureconfiguration, producttype)
values (1788,1)
insert into encodingstructureconfigurationproducttype (encodingstructureconfiguration, producttype)
values (1789,1)*/
select * from encodingconfiguration where description = 'QCELP (variable) QCP 8khz'
select * from encodingconfiguration where id in (72,210,131,72,68,210,131,68)
select * from encodingstructureconfiguration where encodingstructure = 515
update encodingstructureconfiguration set encodingconfiguration = 13 where id = 1787


select * from encodingstructureconfigurationproducttype where encodingstructureconfiguration in (select id from encodingstructureconfiguration where encodingstructure = 515)
--update encodingstructureconfiguration set encodingconfiguration = 72, main = 0 where id = 1750
--update encodingstructureconfiguration set main = 1 where id = 1773
select * from musicservice where name = 'real networks mst'

select * from encodingconfiguration where id in(41,210,131,68)
--update encodingstructureconfiguration set sampleprofile = NULL, Main = 0 where EncodingStructure = 515

INSERT INTO [dbo].[EncodingStructureConfiguration]           ([EncodingStructure]           ,[Main]           ,[EncodingConfiguration]           ,[SongCutType]           ,[CustomId]           ,[SampleProfile]           ,[OutSourceType])
     SELECT
           515           ,0
           ,(SELECT ID from encodingconfiguration where description='MP3 128 Kbps CBR')
                      ,(SELECT ID from SongCutType where DescriptionKey = '_15s_cut')           ,NULL           ,NULL           ,NULL

select * from musicservice where name like '%real%'
select * from syndicatortype where id = 315

select * from musicservice where name = 'musicload'
select * from arearestriction where musicservice = 439
select * from album where gtin = '795103006621'
select * from arearestriction where album = 1216

select * from musicservice
select * from musicservicetype
select * from distributiontype


select * from musicservice where name = 'real networks mst'
select top 50 * from ingrooveslog.dbo.log
select * from eventqueue

select * from musicservice where name like '%real%'


select * from encodingstructureconfiguration where encodingstructure = 
select * from encodingstructureconfigurationproducttype where encodingstructureconfiguration in (1780,1781,1782,1783)
select * from encodingconfiguration where id in (99,232, 210,41)

update musicservice set distributionset = 224 where id = 727

select * from musicservicetransfersettings where musicservice in (select id from musicservice where name like '%real%netw%')
update musicservicetransfersettings set transferprotocol = 2, server = 'content-delivery.real.com', port = 22, username = 'ingroovesft', password = 'dum888b', privatekey = (select convert (binary(620),'0x000000077373682D7273610000008079E30F18D50BC0B4C44CD73B06A1C38F571C9848DF9C394FBD55E687107D1CDA62DF45A7B2CBE5C1126A1C8CDD9C848C06EE58770940A8F9151B6DA0D3882FF8DE71205736F7F4FCA2BD1D84BAAC96AC351CF256A1FFE7C1B7E7723E09F0493DD881ED720F5978998AB2F9A5530D689AA0CF0BCD8A96832C73159C5D73D0E655000000012500000080452DD822D9C866746F69E1F1119A150C2A85D9E42BE30BC5794C6E154E8C32F87D4E4A20E8F04421792777FCEC7B6DD2EF2D54CDF07EA517BFDF228BB65436E667E46A9A66E2DCDFF4EC9C042BC84014C9101A5FABCAD55FB985FA37047594A734B58DF95D1F2BD774A4DD6EA6C5DD6E17F1B39890AAD66D806E99CCD78E6CF900000040C9774CC5CC52AB7CD2FC7E0DDD9A026CA7F4F6CD47C80A9F03ADEA20826A750998E0F8A98FE93C6EBD6391E2F393C10189AEAB15E4DB00C034D46349F65C9623000000409AE14881600962D0A650806352FAE664128583ECFAC64CCF6128E7A43685E6AC1FB6685A4914BE29182CEDCEA759FCE34E7685CF69E3D7DC12D3B030AC54CD270000004082AE3FA2E5660E5ECE0B9008FE71BC6227C17D7E3C6614BA2BE66E5A46C1980639A6AF21E0CEA3BD73ED8F0FC0973115C1175A37B70A98B406979A597D35231D00000040366AD44921BE1BCCC4D02D1BFA8F81616E4A9622D4A689B0A598C0171A135EE287AECAB7F029E1F2C34E0E5D5D64CE7960C1DBFCC456F8D0C85836FC583978830000004060BCB09E06F321BEA9C319950EAD052349D1CE629BB6DAA884B736E9074043D338534BC80FF44514EACEB5D0ECFA4A5D34CF3871F5621BBA5F6C5129AA6B49BC',1)), uploadroot = '/data/ddfeeds/ingrooves/newroot/incoming/' where id = 1035
update musicservicetransfersettings set transferprotocol = 2, server = 'ftp.ingrooves.com', port = 22, username = 'ingroovestest', password = 'ingrooves', privatekey = NULL, uploadroot = 'NULL' where id = 1035
select * from musicservice where id = 721




    insert MusicServiceTransferSettings
          (MusicService, TransferProtocol, Server, Port, Passive, Username, Password, PrivateKey, UploadRoot, ContractAuthority)
    values
	    (	    (select id from musicservice where name = 'real networks rbt'),
	    2,	    'content-delivery.real.com',
	    22,	    0,	    'ingroovesft',
	    'dum888b',
	    (select convert (binary(620),'0x000000077373682D7273610000008079E30F18D50BC0B4C44CD73B06A1C38F571C9848DF9C394FBD55E687107D1CDA62DF45A7B2CBE5C1126A1C8CDD9C848C06EE58770940A8F9151B6DA0D3882FF8DE71205736F7F4FCA2BD1D84BAAC96AC351CF256A1FFE7C1B7E7723E09F0493DD881ED720F5978998AB2F9A5530D689AA0CF0BCD8A96832C73159C5D73D0E655000000012500000080452DD822D9C866746F69E1F1119A150C2A85D9E42BE30BC5794C6E154E8C32F87D4E4A20E8F04421792777FCEC7B6DD2EF2D54CDF07EA517BFDF228BB65436E667E46A9A66E2DCDFF4EC9C042BC84014C9101A5FABCAD55FB985FA37047594A734B58DF95D1F2BD774A4DD6EA6C5DD6E17F1B39890AAD66D806E99CCD78E6CF900000040C9774CC5CC52AB7CD2FC7E0DDD9A026CA7F4F6CD47C80A9F03ADEA20826A750998E0F8A98FE93C6EBD6391E2F393C10189AEAB15E4DB00C034D46349F65C9623000000409AE14881600962D0A650806352FAE664128583ECFAC64CCF6128E7A43685E6AC1FB6685A4914BE29182CEDCEA759FCE34E7685CF69E3D7DC12D3B030AC54CD270000004082AE3FA2E5660E5ECE0B9008FE71BC6227C17D7E3C6614BA2BE66E5A46C1980639A6AF21E0CEA3BD73ED8F0FC0973115C1175A37B70A98B406979A597D35231D00000040366AD44921BE1BCCC4D02D1BFA8F81616E4A9622D4A689B0A598C0171A135EE287AECAB7F029E1F2C34E0E5D5D64CE7960C1DBFCC456F8D0C85836FC583978830000004060BCB09E06F321BEA9C319950EAD052349D1CE629BB6DAA884B736E9074043D338534BC80FF44514EACEB5D0ECFA4A5D34CF3871F5621BBA5F6C5129AA6B49BC',1)),
	    '/data/ddfeeds/ingrooves/newroot/incoming/',	    1	    )


select * from track where album = (select id from album where gtin = '795103006621')
select * from tracksyndication where track in (select id from track where album = (select id from album where gtin = '795103006621'))
select * from syndication where id in (select syndication from tracksyndication where track in (select id from track where album = (select id from album where gtin = '795103006621')))
select * from musicservicetransfersettings where musicservice = 727

selec
select * from musicservice where id = 439


select * from songcut where path like '%GT Boyz%'
select * from track where song = 519507
select * from album where id in (55162,55698)
\\fileserver2\Beta-Master--201\XL Productionz\Ringtones



if exists (select