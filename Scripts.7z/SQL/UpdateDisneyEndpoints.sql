


--begin tran
--update AthenaAssetProcessor..ImportFolderConfigurations set ExternalDropHost = '' where SafeName = 'FtpDisneyPublishingWorldwideInc'
--select * from AthenaAssetProcessor..ImportFolderConfigurations where ExternalDropHost is not null

/*
update ftp set ProtocolType = 1, HostName = 'ftp.ingrooves.com', PortNumber = 21, StartingDirectory = '/RetailersTestUploadNewDistro/GoogleDisney', UserName = 'productionftp', Password = 'inscribe' from AthenaDistribution..TransferServiceFtpEndpoints ftp
inner join AthenaDistribution..DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
inner join AthenaDistribution..Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.Name = 'Google Books Ftp for All Disney Content'

select dc.Name, * from AthenaDistribution..TransferServiceFtpEndpoints ftp
inner join AthenaDistribution..DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
inner join AthenaDistribution..Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.Name = 'Google Books Ftp for All Disney Content'

update ftp set ProtocolType = 1, HostName = 'ftp.ingrooves.com', PortNumber = 21, StartingDirectory = '/RetailersTestUploadNewDistro/AmazonDisney', UserName = 'productionftp', Password = 'inscribe' from AthenaDistribution..TransferServiceFtpEndpoints ftp
inner join AthenaDistribution..DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
inner join AthenaDistribution..Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Disney Content'

select dc.Name, * from AthenaDistribution..TransferServiceFtpEndpoints ftp
inner join AthenaDistribution..DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
inner join AthenaDistribution..Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Disney Content'

--commit


-----------------------REVERT TO NORMAL SETTINGS-----------------

/*
update ftp set ProtocolType = 2, HostName = 'corpftp2.disney.com', PortNumber = 2262, StartingDirectory = '/Google', UserName = 'shanejacobson', Password = 'toystory1' from AthenaDistribution..TransferServiceFtpEndpoints ftp
inner join AthenaDistribution..DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
inner join AthenaDistribution..Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.Name = 'Google Books Ftp for All Disney Content'

select dc.Name, * from AthenaDistribution..TransferServiceFtpEndpoints ftp
inner join AthenaDistribution..DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
inner join AthenaDistribution..Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.Name = 'Google Books Ftp for All Disney Content'

update ftp set ProtocolType = 2, HostName = 'dar.amazon-digital-ftp.com', PortNumber =22, StartingDirectory = '/ebs_data/DisneyINscribe', UserName = 'DisneyINscribe', Password = 'hPPjL4qqh6' from AthenaDistribution..TransferServiceFtpEndpoints ftp
inner join AthenaDistribution..DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
inner join AthenaDistribution..Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Disney Content'

select dc.Name, * from AthenaDistribution..TransferServiceFtpEndpoints ftp
inner join AthenaDistribution..DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
inner join AthenaDistribution..Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Disney Content'

*/
--update AthenaAssetProcessor..ImportFolderConfigurations set ExternalDropHost = 'ftp' where SafeName = 'FtpDisneyPublishingWorldwideInc'
--select * from AthenaAssetProcessor..ImportFolderConfigurations where ExternalDropHost is not null