;with parents as (
select OrganizationName, OrganizationUid from Organizations
where ParentOrganizationUid = '00000000-0000-0000-0000-000000000001'),
DigitalProducts as (
select distinct p.Ordinal ISBN, p.OrganizationUid 
from Product p
join asset a on a.ProductUid = p.ProductUid
CROSS APPLY
	(select top 1 AssetOverrideUid 
	from AssetOverride 
	where AssetOverride.assetUid = a.AssetUid
	order by retailerUid) ao
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
where av.ValidUntilUtc is NULL
and pf.ProductFormTypeValue in (48,49,50,51,52)),
dp as
(select 
	Parents.OrganizationName Organization,
	ISBN
from parents
join DigitalProducts dp on dp.organizationUid = parents.OrganizationUId
UNION
select 
	parents.OrganizationName Organization,
	ISBN
from parents 
join organizations children on children.ParentOrganizationUid = parents.OrganizationUid
join DigitalProducts dp on dp.organizationUid = children.OrganizationUId
UNION
select
	parents.OrganizationName Organization,
	ISBN
from parents 
join organizations children on children.ParentOrganizationUid = parents.OrganizationUid
join organizations grandchildren on grandchildren.ParentOrganizationUid = children.OrganizationUid
join DigitalProducts dp on dp.organizationUid = grandchildren.OrganizationUId),
DPcount as 
(SELECT
	Organization, count(ISBN) DigitalProductCount
	from DP
	group by Organization)

select Organization, 
sum(t2.DigitalProductCount) as DigitalProductCount 
from 
	(select case when Sequence < 10 then Organization else 'Other' end as Organization, DigitalProductCount,Sequence from 
		(select Organization, DigitalProductCount, ROW_NUMBER() over (order by DigitalProductCount desc, Organization asc) as Sequence from DPcount
		) t
	) t2
group by t2.Organization, (case when Sequence < 10 then cast(t2.DigitalProductCount as nvarchar(20)) else Organization end)
order by 
	case 
		when Organization = 'Other' then (case when Sequence < 10 then cast(t2.DigitalProductCount as nvarchar(20)) else Organization end) END asc,
	case
		when Organization <> 'Other' then (case when Sequence < 10 then cast(t2.DigitalProductCount as nvarchar(20)) else Organization end) END desc
