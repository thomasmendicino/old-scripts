select distinct gtin from album a
join countryset cs on a.countryset = cs.id
join countrysetcountry csc on csc.countryset = cs.id
where csc.country in (select ID from country where A2 in ('de','at'))
except
select distinct gtin from album a
join countryset cs on a.countryset = cs.id
join countrysetcountry csc on csc.countryset = cs.id
where csc.country in (select ID from country where A2 in ('ch','gb','gr'))
/*
select * from arearestriction where musicservice = (select id from musicservice where name = 'musicload')
select * from country where id in (18,89,93,224,248)
*/

select distinct gtin from album a
join countryset cs on a.countryset = cs.id
join countrysetcountry csc on csc.countryset = cs.id
where csc.country in (select ID from country where A2 in ('de','at','ch','gb','gr')) ---52252

select distinct gtin from album a
join countryset cs on a.countryset = cs.id
join countrysetcountry csc on csc.countryset = cs.id
where csc.country not in (select ID from country where A2 in ('de','at','ch','gb','gr'))
intersect 
select distinct gtin from album a
join organization o on a.organization = o.id
join countryset cs on o.countryset = cs.id
join countrysetcountry csc on csc.countryset = cs.id
where csc.country not in (select ID from country where A2 in ('de','at','ch','gb','gr'))



select c.a2, * from album a 
join countryset cs on cs.id = a.countryset
join countrysetcountry csc on csc.countryset = cs.id 
join country c on csc.country = c.id
where a.gtin = '601811009321'
order by c.a2


select distinct a.gtin from album a
join countryset cs on a.countryset = cs.id
join countrysetcountry csc on csc.countryset = cs.id
where csc.country not in (select ID from country where a2 in ('DE', 'AT', 'CH', 'GB', 'GR'))
intersect
select distinct a.gtin from album a
join organization o on o.id = a.organization
join countryset cs on o.countryset = cs.id
join countrysetcountry csc on csc.countryset = cs.id
where csc.country not in (select ID from country where a2 in ('DE', 'AT', 'CH', 'GB', 'GR'))


select distinct gtin from album a1
except 
( select distinct gtin from album a
inner join countryset cs on a.countryset = cs.id
inner join countrysetcountry csc on csc.countryset = cs.id
where csc.country  in (select ID from country where A2 in ('de','at','ch','gb','gr'))
)
and 
intersect 
select distinct gtin from album a
inner join organization o on a.organization = o.id
inner join countryset cs on o.countryset = cs.id
inner join countrysetcountry csc on csc.countryset = cs.id
where csc.country in (select ID from country where A2  in ('de','at','ch','gb','gr'))
)

select * from musicservice where name like '%sonora%'


select * from contract where contractauthority = (select id from contractauthority where folderprefix = 'disney')

--insert contract (contractauthority, organization, mediadefault, starts, excludeservices, notes, countryset, hidden)
select (select ID from contractauthority where folderprefix = 'disney'), (select id from organization where name ='UMG Affiliates'),0, (getdate()-10), 0, 'Sonora stuff', 5525, 0
select * from contract where contractauthority = 29
select * from contractauthority where folderprefix = 'disney')

select * from countrysetcountry where countryset in (select countryset from countrysetcountry group by countryset having count(countryset) = 1)

insert autosynclog (WNPackageID, StagingPath, State, Downloaded, AutoSyncBundleType)
select 'ThomasTest', '\\nas2\WamNet-Staging\2011\10\00050087238759', 2, getdate(), 1
select top 5 * from autosynclog order by downloaded desc
--update autosynclog set state = 2, errormessage = null where ID = 219496
\\fileserver2\WNStaging\2011\10\00044003152595(1)\00044003152595 - Copy\2


update album set coverart = '/images/Covers/HAS\2011\08\17\15\CoverArt_11DMGIM02830_Qv4dk.jpg' where ID = 251444
select * from album a where a.bigintgtin = '50087238759'

select * from organization where ID = 7909
select * from organization where ID = 3214

select top 5 * from contractalbumview where album = (select ID from album where bigintgtin = '50087238759')
insert contractalbumview (album, contract, contractauthority, frommediadefault)
select (select ID from album where bigintgtin = '50087238759'), 16169, 29, 0
insert contractmedia (contract,album)
select 16172, ID from album where bigintgtin = '50087238759'
select * from contractmedia where album = (select ID from album where bigintgtin = '50087238759')

select * from contract where contractauthority = 29
select * from contract where organization = 3214 and contractauthority = 1
select * from contractalbumview where album = (select ID from album where bigintgtin = '50087238759')

select * from contractmusicservice where musicservice = (select id from musicservice where name = 'sonora')
select * from contract where id in (16147,16146)

select * from organization where name like '%disne%pea%'

select * from contractorganizationview where organization = (select id from organization where name like '%disne%pea%') and contractauthority = 29
select * from contract where id = 16169

select * from contractorganizationview where organization = (select id from organization where name like '%disne%pea%') and contractauthority = 29


select * from contractorganizationview where organization = (select id from organization where name like '%disne%pea%') and contractauthority = 29
select * from contractmusicservice where musicservice = (select id from musicservice where name = 'sonora')
select * from contractalbumview where album = 

select * from album where id = (select ID from album where bigintgtin = '50087238759')
select * from track where album = (select ID from album where bigintgtin = '50087238759')
select * from song where id in(select song from track where album = (select ID from album where bigintgtin = '50087238759'))
update album set umgincomplete = 0 where bigintgtin = '50087238759'
update track set albumonly = 1 where ID = 1956023

select countryset from organization where name like '%disne%pear%'
select countryset from album where bigintgtin = '50087238759'
select * from countrysetcountry where countryset = 5525
select * from country where id = 34
select countryset from musicservice where name = 'sonora'

select countryset from song where id in (select song from track where album = (select ID from album where bigintgtin = '50087238759'))
select * from musicservice where name = 'sonora'
update musicservice set supportalbumonly = 0 where ID = 683

select top 5000 * from ingrooveslog.dbo.log where message not like 'TransferToITunes%'