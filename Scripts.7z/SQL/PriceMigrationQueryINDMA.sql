--select * from job where name = 'ImportJob'
--begin tran
select * from job where name = 'ImportJob'
--update job set Instruction = 1, At = getdate(), INDMAuser = (select id from indmauser where name = 'thomasm'), Machine = 'SFINDMAQA04' where id = 2386
select * from job where name = 'ImportJob'
--commit
--rollback
--select * from job where condition = 2
select top 500 * from priceCampaign 
order by id desc

create table #PricesWithTiers (ISBN bigint, Amount float, Currency int, Country int, tier int)
insert #PricesWithTiers (ISBN, Amount, Currency, Country, tier)
select a.bigintgtin, p.Amount, c.ID, NULL, pt.ID
from album a
join #Prices p on p.ISBN = a.bigintgtin
join currency c on c.Code = p.Currency
join priceTierMappingValue ptv on ptv.AlbumPrice = p.Amount and c.ID = ptv.Currency
join priceTierMappingType pmt on pmt.id = ptv.priceTierMappingType
join priceTierMapping ptm on ptm.priceTiermappingValue = ptv.id
join priceTier pt on pt.id = ptm.priceTier
where pmt.Name = 'ebook Price Tier'
select * from #PricesWithTiers
--select * from currency
--drop table #PricesWithTiers
select * from #PricesWithTiers where isbn = 9780830748174
select * from #PricesWithoutTiers where isbn = 9780830748174
--select * from priceTierMappingType 

create table #PricesWithoutTiers (ISBN bigint, Amount float, Currency int, Country int)
insert #PricesWithoutTiers (ISBN, Amount, Currency, Country)
select i.bigintgtin, i.Amount, i.ID, p.Country from 
(select a.bigintgtin, p.Amount, c.ID from album a
join #Prices p on p.isbn = a.bigintgtin
join currency c on c.Code = p.Currency
join country cn on cn.A2 = p.Country
except
select ISBN, Amount, Currency from #pricesWithTiers) i
join #Prices p on p.isbn = i.bigintgtin and p.Amount = i.amount and (select id from country where a2 = p.Country) = i.id


select pwt.ISBN, pwt.Amount, c.name, cn.Name from #pricesWithoutTiers pwt
join currency c on c.id = pwt.currency
join country cn on cn.id = pwt.Country

ISBN	Amount	name	Name
9780830748174	14.99	Canadian Dollar	Canada




--select * from #temp
if object_id('tempdb.dbo.#Prices') is not null drop table #Prices
create table #Prices (ISBN bigint, Amount float, Currency char(3), Country char(5))
bulk insert #Prices --(ISBN, Amount, Currency, Country)
from 'C:\AthenaPrices.txt'
with (fieldterminator = '\t',
firstrow = 2)
select * from #Prices

--update #Prices set Country = NULL where Country = 'NULL'

select * from priceTierMappingValue ptv
join priceTierMappingType pmt on pmt.id = ptv.priceTierMappingType
where pmt.Name = 'ebook price tier'
