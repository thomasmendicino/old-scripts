select * from musicservice where name like '%real%mst%' or name like '%rbt%'
select * from  musicserviceproducttype where producttype in (1,2) and contractauthority = 1 order by musicservice  where musicservice = (select id from musicservice where name like '%real%mst%')
select * from producttype
select * from musicservice where id = 705

exec job_verify 'corporate'
exec reset_jobs_and_sessions 'betadb2'

select * from musicservice where name like '%real%'
select * from encodingstructure where name like '%real%'
select * from encodingstructureconfiguration where encodingstructure in (407, 515) order by encodingconfiguration
select * from encodingstructureconfiguration where encodingstructure in (471) order by encodingconfiguration
select * from encodingstructureconfigurationproducttype where encodingstructureconfiguration  = 1762

--update encodingstructureconfiguration set CustomId = null, sampleprofile = null where id in (1750,1751,1773,1774)
select * from encodingconfiguration where id = 210
--update encodingstructureconfiguration set sampleprofile = 64 where id = 1750 encodingconfiguration = 210 where id in (1750,1751)
select * from songcut
select top 50 * from ingrooveslog.dbo.log
select * from songcuttype
select * from job where name like '%real%'
select * from encodingconfiguration where id in (41,68,131,210)
update encodingstructureconfi
select * from songcuttype
select * from sampleprofile
--begin tran
--commit
--rollback
/*
update encodingstructureconfiguration set Main = 0, EncodingConfiguration = 41, SongCutType = 7, CustomId = '_wav_44kHz16bitstereo_30_00', SampleProfile = 64 where id = 1750
update encodingstructureconfiguration set SongCutType = 7, CustomId = '_aac_44kHz16bitstereo_30_00', SampleProfile = 64 where id = 1751
insert into encodingstructureconfiguration (EncodingStructure, Main, EncodingConfiguration, SongCutType, CustomId, SampleProfile)
values (515,0,68,7,'_wav_8kHz16bitmono_30_00', 64)
insert into encodingstructureconfiguration (EncodingStructure, Main, EncodingConfiguration, SongCutType, CustomId, SampleProfile)
values (515,0,131,7,'_mp3_44kHz16bitstereo_30_00', 64)
*/

select top 50 * from ingrooveslog.dbo.log
--update encodingstructureconfiguration set main = 1, songcuttype = null, sampleprofile = null where id = 1750

select * from encodingstructureconfiguration where encodingstructure = (select id from encodingstructure where name = 'real networks mst')

select * from album where gtin = '017046190121'
select * from track where album = 40642
select top 100 album from track group by album having count(*) = 5

select * from sampleprofile where id = 64
select * from songcuttype
select * from encodingstructureconfiguration where encodingstructure in (select ms.encodingstructure from musicservice ms join musicservicecontractauthority ca on ca.musicservice = ms.id left join musicservicecontractauthorityoverride o on o.musicservice = ms.id where o.contractauthority = 1 or ca.contractauthority = 1)
order by encodingstructure

select * from encodingconfiguration where id in (41,68,131,210)