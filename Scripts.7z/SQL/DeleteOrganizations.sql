BEGIN TRAN
--ROLLBACK
--COMMIT

declare @publisherUid uniqueidentifier
declare @organizationUid uniqueidentifier
select @organizationUid = OrganizationUid from AthenaSecurity..Organizations where OrganizationName = 'Bloomsbury Publishing USA'

select @publisherUid = publisherUid from AthenaDistribution..Publishers where OrganizationUid = @organizationUid

DELETE RR FROM AthenaReportCatalog..ReportResources RR
INNER JOIN AthenaReportCatalog..ReportItems RI on RI.ReportItemId = RR.ReportItemId
INNER JOIN AthenaReportCatalog..ReportTypePublishers RTP on RTP.ReportTypePublisherId = RI.ReportTypePublisherId
WHERE RTP.PublisherUid = @publisherUid

DELETE RI FROM AthenaReportCatalog..ReportItems RI
INNER JOIN AthenaReportCatalog..ReportTypePublishers RTP on RTP.ReportTypePublisherId = RI.ReportTypePublisherId
WHERE RTP.PublisherUid = @publisherUid

DELETE FROM AthenaReportCatalog..ReportTypePublishers where PublisherUid = @publisherUid

DELETE FOS FROM AthenaAssetProcessor..FolderObjectStatus FOS 
INNER JOIN AthenaAssetProcessor..FolderObjects FO on FO.FolderObjectUid = FOS.FolderObjectUid
INNER JOIN AthenaAssetProcessor..ImportFolderConfigurations IFC on IFC.ImportFolderConfigurationUid = FO.ImportFolderConfigurationUid
WHERE IFC.PublisherUid = @publisherUid

DELETE FO FROM AthenaAssetProcessor..FolderObjects FO
INNER JOIN AthenaAssetProcessor..ImportFolderConfigurations IFC on IFC.ImportFolderConfigurationUid = FO.ImportFolderConfigurationUid
WHERE IFC.PublisherUid = @publisherUid

DELETE FROM AthenaAssetProcessor..ImportFolderConfigurationLocks WHERE ImportFolderConfigurationUid in (select ImportFolderConfigurationUid FROM AthenaAssetProcessor..ImportFolderConfigurations WHERE PublisherUid = @publisherUid)

DELETE FROM AthenaAssetProcessor..ImportFolderConfigurations WHERE PublisherUid = @publisherUid

DELETE FROM AthenaDistribution..Contracts WHERE PublisherUid = @publisherUid

DELETE FROM AthenaDistribution..Publishers WHERE PublisherUid = @publisherUid

DELETE FROM AthenaSecurity..Organizations WHERE OrganizationUid = @organizationUid
