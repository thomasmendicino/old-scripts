use [INgrooves]
Select Song.Name, Song.Mix as Mix_Name, Song.At, Song.Performer, Organization.Name as Artist_Band_Label, Song.Copyright, Publisher.Name as Publisher, Song.ISRC from Song
Inner Join Organization ON Organization.ID = Song.Organization
Inner Join SongPublisher ON SongPublisher.Song = Song.ID
Inner Join Publisher ON Publisher.ID = SongPublisher.ID
Order by Song.Name ASC, Song.Performer ASC





--use [INgrooves]
--Select Song.Name, Song.Mix as Mix_Name, Song.At, Song.Performer, Organization.Name as Artist_Band_Label, Song.Copyright, Publisher.Name as Publisher, Song.ISRC from Song
--Inner Join SongPublisher ON SongPublisher.Song = Song.ID
--Inner Join Organization ON Organization.ID = Song.Organization
--Inner Join Publisher ON Publisher.ID = SongPublisher.ID
--Order by Song.Name ASC, Song.Performer ASC

--use [INgrooves]
--Select Song.Name, Song.Mix as Mix_Name, Song.At, Song.Performer, Organization.Name as Artist_Band_Label, Song.Copyright, Publisher.Name as Publisher, Song.ISRC from Song
--Inner Join SongSyndication ON SongSyndication.Song = Song.ID
--Inner Join Contract ON Contract.ID = SongSyndication.Contract
--Inner Join Organization ON Organization.ID = Song.Organization
--Inner Join SongPublisher ON SongPublisher.Song = Song.ID
--Inner Join Publisher ON Publisher.ID = SongPublisher.ID
--Order by Song.Name ASC, Song.Performer ASC