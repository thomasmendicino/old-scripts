;with mostrecentstatus as (
select pr.ProductUid, max(dos.DistributionOrderStatusId) MaxDistroOrderStatusId, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
where dos.CreatedAtUtc > getdate()-365
and r.code not in ('OST','ENT','SNY','FLK')
group by pr.productUid, r.code),
mostrecentisbatch as (
select dos.DistributionOrderUid, dos.CreatedAtUtc, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join refEventType et on et.EventTypeId = dos.ResultingEvent
join mostrecentstatus m on m.ProductUid = pr.ProductUid and m.MaxDistroOrderStatusId = dos.DistributionOrderStatusId and r.code = m.Retailer
where 
et.EventLevelId < 4 --ERROR
AND et.EventTypeId <> 110 --Distribution Order Transfer Complete
AND dos.CreatedAtUtc < GETUTCDATE()-1) -- this is just to ignore batches in the last day that may not have had fulfillment attempted yet.
, hasDIDC as (
select dos.DistributionOrderUid 
from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join refEventType et on et.EventTypeId = dos.ResultingEvent
join mostrecentstatus m on m.ProductUid = pr.ProductUid and m.MaxDistroOrderStatusId = dos.DistributionOrderStatusId and r.code = m.Retailer
where et.Code = 'DIDC')
select distinct m.Retailer, p.Ordinal as ISBN from mostrecentisbatch m
join DistributionOrders do on do.DistributionOrderUid = m.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.productUid
left join hasDIDC did on did.distributionorderUid = do.DistributionOrderUid
where did.DistributionOrderUid is NULL
order by m.Retailer, p.Ordinal