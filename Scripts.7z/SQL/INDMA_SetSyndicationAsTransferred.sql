declare @ms varchar(50)
Declare @transferred bit

Set @transferred = 1

--SET @ms = 'Rogers CA RBT'
--SET @ms = 'Airborne RBT'
--SET @ms = 'Bell CA RBT'
--SET @ms = 'Cricket WMode RBT'
--SET @ms = 'ATT OTA'
--set @ms = 'Boost Cellmania MST'
--set @ms = 'Verizon RBT'
--set @ms = 'Mercury Bell MST'
--SET @ms = 'Rogers MST'
--SET @ms = 'SendMe Mobile MST'
--SET @ms = 'Wind Mobile CA WP'
--SET @ms = 'Wind Mobile CA MST'
--SET @ms = 'Telcel MX MST'
--SET @ms = 'Dashbox'
--set @ms = 'Tigo MST'
--set @ms = 'Claro MST CAM'
--set @ms = 'Millward Brown'
--set @ms = 'MusicLoad'
--set @ms = 'Real'
--set @ms = '24-7'
--set @ms = 'Xurpas MST Latam'
--set @ms = 'Myxer WP'
--set @ms = 'Claro MST'
-- set @ms = 'Spotify'
--set @ms = 'Amdocs MST'
--set @ms = 'ATT MST'
set @ms = 'ATT MST v2'

DECLARE @level int
--select @level = max(syndicationlevel) from syndication where musicservice = (select id from musicservice where name = @ms)
select @level = max(syndicationlevel) from syndication where musicservice = (select id from musicservice where name = @ms) and TransferredAt is null

print 'Set as ' + case when @transferred = 1 then '' else 'UN' end + 'transferred: ' + convert(varchar(20),@level)

Declare	@MusicServiceName nvarchar(100)
Declare	@SyndicationLevel int

Set @SyndicationLevel = @level
Set @MusicServiceName = @ms

if @MusicServiceName is null or @SyndicationLevel is null return

declare @MusicService int
declare @acceptsAlbums bit
declare @acceptsSongs bit	

select	@MusicService = ms.ID, 
		@acceptsAlbums = CAST(MAX(CAST(msmt.ForTrack as INT)) as BIT), 
		@acceptsSongs = CAST(MAX(CAST(msmt.ForSong as INT)) as BIT) 
from MusicService ms inner join MusicServiceMediaType msmt on msmt.MusicService = ms.ID
where name = @MusicServiceName
group by ms.ID
/*
if @acceptsAlbums=1 begin
	update TrackSyndication
	set transferredAt=null
	where MusicService = @MusicService and SyndicationLevel = @SyndicationLevel;
end

if @acceptsSongs=1 begin
	update SongSyndication
	set transferredAt=null
	where MusicService = @MusicService and SyndicationLevel = @SyndicationLevel;
end
*/	
update Syndication
set transferredAt= case when @transferred = 1 then GETDATE() else null end
where MusicService = @MusicService and SyndicationLevel = @SyndicationLevel;

delete from Transferlog
where musicservice=@MusicService and SyndicationLevel=@SyndicationLevel




