Distribution History in INDMA:


declare @org nvarchar(50)
set @org = 'ebooktest'
;with #latest as
(select Album, asv.MusicService, max(SyndicatedAt) [latestSyndicatedAt] from albumSyndicationView asv
join album a on a.id = asv.album
join organization o on a.organization = o.id
where o.name = @org
group by asv.Album, asv.Musicservice)

select a.bigintgtin [ISBN], ms.Name [Retailer], asv.SyndicatedAt, o.Name [Publisher], po.Name [Parent] from albumsyndicationview asv
join musicservice ms on ms.id = asv.musicservice 
join album a on a.id = asv.album
join organization o on o.id = a.organization
left join organization po on po.id = o.parent
join #latest l on l.Album = asv.album and l.latestSyndicatedAt = asv.SyndicatedAt and l.musicService = ms.id
where o.Name = @org
order by a.bigintgtin, ms.name

-- OR --

declare @organizationid int
set @organizationid = (select id from organization where name ='Arcadia Publishing')
            select
                q.TrackSyndicationId,
                q.SyndicationId,
                q.ISBN,
                q.MediaType,
                q.ProductTitle,
                q.SyndicationLevel,
                q.SyndicatedAt,
                q.TransferredAt,            
                DATEADD(second, DATEDIFF(second, GETDATE(), GETUTCDATE()), q.SyndicatedAt) as SyndicatedAtUtc,
                DATEADD(second, DATEDIFF(second, GETDATE(), GETUTCDATE()), q.TransferredAt) as TransferredAtUtc,               
                q.Transferred,
                q.MusicService RetailerId,
                (select stuff((
                    select ' ' + A2
                    from  CountrySetCountry cscMatch
                    inner join Country c on c.ID = cscMatch.Country
                    where cscMatch.CountrySet = q.CountrySet and c.Deprecated = 0
                    order by A2 for XML path('')), 1, 1, '')) AS CountriesSummary
            from
            (
                select
                    ts.ID as TrackSyndicationId,
                    ts.Syndication as SyndicationId,
                    a.GTIN ISBN,
                    mt.Name MediaType,
                    a.Name ProductTitle,
                    synd.SyndicationLevel,
                    synd.SyndicatedAt,
                    synd.TransferredAt,
                    synd.Transferred,
                    synd.MusicService,
                    ts.CountrySet,
                    ms.Name MusicServiceName,
                    ROW_NUMBER() OVER (PARTITION BY a.GTIN, mt.Name, synd.MusicService ORDER BY SyndicationLevel DESC) AS RowNumber
                from Album a
                inner join Organization o on o.ID = a.Organization
                inner join AlbumProductType apt on a.ID = apt.Album
                inner join ProductType pt on pt.ID = apt.ProductType
                inner join Track t on t.Album = a.id
                inner join TrackSyndication ts on ts.Track = t.Id
                inner join Syndication synd on synd.ID = ts.Syndication
                inner join MusicService ms on ms.ID = synd.MusicService
                inner join Song s on s.Id = t.Song
                inner join Media m on s.Media = m.ID
                inner join MediaType mt on m.MediaType = mt.ID
                where pt.Name in ('Ebook', 'Enhanced_Ebook', 'FixedFormat_Ebook') and o.ID = @OrganizationId
            ) q
            where q.RowNumber = 1


Distribution History in Athena:


declare @org nvarchar(50)
set @org = 'ebooktest'
select p.Ordinal [ISBN], r.Name [Retailer], dateadd(hh,-7,do.CreatedAtUtc) [SyndicatedAt], o.OrganizationName [Publisher], po.OrganizationName [Parent] from AthenaDistributionWorkflow..DistributionOrder do
join AthenaProductCatalog..Product p on p.ProductUid = do.ProductUid
join AthenaWorkflowConfiguration..Retailers r on r.RetailerUid = do.RetailerUid
join AthenaSecurity..Organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..Organizations po on po.OrganizationUId = o.ParentOrganizationUid
where o.OrganizationName = @org
order by ISBN, Retailer

-----------------------

declare @org nvarchar(50)
set @org = 'ebooktest'
select p.Ordinal [ISBN], r.Name [Retailer], dateadd(hh,-7,do.CreatedAtUtc) [SyndicatedAt], o.OrganizationName [Publisher], po.OrganizationName [Parent], dateadd(hh,-7,b.TransferCompletedAtUtc) [TransferredAt] from AthenaDistributionWorkflow..DistributionOrder do
join AthenaProductCatalog..Product p on p.ProductUid = do.ProductUid
join AthenaWorkflowConfiguration..Retailers r on r.RetailerUid = do.RetailerUid
join AthenaSecurity..Organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..Organizations po on po.OrganizationUId = o.ParentOrganizationUid
join AthenaDistributionWorkflow..Packet pk on pk.distributionOrderUid = do.distributionOrderUid
join AthenaDistributionWorkflow..PacketSyndication ps on ps.PacketUid = pk.PacketUid
join AthenaDistributionWorkflow..BatchPacketSyndication bps on bps.PacketSyndicationUid = ps.PacketSyndicationUid
join AthenaDistributionWorkflow..Batch b on b.BatchUid = bps.BatchUid
where o.OrganizationName = @org
order by ISBN, Retailer

----------------------

declare @org nvarchar(50)
set @org = 'amok books'
select p.Ordinal [ISBN], r.Name [Retailer], dateadd(hh,-7,do.CreatedAtUtc) [SyndicatedAt], o.OrganizationName [Publisher], po.OrganizationName [Parent], dateadd(hh,-7,b.TransferCompletedAtUtc) [TransferredAt], tc.A2 from AthenaDistributionWorkflow..DistributionOrder do
join AthenaProductCatalog..Product p on p.ProductUid = do.ProductUid
join AthenaWorkflowConfiguration..Retailers r on r.RetailerUid = do.RetailerUid
join AthenaSecurity..Organizations o on o.OrganizationUid = p.OrganizationUid
left join AthenaSecurity..Organizations po on po.OrganizationUId = o.ParentOrganizationUid
join AthenaDistributionWorkflow..Packet pk on pk.distributionOrderUid = do.distributionOrderUid
join AthenaDistributionWorkflow..PacketSyndication ps on ps.PacketUid = pk.PacketUid
join AthenaDistributionWorkflow..BatchPacketSyndication bps on bps.PacketSyndicationUid = ps.PacketSyndicationUid
join AthenaDistributionWorkflow..Batch b on b.BatchUid = bps.BatchUid
join AthenaDistributionWorkflow..PacketCountry pc on pc.PacketUid = pk.PacketUid
join AthenaDistributionWorkflow..TMCountryMap tc on tc.CountryId = pc.Country
where o.OrganizationName = @org
order by ISBN, Retailer
