;with refTexts as (select '1' as Type, 'Sender-defined text' as Description union
select '2' as Type, 'Short description/annotation' as Description union
select '3' as Type, 'Description' as Description union
select '4' as Type, 'Table of contents' as Description union
select '5' as Type, 'Flap / cover copy' as Description union
select '6' as Type, 'Review quote' as Description union
select '7' as Type, 'Review quote: previous edition' as Description union
select '8' as Type, 'Review quote: previous work' as Description union
select '9' as Type, 'Endorsement' as Description union
select '10' as Type, 'Promotional headline' as Description union
select '11' as Type, 'Feature' as Description union
select '12' as Type, 'Biographical note' as Description union
select '13' as Type, 'Publisher’s notice' as Description union
select '14' as Type, 'Excerpt' as Description union
select '15' as Type, 'Index' as Description union
select '16' as Type, 'Short description/annotation for collection' as Description union
select '17' as Type, 'Description for collection' as Description
)
--#NAME?
,
SingleTextContents as (
select tc.assetVersionUid from athenaProductCatalog..assetVersion av
join textContents tc on tc.AssetVersionUid = av.AssetVersionUid
where av.validUntilUtc is null
group by tc.AssetVersionUid
having count(*) = 1)

select o.OrganizationName, po.OrganizationName Parent, ordinal ISBN, len(replace(replace(replace(replace(replace(replace(t.Value, '''', '&#39;'),'&amp;','&'),'"','&#34;'),'&','&amp;'),'>','&gt;'), '<','&lt;')) DescriptionLengthNOTformattedInXML, len(t.Value) DescriptionLengthFormattedInXML, replace(replace(replace(replace(replace(replace(t.Value, '''', '&#39;'),'&amp;','&'),'"','&quot;'),'&','&amp;'),'>','&gt;'), '<','&lt;') [Description],  rf.Description as TextType from SingleTextContents st
join textContents tc on tc.AssetVersionUid = st.AssetVersionUid
join texts t on t.TextContentId = tc.TextContentId
join refTexts rf on rf.Type = tc.textType
join assetVersion av on av.AssetVersionUid = st.assetVersionUid
join AssetOverride ao on ao.AssetOverrideUid = av.AssetOverrideUid
join asset a on a.AssetUid = ao.AssetUid
join product p on p.ProductUid = a.ProductUid
join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
join athenaSecurity..organizations o on o.organizationUId = p.OrganizationUid
join AthenaSecurity..organizations po on po.organizationUId = o.ParentOrganizationUid
where av.ValidUntilUtc is null and ao.RetailerUid is null and pf.ProductFormTypeValue = 52-- and ordinal = 9781632060075
group by t.Value, ordinal, rf.Description, o.organizationName, po.OrganizationName, t.Value
having len(replace(replace(replace(replace(replace(replace(t.Value, '''', '&#39;'),'&amp;','&'),'"','&#34;'),'&','&amp;'),'>','&gt;'), '<','&lt;'))  > 4000 
order by o.OrganizationName, ordinal



