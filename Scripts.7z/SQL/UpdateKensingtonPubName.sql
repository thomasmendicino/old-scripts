--begin tran
select * from athenaSecurity..organizations where organizationName = 'Kensington'
--update athenaSecurity..organizations
set Organizationname = 'Kensington Publishing Corp.' where organizationName = 'Kensington'
select * from athenaSecurity..organizations where organizationName = 'Kensington Publishing Corp.'

select * from athenaDistribution..Publishers where Name = 'Kensington'
--update AthenaDistribution..Publishers
set Name = 'Kensington Publishing Corp.', SafeName = 'KensingtonPublishingCorp' where name = 'Kensington'
select * from athenaDistribution..Publishers where Name = 'Kensington Publishing Corp.'

select * from athenaSecurity..aspnet_users where primaryOrganizationUid = '8822C822-191F-489D-AC76-94D48E913CFD'
--update athenaSecurity..aspnet_users set UserName = 'KensingtonPublishingCorp', LoweredUserName = 'kensingtonpublishingcorp'
where primaryOrganizationUid = '8822C822-191F-489D-AC76-94D48E913CFD'
select * from athenaSecurity..aspnet_users where primaryOrganizationUid = '8822C822-191F-489D-AC76-94D48E913CFD'

select * from athenaAssetProcessor..importFolderConfigurations where publisherUid = '64D311E1-A62B-4FEE-835B-6133C52BA1ED'
--update AthenaAssetProcessor..ImportFolderConfigurations
set Path = replace(Path,'Kensington','KensingtonPublishingCorp'),Name = replace(Name,'Kensington','Kensington Publishing Corp.'), SafeName = replace(SafeName,'Kensington','KensingtonPublishingCorp')
where PublisherUid = '64D311E1-A62B-4FEE-835B-6133C52BA1ED'
select * from athenaAssetProcessor..importFolderConfigurations where publisherUid = '64D311E1-A62B-4FEE-835B-6133C52BA1ED'

--rollback
--commit