
drop table #versions
create table #versions (assetVersionUid uniqueidentifier, DistributionOrderUid uniqueidentifier, CreatedAtUtc datetime, Retailer nvarchar(3))
;with mostrecentorders as (
select Ordinal,r.Code, max(do.CreatedAtUtc) CreatedAtUtc
from product p
join productRevisions pr on pr.ProductUid = p.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
where do.CreatedAtUtc > GETDATE()-10
group by Ordinal, r.code),
mostrecentstatus as (
select dos.distributionOrderUid, max(dos.CreatedAtUtc) CreatedAtUtc, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostrecentorders m on m.Ordinal = p.Ordinal and m.CreatedAtUtc = do.CreatedAtUtc and r.code = m.Code
where dos.CreatedAtUtc > getdate()-10
group by dos.DistributionOrderUid, r.code),
mostrecentisbatch as (
select dos.DistributionOrderUid, dos.CreatedAtUtc, r.Code Retailer from DistributionOrderStatus dos
join DistributionOrders do on do.DistributionOrderUid = dos.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join product p on p.ProductUid = pr.ProductUid
join Contracts c on c.ContractUid = pr.ContractUid
join retailers r on r.RetailerUid = c.RetailerUid
join mostrecentstatus m on m.DistributionOrderUid = dos.DistributionOrderUid and m.CreatedAtUtc = dos.CreatedAtUtc and r.code = m.Retailer
where dos.ResultingEvent = 108
and dos.CreatedAtUtc < GETUTCDATE()-1) -- this is just to ignore batches in the last day that may not have had fulfillment attempted yet.
--, versions as 
insert #versions
select prs.assetVersionUid, m.DistributionOrderUid, m.CreatedAtUtc, m.Retailer from mostrecentisbatch m
join DistributionOrders do on do.DistributionOrderUid = m.DistributionOrderUid
join productRevisions pr on pr.ProductRevisionUid = do.ProductRevisionUid
join productRevisionStructures prs on prs.ProductRevisionUid = pr.ProductRevisionUid
where prs.ResourceContentType = 100

--select * from #versions

select distinct 
'Distribution.Launcher.exe -a CreateAndProcessProductRevisionForRetailer --asset-version-uid-list ' + STUFF((select ','+ cast(av2.assetVersionUid as nvarchar(100)) from assetVersion av2 
join #versions v2 on v2.assetVersionUid = av2.AssetVersionUid
where v2.Retailer = v.Retailer
for xml path ('')),1,1,'')  
+ ' --retailer-list ' + v.Retailer as Commands, 
 v.Retailer 
from assetVersion av 
 join #versions v on v.assetVersionUid = av.AssetVersionUid