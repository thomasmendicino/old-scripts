--**REMEMBER TO COMMENT OUT ROLLBACK AT THE BOTTOM**
--**ALSO DOUBLE CHECK THE STAGING DIRECTORY FOR TRANSPORTER IS CORRECT**
----run on ATHENADISTRIBUTION DATABASE

--select FTP.TransferServiceEndpointUid, FTP.ProtocolType, FTP.HostName, FTP.PortNumber, FTP.StartingDirectory,
--FTP.UserName, FTP.Password, FTP.Passive, TSE.NAME
--from AthenaDistribution..TransferServiceFtpEndpoints FTP
--JOIN TransferServiceEndpoints TSE ON TSE.TransferServiceEndpointUid = FTP.TransferServiceEndpointUid
--where TSE.NAME like '%DISNEY%'
--ORDER BY TSE.NAME


BEGIN TRAN

--UPDATE TRANSPORTER CREDENTIALS FOR DISNEY
update TransferServiceItmsEndpoints set StagingDirectoryLocation = '\\instor05\inscribe-master--1\Distribution\APC\Disney\Transfer'
	where StagingDirectoryLocation like '%disney%'
update TransferServiceItmsEndpoints set ProviderName = 'disneypub' 
	where StagingDirectoryLocation = '\\instor05\inscribe-master--1\Distribution\APC\Disney\Transfer'
--UPDATE 3M FTP CREDENTIALS 
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = '3M Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = '3M Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET HostName  = 'b2b.3m.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = '3M Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = '3M Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET UserName = 'USPFCL0019'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = '3M Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET [Password] =  'p*})MN{@!rC58GG'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = '3M Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = '3M Disney Ftp for All Content')
--UPDATE AMAZON FTP CREDENTIALS
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/ebs_data/bryan_disqq'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Amazon eBookBase Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Amazon eBookBase Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET HostName  = 'dar.amazon-digital-ftp.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Amazon eBookBase Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Amazon eBookBase Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET UserName = 'bryan_disqq'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Amazon eBookBase Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET [Password] =  'YRDEwv4yQ2'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Amazon eBookBase Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Amazon eBookBase Ftp for All Disney Content')
------UPDATE BAKER & TAYLOR FTP CREDENTIALS 
	--reflowable ebooks, covers, and metadata
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney Content except FF eBooks')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney Content except FF eBooks')
update TransferServiceFtpEndpoints SET HostName  = 'econtentftp.baker-taylor.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney Content except FF eBooks')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney Content except FF eBooks')
update TransferServiceFtpEndpoints SET UserName = 'disney'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney Content except FF eBooks')
update TransferServiceFtpEndpoints SET [Password] =  '@M4gZ2d396'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney Content except FF eBooks')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney Content except FF eBooks')
	--Fixed format
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/Fixed Format'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney FF eBooks')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney FF eBooks')
update TransferServiceFtpEndpoints SET HostName  = 'econtentftp.baker-taylor.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney FF eBooks')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney FF eBooks')
update TransferServiceFtpEndpoints SET UserName = 'disney'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney FF eBooks')
update TransferServiceFtpEndpoints SET [Password] =  '@M4gZ2d396'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney FF eBooks')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Baker and Taylor Ftp for Disney FF eBooks')
--UPDATE BARNES & NOBLE FTP CREDENTIALS
	--B&N cover and metadata
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Cover and Metadata')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Cover and Metadata')
update TransferServiceFtpEndpoints SET HostName  = 'sftp-pub.barnesandnoble.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Cover and Metadata')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Cover and Metadata')
update TransferServiceFtpEndpoints SET UserName = 'D0175'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Cover and Metadata')
update TransferServiceFtpEndpoints SET [Password] =  'Kl9iVPieS'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Cover and Metadata')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Cover and Metadata')
	--B&N Enhanced epubs
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/Comics_Graphic_Novels'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Enhanced ePub Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Enhanced ePub Content')
update TransferServiceFtpEndpoints SET HostName  = 'sftp-pub.barnesandnoble.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Enhanced ePub Content')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Enhanced ePub Content')
update TransferServiceFtpEndpoints SET UserName = 'A0138'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Enhanced ePub Content')
update TransferServiceFtpEndpoints SET [Password] =  'u5oES5sdig'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Enhanced ePub Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Enhanced ePub Content')
	--B&N Epibs
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/nook_Kids_ePibs'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePib Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePib Content')
update TransferServiceFtpEndpoints SET HostName  = 'sftp-pub.barnesandnoble.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePib Content')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePib Content')
update TransferServiceFtpEndpoints SET UserName = 'A0138'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePib Content')
update TransferServiceFtpEndpoints SET [Password] =  'u5oES5sdig'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePib Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePib Content')
	--B&N Epubs
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePub Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePub Content')
update TransferServiceFtpEndpoints SET HostName  = 'sftp-pub.barnesandnoble.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePub Content')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePub Content')
update TransferServiceFtpEndpoints SET UserName = 'D0175'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePub Content')
update TransferServiceFtpEndpoints SET [Password] =  'Kl9iVPieS'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePub Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney ePub Content')
	--Graphic Novels 
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/Comics_Graphic_Novels'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Graphic Novels or Comic Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Graphic Novels or Comic Content')
update TransferServiceFtpEndpoints SET HostName  = 'sftp-pub.barnesandnoble.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Graphic Novels or Comic Content')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Graphic Novels or Comic Content')
update TransferServiceFtpEndpoints SET UserName = 'A0138'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Graphic Novels or Comic Content')
update TransferServiceFtpEndpoints SET [Password] =  'u5oES5sdig'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Graphic Novels or Comic Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney Graphic Novels or Comic Contentt')
	--B&N PDF/Page Perfect
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/Page_Perfect_PDFs'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney PDF Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney PDF Content')
update TransferServiceFtpEndpoints SET HostName  = 'sftp-pub.barnesandnoble.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney PDF Content')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney PDF Content')
update TransferServiceFtpEndpoints SET UserName = 'A0138'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney PDF Content')
update TransferServiceFtpEndpoints SET [Password] =  'u5oES5sdig'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney PDF Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Barnes And Noble Ftp for Disney PDF Content')				
--UPDATE FOLLETT FTP CREDENTIALS
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Follett Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Follett Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET HostName  = 'ftp.follettebooks.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Follett Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET PortNumber = '21'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Follett Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET UserName = 'disn8072'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Follett Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET [Password] =  '848wf226'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Follett Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Follett Ftp for All Disney Content')
--UPDATE GOOGLE FTP CREDENTIALS
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/Google'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Google Books Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Google Books Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET HostName  = 'corpftp2.disney.com/'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Google Books Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET PortNumber = '2262'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Google Books Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET UserName = 'shanejacobson'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Google Books Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET [Password] =  'toystory1'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Google Books Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Google Books Ftp for All Disney Content')
--UPDATE KOBO FTP CREDENTIALS
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/incoming'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Kobo Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Kobo Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET HostName  = 'ftp.kobobooks.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Kobo Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Kobo Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET UserName = 'Disney'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Kobo Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET [Password] =  'gN4WXrkX'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Kobo Ftp for All Disney Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'Kobo Ftp for All Disney Content')
--UPDATE OVERDRIVE FTP CREDENTIALS
UPDATE TransferServiceFtpEndpoints SET StartingDirectory = '/'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'OverDrive Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET ProtocolType  = 2
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'OverDrive Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET HostName  = 'ftp.overdrive.com'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'OverDrive Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET PortNumber = '22'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'OverDrive Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET UserName = 'Disney'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'OverDrive Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET [Password] =  '7G4-MQA-9U2-593'
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'OverDrive Disney Ftp for All Content')
update TransferServiceFtpEndpoints SET Passive = 1
	where TransferServiceEndpointUid = (select TransferServiceEndpointUid from TransferServiceEndpoints where Name = 'OverDrive Disney Ftp for All Content')

ROLLBACK
--COMMIT