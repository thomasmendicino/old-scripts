

declare @OrgName nvarchar(200)
set @OrgName = 'Scholastic Inc.'
declare @WeekTable table (WeekStart datetime, ProductCount int)
declare @earliestProduct datetime
select @earliestProduct = min(ValidFromUtc) from product p
	join asset a on a.ProductUid = p.ProductUid
	join AssetOverride ao on ao.AssetUid = a.AssetUid
	join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
	join AthenaSecurity..OrgHierarchy(@OrgName) oh on oh.organizationUId = p.OrganizationUid
	where pf.ProductFormTypeValue in (49,50,51,52)
set @earliestProduct = DateAdd(DAY, 7 * (DateDiff(DAY, '20000101', @earliestProduct) / 7), '20000101')
while @earliestProduct < getdate()
begin
	insert @WeekTable
	select @earliestProduct, 0
	set @earliestProduct = dateadd(WEEK,1,@earliestProduct)
END
;with recentlyAddedProducts as (
	select p.Ordinal, min(ValidFromUtc) AddedAt from product p
	join asset a on a.ProductUid = p.ProductUid
	join AssetOverride ao on ao.AssetUid = a.AssetUid
	join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
	join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
	join AthenaSecurity..OrgHierarchy(@OrgName) oh on oh.organizationUId = p.OrganizationUid
	where pf.ProductFormTypeValue in (49,50,51,52)
	group by p.Ordinal),
WeeklyIngestion as (
	select count(Ordinal) ProductCount, DateAdd(DAY, 7 * (DateDiff(DAY, '20000101', AddedAt) / 7), '20000101') As ProductIngestion
	,ROW_NUMBER() OVER (ORDER BY DateAdd(DAY, 7 * (DateDiff(DAY, '20000101', AddedAt) / 7), '20000101') ASC) RowNum
	from recentlyAddedProducts rap
	group by DateAdd(DAY, 7 * (DateDiff(DAY, '20000101', AddedAt) / 7), '20000101')),
WeeklyIngestionStats as (
	select coalesce(wi.ProductCount, wt.ProductCount) ProductCount, wt.WeekStart from WeeklyIngestion wi
	right join @WeekTable wt on wt.WeekStart = wi.productIngestion)
SELECT WeekStart
		, ProductCount
		--the following functions are not available until SQL Server 2012
		--AVG(ProductCount) OVER (ORDER BY ProductIngestion ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) 
		--AVG(ProductCount) OVER (PARTITION BY ProductIngestion ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING)        AS AverageWeeklyAddition
		--LAG(ProductCount, 1) OVER (ORDER BY ProductIngestion) AS CountPrev
		,AVG(ProductCount) OVER (PARTITION BY DATEPART(MONTH,WeekStart),1, DATEPART(YEAR,WeekStart),1) as MonthlyAverage
	FROM WeeklyIngestionStats
	GROUP BY WeekStart, DATEPART(MONTH,WeekStart), DATEPART(YEAR,WeekStart), ProductCount
	ORDER BY WeekStart
	