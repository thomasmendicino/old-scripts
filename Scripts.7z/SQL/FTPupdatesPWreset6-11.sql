use AthenaDistribution;

select 
'update ftp set Password = '''' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = ''' + dc.Name + '''',
dc.Name, ftp.ProtocolType, ftp.HostName, ftp.PortNumber, ftp.StartingDirectory, ftp.UserName, ftp.Password from TransferServiceFtpEndpoints ftp
join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid
where c.ValidUntilUtc is NULL
order by dc.Name

begin tran
/**
update ftp set Password = 'MMMinscribe55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = '3M Ftp for All Content'

update ftp set Password = 'MMMscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = '3M Scholastic Ftp for All Content'

update ftp set Password = 'MMMdisney55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = '3M Disney Ftp for All Content'

*/


update ftp set Password = 'MMMdisney55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = '3M Disney Ftp for All Content'

update ftp set Password = 'MMMinscribe55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = '3M Ftp for All Content'

update ftp set Password = 'MMMscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = '3M Scholastic Ftp for All Content'

/*update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Content'
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Creative Homeowner Content'
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Disney Content'
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Dover Publications Content'
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Research And Education Association Content'
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Amazon eBookBase Ftp for All Scholastic Content'*/
/*
?????
*/
update ftp set Password = Password from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Baker and Taylor Ftp for Disney eBook and Cover'

update ftp set Password = 'KNBdisney55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Baker and Taylor Ftp for Disney Metadata'

update ftp set Password = 'KNBdisney55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Baker and Taylor Ftp for eBook and Cover'

update ftp set Password = 'KNBinscribe55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Baker and Taylor Ftp for Metadata'

update ftp set Password = 'KNBscholastic55#digipub2' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Baker and Taylor Ftp for Scholastic eBooks and Cover'

update ftp set Password = 'KNBscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Baker and Taylor Ftp for Scholastic Metadata'

/*


*/


update ftp set Password = ?'BNOinscribe55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Cover and Metadata'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Creative Homeowner Cover and Metadata'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Creative Homeowner PDF Content'

update ftp set Password = 'BNOdisney55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Disney Cover and Metadata'

update ftp set Password = 'BNOdisney55#special' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Disney Enhanced ePub Content'

update ftp set Password = 'BNOdisney55#special' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Disney ePib Content'

update ftp set Password = 'BNOdisney55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Disney ePub Content'

update ftp set Password = 'BNOdisney55#special' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Disney Graphic Novels or Comic Content'

update ftp set Password = 'BNOdisney55#special' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Disney PDF Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Dover Publications Cover and Metadata'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Dover Publications ePub Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Enhanced ePub Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for ePib Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for ePub Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Graphic Novels or Comic Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for PDF Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Research And Education Association Cover and Metadata'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Research And Education Association ePub Content'

update ftp set Password = 'BNOscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Scholastic Cover and Metadata'

update ftp set Password = 'BNOscholastic55#enhanced' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Scholastic DRP Content'

update ftp set Password = 'BNOscholastic55#enhanced' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Scholastic Enhanced ePub Content'

update ftp set Password = 'BNOscholastic55#enhanced' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Scholastic ePib Content'

update ftp set Password = 'BNOscholastic55#trade' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Barnes And Noble Ftp for Scholastic ePub Content'


/*


*/
update ftp set Password = 'BISscholastic55#21' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Biblioshare Ftp for Scholastic Onix2 and Content'

update ftp set Password = 'BISscholastic55#30' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Biblioshare Ftp for Scholastic Onix3'


/*

*/
update ftp set Password = 'BSHscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Bookish Ftp for Scholastic Epubs and Covers'

update ftp set Password = 'BSHscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Bookish Ftp for Scholastic Metadata'

/*

*/
update ftp set Password = 'BKMscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Books-A-Million Ftp for All Scholastic Content'
/*
*/
update ftp set Password = 'BOSscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Bookshare Ftp for All Scholastic Content'
/*

*/
/*
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Bowker Ftp for INscribe Digital eBook'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Bowker Ftp for INscribe Digital Metadata and Cover'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Bowker Ftp for Scholastic eBook'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Bowker Ftp for Scholastic Metadata and Cover'
*/


update ftp set Password = 'CHGinscribe55#' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Chegg Ftp for All INscribe Digital Content'
/*

*/
/*
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Edelweiss Ftp for All Scholastic Content'
*/
update ftp set Password = 'ENTinscribe55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'EnTitle Books Ftp for All INscribe Digital Content'
/*
*/
update ftp set Password = 'FLKscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'FlipKart Ftp for All Scholastic Content'
/*
*/

update ftp set Password = 'FOLdisney55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Follett Ftp for All Disney Content'

update ftp set Password = 'FOLinscribe55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Follett Ftp for All INscribe Digital Content'

update ftp set Password = 'FOLscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Follett Ftp for All Scholastic Content'
/*

*//*
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Gardners Ftp for INscribe Digital Covers'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Gardners Ftp for INscribe Digital eBooks'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Gardners Ftp for INscribe Digital Marketing Materials'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Gardners Ftp for INscribe Digital Metadata'
*/

/*
Did someone talk to IT about this? this is an internal ftp server */
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Google Books Ftp for All Content'

update ftp set Password = 'GOOdisney55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Google Books Ftp for All Disney Content'

/*Did someone talk to IT about this? this is an internal ftp server */

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Google Books Ftp for All Scholastic Content'

/*
*/
/*
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'iBookstore iTMS Transporter for All Charisma Media Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'iBookstore iTMS Transporter for All Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'iBookstore iTMS Transporter for Bloomsbury Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'iBookstore iTMS Transporter for InterVarsity Press All Content'
*/

update ftp set Password = 'INRscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Ingram Ftp for All Scholastic Content'
/*
*//*
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'KDP Ftp for All Content'
*/
/*
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Kobo Ftp for All Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Kobo Ftp for All Disney Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Kobo Ftp for All Scholastic Content'
*/
update ftp set Password = 'MKNscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Mackin Ftp for All Scholastic Content'
/*
*/
/*
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'MyILibrary Ftp for All INscribe Digital Content'
*/
/*
update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Onix Feed Bloomsbury Publishing Ftp for All Content'

update ftp set Password = '' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Onix Feed Ftp for All Content'
*/

update ftp set Password = 'PCDscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Onix Feed Scholastic Ftp for All Content'
/**/
update ftp set Password = 'OVDdisney55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'OverDrive Disney Ftp for All Content'

update ftp set Password = 'OVDinscribe55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'OverDrive Ftp for All Content'

update ftp set Password = 'OVDscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'OverDrive Scholastic Ftp for All Content'

/*
*/
update ftp set Password = 'OSTinscribe55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Oyster Ftp for All INscribe Digital Content'

update ftp set Password = 'OSTscholastic55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Oyster Ftp for All Scholastic Content'
/*
*/
update ftp set Password = 'SRDinscribe55#digipub' from TransferServiceFtpEndpoints ftp join DistributionContracts dc on dc.TransferServiceEndpointUid = ftp.TransferServiceEndpointUid
join Contracts c on c.ContractUid = dc.ContractUid where c.ValidUntilUtc is NULL
and dc.Name = 'Scribd Ftp for All INscribe Digital Content'