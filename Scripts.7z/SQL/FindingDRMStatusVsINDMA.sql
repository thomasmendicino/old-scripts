if object_ID ('tempdb..#INDMADRM') is not null
drop table #INDMADRM
GO

create table #INDMADRM (ISBN bigint)

bulk insert #INDMADRM
from 'D:\temp\INDMADRM.txt'
with (fieldterminator = ' ',
rowterminator = '\n',
firstrow = 1)

;with DRMResults as (
	select distinct
		p.Ordinal AthenaISBN
		, o.OrganizationName Imprint
		, case 
			when etp.EpubTechnicalProtectionType is null then 'DRM-Free'
			when etp.EpubTechnicalProtectionId = 1 then 'DRM-Free'
			when etp.EpubTechnicalProtectionId > 1 then 'DRM-Protected'
			end as 'DRM Status'
		, case 
			when etp.EpubTechnicalProtectionType is null then NULL
			when etp.EpubTechnicalProtectionType = 1 then '00 - None'
			when etp.EpubTechnicalProtectionType = 2 then '01 - DRM'
			when etp.EpubTechnicalProtectionType = 3 then '02 - Digital Watermarking'
			when etp.EpubTechnicalProtectionType = 4 then '03 - Adobe DRM'
			when etp.EpubTechnicalProtectionType = 5 then '04 - Apple DRM'
			when etp.EpubTechnicalProtectionType = 6 then '05 - OMA DRM'
			end as 'DRM Type'
		, i.ISBN INDMAISBN
		, 'DRM-Protected' as [INDMA DRM Status]
	from Product p
		join asset a on a.ProductUid = p.ProductUid
		join AssetOverride ao on ao.AssetUid = a.AssetUid
		join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		join organizations o on o.OrganizationUid = p.OrganizationUid
	    left outer join EpubTechnicalProtections etp on etp.AssetVersionUid = av.AssetVersionUid
		inner join #INDMADRM i on i.ISBN = p.Ordinal
	WHERE av.ValidUntilUtc is NULL
		and a.ResourceContentType = 100)

SELECT * from DRMResults
WHERE [DRM Status] <> [INDMA DRM Status]
ORDER BY Imprint, AthenaISBN


	/*
		select * from Product p
		join asset a on a.ProductUid = p.ProductUid
		join AssetOverride ao on ao.AssetUid = a.AssetUid
		join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
		join organizations o on o.OrganizationUid = p.OrganizationUid
	    left outer join EpubTechnicalProtections etp on etp.AssetVersionUid = av.AssetVersionUid
		join productForms pf on pf.AssetVersionUid = av.AssetVersionUid
		where p.ordinal = 9781625170699
		and a.ResourceContentType = 100
		and av.ValidUntilUtc is null
		*/