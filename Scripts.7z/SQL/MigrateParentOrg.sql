use AthenaSecurity;
begin tran

declare @Imprint nvarchar(50) = 'De Vecchi'
declare @oldParent nvarchar(50) = 'Confidential Concepts'
declare @newParent nvarchar(50) = 'De Vecchi Ediciones'

declare @oldUid uniqueidentifier
declare @newUid uniqueidentifier
declare @impUid uniqueidentifier

select @impUid = organizationUid from AthenaSecurity..Organizations where organizationName = @Imprint
select @oldUid = organizationUid from AthenaSecurity..organizations where OrganizationName = @oldParent
select @newUId = organizationUid from AthenaSecurity..organizations where OrganizationName = @newParent

---select * from athenaSecurity..organizations where organizationName like '%monster%'
UPDATE AthenaSecurity..Organizations 
SET ParentOrganizationUid = @newUid
WHERE OrganizationUid = @impUid
	AND ParentOrganizationUid = @oldUid

--COMMIT