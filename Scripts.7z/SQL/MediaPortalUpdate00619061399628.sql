--begin tran
--commit
--update album set ReleaseDate = (select ReleaseDate from AlbumOverrides where album = (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
Fields = (select Fields from AlbumOverrides where album = (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
Organization = (select Organization from AlbumOverrides where album = (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
CLine = (select CLine from AlbumOverrides where album = (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from AlbumOverrides where album = (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
SalesStartDate = (select SalesStartDate from AlbumOverrides where album = (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
UMGproducttype = (select umgproducttype from AlbumOverrides where album = (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
UMGlabelcore = (select umglabelcore from AlbumOverrides where album = (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
UMGlabellocal = (select umglabellocal from AlbumOverrides where album = (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
process = 1, umgincomplete = 0, UMGAccount = 3, UMGOwningTerritory = 'CA' where gtin = '00619061399628'

--00619061399628--00619061406029--00601091070653--

--begin tran
--rollback
--commit
--update track set Fields = ((select top 1 Fields from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')))),
DistributionSet = ((select top 1 DistributionSet from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')))),
UMGRightTypeCore = ((select top 1 UMGRightTypeCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')))),
UMGLabelCore = ((select top 1 UMGLabelCore from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')))),
UMGLabelLocal = ((select top 1 UMGLabelLocal from TrackOverrides where track in (select id from track where album in (select id from album where gtin = '00619061399628') and Country = (select DefaultCountry from Album where gtin = '00619061399628')))),
UMGOwningTerritory = 'CA' where album = (select ID from album where gtin = '00619061399628')

--begin tran
--rollback
--commit
--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Name = (select Name from SongOverrides where Song = 2511129 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Mix = (select Mix from SongOverrides where Song = 2511129 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Performer = (select Performer from SongOverrides where Song = 2511129 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511129 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511129 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511129

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Name = (select Name from SongOverrides where Song = 2511127 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Mix = (select Mix from SongOverrides where Song = 2511127 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Performer = (select Performer from SongOverrides where Song = 2511127 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511127 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511127 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511127

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Name = (select Name from SongOverrides where Song = 2511128 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Mix = (select Mix from SongOverrides where Song = 2511128 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Performer = (select Performer from SongOverrides where Song = 2511128 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511128 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511128 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511128

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Name = (select Name from SongOverrides where Song = 2511130 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Mix = (select Mix from SongOverrides where Song = 2511130 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Performer = (select Performer from SongOverrides where Song = 2511130 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511130 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511130 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511130

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Name = (select Name from SongOverrides where Song = 2511135 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Mix = (select Mix from SongOverrides where Song = 2511135 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Performer = (select Performer from SongOverrides where Song = 2511135 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511135 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511135 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511135

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Name = (select Name from SongOverrides where Song = 2511131 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Mix = (select Mix from SongOverrides where Song = 2511131 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Performer = (select Performer from SongOverrides where Song = 2511131 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511131 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511131 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511131

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Name = (select Name from SongOverrides where Song = 2511136 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Mix = (select Mix from SongOverrides where Song = 2511136 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Performer = (select Performer from SongOverrides where Song = 2511136 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511136 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511136 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511136

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Name = (select Name from SongOverrides where Song = 2511137 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Mix = (select Mix from SongOverrides where Song = 2511137 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Performer = (select Performer from SongOverrides where Song = 2511137 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511137 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511137 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511137

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Performer = (select Performer from SongOverrides where Song = 2511132 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511132 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511132 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511132

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Performer = (select Performer from SongOverrides where Song = 2511133 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511133 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511133 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511133

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Performer = (select Performer from SongOverrides where Song = 2511134 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511134 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511134 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511134

update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Performer = (select Performer from SongOverrides where Song = 2511138 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song = 2511138 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song = 2511138 and country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where ID = 2511138
/*
--update song set Organization = (select top 1 Organization from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628'))),
Name = (select Name from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
Mix = (select Mix from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
Performer = (select Performer from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
Genre = (select Genre from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
PLine = (select PLine from SongOverrides where Song in (select Song from track where album = (select ID from album where gtin = '00619061399628')) and Mix = 'Urban AC' and Country = (select DefaultCountry from Album where gtin = '00619061399628')),
Process = 1, MediaPortalIncomplete = 0 where (ID in (select Song from Track where Album = (select ID from album where gtin = '00619061399628')) and Name = 'I Love You - (Urban AC)')
*/
--begin tran
--commit

/*
--begin tran
--rollback
insert SongCelebrity (Song, Celebrity, Role)
select 2511127, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511128, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511129, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511130, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511131, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511132, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511133, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511134, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511135, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511136, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511137, 207375, 1
insert SongCelebrity (Song, Celebrity, Role)
select 2511138, 207375, 1
*/

select Celebrity from AlbumCelebrity where Album = (select id from Album where gtin = '00619061399628')

select * from albumoverrides where album = 313724
select * from albumcelebrity where album = 313724
select * from albumgenre where album = 313724

--begin tran
--commit
declare @gtin nvarchar (14)
declare @AlbumCelebrity int
set @gtin = '00619061399628'
set @AlbumCelebrity = (select Celebrity from AlbumCelebrity where Album = (select id from Album where gtin = @gtin) and country = (select defaultcountry from album where gtin = @gtin))
insert AlbumCelebrity (Album, Celebrity, Role)
select (select ID from album where gtin = @gtin), @AlbumCelebrity, (select role from AlbumCelebrity where Album = (select id from album where gtin = @gtin) and country = (select defaultcountry from album where gtin = @gtin))


--insert AlbumGenre (Album, Genre, Sequence)
select (select ID from album where gtin = '00619061399628'), 19, 1



select * from celebrity where id = 54235
select * from celebrity where id = 252210

select * from albumgenre where album = 313724
select * from album where gtin = '00619061399628'
select * from albumoverrides where album = 313724 and country = (select defaultcountry from album where id = 313724)
select * from process
select genre, * from song where id in (select song from track where album in (select id from album where gtin in ('00619061399628')))
select * from songoverrides where song in (select song from track where album in (select id from album where gtin in ('00619061399628'))) and country = (select defaultcountry from album where id = 313724) order by name
select * from track where album = (select id from album where gtin = '00619061399628')
select * from trackoverrides where track in (select id from track where album = (select id from album where gtin = '00619061399628')) and country = (select defaultcountry from album where id = 313724)
select * from songcelebrity where song in (select song from track where album = 313724) and (country = 248 or country is null)