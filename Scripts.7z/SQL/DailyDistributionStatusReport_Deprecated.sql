use athenacomposite;
--New Distribution, Last 4 hours
DECLARE @DateRangeStart DateTime
DECLARE @DateRangeEnd DateTime
DECLARE @OnSaleDateRangeStart DateTime
DECLARE @OnSaleDateRangeEnd DateTime
DECLARE @eISBNs NVARCHAR(MAX)
DECLARE @ProhibitedPublisher NVARCHAR(MAX)

SET @DateRangeStart = '2014-11-03 16:00:00.000'
SET @DateRangeEnd = '2014-11-07 16:00:00.000'
-- 11-3 - 11-7
-- 11-7 - 11-10
SET @OnSaleDateRangeStart = NULL
SET @OnSaleDateRangeEnd = NULL
SET @ProhibitedPublisher = 'Scholastic Inc.'
SET @eISBNs = NULL


--*****
--***** Comment out Organization, Retailer, and eISBN WHERE clauses
--*****

IF OBJECT_ID('tempdb..#DistributionTitles') IS NOT NULL
    DROP TABLE #DistributionTitles

IF OBJECT_ID('tempdb..#DistributionDataset') IS NOT NULL
    DROP TABLE #DistributionDataset

IF OBJECT_ID('tempdb..#ProhibitedPublishers') IS NOT NULL
    DROP TABLE #ProhibitedPublishers

SELECT 
P.Name
INTO #ProhibitedPublishers
FROM (SELECT Name from AthenaComposite..Publishers WHERE Name = @ProhibitedPublisher
UNION
SELECT OrganizationName as Name from AthenaComposite..Organizations WHERE ParentOrganizationUid in (
SELECT OrganizationUid from AthenaComposite..Organizations where OrganizationName = @ProhibitedPublisher)
UNION
SELECT OrganizationName as Name from AthenaComposite..Organizations WHERE ParentOrganizationUid in (
SELECT OrganizationUid from AthenaComposite..Organizations WHERE ParentOrganizationUid in (
SELECT OrganizationUid from AthenaComposite..Organizations where OrganizationName = @ProhibitedPublisher))
UNION
SELECT OrganizationName as Name from AthenaComposite..Organizations WHERE ParentOrganizationUid in (
SELECT OrganizationUid from AthenaComposite..Organizations WHERE ParentOrganizationUid in (
SELECT OrganizationUid from AthenaComposite..Organizations WHERE ParentOrganizationUid in (
SELECT OrganizationUid from AthenaComposite..Organizations where OrganizationName = @ProhibitedPublisher)))
) P
SELECT
    pub.Name AS Publisher,
    [pi].Value AS ISBN,
    pr.ProductUid,
    r.RetailerUid,
    r.Name AS Retailer,
    MAX(dos.ProcessedAtUtc) AS ProcessedAtUtc
INTO
	#DistributionTitles
FROM
	AthenaComposite..DistributionOrderStatus dos
	INNER JOIN AthenaComposite..DistributionOrders do ON do.DistributionOrderUid = dos.DistributionOrderUid
	INNER JOIN AthenaComposite..ProductRevisions pr ON pr.ProductRevisionUid = do.ProductRevisionUid
	INNER JOIN AthenaComposite..Publishers pub ON pub.PublisherUid = pr.PublisherUid
	INNER JOIN AthenaComposite..Contracts c ON c.ContractUid = pr.ContractUid
	INNER JOIN AthenaComposite..Retailers r ON r.RetailerUid = c.RetailerUid
	INNER JOIN AthenaComposite..Product p ON p.ProductUid = pr.ProductUid
    INNER JOIN AthenaComposite..ProductIdentifier [pi] ON [pi].ProductUid = p.ProductUid
	INNER JOIN AthenaComposite..Organizations o on o.organizationUid = pub.organizationUid
WHERE
    [pi].ProductIdentifierType = 15                       -- ISBN-13
    AND pub.Name NOT IN (SELECT Name from #ProhibitedPublishers)     -- Part of the selected publisher hierarchy
--    AND (@eISBNs IS NULL OR [pi].Value IN (@eISBNList))   -- In the List of supplied ISBNs
    AND r.Name NOT IN ('Onix Feed','Bookshare','Ingram','Bowker','Mackin','Books-A-Million','Edelweiss','Bookish','Biblioshare','Flipkart')
GROUP BY
	pub.Name,
    pr.ProductUid,
    [pi].Value,
    r.Name,
    r.RetailerUid
HAVING                                                     -- Check the date range of the distribution
	MAX(dos.ProcessedAtUtc) BETWEEN @DateRangeStart AND @DateRangeEnd
	--OR
	--(@DateRangeStart IS NULL 
	--AND @DateRangeEnd IS NOT NULL
	--AND MAX(dos.ProcessedAtUtc) <= @DateRangeEnd)
	--OR
	--(@DateRangeStart IS NOT NULL 
	--AND @DateRangeEnd IS NULL
	--AND MAX(dos.ProcessedAtUtc) >= @DateRangeStart)
	--OR
	--(@DateRangeStart IS NULL AND @DateRangeEnd IS NULL)
    
SELECT DISTINCT
    Publisher,
    ISBN,
    coalesce(td.TitleStatement, te.TitleText) AS Title,
    CASE pfd.ProductFormDetailValue 
        WHEN 190 THEN 'Fixed' 
        WHEN 189 THEN 'Reflowable'
        ELSE 'Not Specified' END AS ContentType, 
    pd.Value AS OnSaleDate,
    dt.Retailer,
    dt.ProcessedAtUtc AS DistributionDate,
    ret.Title AS [EventName],
    dos.DistributionOrderStatusId
INTO
    #DistributionDataset
FROM
	#DistributionTitles dt
    INNER JOIN AthenaComposite..ProductRevisions pr ON 
        pr.ProductUid = dt.ProductUid
    INNER JOIN AthenaComposite..Contracts c ON 
        c.ContractUid = pr.ContractUid
        AND c.RetailerUid = dt.RetailerUid
    INNER JOIN AthenaComposite..DistributionOrders do ON do.ProductRevisionUid = pr.ProductRevisionUid
    INNER JOIN AthenaComposite..DistributionOrderStatus dos ON 
        dos.DistributionOrderUid = do.DistributionOrderUid
        AND dos.ProcessedAtUtc = dt.ProcessedAtUtc
	INNER JOIN AthenaComposite..Product p ON p.ProductUid = dt.ProductUid
/*    CROSS APPLY
        (SELECT
             TOP 1 ProductTitleId
         FROM
             AthenaComposite..ProductTitles
         WHERE
			 ProductUid = p.ProductUid
			 AND ValidUntilUtc IS NULL
	     ORDER BY
	         RetailerUid) pt
    INNER JOIN AthenaComposite..TitleDetails td ON pt.ProductTitleId = td.ProductTitleId
    INNER JOIN AthenaComposite..TitleElements te ON te.TitleDetailId = td.TitleDetailId*/
    INNER JOIN AthenaComposite..Asset a ON a.ProductUid = p.ProductUid
    CROSS APPLY 
        (SELECT 
             TOP 1 AssetOverrideUid
         FROM	
		     AthenaComposite..AssetOverride 
		 WHERE
	         AssetUid = a.AssetUid
	     ORDER BY  
	         RetailerUid) ao
    INNER JOIN AthenaComposite..AssetVersion av ON av.AssetOverrideUid = ao.AssetOverrideUid
	INNER JOIN AthenaComposite..TitleDetails td on td.assetVersionUid = av.assetVersionUid
	INNER JOIN AthenaComposite..TitleElements te ON te.TitleDetailId = td.TitleDetailId
    INNER JOIN AthenaComposite..PublishingDates pd ON pd.AssetVersionUid = av.AssetVersionUid
    LEFT OUTER JOIN AthenaComposite..ProductFormDetails pfd ON 
        pfd.AssetVersionUid = av.AssetVersionUid 
        AND pfd.ProductFormDetailValue IN (189, 190) 
    INNER JOIN AthenaEventLog..refEventType ret ON ret.EventTypeId = dos.ResultingEvent
WHERE
    dos.ResultingEventLevel <= 2
    AND ret.Code = 'DITC'
    AND av.ValidUntilUtc IS NULL                          -- Most recent version
    AND pd.PublishingDateRole = 1                         -- Main publishing date
    AND td.TitleTypeCode = 1                              -- Only report on the main title
    AND te.TitleText IS NOT NULL                          -- Only display the title elements with TitleText
 --   AND                                                   -- Check the On sale date range
	--((@OnSaleDateRangeStart IS NOT NULL 
	--	AND @OnSaleDateRangeEnd IS NOT NULL 
	--	AND 
	--	pd.Value BETWEEN @OnSaleDateRangeStart AND @OnSaleDateRangeEnd)
	--	OR
	--	(@OnSaleDateRangeStart IS NULL 
	--	AND @OnSaleDateRangeEnd IS NOT NULL
	--	AND pd.Value <= @OnSaleDateRangeEnd)
	--	OR
	--	(@OnSaleDateRangeStart IS NOT NULL 
	--	AND @OnSaleDateRangeEnd IS NULL
	--	AND pd.Value >= @OnSaleDateRangeStart)
	--	OR
	--	(@OnSaleDateRangeStart IS NULL AND @OnSaleDateRangeEnd IS NULL)
	--)
--select * from #DistributionDataset
SELECT DISTINCT
    Publisher [OrganizationName],
    ISBN [ProductOrdinal],
    Title,
    Retailer [RetailerName],
    ' ' as ' ',
    DistributionDate as [OrderCreatedAtUtc],
    DistributionDate as [PacketValidatedAtUtc],
    DistributionDate as [SyndicationStartedAtUtc],
    DistributionDate as [SyndicationCompletedAtUtc],
    DistributionOrderStatusId as [BatchNumber],
    DistributionDate as [TransferStartedAtUtc],
    DistributionDate as [TransferCompletedAtUtc],
    DistributionDate as [EventCreatedAt],
    dt.EventName
FROM
    #DistributionDataset dt    
ORDER BY  
OrganizationName,
ProductOrdinal,
RetailerName,
EventCreatedAt
