/*use AthenaReportCatalog;

select * from ReportTypePublishers rp
join AthenaDistribution..publishers p on p.PublisherUid = rp.PublisherUid
join ReportTypeConfigurations rc on rc.ReportTypeConfigurationUid = rp.ReportTypeConfigurationUid
where p.name like '%scholastic%'
and rp.Enabled = 1
and rc.Enabled = 1
and rc.Name = 'Preorder Status Email'

begin tran
update rp set Enabled =0 
from ReportTypePublishers rp
join AthenaDistribution..publishers p on p.PublisherUid = rp.PublisherUid
join ReportTypeConfigurations rc on rc.ReportTypeConfigurationUid = rp.ReportTypeConfigurationUid
where p.name like '%scholastic%'
and rp.Enabled = 1
and rc.Enabled = 1
and rc.Name = 'Preorder Status Email'
*/
/*

use ReportServer
select sc.Name [Subscription], c.Name [Report]--, substring(ExtensionSettings, (patindex('%<Value>%', ExtensionSettings) + len('<Value>')), (patindex('%</Value>%', ExtensionSettings) - patindex('%<Value>%', ExtensionSettings) - len('<Value>'))) EmailList 
,s.* from Subscriptions s
join reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join Schedule sc on sc.scheduleId = rs.ScheduleId
join Catalog c on c.ItemId = s.Report_OID

*/

USE AthenaComposite;
if object_ID ('tempdb..#ReportResultsEM') is not null
drop table #ReportResultsEM
GO
if object_ID ('tempdb..#ErrFile') is not null
drop table #ErrFile
GO

declare @DeliveryExtension nvarchar(50) = 'Report Server Email'
declare @Schedule nvarchar(100) = 'Scholastic Daily Reports'
declare @Report nvarchar(100) = 'Preorder Status'
--Failed Distribution Email
--Preorder Status
--Ingestion Email
--Distribution Email
--Content Validation Errors Email
create table #ReportResultsEM (SubscriptionUid uniqueidentifier, [To] nvarchar(2000), ReplyTo nvarchar(200), IncludeReport nvarchar(10), IncludeLink nvarchar(10), RenderFormat nvarchar(10), Subject nvarchar(500), Priority nvarchar(15), Organization uniqueidentifier, PublisherUid uniqueidentifier, Filename nvarchar(100), DateRangeStart datetime, DateRangeEnd datetime)
CREATE TABLE #ErrFile (ExecError INT)
declare @cmd nvarchar(max), @ExecError INT
declare @queryToRun table (SubscriptionId uniqueidentifier, Query nvarchar(max))
insert @queryToRun (SubscriptionID, Query)
select s.SubscriptionId, substring(cast(DataSettings as nvarchar(max)),(charindex('<CommandText>',cast(DataSettings as nvarchar(max))) + 13),(charindex('</CommandText>',cast(DataSettings as nvarchar(max))) - charindex('<CommandText>',cast(DataSettings as nvarchar(max))) - 13)) Query
 from ReportServer..Subscriptions s
 join ReportServer..reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join ReportServer..Schedule sc on sc.scheduleId = rs.ScheduleId
join ReportServer..Catalog c on c.ItemId = s.Report_OID
 where DeliveryExtension = @DeliveryExtension
 and sc.Name = @Schedule
 and c.Name = @Report

--select * from @queryToRun
select top 1 @cmd = replace(Query,'replace(rtc.Name + ''_'' + SUBSTRING(replace(replace(replace(CONVERT(varchar,GETDATE(),120),''-'',''''),'':'',''''),'' '',''''),0,11),'' '','''') as  [Filename],','/*replace(rtc.Name + ''_'' + SUBSTRING(replace(replace(replace(CONVERT(varchar,GETDATE(),120),''-'',''''),'':'',''''),'' '',''''),0,11),'' '','''') as  [Filename],*/') from @queryToRun
--select @cmd
insert #ReportResultsEM ([To], ReplyTo, IncludeReport, IncludeLink, RenderFormat, Subject, Priority, Organization, PublisherUid, /*FileName, */DateRangeStart, DateRangeEnd)
exec (@cmd)
set @ExecError = (SELECT * FROM #ErrFile)
--select * from #ReportResultsEM
update #ReportResultsEM set SubscriptionUid = SubscriptionId from @queryToRun where SubscriptionUid is NULL
select p.Name Publisher, po.OrganizationName Parent, c.Name Report, sc.Name Schedule, s.Description, s.LastRunTime, LastStatus, [To] Recipient, ReplyTo from #ReportResultsEM em
join ReportServer..Subscriptions s on s.subscriptionId = em.SubscriptionUid
join ReportServer..reportSchedule rs on rs.SubscriptionID = s.SubscriptionID
join ReportServer..Schedule sc on sc.scheduleId = rs.ScheduleId
join ReportServer..Catalog c on c.ItemId = s.Report_OID
join AthenaComposite..publishers p on p.publisherUid = em.PublisherUid
join AthenaComposite..organizations o on o.organizationUid = p.OrganizationUid
left join AthenaComposite..organizations po on po.OrganizationUid = o.ParentOrganizationUid
ORDER by p.Name



--commit