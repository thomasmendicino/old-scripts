declare @Scholastic table (orgUid uniqueidentifier)

declare @organizationName nvarchar(100)
select @organizationname = 'Scholastic inc.'
;with org as (
select o.organizationName, o.ParentOrganizationUid from organizations o
where organizationname = @organizationName
union all
select po.organizationname, po.ParentOrganizationUid from organizations po
join org on org.parentOrganizationUId = po.organizationUid
),
child as (
select po.organizationName, po.OrganizationUid from organizations po
where organizationName = @organizationName
union all
select o.organizationName, o.organizationUId from organizations o
join child c on c.organizationUid = o.parentOrganizationUid)
insert @Scholastic
select organizationUId from org join organizations o on o.organizationName = org.organizationName
union all
select o.organizationUid from child join organizations o on o.organizationName = child.organizationName
EXCEPT
select '00000000-0000-0000-0000-000000000001'

;with AppleDelivered as (
select distinct p.Ordinal from product p
join @Scholastic s on s.orgUid = p.OrganizationUid
join ProductRevisions pr on pr.ProductUid = p.ProductUid
join DistributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join DistributionOrderStructureGroups dsg on dsg.DistributionOrderUid = do.DistributionOrderUid
join contracts c on c.contractUId = pr.ContractUid 
join retailers r on r.RetailerUid = c.RetailerUid
join DistributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join refEventType re on re.EventTypeId = dos.ResultingEvent
where r.Code = 'APC'),
OysterAlreadyDelivered as (
select distinct p.ordinal from product p
join @Scholastic s on s.orgUid = p.OrganizationUid
join ProductRevisions pr on pr.ProductUid = p.ProductUid
join distributionOrders do on do.ProductRevisionUid = pr.ProductRevisionUid
join DistributionOrderStatus dos on dos.DistributionOrderUid = do.DistributionOrderUid
join refEventType rt on rt.EventTypeId = dos.ResultingEvent
join contracts c on c.contractUid = pr.ContractUid
join Retailers r on r.RetailerUid = c.RetailerUid
where rt.Code = 'DITC' and r.Name = 'Oyster')
select distinct p.ordinal from product p
join asset a on a.ProductUid = p.ProductUid
join assetOverride ao on ao.AssetUid = a.assetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join resources r on r.ResourceUid = av.ResourceUid
join publishers pub on pub.OrganizationUid = p.OrganizationUid
join @Scholastic s on s.orgUid = p.OrganizationUid
join ProductForms pf on pf.AssetVersionUid = av.AssetVersionUid
where p.ordinal not in (select ordinal from AppleDelivered) and 
p.Ordinal not in (select ordinal from OysterAlreadyDelivered) and 
av.ValidUntilUtc is NULL AND
pf.ProductFormTypeValue > 21
