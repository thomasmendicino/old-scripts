----------------------Step 1.
ALTER TABLE OnixResources 
ALTER COLUMN [Content] xml NOT NULL
IF EXISTS (SELECT * FROM sys.xml_schema_collections WHERE name = 'Onix302Reference') 
                                    BEGIN
									PRINT 'Dropping Old Schema'
                                    DROP XML SCHEMA COLLECTION Onix302Reference
                                    END


---------------------Step 2.
DECLARE @onixReference varchar(MAX)
SELECT @onixReference = xmlCol

-- adjust path to point to the resource accesible from database server
FROM OPENROWSET(Bulk 'C:\Tools\ONIX_BookProduct_3.0.2_reference_SQlServer.xsd', SINGLE_CLOB)
as results(xmlCol)

DECLARE @onixSchema XML
SET @onixSchema = CONVERT(XML, @onixReference)

CREATE XML SCHEMA COLLECTION Onix302Reference AS @onixSchema
GO


--------------------Step 3.
ALTER TABLE OnixResources 
ALTER COLUMN [Content] xml(Onix302Reference)

--SELECT * FROM sys.xml_schema_collections WHERE name = 'Onix302Reference'
