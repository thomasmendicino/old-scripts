begin tran
update ft set HostName = 'ftp.ingrooves.com', ProtocolType = 1, PortNumber = 21, StartingDirectory = 'RetailersTestUploadNewDistro/Oyster/INscribeDigital', Username = 'ingroovestest', Password = 'ingrooves'
from TransferServiceFtpEndpoints ft 
join DistributionContracts dc on dc.TransferServiceEndpointUid = ft.TransferServiceEndpointUid
where dc.name like '%oyster%'

update ft set HostName = 'ftp.oysterbooks.com', ProtocolType = 1, PortNumber = 21, StartingDirectory = '/', Username = 'Inscribe', Password = 'Inscr!beD!g!tal2014'
from TransferServiceFtpEndpoints ft 
join DistributionContracts dc on dc.TransferServiceEndpointUid = ft.TransferServiceEndpointUid
where dc.name like '%oyster%'