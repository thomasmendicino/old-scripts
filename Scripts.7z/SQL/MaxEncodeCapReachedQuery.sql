select partnername as [DAVe Business Partners with Encode Cap reached] from syndicationorder so
where orderstate = 1
and orderstatemessage like '%Order was not selected because maximum Encode Cap%'
group by partnername

