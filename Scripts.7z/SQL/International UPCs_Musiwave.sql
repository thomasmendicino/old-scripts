select distinct ar.album, album.name, album.gtin from arearestriction ar
inner join album on ar.album = album.id
inner join track t on album.id = t.album
inner join tracksyndication ts on ts.track = t.id
inner join contract c on c.id = ts.contract
inner join syndication s on ts.syndication = s.id
inner join musicservice ms on s.musicservice = ms.id
where ar.country not in (250,44)
and ms.name = 'Musiwave'
and c.contractauthority in (9,26)
group by ar.album, album.name, album.gtin
order by album.name

select top 10 * from syndication
select * from musicservice where name like '%musiwave%'

