;with parents as (
select OrganizationName, OrganizationUid from Organizations
where ParentOrganizationUid = '00000000-0000-0000-0000-000000000001'),
Files as (
select distinct r.[Length] SizeInBytes, p.OrganizationUid 
from Product p
join asset a on a.ProductUid = p.ProductUid
join AssetOverride ao on ao.AssetUid = a.AssetUid
join AssetVersion av on av.AssetOverrideUid = ao.AssetOverrideUid
join Resources r on r.ResourceUid = av.ResourceUid),
fs as
(select 
	Parents.OrganizationName Organization,
	SizeInBytes
from parents
join Files f on f.organizationUid = parents.OrganizationUId
UNION
select 
	parents.OrganizationName Organization,
	SizeInBytes
from parents 
join organizations children on children.ParentOrganizationUid = parents.OrganizationUid
join Files f on f.organizationUid = children.OrganizationUId
UNION
select
	parents.OrganizationName Organization,
	SizeInBytes
from parents 
join organizations children on children.ParentOrganizationUid = parents.OrganizationUid
join organizations grandchildren on grandchildren.ParentOrganizationUid = children.OrganizationUid
join Files f on f.organizationUid = grandchildren.OrganizationUId),
FScount as 
(SELECT
	Organization, sum(SizeInBytes) TotalBytes
	from fs
	group by Organization)
--select * from FSCount order by TotalBytes desc

select Organization, 
cast(sum(TotalBytes) / (1024.00 * 1024 * 1024) as decimal(18,2)) AS [DiskSpaceUsage(GB)]
from 
	(select case when Sequence < 10 then Organization else 'Other' end as Organization, t.TotalBytes, Sequence from 
		(select Organization, TotalBytes, ROW_NUMBER() over (order by TotalBytes desc, Organization asc) as Sequence from FScount
		) t
	) t2
group by t2.Organization, (case when Sequence < 10 then cast(TotalBytes as nvarchar(20)) else Organization end)
order by
	case
		when Organization <> 'Other' then (case when Sequence < 10 then cast(TotalBytes as nvarchar(20)) else Organization end) END desc,
	case 
		when Organization = 'Other' then (case when Sequence < 10 then cast(TotalBytes as nvarchar(20)) else Organization end) END asc