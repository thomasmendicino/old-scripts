--
--BookTitle ISBN MainAuthor Imprint ImprintID Parent
--where first distribution of ISBN has occurred within the last 1 month

DECLARE @DateRangeStart datetime
DECLARE @DateRangeEnd datetime

SELECT @DateRangeStart = DATEADD(month, DATEDIFF(month, 0, GETDATE())-1, 0)
SELECT @DateRangeEnd = DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0)

;with MinSyndications AS (
	SELECT 
		p.Ordinal
		, min(dos.CreatedAtUtc) CreatedAtUtc
	FROM 
		Product p
	INNER JOIN ProductRevisions pr 
		on pr.ProductUid = p.ProductUid
	INNER JOIN DistributionOrders do
		on do.ProductRevisionUid = pr.ProductRevisionUid
	INNER JOIN DistributionOrderStatus dos
		on dos.DistributionOrderUid = do.DistributionOrderUid
	INNER JOIN Contracts c
		on c.ContractUid = pr.ContractUid
	INNER JOIN Retailers r
		on r.RetailerUid = c.RetailerUid
	WHERE 
		r.Code <> 'INX'
		AND dos.ResultingEvent = 110 --Distribution Order Transfer Complete
	GROUP BY 
		p.Ordinal
	HAVING 
		min(dos.CreatedAtUtc) BETWEEN @DateRangeStart and @DateRangeEnd),
SingleMainTitle AS (
	SELECT DISTINCT
		p.Ordinal
		, COALESCE(te.TitleText, te.TitlePrefix + ' ' + te.TitleWithoutPrefix) as Title
	FROM
		Product p
	INNER JOIN MinSyndications ms 
		on ms.Ordinal = p.Ordinal
	INNER JOIN Asset a
		on a.ProductUid = p.ProductUid
	CROSS APPLY (
		SELECT TOP 1 AssetOverrideUid 
		FROM AssetOverride
		WHERE AssetOverride.AssetUid = a.AssetUid
		ORDER BY RetailerUid ASC) ao
	INNER JOIN AssetVersion av
		on av.AssetOverrideUid = ao.AssetOverrideUid
	INNER JOIN TitleDetails td
		on td.AssetVersionUid = av.AssetVersionUid
	CROSS APPLY (
		SELECT TOP 1 TitleElementId 
		FROM TitleElements 
		WHERE TitleElements.TitleDetailId = td.TitleDetailId
		ORDER BY TitleText DESC) dte
	INNER JOIN TitleElements te
		ON te.TitleElementId = dte.TitleElementId
	WHERE av.ValidUntilUtc is NULL),
SingleMainAuthor AS (
	SELECT DISTINCT
		p.Ordinal
		, COALESCE(STUFF((select ', ' + c2.PersonName 
				FROM Contributors c2
				INNER JOIN ContributorRoles cr2 on cr2.ContributorId = c2.ContributorId
				WHERE cr2.ContributorRoleType = 1
					AND c2.AssetVersionUid = c.AssetVersionUid
				FOR XML PATH ('')),1,1,''), ' ' + c.PersonName, ' ')  as MainAuthor
	FROM 
		Product p
	INNER JOIN MinSyndications ms 
		on ms.Ordinal = p.Ordinal
	INNER JOIN Asset a
		on a.ProductUid = p.ProductUid
	CROSS APPLY (
		SELECT TOP 1 AssetOverrideUid 
		FROM AssetOverride
		WHERE AssetOverride.AssetUid = a.AssetUid
		ORDER BY RetailerUid ASC) ao
	INNER JOIN AssetVersion av
		on av.AssetOverrideUid = ao.AssetOverrideUid
	INNER JOIN Contributors c 
		on c.AssetVersionUid = av.AssetVersionUid
	INNER JOIN ContributorRoles cr
		on cr.ContributorId = c.ContributorId
	WHERE av.ValidUntilUtc is NULL)

SELECT Title, p.Ordinal as ISBN, ltrim(MainAuthor) as MainAuthor, o.OrganizationName as Imprint, --t.ID as ImprintID, 
case 
	when po.OrganizationName = 'INscribe Digital' then ' ' 
	else po.OrganizationName 
end as Parent
FROM
	Product P
INNER JOIN MinSyndications ms
	on ms.Ordinal = p.Ordinal
INNER JOIN SingleMainAuthor sma
	on sma.Ordinal = p.Ordinal
INNER JOIN SingleMainTitle smt
	on smt.Ordinal = p.Ordinal
INNER JOIN Organizations o
	on o.OrganizationUid = p.OrganizationUid
INNER JOIN Organizations po
	on po.OrganizationUid = o.ParentOrganizationUid

