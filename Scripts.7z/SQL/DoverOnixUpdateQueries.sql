--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'
/***
To Start
***/

--update p set OrganizationUId = @Courier from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUId = @Dover
--commit
--rollback
/****
Run #1 Setup
***/
--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Dover from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Courier and ordinal < 9780486132747
--commit
--rollback
/***
Run Migrator HERE
***/
--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Courier from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Dover and ordinal < 9780486132747
--commit
--rollback
/***
Return to base. Setup Run #2.
****/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Dover from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Courier and ordinal between 9780486132747 and 9780486146980
--commit
--rollback
/***
Run Migrator HERE
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Courier from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Dover and ordinal between 9780486132747 and 9780486146980
--commit
--rollback
/***
Return to base. Setup Run #3
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Dover from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Courier and ordinal between 9780486146980 and 9780486163598
--commit
--rollback
/***
Run Migrator HERE
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Courier from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Dover and ordinal between 9780486146980 and 9780486163598
--commit
--rollback
/***
Return to base. Setup Run #4
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Dover from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Courier and ordinal between 9780486163604 and 9780486297682
--commit
--rollback
/***
Run Migrator HERE
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Courier from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Dover and ordinal between 9780486163604 and 9780486297682
--commit
--rollback
/***
Return to base. Setup Run #5
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Dover from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Courier and ordinal between 9780486297712 and 9780486431765
--commit
--rollback
/***
Run Migrator HERE
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Courier from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Dover and ordinal between 9780486297712 and 9780486431765
--commit
--rollback
/***
Return to base. Setup Run #6
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Dover from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Courier and ordinal > 9780486431772
--commit
--rollback
/***
Run Migrator HERE
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUid = @Courier from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUid = @Dover and ordinal > 9780486431772
--commit
--rollback
/***
Return to base.
Finish off
***/

--begin tran
--declare @Dover uniqueidentifier
--declare @Courier uniqueidentifier

--select @Dover = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Dover Publications'
--select @Courier = organizationUId from AthenaSecurity..Organizations where OrganizationName = 'Courier'

--update p set OrganizationUId = @Dover from athenaproductCatalog..product p
--join athenasecurity..organizations o on o.organizationUid = p.organizationUId
--where p.OrganizationUId = @Courier
--commit
--rollback


select * from athenaproductCatalog..product p
join athenasecurity..organizations o on o.organizationUid = p.organizationUId
join athenaproductCatalog..asset a on a.productUid = p.productUid
join athenaproductCatalog..assetOverride ao on ao.assetUid = a.assetUid
join athenaproductCatalog..assetversion av on av.assetOverrideUId = ao.assetOverrideUid
where o.organizationName = 'dover publications' and a.resourceContentType = 100 and ordinal < 9780486132747


select * from athenaproductCatalog..product p
join athenasecurity..organizations o on o.organizationUid = p.organizationUId
join athenaproductCatalog..asset a on a.productUid = p.productUid
join athenaproductCatalog..assetOverride ao on ao.assetUid = a.assetUid
join athenaproductCatalog..assetversion av on av.assetOverrideUId = ao.assetOverrideUid
where o.organizationName = 'dover publications' and a.resourceContentType = 100 and ordinal between 9780486132747 and 9780486146980


select p.ordinal from athenaproductCatalog..product p
join athenasecurity..organizations o on o.organizationUid = p.organizationUId
join athenaproductCatalog..asset a on a.productUid = p.productUid
join athenaproductCatalog..assetOverride ao on ao.assetUid = a.assetUid
join athenaproductCatalog..assetversion av on av.assetOverrideUId = ao.assetOverrideUid
where o.organizationName = 'dover publications' and a.resourceContentType = 100 and ordinal between 9780486146980 and 9780486163598


select * from athenaproductCatalog..product p
join athenasecurity..organizations o on o.organizationUid = p.organizationUId
join athenaproductCatalog..asset a on a.productUid = p.productUid
join athenaproductCatalog..assetOverride ao on ao.assetUid = a.assetUid
join athenaproductCatalog..assetversion av on av.assetOverrideUId = ao.assetOverrideUid
where o.organizationName = 'dover publications' and a.resourceContentType = 100 and ordinal between 9780486163598 and 9780486297682


select * from athenaproductCatalog..product p
join athenasecurity..organizations o on o.organizationUid = p.organizationUId
join athenaproductCatalog..asset a on a.productUid = p.productUid
join athenaproductCatalog..assetOverride ao on ao.assetUid = a.assetUid
join athenaproductCatalog..assetversion av on av.assetOverrideUId = ao.assetOverrideUid
where o.organizationName = 'dover publications' and a.resourceContentType = 100 and ordinal between 9780486297682 and 9780486431765


select * from athenaproductCatalog..product p
join athenasecurity..organizations o on o.organizationUid = p.organizationUId
join athenaproductCatalog..asset a on a.productUid = p.productUid
join athenaproductCatalog..assetOverride ao on ao.assetUid = a.assetUid
join athenaproductCatalog..assetversion av on av.assetOverrideUId = ao.assetOverrideUid
where o.organizationName = 'dover publications' and a.resourceContentType = 100 and ordinal > 9780486431765