USE AthenaUATAssetProcessor
BEGIN TRAN  

--First delete the importFolderConfigurations that are not associated with any FolderObjects. These will necessarily be duplicates that should be deleted.
;WITH
DuplicateImportFolderConfigurations AS
(
SELECT
    ic.PublisherUid,
    ic.FolderProcessorId
FROM ImportFolderConfigurations ic
GROUP BY    ic.FolderProcessorId,
            ic.PublisherUid
HAVING COUNT(*) > 1),
NoFolderObjects AS
(
SELECT 
	ic.ImportFolderConfigurationUid
FROM ImportFolderConfigurations ic
	INNER JOIN DuplicateImportFolderConfigurations dfc
		ON dfc.PublisherUid = ic.PublisherUid
			AND dfc.FolderProcessorId = ic.FolderProcessorId
	LEFT OUTER JOIN FolderObjects fo
		ON fo.ImportFolderConfigurationUid = ic.ImportFolderConfigurationUid
WHERE fo.FolderObjectUid IS NULL
),
Ranking AS
(
SELECT
    ROW_NUMBER() OVER (PARTITION BY ic.PublisherUid, ic.FolderProcessorId ORDER BY ExternalDropHost ASC, ic.PublisherUid, ic.FolderProcessorId) AS Rank,
    ic.ImportFolderConfigurationUid
FROM DuplicateImportFolderConfigurations dic
	JOIN ImportFolderConfigurations ic
	    ON dic.FolderProcessorId = ic.FolderProcessorId
			AND dic.PublisherUid = ic.PublisherUid
	JOIN NoFolderObjects nf on nf.ImportFolderConfigurationUid = ic.ImportFolderConfigurationUid
)
-- Comment the line below out
DELETE ic
--SELECT    *
FROM Ranking r
JOIN ImportFolderConfigurations ic
    ON r.ImportFolderConfigurationUid = ic.ImportFolderConfigurationUid
WHERE r.Rank > 1


--Next delete the importFolderConfigurations that are still duplicates, but neither of the folder processors have folder objects
;WITH
DuplicateImportFolderConfigurations AS
(
SELECT
    ic.PublisherUid,
    ic.FolderProcessorId
FROM ImportFolderConfigurations ic
GROUP BY    ic.FolderProcessorId,
            ic.PublisherUid
HAVING COUNT(*) > 1),
Ranking AS
(
SELECT
    ROW_NUMBER() OVER (PARTITION BY ic.PublisherUid, ic.FolderProcessorId ORDER BY ExternalDropHost ASC, ic.PublisherUid, ic.FolderProcessorId) AS Rank,
    ic.ImportFolderConfigurationUid
FROM DuplicateImportFolderConfigurations dic
	JOIN ImportFolderConfigurations ic
	    ON dic.FolderProcessorId = ic.FolderProcessorId
			AND dic.PublisherUid = ic.PublisherUid
)
-- Comment the line below out
DELETE ic
--SELECT    *
FROM Ranking r
JOIN ImportFolderConfigurations ic
    ON r.ImportFolderConfigurationUid = ic.ImportFolderConfigurationUid
WHERE r.Rank > 1


--Double check there are no more duplicates 
;WITH
DuplicateImportFolderConfigurations AS
(
SELECT
    ic.PublisherUid,
    ic.FolderProcessorId
FROM ImportFolderConfigurations ic
GROUP BY    ic.FolderProcessorId,
            ic.PublisherUid
HAVING COUNT(*) > 1),
Ranking AS
(
SELECT
    ROW_NUMBER() OVER (PARTITION BY ic.PublisherUid, ic.FolderProcessorId ORDER BY ExternalDropHost ASC, ic.PublisherUid, ic.FolderProcessorId) AS Rank,
    ic.ImportFolderConfigurationUid
FROM DuplicateImportFolderConfigurations dic
	JOIN ImportFolderConfigurations ic
	    ON dic.FolderProcessorId = ic.FolderProcessorId
			AND dic.PublisherUid = ic.PublisherUid
)
-- Comment the line below out
SELECT    *
FROM Ranking r
JOIN ImportFolderConfigurations ic
    ON r.ImportFolderConfigurationUid = ic.ImportFolderConfigurationUid
WHERE r.Rank > 1
