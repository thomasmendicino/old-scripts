USE AthenaComposite;
declare @Title nvarchar(1000) = 'Asgard%hammer'
select 
	p.Ordinal
	, o.OrganizationName
	, te.*
	, * 
from TitleElements te
	join TitleDetails td on td.TitleDetailId = te.TitleDetailId
	join AssetVersion av on av.AssetVersionUid = td.AssetVersionUid
	join AssetOverride ao on ao.AssetOverrideUid = av.AssetOverrideUid
	join asset a on a.AssetUid= ao.AssetUid
	join product p on p.ProductUid = a.ProductUid
where 
	TitleText like '%' + @Title + '%'
	OR TitlePrefix like '%' + @Title + '%'
	OR TitleWithoutPrefix like '%' + @Title + '%'
