/*
Clean up for the bug in INDMA-4258.
Kobo Trend reports were being imported with the wrong transaction date, in which the day and month were switched.
*/

CREATE TABLE #NewDates (OldTranDate nvarchar(30),NewTranDate nvarchar(30), Sheet nvarchar(100))
INSERT #NewDates
select distinct cast(TransactionDate as nvarchar(30)), substring(cast(TransactionDate as nvarchar(30)),1,4) + '-' + substring(cast(TransactionDate as nvarchar(30)),9,2) + '-' + substring(cast(TransactionDate as nvarchar(30)),6,2), tt.SheetName from trendTransaction tt
inner join trendStatement ts on ts.id = tt.trendStatement
inner join trendFileConfiguration tfc on tfc.id = ts.trendFileConfiguration
inner join musicservice ms on ms.id = tfc.musicservice
where ms.name = 'Kobo'
and tt.SheetName <> 'Kobo'
and substring(cast(TransactionDate as nvarchar(30)),6,2) + substring(cast(TransactionDate as nvarchar(30)),9,2) <> substring(tt.SheetName, 15, 4)

UPDATE TrendTransaction SET TransactionDate = #NewDates.NewTranDate
FROM TrendTransaction 
INNER JOIN #NewDates on #NewDates.Sheet = TrendTransaction.SheetName AND #NewDates.OldTranDate = TrendTransaction.TransactionDate
