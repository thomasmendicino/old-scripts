select * from xxx_athenaMigratedOrgs
'2013-10-11 12:20:00.00'
--begin tran
--insert xxx_AthenaMigratedOrgs (Org, MigratedAt)
select id, '2013-10-11 12:20:00.00' from organization where name = 'ebooktest'
--commit
--ebooktest

 declare @LastRunTime datetime
                                                        select @LastRunTime = MigratedAt FROM xxx_AthenaMigratedOrgs x 
                                                        INNER JOIN Organization o on o.id = x.org WHERE o.Name = 'ebooktest'
                                                        ;with #SingleMainArtist as
                                                            (select ac.Album, min(ac.ID) [AlbCelId]
                                                            from AlbumCelebrity ac
                                                            join Album a on a.id = ac.album
                                                            join AthenaAlbum aa on aa.album = a.id
                                                            where ac.Role = 1
                                                            group by ac.Album)
                                                        select distinct a.Name [Title], rtrim(GTIN) [ISBN], c.Name [Author], o.Name [Imprint], o.Id [ImprintID], po.Name [Parent] from album a 
                                                            inner join AthenaAlbum AA on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            inner join AlbumCelebrity ac on ac.album = a.id
                                                            inner join Celebrity c on c.id = ac.Celebrity
                                                            inner join Role r on r.id = ac.Role
                                                            left outer join organization po on po.id = o.parent
                                                            inner join #SingleMainArtist sma on sma.AlbCelId = ac.ID
                                                            where r.Name = 'Main Artist'
                                                            and A.CreatedAt > @LastRunTime
                                                            and substring(ai.FilePath,11,2) < '15'
                                                            order by rtrim(a.gtin)
										
                                                         

declare @lastRunAt datetime
set @lastRunAt = '2013-10-11 12:20:00.00'
;with #SingleMainArtist as
                                                            (select ac.Album, min(ac.ID) [AlbCelId]
                                                            from AlbumCelebrity ac
                                                            join Album a on a.id = ac.album
                                                            join AthenaAlbum aa on aa.album = a.id
                                                            where ac.Role = 1
                                                            group by ac.Album),
#NewSyndications as (select a.GTIN ISBN, o.Name Imprint, o.ID ImprintId, po.Name Parent, rtrim(ms.Name) Retailer from album a
															inner join athenaAlbum aa on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            left outer join AlbumSyndicationView asv on asv.Album = a.id
                                                            left outer join MusicService ms on ms.id = asv.musicservice
                                                            left outer join organization po on po.id = o.parent
                                                            where asv.SyndicatedAt > @lastRunAt
                                                            except
                                                            select a.GTIN ISBN, o.Name Imprint, o.ID ImprintId, po.Name Parent, rtrim(ms.Name) Retailer from album a
															inner join athenaAlbum aa on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            left outer join AlbumSyndicationView asv on asv.Album = a.id
                                                            left outer join MusicService ms on ms.id = asv.musicservice
                                                            left outer join organization po on po.id = o.parent
                                                            where asv.SyndicatedAt <= @lastRunAt),
#INDMASyndications as (select distinct a.GTIN ISBN, o.Name Imprint, o.ID ImprintId, po.Name Parent, rtrim(ms.Name) Retailer from album a
                                                            inner join organization o on o.id = a.organization
                                                            inner join xxx_AthenaMigratedOrgs amo on amo.org = o.id
                                                            inner join albumSyndicationView asv on asv.album = a.id
                                                            inner join musicService ms on ms.id = asv.musicservice
                                                            left outer join organization po on po.id = o.parent
                                                            where asv.SyndicatedAt < amo.MigratedAt)
                                                    select distinct a.Name [Title], rtrim(GTIN) [ISBN], c.Name [Author], o.Name [Imprint], o.ID ImprintId, po.Name Parent, coalesce(rtrim(ms.Name),' ') [Retailer] from album a 
                                                            inner join AthenaAlbum AA on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            inner join AlbumCelebrity ac on ac.album = a.id
                                                            inner join Celebrity c on c.id = ac.Celebrity
                                                            inner join Role r on r.id = ac.Role
                                                            inner join #SingleMainArtist sma on sma.AlbCelId = ac.ID
                                                            inner join AlbumSyndicationView asv on asv.Album = a.id
                                                            inner join MusicService ms on ms.id = asv.musicservice
                                                            inner join #NewSyndications ns on ns.ISBN = a.GTIN and ns.Imprint = o.Name and ns.Retailer = rtrim(ms.Name)
                                                            left outer join organization po on po.id = o.parent
                                                            where r.Name = 'Main Artist'
                                                            UNION
													select distinct a.Name [Title], rtrim(GTIN) [ISBN], c.Name [Author], o.Name [Imprint], o.ID ImprintId, po.Name [Parent], coalesce(rtrim(ms.Name),' ') [Retailer] from album a 
                                                            inner join AthenaAlbum AA on AA.Album = a.ID
                                                            inner join AthenaImport AI on AI.ID = AA.AthenaImport
                                                            inner join organization o on o.id = a.organization
                                                            inner join AlbumCelebrity ac on ac.album = a.id
                                                            inner join Celebrity c on c.id = ac.Celebrity
                                                            inner join Role r on r.id = ac.Role
                                                            inner join #SingleMainArtist sma on sma.AlbCelId = ac.ID
                                                            left outer join AlbumSyndicationView asv on asv.album = a.id
                                                            left outer join MusicService ms on ms.id = asv.musicservice
                                                            left outer join organization po on po.id = o.parent
                                                            where asv.SyndicatedAt is NULL
                                                            and a.CreatedAt > @lastRunAt and '2013-10-15 00:00:00.000'
                                                            EXCEPT
                                                    select distinct a.Name [Title], rtrim(GTIN) [ISBN], c.Name [Author], o.Name [Imprint], o.ID ImprintId, po.Name [Parent], coalesce(rtrim(ms.Name),' ') [Retailer] from album a 
                                                            inner join organization o on o.id = a.organization
                                                            inner join albumCelebrity ac on ac.album = a.id
                                                            inner join celebrity c on c.id = ac.celebrity
                                                            inner join albumSyndicationView asv on asv.album = a.id
                                                            inner join musicservice ms on ms.id = asv.musicservice
                                                            inner join #INDMASyndications ins on ins.ISBN = a.GTIN and ins.Imprint = o.Name and ins.Retailer = rtrim(ms.name)
                                                            left outer join organization po on po.id = o.parent
                                                            order by o.Name, a.Name
                                                            
                                                            